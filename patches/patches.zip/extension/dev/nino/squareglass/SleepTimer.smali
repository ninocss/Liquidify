.class public final Ldev/nino/squareglass/SleepTimer;
.super Ljava/lang/Object;
.source "SleepTimer.java"


# static fields
.field private static alarm:Landroid/app/AlarmManager$OnAlarmListener;

.field private static endPoll:Ljava/lang/Runnable;

.field private static fallback:Ljava/lang/Runnable;

.field private static final main:Landroid/os/Handler;

.field private static manager:Landroid/app/AlarmManager;

.field private static player:Lbi/e;

.field private static final timer:Ldev/nino/squareglass/SleepDeadline;

.field private static final trackEnd:Ldev/nino/squareglass/TrackEndGate;

.field private static visible:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Dialog;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static bridge synthetic -$$Nest$sfgetmain()Landroid/os/Handler;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetplayer()Lbi/e;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->player:Lbi/e;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgettimer()Ldev/nino/squareglass/SleepDeadline;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->timer:Ldev/nino/squareglass/SleepDeadline;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgettrackEnd()Ldev/nino/squareglass/TrackEndGate;
    .locals 1

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->trackEnd:Ldev/nino/squareglass/TrackEndGate;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$smpause()V
    .locals 0

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->pause()V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 16
    new-instance v0, Ldev/nino/squareglass/SleepDeadline;

    invoke-direct {v0}, Ldev/nino/squareglass/SleepDeadline;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->timer:Ldev/nino/squareglass/SleepDeadline;

    .line 17
    new-instance v0, Ldev/nino/squareglass/TrackEndGate;

    invoke-direct {v0}, Ldev/nino/squareglass/TrackEndGate;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->trackEnd:Ldev/nino/squareglass/TrackEndGate;

    .line 18
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    .line 23
    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->visible:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static activity(Landroid/content/Context;)Landroid/app/Activity;
    .locals 1

    .line 80
    :goto_0
    instance-of v0, p0, Landroid/content/ContextWrapper;

    if-eqz v0, :cond_2

    .line 81
    instance-of v0, p0, Landroid/app/Activity;

    if-eqz v0, :cond_0

    check-cast p0, Landroid/app/Activity;

    return-object p0

    .line 82
    :cond_0
    move-object v0, p0

    check-cast v0, Landroid/content/ContextWrapper;

    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    if-ne v0, p0, :cond_1

    goto :goto_1

    :cond_1
    move-object p0, v0

    goto :goto_0

    :cond_2
    :goto_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public static button(Landroid/content/Context;Ldev/nino/squareglass/LiquidMenuSurface;)Landroid/view/View;
    .locals 1

    .line 101
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->status()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "  \u203a"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ldev/nino/squareglass/SleepTimer$0;

    invoke-direct {v0}, Ldev/nino/squareglass/SleepTimer$0;-><init>()V

    invoke-static {p0, p1, v0}, Ldev/nino/squareglass/SleepTimer;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object p1

    .line 102
    new-instance v0, Ldev/nino/squareglass/SleepTimer$8;

    invoke-direct {v0, p1, p0}, Ldev/nino/squareglass/SleepTimer$8;-><init>(Landroid/widget/TextView;Landroid/content/Context;)V

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 103
    new-instance p0, Ldev/nino/squareglass/SleepTimer$2;

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SleepTimer$2;-><init>(Landroid/widget/TextView;)V

    .line 104
    new-instance v0, Ldev/nino/squareglass/SleepTimer$3;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/SleepTimer$3;-><init>(Ljava/lang/Runnable;Landroid/widget/TextView;)V

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-object p1
.end method

.method public static cancel()V
    .locals 2

    .line 32
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->manager:Landroid/app/AlarmManager;

    if-eqz v0, :cond_0

    sget-object v1, Ldev/nino/squareglass/SleepTimer;->alarm:Landroid/app/AlarmManager$OnAlarmListener;

    if-eqz v1, :cond_0

    invoke-virtual {v0, v1}, Landroid/app/AlarmManager;->cancel(Landroid/app/AlarmManager$OnAlarmListener;)V

    .line 33
    :cond_0
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->fallback:Ljava/lang/Runnable;

    if-eqz v0, :cond_1

    sget-object v1, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 34
    :cond_1
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->endPoll:Ljava/lang/Runnable;

    if-eqz v0, :cond_2

    sget-object v1, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_2
    const/4 v0, 0x0

    .line 35
    sput-object v0, Ldev/nino/squareglass/SleepTimer;->alarm:Landroid/app/AlarmManager$OnAlarmListener;

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->fallback:Ljava/lang/Runnable;

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->endPoll:Ljava/lang/Runnable;

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->player:Lbi/e;

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->timer:Ldev/nino/squareglass/SleepDeadline;

    invoke-virtual {v0}, Ldev/nino/squareglass/SleepDeadline;->cancel()V

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->trackEnd:Ldev/nino/squareglass/TrackEndGate;

    invoke-virtual {v0}, Ldev/nino/squareglass/TrackEndGate;->cancel()V

    return-void
.end method

.method public static content(Landroid/content/Context;Ldev/nino/squareglass/LiquidMenuSurface;Ljava/lang/Runnable;)Landroid/view/View;
    .locals 13

    .line 111
    new-instance v0, Ldev/nino/squareglass/GlassFrame;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/GlassFrame;-><init>(Landroid/content/Context;)V

    const/high16 v1, 0x41e00000    # 28.0f

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1, v2, v3}, Ldev/nino/squareglass/LiquidMenuSurface;->paint(Landroid/widget/FrameLayout;FZZ)V

    .line 112
    new-instance p1, Landroid/widget/LinearLayout;

    invoke-direct {p1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v1, 0x8

    .line 113
    invoke-static {p0, v1}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v4

    const/16 v5, 0x18

    invoke-static {p0, v5}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {p1, v2, v4, v2, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 114
    new-instance v4, Landroid/widget/FrameLayout;

    invoke-direct {v4, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 115
    const-string v5, "Stop audio in"

    const/16 v6, 0x13

    invoke-static {p0, v5, v6}, Ldev/nino/squareglass/SleepTimer;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v5

    const/16 v6, 0x11

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 116
    new-instance v7, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v8, 0x40

    invoke-static {p0, v8}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v9

    const/4 v10, -0x1

    invoke-direct {v7, v10, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v5, v7}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 117
    const-string v5, "\u2039"

    const/16 v7, 0x1e

    invoke-static {p0, v5, v7}, Ldev/nino/squareglass/SleepTimer;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setGravity(I)V

    const-string v9, "Close sleep timer"

    invoke-virtual {v5, v9}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 118
    new-instance v9, Ldev/nino/squareglass/SleepTimer$12;

    invoke-direct {v9, p2}, Ldev/nino/squareglass/SleepTimer$12;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v5, v9}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setFocusable(Z)V

    .line 119
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v11, 0x38

    invoke-static {p0, v11}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v11

    invoke-static {p0, v8}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v8

    const/4 v12, 0x3

    invoke-direct {v9, v11, v8, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v4, v5, v9}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 120
    const-string v4, ""

    const/16 v5, 0xe

    invoke-static {p0, v4, v5}, Ldev/nino/squareglass/SleepTimer;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {p1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v5, 0x6

    .line 121
    new-array v6, v5, [I

    fill-array-data v6, :array_0

    move v8, v2

    :goto_0
    if-ge v8, v5, :cond_1

    aget v9, v6, v8

    const/16 v11, 0x3c

    if-ne v9, v11, :cond_0

    .line 122
    const-string v11, "1 hour"

    goto :goto_1

    :cond_0
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v12, " minutes"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    :goto_1
    new-instance v12, Ldev/nino/squareglass/SleepTimer$13;

    invoke-direct {v12, p0, v9, p2}, Ldev/nino/squareglass/SleepTimer$13;-><init>(Landroid/content/Context;ILjava/lang/Runnable;)V

    invoke-static {p0, v11, v12}, Ldev/nino/squareglass/SleepTimer;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {p1, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    .line 124
    :cond_1
    new-instance v5, Ldev/nino/squareglass/SleepTimer$14;

    invoke-direct {v5, p0, p2}, Ldev/nino/squareglass/SleepTimer$14;-><init>(Landroid/content/Context;Ljava/lang/Runnable;)V

    const-string v6, "End of track"

    invoke-static {p0, v6, v5}, Ldev/nino/squareglass/SleepTimer;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {p1, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 125
    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x10

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 126
    new-instance v6, Landroid/widget/NumberPicker;

    invoke-direct {v6, p0}, Landroid/widget/NumberPicker;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6, v3}, Landroid/widget/NumberPicker;->setMinValue(I)V

    const/16 v3, 0xb4

    invoke-virtual {v6, v3}, Landroid/widget/NumberPicker;->setMaxValue(I)V

    invoke-virtual {v6, v7}, Landroid/widget/NumberPicker;->setValue(I)V

    .line 127
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v3

    invoke-static {v3}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v3

    invoke-virtual {v6, v3}, Landroid/widget/NumberPicker;->setTextColor(I)V

    const-string v3, "Custom duration in minutes"

    invoke-virtual {v6, v3}, Landroid/widget/NumberPicker;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 128
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x78

    invoke-static {p0, v7}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v7

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v3, v2, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v5, v6, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 129
    new-instance v3, Ldev/nino/squareglass/SleepTimer$15;

    invoke-direct {v3, v6, p0, p2}, Ldev/nino/squareglass/SleepTimer$15;-><init>(Landroid/widget/NumberPicker;Landroid/content/Context;Ljava/lang/Runnable;)V

    const-string v6, "Set timer"

    invoke-static {p0, v6, v3}, Ldev/nino/squareglass/SleepTimer;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v5, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 130
    invoke-virtual {v5, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 131
    new-instance v1, Ldev/nino/squareglass/SleepTimer$16;

    invoke-direct {v1, v5}, Ldev/nino/squareglass/SleepTimer$16;-><init>(Landroid/widget/LinearLayout;)V

    const-string v3, "Custom duration\u2026"

    invoke-static {p0, v3, v1}, Ldev/nino/squareglass/SleepTimer;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 132
    invoke-virtual {p1, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 133
    new-instance v1, Ldev/nino/squareglass/SleepTimer$17;

    invoke-direct {v1, p2}, Ldev/nino/squareglass/SleepTimer$17;-><init>(Ljava/lang/Runnable;)V

    const-string p2, "Turn off timer"

    invoke-static {p0, p2, v1}, Ldev/nino/squareglass/SleepTimer;->row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 134
    new-instance v1, Ldev/nino/squareglass/SleepTimer$4;

    invoke-direct {v1, p0, p0}, Ldev/nino/squareglass/SleepTimer$4;-><init>(Landroid/content/Context;Landroid/content/Context;)V

    .line 141
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v3, v10, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, p1, v3}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v0, v1}, Ldev/nino/squareglass/SheetChrome;->layout(Landroid/widget/FrameLayout;Landroid/view/View;)Landroid/widget/LinearLayout;

    .line 142
    new-instance v1, Ldev/nino/squareglass/SleepTimer$18;

    invoke-direct {v1, p1, p0}, Ldev/nino/squareglass/SleepTimer$18;-><init>(Landroid/widget/LinearLayout;Landroid/content/Context;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnApplyWindowInsetsListener(Landroid/view/View$OnApplyWindowInsetsListener;)V

    .line 146
    new-instance p0, Ldev/nino/squareglass/SleepTimer$5;

    invoke-direct {p0, v4, p2, v0}, Ldev/nino/squareglass/SleepTimer$5;-><init>(Landroid/widget/TextView;Landroid/widget/TextView;Ldev/nino/squareglass/GlassFrame;)V

    .line 151
    new-instance p1, Ldev/nino/squareglass/SleepTimer$6;

    invoke-direct {p1, p0, v0}, Ldev/nino/squareglass/SleepTimer$6;-><init>(Ljava/lang/Runnable;Ldev/nino/squareglass/GlassFrame;)V

    invoke-virtual {v0, p1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 154
    invoke-static {v0, v2, v2}, Ldev/nino/squareglass/SurfaceMotion;->enter(Landroid/view/View;ZZ)V

    return-object v0

    nop

    :array_0
    .array-data 4
        0x5
        0xa
        0xf
        0x1e
        0x2d
        0x3c
    .end array-data
.end method

.method private static dp(Landroid/content/Context;I)I
    .locals 0

    int-to-float p1, p1

    .line 86
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public static endOfTrack(Landroid/content/Context;)Z
    .locals 2

    .line 63
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->host()Lbi/e;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 64
    invoke-interface {v0}, Lbi/e;->getCurrentItem()Lcom/aspiro/wamp/playqueue/u0;

    move-result-object v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 65
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->cancel()V

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->player:Lbi/e;

    .line 66
    sget-object p0, Ldev/nino/squareglass/SleepTimer;->trackEnd:Ldev/nino/squareglass/TrackEndGate;

    invoke-interface {v0}, Lbi/e;->getCurrentItem()Lcom/aspiro/wamp/playqueue/u0;

    move-result-object v1

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v1

    invoke-virtual {v1}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v1

    invoke-interface {v0}, Lbi/e;->getCurrentMediaPosition()I

    move-result v0

    invoke-virtual {p0, v1, v0}, Ldev/nino/squareglass/TrackEndGate;->start(II)V

    .line 67
    new-instance p0, Ldev/nino/squareglass/SleepTimer$1;

    invoke-direct {p0}, Ldev/nino/squareglass/SleepTimer$1;-><init>()V

    sput-object p0, Ldev/nino/squareglass/SleepTimer;->endPoll:Ljava/lang/Runnable;

    .line 76
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 p0, 0x1

    return p0

    .line 64
    :cond_1
    :goto_0
    invoke-static {p0}, Ldev/nino/squareglass/SleepTimer;->unavailable(Landroid/content/Context;)V

    const/4 p0, 0x0

    return p0
.end method

.method static synthetic lambda$button$0()V
    .locals 0

    return-void
.end method

.method static synthetic lambda$button$1(Landroid/widget/TextView;Landroid/content/Context;Landroid/view/View;)V
    .locals 0

    .line 102
    invoke-static {p0}, Ldev/nino/squareglass/SquareMenus;->sleepTimer(Landroid/view/View;)Z

    move-result p0

    if-nez p0, :cond_0

    invoke-static {p1}, Ldev/nino/squareglass/SleepTimer;->show(Landroid/content/Context;)V

    :cond_0
    return-void
.end method

.method static synthetic lambda$content$0(Ljava/lang/Runnable;Landroid/view/View;)V
    .locals 0

    .line 118
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method static synthetic lambda$content$1(Landroid/content/Context;ILjava/lang/Runnable;)V
    .locals 0

    .line 122
    invoke-static {p0, p1}, Ldev/nino/squareglass/SleepTimer;->start(Landroid/content/Context;I)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    :cond_0
    return-void
.end method

.method static synthetic lambda$content$2(Landroid/content/Context;Ljava/lang/Runnable;)V
    .locals 0

    .line 124
    invoke-static {p0}, Ldev/nino/squareglass/SleepTimer;->endOfTrack(Landroid/content/Context;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :cond_0
    return-void
.end method

.method static synthetic lambda$content$3(Landroid/widget/NumberPicker;Landroid/content/Context;Ljava/lang/Runnable;)V
    .locals 0

    .line 129
    invoke-virtual {p0}, Landroid/widget/NumberPicker;->clearFocus()V

    invoke-virtual {p0}, Landroid/widget/NumberPicker;->getValue()I

    move-result p0

    invoke-static {p1, p0}, Ldev/nino/squareglass/SleepTimer;->start(Landroid/content/Context;I)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    :cond_0
    return-void
.end method

.method static synthetic lambda$content$4(Landroid/widget/LinearLayout;)V
    .locals 2

    .line 131
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v0

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    const/4 v1, 0x0

    :cond_0
    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    return-void
.end method

.method static synthetic lambda$content$5(Ljava/lang/Runnable;)V
    .locals 0

    .line 133
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->cancel()V

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method static synthetic lambda$content$6(Landroid/widget/LinearLayout;Landroid/content/Context;Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 3

    .line 143
    invoke-static {}, Landroid/view/WindowInsets$Type;->systemBars()I

    move-result p2

    invoke-virtual {p3, p2}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object p2

    iget p2, p2, Landroid/graphics/Insets;->bottom:I

    const/16 v0, 0x8

    .line 144
    invoke-static {p1, v0}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v1

    const/16 v2, 0x18

    invoke-static {p1, v2}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v2

    invoke-static {p1, v0}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result p1

    add-int/2addr p2, p1

    invoke-static {v2, p2}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 p2, 0x0

    invoke-virtual {p0, p2, v1, p2, p1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    return-object p3
.end method

.method static synthetic lambda$playerChanged$0(Lbi/e;)V
    .locals 1

    .line 45
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->timer:Ldev/nino/squareglass/SleepDeadline;

    invoke-virtual {v0}, Ldev/nino/squareglass/SleepDeadline;->active()Z

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->trackEnd:Ldev/nino/squareglass/TrackEndGate;

    invoke-virtual {v0}, Ldev/nino/squareglass/TrackEndGate;->active()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 46
    :cond_0
    sput-object p0, Ldev/nino/squareglass/SleepTimer;->player:Lbi/e;

    .line 47
    sget-object p0, Ldev/nino/squareglass/SleepTimer;->endPoll:Ljava/lang/Runnable;

    if-eqz p0, :cond_1

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    sget-object p0, Ldev/nino/squareglass/SleepTimer;->endPoll:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1
    :goto_0
    return-void
.end method

.method static synthetic lambda$row$0(Ljava/lang/Runnable;Landroid/view/View;)V
    .locals 0

    .line 98
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method static synthetic lambda$start$0(I)V
    .locals 3

    .line 55
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->timer:Ldev/nino/squareglass/SleepDeadline;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-virtual {v0, p0, v1, v2}, Ldev/nino/squareglass/SleepDeadline;->consume(IJ)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->pause()V

    :cond_0
    return-void
.end method

.method private static pause()V
    .locals 3

    .line 38
    const-string v0, "SquareGlass"

    sget-object v1, Ldev/nino/squareglass/SleepTimer;->player:Lbi/e;

    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->cancel()V

    if-eqz v1, :cond_0

    .line 39
    :try_start_0
    invoke-interface {v1}, Lbi/e;->d()V

    const-string v1, "Sleep timer paused native playback"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v1

    .line 40
    const-string v2, "Sleep timer could not pause playback"

    invoke-static {v0, v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    return-void
.end method

.method public static playerChanged(Lbi/e;)V
    .locals 2

    .line 43
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->timer:Ldev/nino/squareglass/SleepDeadline;

    invoke-virtual {v0}, Ldev/nino/squareglass/SleepDeadline;->active()Z

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/SleepTimer;->trackEnd:Ldev/nino/squareglass/TrackEndGate;

    invoke-virtual {v0}, Ldev/nino/squareglass/TrackEndGate;->active()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 44
    :cond_0
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/SleepTimer$19;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SleepTimer$19;-><init>(Lbi/e;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private static row(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/TextView;
    .locals 5

    const/16 v0, 0x11

    .line 93
    invoke-static {p0, p1, v0}, Ldev/nino/squareglass/SleepTimer;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x10

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0x18

    .line 94
    invoke-static {p0, v1}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v2

    invoke-static {p0, v0}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v3

    invoke-static {p0, v1}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v1

    invoke-static {p0, v0}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {p1, v2, v3, v1, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    const/16 v1, 0x38

    invoke-static {p0, v1}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setMinimumHeight(I)V

    .line 95
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v2, -0x1

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-static {p0, v0}, Ldev/nino/squareglass/SleepTimer;->dp(Landroid/content/Context;I)I

    move-result p0

    int-to-float p0, p0

    invoke-virtual {v1, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 96
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p0

    invoke-static {p0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p0

    .line 97
    new-instance v0, Landroid/graphics/drawable/RippleDrawable;

    const v2, 0xffffff

    and-int/2addr p0, v2

    const/high16 v2, 0x18000000

    or-int/2addr p0, v2

    invoke-static {p0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p0

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 p0, 0x1

    .line 98
    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setFocusable(Z)V

    new-instance p0, Ldev/nino/squareglass/SleepTimer$20;

    invoke-direct {p0, p2}, Ldev/nino/squareglass/SleepTimer$20;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object p1
.end method

.method public static show(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x0

    .line 156
    invoke-static {p0, v0}, Ldev/nino/squareglass/SleepTimer;->show(Landroid/content/Context;Landroid/view/View;)V

    return-void
.end method

.method public static show(Landroid/content/Context;Landroid/view/View;)V
    .locals 1

    .line 158
    invoke-static {p0}, Ldev/nino/squareglass/SleepTimer;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    .line 159
    :cond_0
    new-instance p1, Landroid/app/Dialog;

    invoke-direct {p1, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    invoke-static {p1, p0}, Ldev/nino/squareglass/SleepTimer;->showInDialog(Landroid/app/Dialog;Landroid/app/Activity;)V

    :cond_1
    :goto_0
    return-void
.end method

.method public static showInDialog(Landroid/app/Dialog;Landroid/app/Activity;)V
    .locals 7

    .line 163
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->visible:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Dialog;

    if-eqz v0, :cond_0

    if-eq v0, p0, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->visible:Ljava/lang/ref/WeakReference;

    .line 164
    invoke-static {p1}, Ldev/nino/squareglass/PlayerWindow;->source(Landroid/app/Activity;)Landroid/view/View;

    move-result-object v0

    .line 165
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    if-lez v1, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v1

    if-lez v1, :cond_1

    new-instance v1, Ldev/nino/squareglass/PlayerWindow$Snapshot;

    invoke-direct {v1, v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;-><init>(Landroid/view/View;)V

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    .line 166
    :goto_0
    new-instance v0, Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-direct {v0, p1, v1}, Ldev/nino/squareglass/LiquidMenuSurface;-><init>(Landroid/app/Activity;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    .line 167
    new-instance v2, Landroid/widget/FrameLayout;

    invoke-direct {v2, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, -0x1

    if-eqz v1, :cond_2

    const/4 v4, 0x1

    .line 168
    invoke-virtual {v1, p1, v4}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->view(Landroid/content/Context;Z)Landroid/view/View;

    move-result-object v4

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v5, v3, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 169
    :cond_2
    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v4, Ldev/nino/squareglass/SleepTimer$9;

    invoke-direct {v4, p0}, Ldev/nino/squareglass/SleepTimer$9;-><init>(Landroid/app/Dialog;)V

    invoke-static {p1, v0, v4}, Ldev/nino/squareglass/SleepTimer;->content(Landroid/content/Context;Ldev/nino/squareglass/LiquidMenuSurface;Ljava/lang/Runnable;)Landroid/view/View;

    move-result-object p1

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x2

    const/16 v6, 0x50

    invoke-direct {v4, v3, v5, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v2, p1, v4}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 170
    new-instance p1, Ldev/nino/squareglass/SleepTimer$7;

    invoke-direct {p1, v0, v1}, Ldev/nino/squareglass/SleepTimer$7;-><init>(Ldev/nino/squareglass/LiquidMenuSurface;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    invoke-virtual {v2, p1}, Landroid/widget/FrameLayout;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    const p1, 0x1020002

    .line 174
    invoke-virtual {p0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    .line 175
    invoke-virtual {p0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_3

    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_3

    .line 179
    check-cast p1, Landroid/view/ViewGroup;

    invoke-static {p1}, Landroid/transition/TransitionManager;->endTransitions(Landroid/view/ViewGroup;)V

    .line 180
    invoke-virtual {p1}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 181
    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {v0, v3, v3}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_1

    .line 182
    :cond_3
    invoke-virtual {p0, v2}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    .line 183
    :goto_1
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_4

    .line 184
    invoke-static {p0}, Ldev/nino/squareglass/SystemBarTheme;->installWindow(Landroid/view/Window;)Ldev/nino/squareglass/SystemBarTheme;

    new-instance p1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {p0, p1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0, v3, v3}, Landroid/view/Window;->setLayout(II)V

    :cond_4
    return-void
.end method

.method public static start(Landroid/content/Context;I)Z
    .locals 12

    .line 51
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->host()Lbi/e;

    move-result-object v0

    if-nez v0, :cond_0

    .line 52
    invoke-static {p0}, Ldev/nino/squareglass/SleepTimer;->unavailable(Landroid/content/Context;)V

    const/4 p0, 0x0

    return p0

    .line 53
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SleepTimer;->cancel()V

    sput-object v0, Ldev/nino/squareglass/SleepTimer;->player:Lbi/e;

    .line 54
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->timer:Ldev/nino/squareglass/SleepDeadline;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    int-to-long v3, p1

    const-wide/32 v5, 0xea60

    mul-long/2addr v3, v5

    invoke-virtual {v0, v1, v2, v3, v4}, Ldev/nino/squareglass/SleepDeadline;->start(JJ)I

    move-result p1

    .line 55
    new-instance v1, Ldev/nino/squareglass/SleepTimer$10;

    invoke-direct {v1, p1}, Ldev/nino/squareglass/SleepTimer$10;-><init>(I)V

    .line 56
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string p1, "alarm"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/AlarmManager;

    sput-object p0, Ldev/nino/squareglass/SleepTimer;->manager:Landroid/app/AlarmManager;

    .line 57
    new-instance p0, Ldev/nino/squareglass/SleepTimer$11;

    invoke-direct {p0, v1}, Ldev/nino/squareglass/SleepTimer$11;-><init>(Ljava/lang/Runnable;)V

    sput-object p0, Ldev/nino/squareglass/SleepTimer;->alarm:Landroid/app/AlarmManager$OnAlarmListener;

    .line 58
    sget-object v5, Ldev/nino/squareglass/SleepTimer;->manager:Landroid/app/AlarmManager;

    if-eqz v5, :cond_1

    :try_start_0
    invoke-virtual {v0}, Ldev/nino/squareglass/SleepDeadline;->deadline()J

    move-result-wide v7

    const-string v9, "SquareGlass sleep timer"

    sget-object v10, Ldev/nino/squareglass/SleepTimer;->alarm:Landroid/app/AlarmManager$OnAlarmListener;

    sget-object v11, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    const/4 v6, 0x2

    invoke-virtual/range {v5 .. v11}, Landroid/app/AlarmManager;->setExact(IJLjava/lang/String;Landroid/app/AlarmManager$OnAlarmListener;Landroid/os/Handler;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    move-object p0, v0

    .line 59
    const-string p1, "SquareGlass"

    const-string v0, "Using in-process sleep timer"

    invoke-static {p1, v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 60
    :cond_1
    :goto_0
    sput-object v1, Ldev/nino/squareglass/SleepTimer;->fallback:Ljava/lang/Runnable;

    sget-object p0, Ldev/nino/squareglass/SleepTimer;->main:Landroid/os/Handler;

    invoke-virtual {p0, v1, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 p0, 0x1

    return p0
.end method

.method public static status()Ljava/lang/String;
    .locals 7

    .line 26
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->trackEnd:Ldev/nino/squareglass/TrackEndGate;

    invoke-virtual {v0}, Ldev/nino/squareglass/TrackEndGate;->active()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "Sleep timer \u00b7 End of track"

    return-object v0

    .line 27
    :cond_0
    sget-object v0, Ldev/nino/squareglass/SleepTimer;->timer:Ldev/nino/squareglass/SleepDeadline;

    invoke-virtual {v0}, Ldev/nino/squareglass/SleepDeadline;->active()Z

    move-result v1

    if-nez v1, :cond_1

    const-string v0, "Sleep timer"

    return-object v0

    .line 28
    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ldev/nino/squareglass/SleepDeadline;->remaining(J)J

    move-result-wide v0

    const-wide/16 v2, 0x3e7

    add-long/2addr v0, v2

    const-wide/16 v2, 0x3e8

    div-long/2addr v0, v2

    .line 29
    sget-object v2, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const-wide/16 v3, 0x3c

    div-long v5, v0, v3

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    rem-long/2addr v0, v3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    filled-new-array {v5, v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "Sleep timer \u00b7 %d:%02d"

    invoke-static {v2, v1, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;
    .locals 1

    .line 88
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    int-to-float p1, p2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 89
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p1

    invoke-static {p1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 90
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const p1, 0x7f090005

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getFont(I)Landroid/graphics/Typeface;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    return-object v0
.end method

.method private static unavailable(Landroid/content/Context;)V
    .locals 2

    .line 78
    const-string v0, "Open a track before setting a sleep timer"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method
