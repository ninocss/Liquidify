.class public final synthetic Ldev/nino/squareglass/SleepTimer$19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lbi/e;


# direct methods
.method public synthetic constructor <init>(Lbi/e;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$19;->f$0:Lbi/e;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$19;->f$0:Lbi/e;

    invoke-static {p0}, Ldev/nino/squareglass/SleepTimer;->lambda$playerChanged$0(Lbi/e;)V

    return-void
.end method
