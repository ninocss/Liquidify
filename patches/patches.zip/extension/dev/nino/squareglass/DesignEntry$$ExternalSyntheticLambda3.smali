.class public final synthetic Ldev/nino/squareglass/DesignEntry$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Landroidx/compose/foundation/interaction/MutableInteractionSource;

.field public final synthetic f$1:J


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/foundation/interaction/MutableInteractionSource;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$$ExternalSyntheticLambda3;->f$0:Landroidx/compose/foundation/interaction/MutableInteractionSource;

    iput-wide p2, p0, Ldev/nino/squareglass/DesignEntry$$ExternalSyntheticLambda3;->f$1:J

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$$ExternalSyntheticLambda3;->f$0:Landroidx/compose/foundation/interaction/MutableInteractionSource;

    iget-wide v1, p0, Ldev/nino/squareglass/DesignEntry$$ExternalSyntheticLambda3;->f$1:J

    move-object v3, p1

    check-cast v3, Landroidx/compose/material3/SliderState;

    move-object v4, p2

    check-cast v4, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/DesignEntry;->$r8$lambda$O-wJrYE1dQcHGo6og5jMyhkqKD0(Landroidx/compose/foundation/interaction/MutableInteractionSource;JLandroidx/compose/material3/SliderState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
