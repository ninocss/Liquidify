.class final Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;
.super Ljava/lang/Object;
.source "NativeMiniGestures.kt"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/NativeMiniGestures;->decorate(Landroidx/compose/ui/Modifier;Lam0/a;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $flickSpeed:F

.field final synthetic $open$delegate:Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/State<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;>;"
        }
    .end annotation
.end field

.field final synthetic $openDistance:F

.field final synthetic $skipDistance:F


# direct methods
.method constructor <init>(FFFLandroidx/compose/runtime/State;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FFF",
            "Landroidx/compose/runtime/State<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;>;)V"
        }
    .end annotation

    iput p1, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->$openDistance:F

    iput p2, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->$flickSpeed:F

    iput p3, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->$skipDistance:F

    iput-object p4, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->$open$delegate:Landroidx/compose/runtime/State;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/input/pointer/PointerInputScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 37
    new-instance v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;

    iget v1, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->$openDistance:F

    iget v2, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->$flickSpeed:F

    iget v3, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->$skipDistance:F

    iget-object v4, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->$open$delegate:Landroidx/compose/runtime/State;

    const/4 v5, 0x0

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;-><init>(FFFLandroidx/compose/runtime/State;Lkotlin/coroutines/e;)V

    check-cast v0, Lam0/p;

    invoke-static {p1, v0, p2}, Landroidx/compose/foundation/gestures/ForEachGestureKt;->awaitEachGesture(Landroidx/compose/ui/input/pointer/PointerInputScope;Lam0/p;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object p1

    if-ne p0, p1, :cond_0

    return-object p0

    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
