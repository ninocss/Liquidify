.class public final synthetic Ldev/nino/squareglass/NativeViewBackdrop$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/NativeViewBackdrop;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/NativeViewBackdrop;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/NativeViewBackdrop;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/NativeViewBackdrop;

    invoke-static {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->$r8$lambda$65PuB9qN1eubWUzqCYuB0671Pz4(Ldev/nino/squareglass/NativeViewBackdrop;)V

    return-void
.end method
