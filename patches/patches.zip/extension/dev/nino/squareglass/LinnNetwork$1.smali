.class Ldev/nino/squareglass/LinnNetwork$1;
.super Landroid/net/ConnectivityManager$NetworkCallback;
.source "LinnNetwork.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/LinnNetwork;-><init>(Landroid/app/Application;Ljava/lang/Runnable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/LinnNetwork;

.field final synthetic val$changed:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/LinnNetwork;Ljava/lang/Runnable;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 15
    iput-object p1, p0, Ldev/nino/squareglass/LinnNetwork$1;->this$0:Ldev/nino/squareglass/LinnNetwork;

    iput-object p2, p0, Ldev/nino/squareglass/LinnNetwork$1;->val$changed:Ljava/lang/Runnable;

    invoke-direct {p0}, Landroid/net/ConnectivityManager$NetworkCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onAvailable(Landroid/net/Network;)V
    .locals 0

    .line 16
    iget-object p0, p0, Ldev/nino/squareglass/LinnNetwork$1;->val$changed:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public onLinkPropertiesChanged(Landroid/net/Network;Landroid/net/LinkProperties;)V
    .locals 0

    .line 18
    iget-object p0, p0, Ldev/nino/squareglass/LinnNetwork$1;->val$changed:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public onLost(Landroid/net/Network;)V
    .locals 0

    .line 17
    iget-object p0, p0, Ldev/nino/squareglass/LinnNetwork$1;->val$changed:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method
