.class public final synthetic Ldev/nino/squareglass/SleepTimer$15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/widget/NumberPicker;

.field public final synthetic f$1:Landroid/content/Context;

.field public final synthetic f$2:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/NumberPicker;Landroid/content/Context;Ljava/lang/Runnable;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$15;->f$0:Landroid/widget/NumberPicker;

    iput-object p2, p0, Ldev/nino/squareglass/SleepTimer$15;->f$1:Landroid/content/Context;

    iput-object p3, p0, Ldev/nino/squareglass/SleepTimer$15;->f$2:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SleepTimer$15;->f$0:Landroid/widget/NumberPicker;

    iget-object v1, p0, Ldev/nino/squareglass/SleepTimer$15;->f$1:Landroid/content/Context;

    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$15;->f$2:Ljava/lang/Runnable;

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/SleepTimer;->lambda$content$8(Landroid/widget/NumberPicker;Landroid/content/Context;Ljava/lang/Runnable;)V

    return-void
.end method
