.class Ldev/nino/squareglass/LinnPlayer$1;
.super Landroidx/media/VolumeProviderCompat;
.source "LinnPlayer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/LinnPlayer;->transfer()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/LinnPlayer;


# direct methods
.method public static synthetic $r8$lambda$BAvWvJXDzLmZdo9ky5-EQTXxZMg(Ldev/nino/squareglass/LinnPlayer$1;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer$1;->lambda$onAdjustVolume$0(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$He2iR_ZdkKA-xTIl5IPo-PeYCDE(Ldev/nino/squareglass/LinnPlayer$1;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer$1;->lambda$onSetVolumeTo$0(I)V

    return-void
.end method

.method constructor <init>(Ldev/nino/squareglass/LinnPlayer;III)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation

    .line 117
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$1;->this$0:Ldev/nino/squareglass/LinnPlayer;

    invoke-direct {p0, p2, p3, p4}, Landroidx/media/VolumeProviderCompat;-><init>(III)V

    return-void
.end method

.method private synthetic lambda$onAdjustVolume$0(I)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 119
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$1;->this$0:Ldev/nino/squareglass/LinnPlayer;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    if-lez p1, :cond_0

    const-string p1, "VolumeIncNoUnmute"

    goto :goto_0

    :cond_0
    const-string p1, "VolumeDecNoUnmute"

    :goto_0
    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Volume"

    invoke-virtual {p0, v1, p1, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$onSetVolumeTo$0(I)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 118
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$1;->this$0:Ldev/nino/squareglass/LinnPlayer;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/16 v0, 0x64

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const-string v0, "Volume"

    const-string v1, "SetVolumeNoUnmute"

    invoke-virtual {p0, v0, v1, p1}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public onAdjustVolume(I)V
    .locals 2

    if-eqz p1, :cond_0

    .line 119
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$1;->this$0:Ldev/nino/squareglass/LinnPlayer;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$1$0;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnPlayer$1$0;-><init>(Ldev/nino/squareglass/LinnPlayer$1;I)V

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    :cond_0
    return-void
.end method

.method public onSetVolumeTo(I)V
    .locals 2

    .line 118
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$1;->this$0:Ldev/nino/squareglass/LinnPlayer;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$1$1;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnPlayer$1$1;-><init>(Ldev/nino/squareglass/LinnPlayer$1;I)V

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method
