.class public final synthetic Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ldev/nino/squareglass/LinnPlayer$Action;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:I

.field public final synthetic f$2:Z


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;IZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda14;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput p2, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda14;->f$1:I

    iput-boolean p3, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda14;->f$2:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda14;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda14;->f$1:I

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda14;->f$2:Z

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$DRidTn6VxBx4jg64tLtOtTgBbHM(Ldev/nino/squareglass/LinnPlayer;IZ)V

    return-void
.end method
