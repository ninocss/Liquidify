.class public final synthetic Ldev/nino/squareglass/OpenHome$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Ljava/util/Set;


# direct methods
.method public synthetic constructor <init>(Ljava/util/Set;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/OpenHome$0;->f$0:Ljava/util/Set;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/OpenHome$0;->f$0:Ljava/util/Set;

    check-cast p1, Ldev/nino/squareglass/LinnDiscovery$Result;

    invoke-static {p0, p1}, Ldev/nino/squareglass/OpenHome;->lambda$discover$0(Ljava/util/Set;Ldev/nino/squareglass/LinnDiscovery$Result;)V

    return-void
.end method
