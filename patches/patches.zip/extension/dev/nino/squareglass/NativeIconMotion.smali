.class public final Ldev/nino/squareglass/NativeIconMotion;
.super Ljava/lang/Object;
.source "NativeIconMotion.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static after(Landroid/view/View;Landroid/view/View;Landroid/graphics/Canvas;I)V
    .locals 0

    return-void
.end method

.method public static attach(Landroid/view/View;)V
    .locals 0

    .line 10
    invoke-static {p0}, Ldev/nino/squareglass/NativeIconGlass;->attach(Landroid/view/View;)V

    return-void
.end method

.method public static before(Landroid/view/View;Landroid/view/View;Landroid/graphics/Canvas;)I
    .locals 0

    .line 14
    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeIconGlass;->observe(Landroid/view/View;Landroid/view/View;)V

    const/4 p0, -0x1

    return p0
.end method

.method public static detach(Landroid/view/View;)V
    .locals 0

    .line 11
    invoke-static {p0}, Ldev/nino/squareglass/NativeIconGlass;->detach(Landroid/view/View;)V

    return-void
.end method

.method public static touch(Landroid/view/View;Landroid/view/MotionEvent;)V
    .locals 0

    .line 12
    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeIconGlass;->touch(Landroid/view/View;Landroid/view/MotionEvent;)V

    return-void
.end method
