.class final Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;
.super Ljava/lang/Object;
.source "LiquidMenuSurface.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/Backdrop;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/LiquidMenuSurface;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "WindowBackdrop"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLiquidMenuSurface.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LiquidMenuSurface.kt\ndev/nino/squareglass/LiquidMenuSurface$WindowBackdrop\n+ 2 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n*L\n1#1,188:1\n120#2,3:189\n233#2:192\n124#2,3:193\n*S KotlinDebug\n*F\n+ 1 LiquidMenuSurface.kt\ndev/nino/squareglass/LiquidMenuSurface$WindowBackdrop\n*L\n148#1:189,3\n149#1:192\n148#1:193,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0008\u0082\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J9\u0010\u000b\u001a\u00020\u000c*\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0008\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0019\u0010\u0012\u001a\u0015\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u000c\u0018\u00010\u0013\u00a2\u0006\u0002\u0008\u0015H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u0007X\u0096D\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0008R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"
    }
    d2 = {
        "Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "target",
        "Landroid/view/View;",
        "<init>",
        "(Ldev/nino/squareglass/LiquidMenuSurface;Landroid/view/View;)V",
        "isCoordinatesDependent",
        "",
        "()Z",
        "screen",
        "",
        "drawBackdrop",
        "",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layerBlock",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "Lkotlin/ExtensionFunctionType;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final isCoordinatesDependent:Z

.field private final screen:[I

.field private final target:Landroid/view/View;

.field final synthetic this$0:Ldev/nino/squareglass/LiquidMenuSurface;


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/LiquidMenuSurface;Landroid/view/View;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    const-string v0, "target"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    iput-object p1, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->this$0:Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->target:Landroid/view/View;

    const/4 p1, 0x1

    .line 139
    iput-boolean p1, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->isCoordinatesDependent:Z

    const/4 p1, 0x2

    .line 140
    new-array p1, p1, [I

    iput-object p1, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->screen:[I

    return-void
.end method


# virtual methods
.method public drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroidx/compose/ui/unit/Density;",
            "Landroidx/compose/ui/layout/LayoutCoordinates;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string p4, "<this>"

    invoke-static {p1, p4}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p4, "density"

    invoke-static {p2, p4}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p3, :cond_2

    .line 143
    invoke-interface {p3}, Landroidx/compose/ui/layout/LayoutCoordinates;->isAttached()Z

    move-result p2

    if-eqz p2, :cond_2

    iget-object p2, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->this$0:Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-static {p2}, Ldev/nino/squareglass/LiquidMenuSurface;->access$getNode$p(Ldev/nino/squareglass/LiquidMenuSurface;)Landroid/graphics/RenderNode;

    move-result-object p2

    invoke-virtual {p2}, Landroid/graphics/RenderNode;->hasDisplayList()Z

    move-result p2

    if-nez p2, :cond_0

    goto :goto_0

    .line 144
    :cond_0
    iget-object p2, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->target:Landroid/view/View;

    iget-object p3, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->screen:[I

    invoke-virtual {p2, p3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 148
    iget-object p2, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->this$0:Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-static {p2}, Ldev/nino/squareglass/LiquidMenuSurface;->access$getSourceScreen$p(Ldev/nino/squareglass/LiquidMenuSurface;)[I

    move-result-object p2

    const/4 p3, 0x0

    aget p2, p2, p3

    iget-object p4, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->screen:[I

    aget p3, p4, p3

    sub-int/2addr p2, p3

    int-to-float p2, p2

    iget-object p3, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->this$0:Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-static {p3}, Ldev/nino/squareglass/LiquidMenuSurface;->access$getSourceScreen$p(Ldev/nino/squareglass/LiquidMenuSurface;)[I

    move-result-object p3

    const/4 p4, 0x1

    aget p3, p3, p4

    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->screen:[I

    aget p4, v0, p4

    sub-int/2addr p3, p4

    int-to-float p3, p3

    iget-object p0, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->this$0:Ldev/nino/squareglass/LiquidMenuSurface;

    .line 189
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p4

    invoke-interface {p4}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p4

    invoke-interface {p4, p2, p3}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 192
    :try_start_0
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p4

    invoke-interface {p4}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p4

    .line 150
    invoke-static {p4}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/Canvas;->isHardwareAccelerated()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {p4}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object p4

    invoke-static {p0}, Ldev/nino/squareglass/LiquidMenuSurface;->access$getNode$p(Ldev/nino/squareglass/LiquidMenuSurface;)Landroid/graphics/RenderNode;

    move-result-object p0

    invoke-virtual {p4, p0}, Landroid/graphics/Canvas;->drawRenderNode(Landroid/graphics/RenderNode;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 193
    :cond_1
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p0

    neg-float p1, p2

    neg-float p2, p3

    invoke-interface {p0, p1, p2}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    return-void

    :catchall_0
    move-exception p0

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p1

    neg-float p2, p2

    neg-float p3, p3

    invoke-interface {p1, p2, p3}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    throw p0

    :cond_2
    :goto_0
    return-void
.end method

.method public isCoordinatesDependent()Z
    .locals 0

    .line 139
    iget-boolean p0, p0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;->isCoordinatesDependent:Z

    return p0
.end method
