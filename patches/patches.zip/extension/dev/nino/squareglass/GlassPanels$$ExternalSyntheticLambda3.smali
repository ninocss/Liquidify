.class public final synthetic Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-static {}, Ldev/nino/squareglass/GlassPanels;->$r8$lambda$FhRiG2QQX925nLIVaE_9PtebqKY()Ldev/nino/squareglass/backdrop/shadow/Shadow;

    move-result-object p0

    return-object p0
.end method
