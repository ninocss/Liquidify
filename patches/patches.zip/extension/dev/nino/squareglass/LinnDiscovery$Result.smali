.class final Ldev/nino/squareglass/LinnDiscovery$Result;
.super Ljava/lang/Object;
.source "LinnDiscovery.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/LinnDiscovery;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Result"
.end annotation


# instance fields
.field final bootId:Ljava/lang/String;

.field final configId:Ljava/lang/String;

.field final leaseNanos:J

.field final location:Ljava/lang/String;

.field final uuid:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 0

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    iput-object p1, p0, Ldev/nino/squareglass/LinnDiscovery$Result;->location:Ljava/lang/String;

    iput-object p2, p0, Ldev/nino/squareglass/LinnDiscovery$Result;->bootId:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/LinnDiscovery$Result;->configId:Ljava/lang/String;

    iput-object p4, p0, Ldev/nino/squareglass/LinnDiscovery$Result;->uuid:Ljava/lang/String;

    iput-wide p5, p0, Ldev/nino/squareglass/LinnDiscovery$Result;->leaseNanos:J

    return-void
.end method
