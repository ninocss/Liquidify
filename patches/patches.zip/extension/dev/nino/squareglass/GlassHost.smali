.class public final Ldev/nino/squareglass/GlassHost;
.super Ljava/lang/Object;
.source "GlassHost.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nGlassHost.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GlassHost.kt\ndev/nino/squareglass/GlassHost\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,30:1\n1128#2,6:31\n*S KotlinDebug\n*F\n+ 1 GlassHost.kt\ndev/nino/squareglass/GlassHost\n*L\n21#1:31,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J3\u0010\u0004\u001a\r\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0002\u0008\u00072\u0006\u0010\u0008\u001a\u00020\t2\u0011\u0010\n\u001a\r\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0002\u0008\u0007H\u0007\u00a2\u0006\u0002\u0010\u000b\u00a8\u0006\u000c"
    }
    d2 = {
        "Ldev/nino/squareglass/GlassHost;",
        "",
        "<init>",
        "()V",
        "wrapNative",
        "Lkotlin/Function0;",
        "",
        "Landroidx/compose/runtime/Composable;",
        "activity",
        "Landroid/app/Activity;",
        "content",
        "(Landroid/app/Activity;Lam0/p;)Lam0/p;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/GlassHost;


# direct methods
.method public static synthetic $r8$lambda$AGP7vfHMDvWeR-elxkpTvBRLBww(Landroid/app/Activity;Lam0/p;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/GlassHost;->wrapNative$lambda$0(Landroid/app/Activity;Lam0/p;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NlYStr1UX3h1xLkfiK0VT8iHEKA(Landroid/app/Activity;Z)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/GlassHost;->wrapNative$lambda$0$0$0(Landroid/app/Activity;Z)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/GlassHost;

    invoke-direct {v0}, Ldev/nino/squareglass/GlassHost;-><init>()V

    sput-object v0, Ldev/nino/squareglass/GlassHost;->INSTANCE:Ldev/nino/squareglass/GlassHost;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final wrapNative(Landroid/app/Activity;Lam0/p;)Lam0/p;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;)",
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    const-string v0, "activity"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "content"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->initialize(Landroid/content/Context;)V

    const v0, 0x7f0b02e6

    .line 14
    invoke-virtual {p0, v0}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 15
    sget-object v1, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v1, v0}, Ldev/nino/squareglass/NativeBackdrop;->attachNative(Landroid/view/View;)V

    .line 16
    invoke-static {p0}, Ldev/nino/squareglass/SystemBarTheme;->install(Landroid/app/Activity;)V

    .line 17
    invoke-static {p0}, Ldev/nino/squareglass/PageCoordinator;->install(Landroid/app/Activity;)V

    .line 18
    invoke-virtual {p0}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "dev.nino.tidalglass.test"

    invoke-static {v1, v2}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {p0, v0}, Ldev/nino/squareglass/ProbeDiagnostics;->install(Landroid/app/Activity;Landroid/view/View;)V

    .line 19
    :cond_0
    new-instance v0, Ldev/nino/squareglass/GlassHost$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/GlassHost$$ExternalSyntheticLambda1;-><init>(Landroid/app/Activity;Lam0/p;)V

    const p0, 0x435ed35f

    const/4 p1, 0x1

    invoke-static {p0, p1, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object p0

    check-cast p0, Lam0/p;

    return-object p0
.end method

.method private static final wrapNative$lambda$0(Landroid/app/Activity;Lam0/p;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 4

    const-string v0, "C19@858L4,20@886L276,20@875L287,25@1175L9:GlassHost.kt#vqphja"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, -0x1

    const-string v1, "dev.nino.squareglass.GlassHost.wrapNative.<anonymous> (GlassHost.kt:19)"

    const v3, 0x435ed35f

    invoke-static {v3, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 20
    :cond_1
    sget-object p3, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v0, 0x6

    invoke-virtual {p3, p2, v0}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result p3

    const v0, -0x19087f2d

    const-string v1, "CC(remember):GlassHost.kt#9igjgp"

    .line 21
    invoke-static {p2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p2, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    invoke-interface {p2, p3}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v1

    or-int/2addr v0, v1

    .line 31
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_2

    .line 32
    sget-object v0, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v0}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v1, v0, :cond_3

    .line 21
    :cond_2
    new-instance v1, Ldev/nino/squareglass/GlassHost$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p3}, Ldev/nino/squareglass/GlassHost$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;Z)V

    .line 34
    invoke-interface {p2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 21
    :cond_3
    check-cast v1, Lam0/a;

    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v1, p2, v2}, Landroidx/compose/runtime/EffectsKt;->SideEffect(Lam0/a;Landroidx/compose/runtime/Composer;I)V

    .line 26
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-interface {p1, p2, p0}, Lam0/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    .line 19
    :cond_4
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 27
    :cond_5
    :goto_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final wrapNative$lambda$0$0$0(Landroid/app/Activity;Z)Lkotlin/u;
    .locals 1

    .line 24
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/Window;->getInsetsController()Landroid/view/WindowInsetsController;

    move-result-object p0

    if-eqz p0, :cond_1

    const/16 v0, 0x18

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    move p1, v0

    :goto_0
    invoke-interface {p0, p1, v0}, Landroid/view/WindowInsetsController;->setSystemBarsAppearance(II)V

    .line 25
    :cond_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
