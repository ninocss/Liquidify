.class public final synthetic Ldev/nino/squareglass/GlassMotion$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/InteractiveHighlight;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/InteractiveHighlight;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassMotion$3;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/GlassMotion$3;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    invoke-static {p0}, Ldev/nino/squareglass/GlassMotion;->$r8$lambda$JX-ANoXePWXlnKSY4hdANqSKRFI(Ldev/nino/squareglass/material/InteractiveHighlight;)Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object p0

    return-object p0
.end method
