.class final Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;
.super Lkotlin/coroutines/jvm/internal/RestrictedSuspendLambda;
.source "NativeMiniGestures.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;->invoke(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/RestrictedSuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeMiniGestures.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeMiniGestures.kt\ndev/nino/squareglass/NativeMiniGestures$decorate$2$1$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Offset.kt\nandroidx/compose/ui/geometry/Offset\n+ 4 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 5 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,69:1\n296#2,2:70\n65#3:72\n69#3:75\n60#4:73\n70#4:76\n22#5:74\n*S KotlinDebug\n*F\n+ 1 NativeMiniGestures.kt\ndev/nino/squareglass/NativeMiniGestures$decorate$2$1$1\n*L\n45#1:70,2\n47#1:72\n47#1:75\n47#1:73\n47#1:76\n47#1:74\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $flickSpeed:F

.field final synthetic $open$delegate:Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/State<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;>;"
        }
    .end annotation
.end field

.field final synthetic $openDistance:F

.field final synthetic $skipDistance:F

.field F$0:F

.field F$1:F

.field I$0:I

.field I$1:I

.field I$2:I

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(FFFLandroidx/compose/runtime/State;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FFF",
            "Landroidx/compose/runtime/State<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;>;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;",
            ">;)V"
        }
    .end annotation

    iput p1, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$openDistance:F

    iput p2, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$flickSpeed:F

    iput p3, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$skipDistance:F

    iput-object p4, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$open$delegate:Landroidx/compose/runtime/State;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/RestrictedSuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;

    iget v1, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$openDistance:F

    iget v2, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$flickSpeed:F

    iget v3, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$skipDistance:F

    iget-object v4, p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$open$delegate:Landroidx/compose/runtime/State;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;-><init>(FFFLandroidx/compose/runtime/State;Lkotlin/coroutines/e;)V

    iput-object p1, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->invoke(Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    move-object/from16 v0, p0

    iget-object v1, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->L$0:Ljava/lang/Object;

    check-cast v1, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v2

    .line 37
    iget v3, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->label:I

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v3, :cond_2

    if-eq v3, v7, :cond_1

    if-ne v3, v6, :cond_0

    iget v3, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->I$2:I

    iget v8, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->I$1:I

    iget v9, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->I$0:I

    iget v10, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->F$1:F

    iget v11, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->F$0:F

    iget-object v12, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->L$2:Ljava/lang/Object;

    check-cast v12, Landroidx/compose/ui/input/pointer/util/VelocityTracker;

    iget-object v13, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->L$1:Ljava/lang/Object;

    check-cast v13, Landroidx/compose/ui/input/pointer/PointerInputChange;

    invoke-static/range {p1 .. p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    move-object/from16 v14, p1

    goto :goto_3

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    invoke-static/range {p1 .. p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    move-object/from16 v3, p1

    goto :goto_0

    :cond_2
    invoke-static/range {p1 .. p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 38
    sget-object v3, Landroidx/compose/ui/input/pointer/PointerEventPass;->Initial:Landroidx/compose/ui/input/pointer/PointerEventPass;

    move-object v8, v0

    check-cast v8, Lkotlin/coroutines/e;

    iput-object v1, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->L$0:Ljava/lang/Object;

    iput v7, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->label:I

    invoke-static {v1, v5, v3, v8}, Landroidx/compose/foundation/gestures/TapGestureDetectorKt;->awaitFirstDown(Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;ZLandroidx/compose/ui/input/pointer/PointerEventPass;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v2, :cond_3

    goto :goto_2

    .line 37
    :cond_3
    :goto_0
    check-cast v3, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 39
    new-instance v8, Landroidx/compose/ui/input/pointer/util/VelocityTracker;

    invoke-direct {v8}, Landroidx/compose/ui/input/pointer/util/VelocityTracker;-><init>()V

    invoke-virtual {v3}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getUptimeMillis()J

    move-result-wide v9

    invoke-virtual {v3}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v11

    invoke-virtual {v8, v9, v10, v11, v12}, Landroidx/compose/ui/input/pointer/util/VelocityTracker;->addPosition-Uv8p0NA(JJ)V

    move-object v13, v3

    move v3, v5

    move v9, v3

    move-object v12, v8

    const/4 v10, 0x0

    const/4 v11, 0x0

    move v8, v9

    .line 43
    :goto_1
    sget-object v14, Landroidx/compose/ui/input/pointer/PointerEventPass;->Initial:Landroidx/compose/ui/input/pointer/PointerEventPass;

    move-object v15, v0

    check-cast v15, Lkotlin/coroutines/e;

    iput-object v1, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->L$0:Ljava/lang/Object;

    iput-object v13, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->L$1:Ljava/lang/Object;

    iput-object v12, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->L$2:Ljava/lang/Object;

    iput v11, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->F$0:F

    iput v10, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->F$1:F

    iput v9, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->I$0:I

    iput v8, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->I$1:I

    iput v3, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->I$2:I

    iput v6, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->label:I

    invoke-interface {v1, v14, v15}, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;->awaitPointerEvent(Landroidx/compose/ui/input/pointer/PointerEventPass;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object v14

    if-ne v14, v2, :cond_4

    :goto_2
    return-object v2

    .line 37
    :cond_4
    :goto_3
    check-cast v14, Landroidx/compose/ui/input/pointer/PointerEvent;

    .line 44
    invoke-virtual {v14}, Landroidx/compose/ui/input/pointer/PointerEvent;->getChanges()Ljava/util/List;

    move-result-object v15

    invoke-interface {v15}, Ljava/util/List;->size()I

    move-result v15

    if-eq v15, v7, :cond_5

    move v3, v7

    const/16 v17, 0x0

    goto/16 :goto_8

    .line 45
    :cond_5
    invoke-virtual {v14}, Landroidx/compose/ui/input/pointer/PointerEvent;->getChanges()Ljava/util/List;

    move-result-object v14

    check-cast v14, Ljava/lang/Iterable;

    .line 70
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_4
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_7

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v16, v15

    check-cast v16, Landroidx/compose/ui/input/pointer/PointerInputChange;

    const/16 v17, 0x0

    .line 45
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getId-J3iCeTQ()J

    move-result-wide v4

    move/from16 p1, v8

    invoke-virtual {v13}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getId-J3iCeTQ()J

    move-result-wide v7

    invoke-static {v4, v5, v7, v8}, Landroidx/compose/ui/input/pointer/PointerId;->equals-impl0(JJ)Z

    move-result v4

    if-eqz v4, :cond_6

    goto :goto_5

    :cond_6
    move/from16 v8, p1

    const/4 v5, 0x0

    const/4 v7, 0x1

    goto :goto_4

    :cond_7
    move/from16 p1, v8

    const/16 v17, 0x0

    const/4 v15, 0x0

    :goto_5
    check-cast v15, Landroidx/compose/ui/input/pointer/PointerInputChange;

    if-nez v15, :cond_8

    move/from16 v8, p1

    goto/16 :goto_8

    .line 46
    :cond_8
    invoke-virtual {v15}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getUptimeMillis()J

    move-result-wide v4

    invoke-virtual {v15}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v7

    invoke-virtual {v12, v4, v5, v7, v8}, Landroidx/compose/ui/input/pointer/util/VelocityTracker;->addPosition-Uv8p0NA(JJ)V

    .line 47
    invoke-virtual {v15}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v4

    const/16 v7, 0x20

    shr-long/2addr v4, v7

    long-to-int v4, v4

    .line 74
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v4

    .line 47
    invoke-virtual {v13}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v10

    shr-long v7, v10, v7

    long-to-int v5, v7

    .line 74
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v5

    sub-float v11, v4, v5

    .line 47
    invoke-virtual {v15}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v4

    const-wide v7, 0xffffffffL

    and-long/2addr v4, v7

    long-to-int v4, v4

    .line 74
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v4

    .line 47
    invoke-virtual {v13}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v18

    and-long v7, v18, v7

    long-to-int v5, v7

    .line 74
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v5

    sub-float v10, v4, v5

    if-nez v9, :cond_b

    .line 49
    invoke-interface {v1}, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;->getViewConfiguration()Landroidx/compose/ui/platform/ViewConfiguration;

    move-result-object v4

    invoke-interface {v4}, Landroidx/compose/ui/platform/ViewConfiguration;->getTouchSlop()F

    move-result v4

    .line 50
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v5

    cmpl-float v5, v5, v4

    if-lez v5, :cond_9

    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v5

    invoke-static {v10}, Ljava/lang/Math;->abs(F)F

    move-result v7

    const v8, 0x3f933333    # 1.15f

    mul-float/2addr v7, v8

    cmpl-float v5, v5, v7

    if-lez v5, :cond_9

    const/4 v9, 0x1

    goto :goto_6

    :cond_9
    neg-float v5, v10

    cmpl-float v7, v5, v4

    if-lez v7, :cond_a

    .line 51
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v7

    const v8, 0x3f866666    # 1.05f

    mul-float/2addr v7, v8

    cmpl-float v5, v5, v7

    if-lez v5, :cond_a

    move v9, v6

    goto :goto_6

    :cond_a
    cmpl-float v4, v10, v4

    if-lez v4, :cond_b

    .line 52
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpl-float v4, v10, v4

    if-lez v4, :cond_b

    move/from16 v8, p1

    const/4 v3, 0x1

    goto :goto_8

    :cond_b
    :goto_6
    if-eqz v9, :cond_c

    .line 54
    invoke-virtual {v15}, Landroidx/compose/ui/input/pointer/PointerInputChange;->consume()V

    :cond_c
    if-ne v9, v6, :cond_d

    if-nez p1, :cond_d

    neg-float v4, v10

    .line 55
    iget v5, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$openDistance:F

    cmpl-float v4, v4, v5

    if-ltz v4, :cond_d

    iget-object v4, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$open$delegate:Landroidx/compose/runtime/State;

    invoke-static {v4}, Ldev/nino/squareglass/NativeMiniGestures;->access$decorate$lambda$0(Landroidx/compose/runtime/State;)Lam0/a;

    move-result-object v4

    invoke-interface {v4}, Lam0/a;->invoke()Ljava/lang/Object;

    const/4 v8, 0x1

    goto :goto_7

    :cond_d
    move/from16 v8, p1

    .line 56
    :goto_7
    invoke-virtual {v15}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPressed()Z

    move-result v4

    if-nez v4, :cond_13

    :goto_8
    if-nez v3, :cond_12

    if-nez v8, :cond_12

    .line 59
    invoke-virtual {v12}, Landroidx/compose/ui/input/pointer/util/VelocityTracker;->calculateVelocity-9UxMQ8M()J

    move-result-wide v2

    if-ne v9, v6, :cond_f

    neg-float v4, v10

    .line 60
    invoke-interface {v1}, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;->getViewConfiguration()Landroidx/compose/ui/platform/ViewConfiguration;

    move-result-object v5

    invoke-interface {v5}, Landroidx/compose/ui/platform/ViewConfiguration;->getTouchSlop()F

    move-result v5

    cmpl-float v5, v4, v5

    if-lez v5, :cond_f

    iget v5, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$openDistance:F

    cmpl-float v4, v4, v5

    if-gez v4, :cond_e

    invoke-static {v2, v3}, Landroidx/compose/ui/unit/Velocity;->getY-impl(J)F

    move-result v4

    neg-float v4, v4

    iget v5, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$flickSpeed:F

    cmpl-float v4, v4, v5

    if-ltz v4, :cond_f

    :cond_e
    iget-object v0, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$open$delegate:Landroidx/compose/runtime/State;

    invoke-static {v0}, Ldev/nino/squareglass/NativeMiniGestures;->access$decorate$lambda$0(Landroidx/compose/runtime/State;)Lam0/a;

    move-result-object v0

    invoke-interface {v0}, Lam0/a;->invoke()Ljava/lang/Object;

    goto :goto_a

    :cond_f
    const/4 v4, 0x1

    if-ne v9, v4, :cond_12

    .line 61
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v5

    invoke-interface {v1}, Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;->getViewConfiguration()Landroidx/compose/ui/platform/ViewConfiguration;

    move-result-object v1

    invoke-interface {v1}, Landroidx/compose/ui/platform/ViewConfiguration;->getTouchSlop()F

    move-result v1

    cmpl-float v1, v5, v1

    if-lez v1, :cond_12

    .line 62
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v1

    iget v5, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$skipDistance:F

    cmpl-float v1, v1, v5

    if-gez v1, :cond_10

    invoke-static {v2, v3}, Landroidx/compose/ui/unit/Velocity;->getX-impl(J)F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    iget v0, v0, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1$1;->$flickSpeed:F

    cmpl-float v0, v1, v0

    if-ltz v0, :cond_12

    :cond_10
    cmpl-float v0, v11, v17

    if-lez v0, :cond_11

    move v5, v4

    goto :goto_9

    :cond_11
    const/4 v5, 0x0

    :goto_9
    invoke-static {v5}, Ldev/nino/squareglass/NativePlayback;->next(Z)V

    .line 65
    :cond_12
    :goto_a
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0

    :cond_13
    const/4 v5, 0x0

    const/4 v7, 0x1

    goto/16 :goto_1
.end method
