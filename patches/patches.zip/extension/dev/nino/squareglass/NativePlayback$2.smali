.class public final synthetic Ldev/nino/squareglass/NativePlayback$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:J

.field public final synthetic f$2:Z


# direct methods
.method public synthetic constructor <init>(IJZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Ldev/nino/squareglass/NativePlayback$2;->f$0:I

    iput-wide p2, p0, Ldev/nino/squareglass/NativePlayback$2;->f$1:J

    iput-boolean p4, p0, Ldev/nino/squareglass/NativePlayback$2;->f$2:Z

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 6

    .line 0
    iget v0, p0, Ldev/nino/squareglass/NativePlayback$2;->f$0:I

    iget-wide v1, p0, Ldev/nino/squareglass/NativePlayback$2;->f$1:J

    iget-boolean v3, p0, Ldev/nino/squareglass/NativePlayback$2;->f$2:Z

    move-object v4, p1

    check-cast v4, Ldev/nino/squareglass/NativePlayback$Entry;

    move-object v5, p2

    check-cast v5, Ldev/nino/squareglass/NativePlayback$Entry;

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/NativePlayback;->lambda$autoplay$0(IJZLdev/nino/squareglass/NativePlayback$Entry;Ldev/nino/squareglass/NativePlayback$Entry;)I

    move-result p0

    return p0
.end method
