.class public final synthetic Ldev/nino/squareglass/GlassHost$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassHost$0;->f$0:Landroid/app/Activity;

    iput-boolean p2, p0, Ldev/nino/squareglass/GlassHost$0;->f$1:Z

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/GlassHost$0;->f$0:Landroid/app/Activity;

    iget-boolean p0, p0, Ldev/nino/squareglass/GlassHost$0;->f$1:Z

    invoke-static {v0, p0}, Ldev/nino/squareglass/GlassHost;->$r8$lambda$NlYStr1UX3h1xLkfiK0VT8iHEKA(Landroid/app/Activity;Z)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
