.class Ldev/nino/squareglass/RecommendationUpdates$Pending$1;
.super Ljava/lang/Object;
.source "RecommendationUpdates.java"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/RecommendationUpdates$Pending;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/RecommendationUpdates$Pending;

.field final synthetic val$animator:Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;

.field final synthetic val$linear:Landroidx/recyclerview/widget/LinearLayoutManager;

.field final synthetic val$list:Landroidx/recyclerview/widget/RecyclerView;

.field final synthetic val$screenTop:I

.field final synthetic val$target:I


# direct methods
.method constructor <init>(Ldev/nino/squareglass/RecommendationUpdates$Pending;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/LinearLayoutManager;IILandroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 123
    iput-object p1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->this$0:Ldev/nino/squareglass/RecommendationUpdates$Pending;

    iput-object p2, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$list:Landroidx/recyclerview/widget/RecyclerView;

    iput-object p3, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$linear:Landroidx/recyclerview/widget/LinearLayoutManager;

    iput p4, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$target:I

    iput p5, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$screenTop:I

    iput-object p6, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$animator:Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onPreDraw()Z
    .locals 10

    .line 125
    iget-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 126
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$linear:Landroidx/recyclerview/widget/LinearLayoutManager;

    iget v1, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$target:I

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findViewByPosition(I)Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    .line 128
    new-array v3, v2, [I

    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationInWindow([I)V

    aget v0, v3, v1

    iget v3, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$screenTop:I

    sub-int v6, v0, v3

    .line 129
    new-array v7, v2, [I

    .line 130
    iget-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v2, v1}, Landroidx/recyclerview/widget/RecyclerView;->startNestedScroll(II)Z

    .line 131
    iget-object v4, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$list:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v5, 0x0

    invoke-virtual/range {v4 .. v9}, Landroidx/recyclerview/widget/RecyclerView;->dispatchNestedPreScroll(II[I[II)Z

    .line 132
    iget-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$list:Landroidx/recyclerview/widget/RecyclerView;

    aget v2, v7, v1

    sub-int/2addr v6, v2

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v6}, Landroidx/recyclerview/widget/RecyclerView;->scrollBy(II)V

    iget-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->stopNestedScroll(I)V

    .line 134
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$list:Landroidx/recyclerview/widget/RecyclerView;

    iget-object p0, p0, Ldev/nino/squareglass/RecommendationUpdates$Pending$1;->val$animator:Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    return v1
.end method
