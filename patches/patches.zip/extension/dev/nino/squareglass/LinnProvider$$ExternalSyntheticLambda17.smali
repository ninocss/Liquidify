.class public final synthetic Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda17;->f$0:Ldev/nino/squareglass/LinnProvider;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda17;->f$0:Ldev/nino/squareglass/LinnProvider;

    invoke-static {p0}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$HsBScKsuKn3r05ojAaApsffFdho(Ldev/nino/squareglass/LinnProvider;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method
