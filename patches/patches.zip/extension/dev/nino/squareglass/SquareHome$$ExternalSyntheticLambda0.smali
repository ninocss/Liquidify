.class public final synthetic Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareHome;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Lam0/a;

.field public final synthetic f$3:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareHome;Ljava/lang/String;Lam0/a;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/SquareHome;

    iput-object p2, p0, Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;->f$1:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;->f$2:Lam0/a;

    iput p4, p0, Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;->f$3:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/SquareHome;

    iget-object v1, p0, Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;->f$1:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;->f$2:Lam0/a;

    iget v3, p0, Ldev/nino/squareglass/SquareHome$$ExternalSyntheticLambda0;->f$3:I

    move-object v4, p1

    check-cast v4, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/SquareHome;->$r8$lambda$EX_GHD2zSicU3ioNUAkIGQM5fok(Ldev/nino/squareglass/SquareHome;Ljava/lang/String;Lam0/a;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
