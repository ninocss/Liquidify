.class Ldev/nino/squareglass/SleepTimer$3;
.super Ljava/lang/Object;
.source "SleepTimer.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SleepTimer;->button(Landroid/content/Context;Ldev/nino/squareglass/LiquidMenuSurface;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$label:Landroid/widget/TextView;

.field final synthetic val$refresh:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Ljava/lang/Runnable;Landroid/widget/TextView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 104
    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$3;->val$refresh:Ljava/lang/Runnable;

    iput-object p2, p0, Ldev/nino/squareglass/SleepTimer$3;->val$label:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    .line 105
    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$3;->val$refresh:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    .line 106
    iget-object p1, p0, Ldev/nino/squareglass/SleepTimer$3;->val$label:Landroid/widget/TextView;

    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$3;->val$refresh:Ljava/lang/Runnable;

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method
