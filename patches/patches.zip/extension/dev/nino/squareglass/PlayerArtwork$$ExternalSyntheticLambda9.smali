.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

.field public final synthetic f$1:Landroid/view/View;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/PlayerArtwork$Frame;Landroid/view/View;Landroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda9;->f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

    iput-object p2, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda9;->f$1:Landroid/view/View;

    iput-object p3, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda9;->f$2:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda9;->f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

    iget-object v1, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda9;->f$1:Landroid/view/View;

    iget-object v2, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda9;->f$2:Landroidx/compose/runtime/MutableState;

    move-object v3, p1

    check-cast v3, Landroidx/compose/ui/layout/MeasureScope;

    move-object v4, p2

    check-cast v4, Landroidx/compose/ui/layout/Measurable;

    move-object v5, p3

    check-cast v5, Landroidx/compose/ui/unit/Constraints;

    invoke-static/range {v0 .. v5}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$2pSme3o6qhSOiXZrVlonxVgXThc(Ldev/nino/squareglass/PlayerArtwork$Frame;Landroid/view/View;Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/MeasureScope;Landroidx/compose/ui/layout/Measurable;Landroidx/compose/ui/unit/Constraints;)Landroidx/compose/ui/layout/MeasureResult;

    move-result-object p0

    return-object p0
.end method
