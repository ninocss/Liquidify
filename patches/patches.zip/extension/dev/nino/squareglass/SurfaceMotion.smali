.class public final Ldev/nino/squareglass/SurfaceMotion;
.super Ljava/lang/Object;
.source "SurfaceMotion.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static enter(Landroid/view/View;ZZ)V
    .locals 8

    .line 9
    const-string v0, "enter"

    invoke-static {p0, v0}, Ldev/nino/squareglass/LiquidViewMotion;->cancel(Landroid/view/View;Ljava/lang/String;)V

    if-eqz p2, :cond_0

    goto :goto_0

    .line 13
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-static {p0}, Ldev/nino/squareglass/SurfaceMotion;->reset(Landroid/view/View;)V

    if-nez p1, :cond_1

    if-nez p2, :cond_1

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setTranslationY(F)V

    :cond_1
    :goto_0
    return-void

    .line 14
    :cond_2
    new-instance v0, Ldev/nino/squareglass/SurfaceMotion$1;

    invoke-direct {v0, p1, p2}, Ldev/nino/squareglass/SurfaceMotion$1;-><init>(ZZ)V

    invoke-virtual {p0, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 20
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/high16 v1, 0x41900000    # 18.0f

    mul-float/2addr v0, v1

    .line 22
    new-instance v6, Ldev/nino/squareglass/SurfaceMotion$0;

    invoke-direct {v6, p0, p2, p1, v0}, Ldev/nino/squareglass/SurfaceMotion$0;-><init>(Landroid/view/View;ZZF)V

    new-instance v7, Ldev/nino/squareglass/SurfaceMotion$2;

    invoke-direct {v7, p0, p1, p2}, Ldev/nino/squareglass/SurfaceMotion$2;-><init>(Landroid/view/View;ZZ)V

    const-string v2, "enter"

    const/4 v3, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v5, 0x0

    move-object v1, p0

    invoke-static/range {v1 .. v7}, Ldev/nino/squareglass/LiquidViewMotion;->animate(Landroid/view/View;Ljava/lang/String;FFZLjava/util/function/Consumer;Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic lambda$enter$0(Landroid/view/View;ZZFLjava/lang/Float;)V
    .locals 3

    if-eqz p1, :cond_0

    const v0, 0x3e19999a    # 0.15f

    .line 23
    invoke-virtual {p4}, Ljava/lang/Float;->floatValue()F

    move-result v1

    mul-float/2addr v1, v0

    const v0, 0x3f59999a    # 0.85f

    add-float/2addr v1, v0

    goto :goto_0

    :cond_0
    invoke-virtual {p4}, Ljava/lang/Float;->floatValue()F

    move-result v1

    :goto_0
    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/4 v2, 0x0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->setAlpha(F)V

    if-eqz p2, :cond_1

    const v1, 0x3d0f5c29    # 0.035f

    .line 25
    invoke-virtual {p4}, Ljava/lang/Float;->floatValue()F

    move-result v2

    mul-float/2addr v2, v1

    const v1, 0x3f770a3d    # 0.965f

    add-float/2addr v2, v1

    invoke-virtual {p0, v2}, Landroid/view/View;->setScaleX(F)V

    const v1, 0x3ca3d70a    # 0.02f

    .line 26
    invoke-virtual {p4}, Ljava/lang/Float;->floatValue()F

    move-result v2

    mul-float/2addr v2, v1

    const v1, 0x3f7ae148    # 0.98f

    add-float/2addr v2, v1

    invoke-virtual {p0, v2}, Landroid/view/View;->setScaleY(F)V

    :cond_1
    if-nez p2, :cond_2

    if-nez p1, :cond_2

    .line 28
    invoke-virtual {p4}, Ljava/lang/Float;->floatValue()F

    move-result p1

    sub-float/2addr v0, p1

    mul-float/2addr p3, v0

    invoke-virtual {p0, p3}, Landroid/view/View;->setTranslationY(F)V

    :cond_2
    return-void
.end method

.method static synthetic lambda$enter$1(Landroid/view/View;ZZ)V
    .locals 0

    .line 29
    invoke-static {p0}, Ldev/nino/squareglass/SurfaceMotion;->reset(Landroid/view/View;)V

    if-nez p1, :cond_0

    if-nez p2, :cond_0

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setTranslationY(F)V

    :cond_0
    return-void
.end method

.method public static reset(Landroid/view/View;)V
    .locals 1

    const/high16 v0, 0x3f800000    # 1.0f

    .line 32
    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleY(F)V

    return-void
.end method
