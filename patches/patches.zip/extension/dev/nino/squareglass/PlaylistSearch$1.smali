.class Ldev/nino/squareglass/PlaylistSearch$1;
.super Ljava/lang/Object;
.source "PlaylistSearch.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/PlaylistSearch;->style(Landroidx/appcompat/widget/SearchView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$search:Landroidx/appcompat/widget/SearchView;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/SearchView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 14
    iput-object p1, p0, Ldev/nino/squareglass/PlaylistSearch$1;->val$search:Landroidx/appcompat/widget/SearchView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    .line 15
    iget-object p0, p0, Ldev/nino/squareglass/PlaylistSearch$1;->val$search:Landroidx/appcompat/widget/SearchView;

    invoke-static {p0}, Ldev/nino/squareglass/PlaylistSearch;->-$$Nest$smpaint(Landroidx/appcompat/widget/SearchView;)V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method
