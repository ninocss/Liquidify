.class public final synthetic Ldev/nino/squareglass/NativePlayback$5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Ljava/util/LinkedHashMap;


# direct methods
.method public synthetic constructor <init>(ILjava/util/LinkedHashMap;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Ldev/nino/squareglass/NativePlayback$5;->f$0:I

    iput-object p2, p0, Ldev/nino/squareglass/NativePlayback$5;->f$1:Ljava/util/LinkedHashMap;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget v0, p0, Ldev/nino/squareglass/NativePlayback$5;->f$0:I

    iget-object p0, p0, Ldev/nino/squareglass/NativePlayback$5;->f$1:Ljava/util/LinkedHashMap;

    invoke-static {v0, p0}, Ldev/nino/squareglass/NativePlayback;->lambda$initialize$0(ILjava/util/LinkedHashMap;)V

    return-void
.end method
