.class final Ldev/nino/squareglass/SquareDetails$Hero;
.super Ljava/lang/Object;
.source "SquareDetails.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareDetails;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Hero"
.end annotation


# instance fields
.field final artwork:Landroid/widget/ImageView;

.field last:Landroid/graphics/drawable/Drawable;

.field lastDark:Z

.field final root:Landroid/view/View;

.field watching:Z


# direct methods
.method static bridge synthetic -$$Nest$smsample(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/SquareDetails$Hero;->sample(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Landroid/view/View;Landroid/widget/ImageView;)V
    .locals 0

    .line 376
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->root:Landroid/view/View;

    iput-object p2, p0, Ldev/nino/squareglass/SquareDetails$Hero;->artwork:Landroid/widget/ImageView;

    return-void
.end method

.method private static sample(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    .locals 7

    .line 411
    :cond_0
    instance-of v0, p0, Lcoil/drawable/CrossfadeDrawable;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    .line 412
    check-cast p0, Lcoil/drawable/CrossfadeDrawable;

    iget-object p0, p0, Lcoil/drawable/CrossfadeDrawable;->k:Landroid/graphics/drawable/Drawable;

    if-nez p0, :cond_0

    return-object v1

    .line 415
    :cond_1
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/16 v2, 0x18

    invoke-static {v2, v2, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 416
    new-instance v3, Landroid/graphics/Canvas;

    invoke-direct {v3, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 417
    instance-of v4, p0, Landroid/graphics/drawable/BitmapDrawable;

    const/4 v5, 0x0

    if-eqz v4, :cond_5

    .line 418
    check-cast p0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p0

    .line 419
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    move-result-object v4

    sget-object v6, Landroid/graphics/Bitmap$Config;->HARDWARE:Landroid/graphics/Bitmap$Config;

    if-ne v4, v6, :cond_2

    sget-object v4, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-virtual {p0, v4, v5}, Landroid/graphics/Bitmap;->copy(Landroid/graphics/Bitmap$Config;Z)Landroid/graphics/Bitmap;

    move-result-object v4

    goto :goto_0

    :cond_2
    move-object v4, p0

    :goto_0
    if-nez v4, :cond_3

    .line 420
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    return-object v1

    .line 421
    :cond_3
    new-instance v6, Landroid/graphics/Rect;

    invoke-direct {v6, v5, v5, v2, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    new-instance v2, Landroid/graphics/Paint;

    const/4 v5, 0x2

    invoke-direct {v2, v5}, Landroid/graphics/Paint;-><init>(I)V

    invoke-virtual {v3, v4, v1, v6, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    if-eq v4, p0, :cond_4

    .line 422
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->recycle()V

    :cond_4
    return-object v0

    .line 424
    :cond_5
    new-instance v4, Landroid/graphics/Rect;

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v6

    invoke-direct {v4, v6}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    .line 425
    :try_start_0
    invoke-virtual {p0, v5, v5, v2, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {p0, v3}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 427
    invoke-virtual {p0, v4}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    return-object v0

    :catchall_0
    move-exception v0

    goto :goto_1

    .line 426
    :catch_0
    :try_start_1
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 427
    invoke-virtual {p0, v4}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    return-object v1

    :goto_1
    invoke-virtual {p0, v4}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    throw v0
.end method


# virtual methods
.method public onPreDraw()Z
    .locals 12

    .line 378
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$Hero;->artwork:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 379
    :goto_0
    instance-of v1, v0, Lcoil/drawable/CrossfadeDrawable;

    if-eqz v1, :cond_0

    check-cast v0, Lcoil/drawable/CrossfadeDrawable;

    iget-object v0, v0, Lcoil/drawable/CrossfadeDrawable;->k:Landroid/graphics/drawable/Drawable;

    goto :goto_0

    .line 380
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v0, :cond_7

    .line 381
    iget-object v3, p0, Ldev/nino/squareglass/SquareDetails$Hero;->last:Landroid/graphics/drawable/Drawable;

    if-ne v0, v3, :cond_1

    iget-boolean v3, p0, Ldev/nino/squareglass/SquareDetails$Hero;->lastDark:Z

    if-eq v1, v3, :cond_7

    :cond_1
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v3

    if-lez v3, :cond_7

    .line 382
    invoke-static {v0}, Ldev/nino/squareglass/SquareDetails$Hero;->sample(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;

    move-result-object v4

    if-nez v4, :cond_2

    return v2

    .line 384
    :cond_2
    iput-object v0, p0, Ldev/nino/squareglass/SquareDetails$Hero;->last:Landroid/graphics/drawable/Drawable;

    iput-boolean v1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->lastDark:Z

    const/16 v0, 0x240

    .line 385
    new-array v5, v0, [I

    const/16 v10, 0x18

    const/16 v11, 0x18

    const/4 v6, 0x0

    const/16 v7, 0x18

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Bitmap;->getPixels([IIIIIII)V

    invoke-virtual {v4}, Landroid/graphics/Bitmap;->recycle()V

    .line 386
    invoke-static {v5}, Ldev/nino/squareglass/CoverColors;->seed([I)I

    move-result v0

    invoke-static {v0, v1}, Ldev/nino/squareglass/CoverColors;->surface(IZ)I

    move-result v0

    .line 387
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->root:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 388
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->artwork:Landroid/widget/ImageView;

    invoke-virtual {v1}, Landroid/widget/ImageView;->getId()I

    move-result v1

    const v3, 0x7f0b00b8

    if-ne v1, v3, :cond_3

    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->artwork:Landroid/widget/ImageView;

    new-instance v3, Ldev/nino/squareglass/SquareDetails$CoverFade;

    invoke-direct {v3, v0}, Ldev/nino/squareglass/SquareDetails$CoverFade;-><init>(I)V

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setForeground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_1

    .line 390
    :cond_3
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->root:Landroid/view/View;

    const v3, 0x7f0b00a9

    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_4

    .line 391
    new-instance v3, Ldev/nino/squareglass/SquareDetails$CoverFade;

    invoke-direct {v3, v0}, Ldev/nino/squareglass/SquareDetails$CoverFade;-><init>(I)V

    invoke-virtual {v1, v3}, Landroid/view/View;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 392
    :cond_4
    iget-object v1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->artwork:Landroid/widget/ImageView;

    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    sget-object v4, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const v5, 0xffffff

    and-int/2addr v5, v0

    const/high16 v6, -0x1a000000

    or-int/2addr v5, v6

    filled-new-array {v5, v0}, [I

    move-result-object v5

    invoke-direct {v3, v4, v5}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 395
    :goto_1
    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$Hero;->root:Landroid/view/View;

    .line 396
    :cond_5
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/View;

    if-eqz v1, :cond_7

    .line 397
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    .line 398
    instance-of v1, p0, Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v1, :cond_6

    move-object v1, p0

    goto :goto_2

    :cond_6
    const v1, 0x7f0b05b8

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 399
    :goto_2
    instance-of v3, v1, Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v3, :cond_5

    .line 400
    invoke-virtual {v1, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 402
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    instance-of p0, p0, Landroid/view/View;

    if-eqz p0, :cond_7

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_7
    return v2
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    .line 432
    iget-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->watching:Z

    if-nez p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->watching:Z

    :cond_0
    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    .line 435
    iget-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->watching:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    :cond_0
    const/4 p1, 0x0

    .line 436
    iput-boolean p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->watching:Z

    const/4 p1, 0x0

    iput-object p1, p0, Ldev/nino/squareglass/SquareDetails$Hero;->last:Landroid/graphics/drawable/Drawable;

    return-void
.end method
