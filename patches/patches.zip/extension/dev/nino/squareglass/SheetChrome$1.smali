.class Ldev/nino/squareglass/SheetChrome$1;
.super Ljava/lang/Object;
.source "SheetChrome.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SheetChrome;->opened(Landroid/app/Dialog;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$glass:Ldev/nino/squareglass/LiquidMenuSurface;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/LiquidMenuSurface;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 101
    iput-object p1, p0, Ldev/nino/squareglass/SheetChrome$1;->val$glass:Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    .line 104
    iget-object v0, p0, Ldev/nino/squareglass/SheetChrome$1;->val$glass:Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-virtual {v0}, Ldev/nino/squareglass/LiquidMenuSurface;->release()V

    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method
