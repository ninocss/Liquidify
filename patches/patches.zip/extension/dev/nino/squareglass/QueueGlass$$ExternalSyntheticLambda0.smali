.class public final synthetic Ldev/nino/squareglass/QueueGlass$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/MenuItem$OnMenuItemClickListener;


# instance fields
.field public final synthetic f$0:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/QueueGlass$$ExternalSyntheticLambda0;->f$0:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final onMenuItemClick(Landroid/view/MenuItem;)Z
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/QueueGlass$$ExternalSyntheticLambda0;->f$0:Landroid/view/View;

    invoke-static {p0, p1}, Ldev/nino/squareglass/QueueGlass;->lambda$install$0(Landroid/view/View;Landroid/view/MenuItem;)Z

    move-result p0

    return p0
.end method
