.class public final synthetic Ldev/nino/squareglass/SquareOutput$Session$8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareOutput$Session;

.field public final synthetic f$1:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareOutput$Session;Ljava/lang/Object;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session$8;->f$0:Ldev/nino/squareglass/SquareOutput$Session;

    iput-object p2, p0, Ldev/nino/squareglass/SquareOutput$Session$8;->f$1:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session$8;->f$0:Ldev/nino/squareglass/SquareOutput$Session;

    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session$8;->f$1:Ljava/lang/Object;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->$r8$lambda$cMoUvCYy9ANICtSCahnZuxjb9FI(Ldev/nino/squareglass/SquareOutput$Session;Ljava/lang/Object;Landroid/view/View;)V

    return-void
.end method
