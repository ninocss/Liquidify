.class public final synthetic Ldev/nino/squareglass/NativeIconGlass$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/NativeIconGlass$State;

.field public final synthetic f$1:Landroidx/compose/ui/platform/ComposeView;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/NativeIconGlass$State;Landroidx/compose/ui/platform/ComposeView;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$1;->f$0:Ldev/nino/squareglass/NativeIconGlass$State;

    iput-object p2, p0, Ldev/nino/squareglass/NativeIconGlass$1;->f$1:Landroidx/compose/ui/platform/ComposeView;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeIconGlass$1;->f$0:Ldev/nino/squareglass/NativeIconGlass$State;

    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$1;->f$1:Landroidx/compose/ui/platform/ComposeView;

    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {v0, p0, p1, p2}, Ldev/nino/squareglass/NativeIconGlass;->attach$lambda$1(Ldev/nino/squareglass/NativeIconGlass$State;Landroidx/compose/ui/platform/ComposeView;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
