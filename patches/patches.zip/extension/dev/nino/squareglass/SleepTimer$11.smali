.class public final synthetic Ldev/nino/squareglass/SleepTimer$11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/app/AlarmManager$OnAlarmListener;


# instance fields
.field public final synthetic f$0:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Runnable;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$11;->f$0:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final onAlarm()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$11;->f$0:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method
