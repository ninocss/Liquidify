.class public final synthetic Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ldev/nino/squareglass/OpenHome$Trace;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final record(Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p1}, Ldev/nino/squareglass/LinnProvider;->lambda$new$0(Ljava/lang/String;)V

    return-void
.end method
