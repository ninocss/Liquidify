.class public final synthetic Ldev/nino/squareglass/SquareMenus$Presentation$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareMenus$Presentation;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareMenus$Presentation;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareMenus$Presentation$1;->f$0:Ldev/nino/squareglass/SquareMenus$Presentation;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation$1;->f$0:Ldev/nino/squareglass/SquareMenus$Presentation;

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->timedOut()V

    return-void
.end method
