.class public final synthetic Ldev/nino/squareglass/SquareExplore$Binding$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareExplore$Binding;

.field public final synthetic f$1:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareExplore$Binding;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareExplore$Binding$0;->f$0:Ldev/nino/squareglass/SquareExplore$Binding;

    iput-object p2, p0, Ldev/nino/squareglass/SquareExplore$Binding$0;->f$1:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SquareExplore$Binding$0;->f$0:Ldev/nino/squareglass/SquareExplore$Binding;

    iget-object p0, p0, Ldev/nino/squareglass/SquareExplore$Binding$0;->f$1:Landroid/view/View;

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareExplore$Binding;->$r8$lambda$As3g_LihEb-QUqlcteanAIsVXlQ(Ldev/nino/squareglass/SquareExplore$Binding;Landroid/view/View;)V

    return-void
.end method
