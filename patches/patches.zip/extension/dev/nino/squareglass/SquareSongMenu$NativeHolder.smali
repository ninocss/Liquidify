.class final Ldev/nino/squareglass/SquareSongMenu$NativeHolder;
.super Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
.source "SquareSongMenu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareSongMenu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "NativeHolder"
.end annotation


# instance fields
.field final nativeHolder:Landroidx/recyclerview/widget/RecyclerView$ViewHolder;


# direct methods
.method constructor <init>(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V
    .locals 1

    .line 248
    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    invoke-direct {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    iput-object p1, p0, Ldev/nino/squareglass/SquareSongMenu$NativeHolder;->nativeHolder:Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    return-void
.end method
