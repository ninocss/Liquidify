.class public final Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;
.super Ljava/lang/Object;
.source "ColorFilter.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0002\u0008\u0008\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0000\u001a\u00020\u0003\u001a\u0014\u0010\u0004\u001a\u00020\u0001*\u00020\u00022\u0008\u0008\u0001\u0010\u0005\u001a\u00020\u0006\u001a(\u0010\u0007\u001a\u00020\u0001*\u00020\u00022\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u00062\u0008\u0008\u0002\u0010\t\u001a\u00020\u00062\u0008\u0008\u0002\u0010\n\u001a\u00020\u0006\u001a\n\u0010\u000c\u001a\u00020\u0001*\u00020\u0002\u001a&\u0010\r\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u00062\u0008\u0008\u0002\u0010\t\u001a\u00020\u00062\u0008\u0008\u0002\u0010\n\u001a\u00020\u0006H\u0002\"\u000e\u0010\u000b\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000e"
    }
    d2 = {
        "colorFilter",
        "",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "Landroidx/compose/ui/graphics/ColorFilter;",
        "opacity",
        "alpha",
        "",
        "colorControls",
        "brightness",
        "contrast",
        "saturation",
        "VibrantColorFilter",
        "vibrancy",
        "colorControlsColorFilter",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final VibrantColorFilter:Landroidx/compose/ui/graphics/ColorFilter;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/high16 v3, 0x3fc00000    # 1.5f

    .line 50
    invoke-static {v2, v2, v3, v0, v1}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->colorControlsColorFilter$default(FFFILjava/lang/Object;)Landroidx/compose/ui/graphics/ColorFilter;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->VibrantColorFilter:Landroidx/compose/ui/graphics/ColorFilter;

    return-void
.end method

.method public static final colorControls(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFF)V
    .locals 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    cmpg-float v0, p1, v0

    if-nez v0, :cond_0

    const/high16 v0, 0x3f800000    # 1.0f

    cmpg-float v1, p2, v0

    if-nez v1, :cond_0

    cmpg-float v0, p3, v0

    if-nez v0, :cond_0

    return-void

    .line 47
    :cond_0
    invoke-static {p1, p2, p3}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->colorControlsColorFilter(FFF)Landroidx/compose/ui/graphics/ColorFilter;

    move-result-object p1

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->colorFilter(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/graphics/ColorFilter;)V

    return-void
.end method

.method public static synthetic colorControls$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFFILjava/lang/Object;)V
    .locals 1

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_0

    const/4 p1, 0x0

    :cond_0
    and-int/lit8 p5, p4, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    if-eqz p5, :cond_1

    move p2, v0

    :cond_1
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_2

    move p3, v0

    .line 38
    :cond_2
    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->colorControls(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFF)V

    return-void
.end method

.method private static final colorControlsColorFilter(FFF)Landroidx/compose/ui/graphics/ColorFilter;
    .locals 7

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float v1, v0, p2

    const v2, 0x3e5a1cac    # 0.213f

    mul-float/2addr v2, v1

    const v3, 0x3f370a3d    # 0.715f

    mul-float/2addr v3, v1

    const v4, 0x3d9374bc    # 0.072f

    mul-float/2addr v1, v4

    const/high16 v4, 0x3f000000    # 0.5f

    mul-float v5, p1, v4

    sub-float/2addr v4, v5

    add-float/2addr v4, p0

    const/high16 p0, 0x437f0000    # 255.0f

    mul-float/2addr v4, p0

    mul-float/2addr v2, p1

    mul-float/2addr v3, p1

    mul-float/2addr v1, p1

    mul-float/2addr p1, p2

    add-float p0, v2, p1

    add-float p2, v3, p1

    add-float/2addr p1, v1

    const/16 v5, 0x14

    .line 80
    new-array v5, v5, [F

    const/4 v6, 0x0

    aput p0, v5, v6

    const/4 p0, 0x1

    aput v3, v5, p0

    const/4 p0, 0x2

    aput v1, v5, p0

    const/4 p0, 0x3

    const/4 v6, 0x0

    aput v6, v5, p0

    const/4 p0, 0x4

    aput v4, v5, p0

    const/4 p0, 0x5

    aput v2, v5, p0

    const/4 p0, 0x6

    aput p2, v5, p0

    const/4 p0, 0x7

    aput v1, v5, p0

    const/16 p0, 0x8

    aput v6, v5, p0

    const/16 p0, 0x9

    aput v4, v5, p0

    const/16 p0, 0xa

    aput v2, v5, p0

    const/16 p0, 0xb

    aput v3, v5, p0

    const/16 p0, 0xc

    aput p1, v5, p0

    const/16 p0, 0xd

    aput v6, v5, p0

    const/16 p0, 0xe

    aput v4, v5, p0

    const/16 p0, 0xf

    aput v6, v5, p0

    const/16 p0, 0x10

    aput v6, v5, p0

    const/16 p0, 0x11

    aput v6, v5, p0

    const/16 p0, 0x12

    aput v0, v5, p0

    const/16 p0, 0x13

    aput v6, v5, p0

    .line 75
    invoke-static {v5}, Landroidx/compose/ui/graphics/ColorMatrix;->constructor-impl([F)[F

    move-result-object p0

    .line 83
    new-instance p1, Landroidx/compose/ui/graphics/ColorMatrixColorFilter;

    const/4 p2, 0x0

    invoke-direct {p1, p0, p2}, Landroidx/compose/ui/graphics/ColorMatrixColorFilter;-><init>([FLkotlin/jvm/internal/DefaultConstructorMarker;)V

    check-cast p1, Landroidx/compose/ui/graphics/ColorFilter;

    return-object p1
.end method

.method static synthetic colorControlsColorFilter$default(FFFILjava/lang/Object;)Landroidx/compose/ui/graphics/ColorFilter;
    .locals 1

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_0

    const/4 p0, 0x0

    :cond_0
    and-int/lit8 p4, p3, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    if-eqz p4, :cond_1

    move p1, v0

    :cond_1
    and-int/lit8 p3, p3, 0x4

    if-eqz p3, :cond_2

    move p2, v0

    .line 56
    :cond_2
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->colorControlsColorFilter(FFF)Landroidx/compose/ui/graphics/ColorFilter;

    move-result-object p0

    return-object p0
.end method

.method public static final colorFilter(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/graphics/ColorFilter;)V
    .locals 1

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "colorFilter"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRenderEffectSupported()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 23
    :cond_0
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object v0

    invoke-static {v0, p1}, Ldev/nino/squareglass/backdrop/internal/RenderEffectKt;->ColorFilterEffect(Landroidx/compose/ui/graphics/RenderEffect;Landroidx/compose/ui/graphics/ColorFilter;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p1

    invoke-interface {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    return-void
.end method

.method public static final opacity(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)V
    .locals 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v0, 0x14

    .line 32
    new-array v0, v0, [F

    const/4 v1, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    aput v2, v0, v1

    const/4 v1, 0x1

    const/4 v3, 0x0

    aput v3, v0, v1

    const/4 v1, 0x2

    aput v3, v0, v1

    const/4 v1, 0x3

    aput v3, v0, v1

    const/4 v1, 0x4

    aput v3, v0, v1

    const/4 v1, 0x5

    aput v3, v0, v1

    const/4 v1, 0x6

    aput v2, v0, v1

    const/4 v1, 0x7

    aput v3, v0, v1

    const/16 v1, 0x8

    aput v3, v0, v1

    const/16 v1, 0x9

    aput v3, v0, v1

    const/16 v1, 0xa

    aput v3, v0, v1

    const/16 v1, 0xb

    aput v3, v0, v1

    const/16 v1, 0xc

    aput v2, v0, v1

    const/16 v1, 0xd

    aput v3, v0, v1

    const/16 v1, 0xe

    aput v3, v0, v1

    const/16 v1, 0xf

    aput v3, v0, v1

    const/16 v1, 0x10

    aput v3, v0, v1

    const/16 v1, 0x11

    aput v3, v0, v1

    const/16 v1, 0x12

    aput p1, v0, v1

    const/16 p1, 0x13

    aput v3, v0, p1

    .line 27
    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorMatrix;->constructor-impl([F)[F

    move-result-object p1

    .line 35
    new-instance v0, Landroidx/compose/ui/graphics/ColorMatrixColorFilter;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, Landroidx/compose/ui/graphics/ColorMatrixColorFilter;-><init>([FLkotlin/jvm/internal/DefaultConstructorMarker;)V

    check-cast v0, Landroidx/compose/ui/graphics/ColorFilter;

    invoke-static {p0, v0}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->colorFilter(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/graphics/ColorFilter;)V

    return-void
.end method

.method public static final vibrancy(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)V
    .locals 1

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    sget-object v0, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->VibrantColorFilter:Landroidx/compose/ui/graphics/ColorFilter;

    invoke-static {p0, v0}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->colorFilter(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/graphics/ColorFilter;)V

    return-void
.end method
