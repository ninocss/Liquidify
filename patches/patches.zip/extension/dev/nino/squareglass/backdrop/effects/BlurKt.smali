.class public final Ldev/nino/squareglass/backdrop/effects/BlurKt;
.super Ljava/lang/Object;
.source "Blur.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a%\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0008\u0008\u0001\u0010\u0003\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008\u00a8\u0006\t"
    }
    d2 = {
        "blur",
        "",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "radius",
        "",
        "edgeTreatment",
        "Landroidx/compose/ui/graphics/TileMode;",
        "blur-3YTHUZs",
        "(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FI)V",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final blur-3YTHUZs(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FI)V
    .locals 7

    const-string v0, "$this$blur"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRenderEffectSupported()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    cmpg-float v0, p1, v0

    if-gtz v0, :cond_1

    :goto_0
    return-void

    .line 25
    :cond_1
    sget-object v0, Landroidx/compose/ui/graphics/TileMode;->Companion:Landroidx/compose/ui/graphics/TileMode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/TileMode$Companion;->getClamp-3opZhB0()I

    move-result v0

    invoke-static {p2, v0}, Landroidx/compose/ui/graphics/TileMode;->equals-impl0(II)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object v0

    if-eqz v0, :cond_3

    .line 26
    :cond_2
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getPadding()F

    move-result v0

    cmpl-float v0, p1, v0

    if-lez v0, :cond_3

    .line 27
    invoke-interface {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->setPadding(F)V

    .line 32
    :cond_3
    new-instance v1, Landroidx/compose/ui/graphics/BlurEffect;

    .line 33
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object v2

    const/4 v6, 0x0

    move v4, p1

    move v3, p1

    move v5, p2

    .line 32
    invoke-direct/range {v1 .. v6}, Landroidx/compose/ui/graphics/BlurEffect;-><init>(Landroidx/compose/ui/graphics/RenderEffect;FFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    check-cast v1, Landroidx/compose/ui/graphics/RenderEffect;

    .line 31
    invoke-interface {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    return-void
.end method

.method public static synthetic blur-3YTHUZs$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FIILjava/lang/Object;)V
    .locals 0

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    .line 20
    sget-object p2, Landroidx/compose/ui/graphics/TileMode;->Companion:Landroidx/compose/ui/graphics/TileMode$Companion;

    invoke-virtual {p2}, Landroidx/compose/ui/graphics/TileMode$Companion;->getClamp-3opZhB0()I

    move-result p2

    .line 18
    :cond_0
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/effects/BlurKt;->blur-3YTHUZs(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FI)V

    return-void
.end method
