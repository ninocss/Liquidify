.class public final Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;
.super Ljava/lang/Object;
.source "RuntimeShaderCache.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/RuntimeShaderCache;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nRuntimeShaderCache.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RuntimeShaderCache.kt\ndev/nino/squareglass/backdrop/RuntimeShaderCacheImpl\n+ 2 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,31:1\n410#2,7:32\n*S KotlinDebug\n*F\n+ 1 RuntimeShaderCache.kt\ndev/nino/squareglass/backdrop/RuntimeShaderCacheImpl\n*L\n24#1:32,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0002\n\u0000\u0008\u0001\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0018\u0010\u0008\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0006H\u0016J\u0006\u0010\u000b\u001a\u00020\u000cR\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCache;",
        "<init>",
        "()V",
        "runtimeShaders",
        "",
        "",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "obtainRuntimeShader",
        "key",
        "string",
        "clear",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final runtimeShaders:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ldev/nino/squareglass/backdrop/RuntimeShader;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v0, Ljava/util/Map;

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;->runtimeShaders:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final clear()V
    .locals 0

    .line 28
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;->runtimeShaders:Ljava/util/Map;

    invoke-interface {p0}, Ljava/util/Map;->clear()V

    return-void
.end method

.method public obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;
    .locals 1

    const-string v0, "key"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "string"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;->runtimeShaders:Ljava/util/Map;

    .line 32
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    .line 24
    invoke-static {p2}, Ldev/nino/squareglass/backdrop/RuntimeShaderKt;->RuntimeShader(Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;

    move-result-object v0

    .line 35
    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    :cond_0
    check-cast v0, Ldev/nino/squareglass/backdrop/RuntimeShader;

    return-object v0
.end method
