.class public final Ldev/nino/squareglass/backdrop/Backdrop$DefaultImpls;
.super Ljava/lang/Object;
.source "Backdrop.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/backdrop/Backdrop;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "DefaultImpls"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic drawBackdrop$default(Ldev/nino/squareglass/backdrop/Backdrop;Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;ILjava/lang/Object;)V
    .locals 0

    .line 21
    invoke-static/range {p0 .. p6}, Ldev/nino/squareglass/backdrop/Backdrop;->drawBackdrop$default(Ldev/nino/squareglass/backdrop/Backdrop;Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;ILjava/lang/Object;)V

    return-void
.end method
