.class public final Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;
.super Ljava/lang/Object;
.source "InverseLayerScope.kt"

# interfaces
.implements Landroidx/compose/ui/graphics/GraphicsLayerScope;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInverseLayerScope.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InverseLayerScope.kt\ndev/nino/squareglass/backdrop/internal/InverseLayerScope\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Matrix.kt\nandroidx/compose/ui/graphics/Matrix\n*L\n1#1,140:1\n1#2:141\n52#3,2:142\n52#3,2:144\n52#3,2:146\n52#3,2:148\n*S KotlinDebug\n*F\n+ 1 InverseLayerScope.kt\ndev/nino/squareglass/backdrop/internal/InverseLayerScope\n*L\n132#1:142,2\n133#1:144,2\n134#1:146,2\n135#1:148,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0010\u0007\n\u0002\u0008\u001a\n\u0002\u0018\u0002\n\u0002\u0008\u0012\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0001\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J+\u0010c\u001a\u00020d*\u00020e2\u0006\u0010\u000b\u001a\u00020f2\u0017\u0010g\u001a\u0013\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020d0h\u00a2\u0006\u0002\u0008iJ\u0006\u0010j\u001a\u00020dJ*\u0010k\u001a\u00020d*\u00020e2\u0008\u0008\u0002\u00103\u001a\u00020\u000c2\u0008\u0008\u0002\u0010\u0014\u001a\u00020\u000c2\u0008\u0008\u0002\u0010\u0017\u001a\u00020\u000cH\u0002R\u001c\u0010\u0004\u001a\u00020\u0005X\u0096\u000e\u00a2\u0006\u0010\n\u0002\u0010\n\u001a\u0004\u0008\u0006\u0010\u0007\"\u0004\u0008\u0008\u0010\tR\u001a\u0010\u000b\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\r\u0010\u000e\"\u0004\u0008\u000f\u0010\u0010R\u001a\u0010\u0011\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0012\u0010\u000e\"\u0004\u0008\u0013\u0010\u0010R\u001a\u0010\u0014\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0015\u0010\u000e\"\u0004\u0008\u0016\u0010\u0010R\u001a\u0010\u0017\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0018\u0010\u000e\"\u0004\u0008\u0019\u0010\u0010R\u001a\u0010\u001a\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001b\u0010\u000e\"\u0004\u0008\u001c\u0010\u0010R\u001a\u0010\u001d\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001e\u0010\u000e\"\u0004\u0008\u001f\u0010\u0010R\u001a\u0010 \u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008!\u0010\u000e\"\u0004\u0008\"\u0010\u0010R\u001a\u0010#\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008$\u0010\u000e\"\u0004\u0008%\u0010\u0010R\u001c\u0010&\u001a\u00020\'X\u0096\u000e\u00a2\u0006\u0010\n\u0002\u0010\n\u001a\u0004\u0008(\u0010\u0007\"\u0004\u0008)\u0010\tR\u001c\u0010*\u001a\u00020\'X\u0096\u000e\u00a2\u0006\u0010\n\u0002\u0010\n\u001a\u0004\u0008+\u0010\u0007\"\u0004\u0008,\u0010\tR\u001a\u0010-\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008.\u0010\u000e\"\u0004\u0008/\u0010\u0010R\u001a\u00100\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00081\u0010\u000e\"\u0004\u00082\u0010\u0010R\u001a\u00103\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00084\u0010\u000e\"\u0004\u00085\u0010\u0010R\u001a\u00106\u001a\u00020\u000cX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00087\u0010\u000e\"\u0004\u00088\u0010\u0010R\u001c\u00109\u001a\u00020:X\u0096\u000e\u00a2\u0006\u0010\n\u0002\u0010\n\u001a\u0004\u0008;\u0010\u0007\"\u0004\u0008<\u0010\tR\u001a\u0010=\u001a\u00020>X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008?\u0010@\"\u0004\u0008A\u0010BR\u001a\u0010C\u001a\u00020DX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008E\u0010F\"\u0004\u0008G\u0010HR\u001c\u0010I\u001a\u0004\u0018\u00010JX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008K\u0010L\"\u0004\u0008M\u0010NR\u001c\u0010O\u001a\u00020PX\u0096\u000e\u00a2\u0006\u0010\n\u0002\u0010U\u001a\u0004\u0008Q\u0010R\"\u0004\u0008S\u0010TR\u001c\u0010V\u001a\u0004\u0018\u00010WX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008X\u0010Y\"\u0004\u0008Z\u0010[R\u001c\u0010\\\u001a\u00020]X\u0096\u000e\u00a2\u0006\u0010\n\u0002\u0010U\u001a\u0004\u0008^\u0010R\"\u0004\u0008_\u0010TR\u0012\u0010`\u001a\u0004\u0018\u00010aX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010b\u00a8\u0006l"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "<init>",
        "()V",
        "size",
        "Landroidx/compose/ui/geometry/Size;",
        "getSize-NH-jbRc",
        "()J",
        "setSize-uvyYCjk",
        "(J)V",
        "J",
        "density",
        "",
        "getDensity",
        "()F",
        "setDensity",
        "(F)V",
        "fontScale",
        "getFontScale",
        "setFontScale",
        "scaleX",
        "getScaleX",
        "setScaleX",
        "scaleY",
        "getScaleY",
        "setScaleY",
        "alpha",
        "getAlpha",
        "setAlpha",
        "translationX",
        "getTranslationX",
        "setTranslationX",
        "translationY",
        "getTranslationY",
        "setTranslationY",
        "shadowElevation",
        "getShadowElevation",
        "setShadowElevation",
        "ambientShadowColor",
        "Landroidx/compose/ui/graphics/Color;",
        "getAmbientShadowColor-0d7_KjU",
        "setAmbientShadowColor-8_81llA",
        "spotShadowColor",
        "getSpotShadowColor-0d7_KjU",
        "setSpotShadowColor-8_81llA",
        "rotationX",
        "getRotationX",
        "setRotationX",
        "rotationY",
        "getRotationY",
        "setRotationY",
        "rotationZ",
        "getRotationZ",
        "setRotationZ",
        "cameraDistance",
        "getCameraDistance",
        "setCameraDistance",
        "transformOrigin",
        "Landroidx/compose/ui/graphics/TransformOrigin;",
        "getTransformOrigin-SzJe1aQ",
        "setTransformOrigin-__ExYCQ",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "getShape",
        "()Landroidx/compose/ui/graphics/Shape;",
        "setShape",
        "(Landroidx/compose/ui/graphics/Shape;)V",
        "clip",
        "",
        "getClip",
        "()Z",
        "setClip",
        "(Z)V",
        "renderEffect",
        "Landroidx/compose/ui/graphics/RenderEffect;",
        "getRenderEffect",
        "()Landroidx/compose/ui/graphics/RenderEffect;",
        "setRenderEffect",
        "(Landroidx/compose/ui/graphics/RenderEffect;)V",
        "blendMode",
        "Landroidx/compose/ui/graphics/BlendMode;",
        "getBlendMode-0nO6VwU",
        "()I",
        "setBlendMode-s9anfk8",
        "(I)V",
        "I",
        "colorFilter",
        "Landroidx/compose/ui/graphics/ColorFilter;",
        "getColorFilter",
        "()Landroidx/compose/ui/graphics/ColorFilter;",
        "setColorFilter",
        "(Landroidx/compose/ui/graphics/ColorFilter;)V",
        "compositingStrategy",
        "Landroidx/compose/ui/graphics/CompositingStrategy;",
        "getCompositingStrategy--NrFUSI",
        "setCompositingStrategy-aDBOjCE",
        "matrix",
        "Landroidx/compose/ui/graphics/Matrix;",
        "[F",
        "inverseTransform",
        "",
        "Landroidx/compose/ui/graphics/drawscope/DrawTransform;",
        "Landroidx/compose/ui/unit/Density;",
        "layerBlock",
        "Lkotlin/Function1;",
        "Lkotlin/ExtensionFunctionType;",
        "reset",
        "inverseTransformAtTopLeft",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private alpha:F

.field private ambientShadowColor:J

.field private blendMode:I

.field private cameraDistance:F

.field private clip:Z

.field private colorFilter:Landroidx/compose/ui/graphics/ColorFilter;

.field private compositingStrategy:I

.field private density:F

.field private fontScale:F

.field private matrix:[F

.field private renderEffect:Landroidx/compose/ui/graphics/RenderEffect;

.field private rotationX:F

.field private rotationY:F

.field private rotationZ:F

.field private scaleX:F

.field private scaleY:F

.field private shadowElevation:F

.field private shape:Landroidx/compose/ui/graphics/Shape;

.field private size:J

.field private spotShadowColor:J

.field private transformOrigin:J

.field private translationX:F

.field private translationY:F


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    sget-object v0, Landroidx/compose/ui/geometry/Size;->Companion:Landroidx/compose/ui/geometry/Size$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Size$Companion;->getUnspecified-NH-jbRc()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->size:J

    const/high16 v0, 0x3f800000    # 1.0f

    .line 35
    iput v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->density:F

    .line 36
    iput v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->fontScale:F

    .line 38
    iput v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->scaleX:F

    .line 39
    iput v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->scaleY:F

    .line 44
    invoke-static {}, Landroidx/compose/ui/graphics/GraphicsLayerScopeKt;->getDefaultShadowColor()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->ambientShadowColor:J

    .line 45
    invoke-static {}, Landroidx/compose/ui/graphics/GraphicsLayerScopeKt;->getDefaultShadowColor()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->spotShadowColor:J

    const/high16 v0, 0x41000000    # 8.0f

    .line 49
    iput v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->cameraDistance:F

    .line 50
    sget-object v0, Landroidx/compose/ui/graphics/TransformOrigin;->Companion:Landroidx/compose/ui/graphics/TransformOrigin$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/TransformOrigin$Companion;->getCenter-SzJe1aQ()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->transformOrigin:J

    .line 51
    invoke-static {}, Landroidx/compose/ui/graphics/RectangleShapeKt;->getRectangleShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->shape:Landroidx/compose/ui/graphics/Shape;

    .line 54
    sget-object v0, Landroidx/compose/ui/graphics/BlendMode;->Companion:Landroidx/compose/ui/graphics/BlendMode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/BlendMode$Companion;->getSrcOver-0nO6VwU()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->blendMode:I

    .line 56
    sget-object v0, Landroidx/compose/ui/graphics/CompositingStrategy;->Companion:Landroidx/compose/ui/graphics/CompositingStrategy$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/CompositingStrategy$Companion;->getAuto--NrFUSI()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->compositingStrategy:I

    return-void
.end method

.method private final inverseTransformAtTopLeft(Landroidx/compose/ui/graphics/drawscope/DrawTransform;FFF)V
    .locals 8

    const/4 v0, 0x0

    cmpg-float v1, p2, v0

    const/high16 v2, 0x3f800000    # 1.0f

    if-nez v1, :cond_2

    cmpg-float p0, p3, v0

    if-nez p0, :cond_0

    return-void

    :cond_0
    cmpg-float p0, p4, v0

    if-nez p0, :cond_1

    return-void

    :cond_1
    div-float p0, v2, p3

    div-float/2addr v2, p4

    .line 112
    sget-object p2, Landroidx/compose/ui/geometry/Offset;->Companion:Landroidx/compose/ui/geometry/Offset$Companion;

    invoke-virtual {p2}, Landroidx/compose/ui/geometry/Offset$Companion;->getZero-F1C5BW0()J

    move-result-wide p2

    invoke-interface {p1, p0, v2, p2, p3}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->scale-0AR0LA0(FFJ)V

    return-void

    .line 117
    :cond_2
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->matrix:[F

    const/4 v3, 0x1

    if-nez v1, :cond_3

    const/4 v1, 0x0

    invoke-static {v1, v3, v1}, Landroidx/compose/ui/graphics/Matrix;->constructor-impl$default([FILkotlin/jvm/internal/DefaultConstructorMarker;)[F

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->matrix:[F

    .line 118
    :cond_3
    array-length p0, v1

    const/16 v4, 0x10

    if-ge p0, v4, :cond_4

    return-void

    :cond_4
    float-to-double v4, p2

    const-wide v6, 0x3f91df46a2529d39L    # 0.017453292519943295

    mul-double/2addr v4, v6

    .line 121
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    move-result-wide v6

    double-to-float p0, v6

    .line 122
    invoke-static {v4, v5}, Ljava/lang/Math;->cos(D)D

    move-result-wide v4

    double-to-float p2, v4

    mul-float v4, p2, p3

    mul-float v5, p0, p4

    neg-float p0, p0

    mul-float/2addr p0, p3

    mul-float/2addr p2, p4

    mul-float p3, v4, p2

    mul-float p4, v5, p0

    sub-float/2addr p3, p4

    cmpg-float p4, p3, v0

    if-nez p4, :cond_5

    return-void

    :cond_5
    div-float/2addr v2, p3

    mul-float/2addr p2, v2

    const/4 p3, 0x0

    .line 142
    aput p2, v1, p3

    neg-float p2, v5

    mul-float/2addr p2, v2

    .line 144
    aput p2, v1, v3

    neg-float p0, p0

    mul-float/2addr p0, v2

    const/4 p2, 0x4

    .line 146
    aput p0, v1, p2

    mul-float/2addr v4, v2

    const/4 p0, 0x5

    .line 148
    aput v4, v1, p0

    .line 137
    invoke-interface {p1, v1}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->transform-58bKbWc([F)V

    return-void
.end method

.method static synthetic inverseTransformAtTopLeft$default(Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;Landroidx/compose/ui/graphics/drawscope/DrawTransform;FFFILjava/lang/Object;)V
    .locals 1

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_0

    const/4 p2, 0x0

    :cond_0
    and-int/lit8 p6, p5, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    if-eqz p6, :cond_1

    move p3, v0

    :cond_1
    and-int/lit8 p5, p5, 0x4

    if-eqz p5, :cond_2

    move p4, v0

    .line 105
    :cond_2
    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->inverseTransformAtTopLeft(Landroidx/compose/ui/graphics/drawscope/DrawTransform;FFF)V

    return-void
.end method


# virtual methods
.method public getAlpha()F
    .locals 0

    .line 40
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->alpha:F

    return p0
.end method

.method public getAmbientShadowColor-0d7_KjU()J
    .locals 2

    .line 44
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->ambientShadowColor:J

    return-wide v0
.end method

.method public getBlendMode-0nO6VwU()I
    .locals 0

    .line 54
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->blendMode:I

    return p0
.end method

.method public getCameraDistance()F
    .locals 0

    .line 49
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->cameraDistance:F

    return p0
.end method

.method public getClip()Z
    .locals 0

    .line 52
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->clip:Z

    return p0
.end method

.method public getColorFilter()Landroidx/compose/ui/graphics/ColorFilter;
    .locals 0

    .line 55
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->colorFilter:Landroidx/compose/ui/graphics/ColorFilter;

    return-object p0
.end method

.method public getCompositingStrategy--NrFUSI()I
    .locals 0

    .line 56
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->compositingStrategy:I

    return p0
.end method

.method public getDensity()F
    .locals 0

    .line 35
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->density:F

    return p0
.end method

.method public getFontScale()F
    .locals 0

    .line 36
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->fontScale:F

    return p0
.end method

.method public getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;
    .locals 0

    .line 53
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->renderEffect:Landroidx/compose/ui/graphics/RenderEffect;

    return-object p0
.end method

.method public getRotationX()F
    .locals 0

    .line 46
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->rotationX:F

    return p0
.end method

.method public getRotationY()F
    .locals 0

    .line 47
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->rotationY:F

    return p0
.end method

.method public getRotationZ()F
    .locals 0

    .line 48
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->rotationZ:F

    return p0
.end method

.method public getScaleX()F
    .locals 0

    .line 38
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->scaleX:F

    return p0
.end method

.method public getScaleY()F
    .locals 0

    .line 39
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->scaleY:F

    return p0
.end method

.method public getShadowElevation()F
    .locals 0

    .line 43
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->shadowElevation:F

    return p0
.end method

.method public getShape()Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 51
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->shape:Landroidx/compose/ui/graphics/Shape;

    return-object p0
.end method

.method public getSize-NH-jbRc()J
    .locals 2

    .line 34
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->size:J

    return-wide v0
.end method

.method public getSpotShadowColor-0d7_KjU()J
    .locals 2

    .line 45
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->spotShadowColor:J

    return-wide v0
.end method

.method public getTransformOrigin-SzJe1aQ()J
    .locals 2

    .line 50
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->transformOrigin:J

    return-wide v0
.end method

.method public getTranslationX()F
    .locals 0

    .line 41
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->translationX:F

    return p0
.end method

.method public getTranslationY()F
    .locals 0

    .line 42
    iget p0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->translationY:F

    return p0
.end method

.method public final inverseTransform(Landroidx/compose/ui/graphics/drawscope/DrawTransform;Landroidx/compose/ui/unit/Density;Lam0/l;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawTransform;",
            "Landroidx/compose/ui/unit/Density;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "density"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "layerBlock"

    invoke-static {p3, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->getSize-NH-jbRc()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setSize-uvyYCjk(J)V

    .line 65
    invoke-interface {p2}, Landroidx/compose/ui/unit/Density;->getDensity()F

    move-result v0

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setDensity(F)V

    .line 66
    invoke-interface {p2}, Landroidx/compose/ui/unit/Density;->getFontScale()F

    move-result p2

    invoke-virtual {p0, p2}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setFontScale(F)V

    .line 68
    invoke-interface {p3, p0}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->getRotationZ()F

    move-result p2

    .line 72
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->getScaleX()F

    move-result p3

    .line 73
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->getScaleY()F

    move-result v0

    .line 70
    invoke-direct {p0, p1, p2, p3, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->inverseTransformAtTopLeft(Landroidx/compose/ui/graphics/drawscope/DrawTransform;FFF)V

    return-void
.end method

.method public final reset()V
    .locals 3

    .line 78
    sget-object v0, Landroidx/compose/ui/geometry/Size;->Companion:Landroidx/compose/ui/geometry/Size$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Size$Companion;->getUnspecified-NH-jbRc()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setSize-uvyYCjk(J)V

    const/high16 v0, 0x3f800000    # 1.0f

    .line 79
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setDensity(F)V

    .line 80
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setFontScale(F)V

    .line 82
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setScaleX(F)V

    .line 83
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setScaleY(F)V

    .line 84
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setAlpha(F)V

    const/4 v0, 0x0

    .line 85
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setTranslationX(F)V

    .line 86
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setTranslationY(F)V

    .line 87
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setShadowElevation(F)V

    .line 88
    invoke-static {}, Landroidx/compose/ui/graphics/GraphicsLayerScopeKt;->getDefaultShadowColor()J

    move-result-wide v1

    invoke-virtual {p0, v1, v2}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setAmbientShadowColor-8_81llA(J)V

    .line 89
    invoke-static {}, Landroidx/compose/ui/graphics/GraphicsLayerScopeKt;->getDefaultShadowColor()J

    move-result-wide v1

    invoke-virtual {p0, v1, v2}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setSpotShadowColor-8_81llA(J)V

    .line 90
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setRotationX(F)V

    .line 91
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setRotationY(F)V

    .line 92
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setRotationZ(F)V

    const/high16 v0, 0x41000000    # 8.0f

    .line 93
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setCameraDistance(F)V

    .line 94
    sget-object v0, Landroidx/compose/ui/graphics/TransformOrigin;->Companion:Landroidx/compose/ui/graphics/TransformOrigin$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/TransformOrigin$Companion;->getCenter-SzJe1aQ()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setTransformOrigin-__ExYCQ(J)V

    .line 95
    invoke-static {}, Landroidx/compose/ui/graphics/RectangleShapeKt;->getRectangleShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object v0

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setShape(Landroidx/compose/ui/graphics/Shape;)V

    const/4 v0, 0x0

    .line 96
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setClip(Z)V

    const/4 v0, 0x0

    .line 97
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    .line 98
    sget-object v1, Landroidx/compose/ui/graphics/BlendMode;->Companion:Landroidx/compose/ui/graphics/BlendMode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/BlendMode$Companion;->getSrcOver-0nO6VwU()I

    move-result v1

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setBlendMode-s9anfk8(I)V

    .line 99
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setColorFilter(Landroidx/compose/ui/graphics/ColorFilter;)V

    .line 100
    sget-object v1, Landroidx/compose/ui/graphics/CompositingStrategy;->Companion:Landroidx/compose/ui/graphics/CompositingStrategy$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/CompositingStrategy$Companion;->getAuto--NrFUSI()I

    move-result v1

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->setCompositingStrategy-aDBOjCE(I)V

    .line 102
    iput-object v0, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->matrix:[F

    return-void
.end method

.method public bridge roundToPx--R2X_6o(J)I
    .locals 0

    .line 32
    invoke-super {p0, p1, p2}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->roundToPx--R2X_6o(J)I

    move-result p0

    return p0
.end method

.method public bridge roundToPx-0680j_4(F)I
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->roundToPx-0680j_4(F)I

    move-result p0

    return p0
.end method

.method public setAlpha(F)V
    .locals 0

    .line 40
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->alpha:F

    return-void
.end method

.method public setAmbientShadowColor-8_81llA(J)V
    .locals 0

    .line 44
    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->ambientShadowColor:J

    return-void
.end method

.method public setBlendMode-s9anfk8(I)V
    .locals 0

    .line 54
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->blendMode:I

    return-void
.end method

.method public setCameraDistance(F)V
    .locals 0

    .line 49
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->cameraDistance:F

    return-void
.end method

.method public setClip(Z)V
    .locals 0

    .line 52
    iput-boolean p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->clip:Z

    return-void
.end method

.method public setColorFilter(Landroidx/compose/ui/graphics/ColorFilter;)V
    .locals 0

    .line 55
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->colorFilter:Landroidx/compose/ui/graphics/ColorFilter;

    return-void
.end method

.method public setCompositingStrategy-aDBOjCE(I)V
    .locals 0

    .line 56
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->compositingStrategy:I

    return-void
.end method

.method public setDensity(F)V
    .locals 0

    .line 35
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->density:F

    return-void
.end method

.method public setFontScale(F)V
    .locals 0

    .line 36
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->fontScale:F

    return-void
.end method

.method public setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V
    .locals 0

    .line 53
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->renderEffect:Landroidx/compose/ui/graphics/RenderEffect;

    return-void
.end method

.method public setRotationX(F)V
    .locals 0

    .line 46
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->rotationX:F

    return-void
.end method

.method public setRotationY(F)V
    .locals 0

    .line 47
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->rotationY:F

    return-void
.end method

.method public setRotationZ(F)V
    .locals 0

    .line 48
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->rotationZ:F

    return-void
.end method

.method public setScaleX(F)V
    .locals 0

    .line 38
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->scaleX:F

    return-void
.end method

.method public setScaleY(F)V
    .locals 0

    .line 39
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->scaleY:F

    return-void
.end method

.method public setShadowElevation(F)V
    .locals 0

    .line 43
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->shadowElevation:F

    return-void
.end method

.method public setShape(Landroidx/compose/ui/graphics/Shape;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->shape:Landroidx/compose/ui/graphics/Shape;

    return-void
.end method

.method public setSize-uvyYCjk(J)V
    .locals 0

    .line 34
    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->size:J

    return-void
.end method

.method public setSpotShadowColor-8_81llA(J)V
    .locals 0

    .line 45
    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->spotShadowColor:J

    return-void
.end method

.method public setTransformOrigin-__ExYCQ(J)V
    .locals 0

    .line 50
    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->transformOrigin:J

    return-void
.end method

.method public setTranslationX(F)V
    .locals 0

    .line 41
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->translationX:F

    return-void
.end method

.method public setTranslationY(F)V
    .locals 0

    .line 42
    iput p1, p0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->translationY:F

    return-void
.end method

.method public bridge toDp-GaN1DYA(J)F
    .locals 0

    .line 32
    invoke-super {p0, p1, p2}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toDp-GaN1DYA(J)F

    move-result p0

    return p0
.end method

.method public bridge toDp-u2uoSUM(F)F
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toDp-u2uoSUM(F)F

    move-result p0

    return p0
.end method

.method public bridge toDp-u2uoSUM(I)F
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toDp-u2uoSUM(I)F

    move-result p0

    return p0
.end method

.method public bridge toDpSize-k-rfVVM(J)J
    .locals 0

    .line 32
    invoke-super {p0, p1, p2}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toDpSize-k-rfVVM(J)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge toPx--R2X_6o(J)F
    .locals 0

    .line 32
    invoke-super {p0, p1, p2}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toPx--R2X_6o(J)F

    move-result p0

    return p0
.end method

.method public bridge toPx-0680j_4(F)F
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toPx-0680j_4(F)F

    move-result p0

    return p0
.end method

.method public bridge toRect(Landroidx/compose/ui/unit/DpRect;)Landroidx/compose/ui/geometry/Rect;
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toRect(Landroidx/compose/ui/unit/DpRect;)Landroidx/compose/ui/geometry/Rect;

    move-result-object p0

    return-object p0
.end method

.method public bridge toSize-XkaWNTQ(J)J
    .locals 0

    .line 32
    invoke-super {p0, p1, p2}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toSize-XkaWNTQ(J)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge toSp-0xMU5do(F)J
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toSp-0xMU5do(F)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge toSp-kPz2Gy4(F)J
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toSp-kPz2Gy4(F)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge toSp-kPz2Gy4(I)J
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->toSp-kPz2Gy4(I)J

    move-result-wide p0

    return-wide p0
.end method
