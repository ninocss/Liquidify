.class public final Ldev/nino/squareglass/backdrop/internal/RenderEffectKt;
.super Ljava/lang/Object;
.source "RenderEffect.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\u001a\u0016\u0010\u0000\u001a\u00020\u0001*\u0004\u0018\u00010\u00012\u0006\u0010\u0002\u001a\u00020\u0001H\u0001\u001a\u0018\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0001\u001a\u001a\u0010\u0008\u001a\u00020\u00012\u0008\u0010\t\u001a\u0004\u0018\u00010\u00012\u0006\u0010\n\u001a\u00020\u000bH\u0001\u00a8\u0006\u000c"
    }
    d2 = {
        "chain",
        "Landroidx/compose/ui/graphics/RenderEffect;",
        "other",
        "RuntimeShaderEffect",
        "runtimeShader",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "uniformShaderName",
        "",
        "ColorFilterEffect",
        "renderEffect",
        "colorFilter",
        "Landroidx/compose/ui/graphics/ColorFilter;",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final ColorFilterEffect(Landroidx/compose/ui/graphics/RenderEffect;Landroidx/compose/ui/graphics/ColorFilter;)Landroidx/compose/ui/graphics/RenderEffect;
    .locals 1

    const-string v0, "colorFilter"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    const-string v0, "createColorFilterEffect(...)"

    if-eqz p0, :cond_0

    .line 51
    invoke-static {p1}, Landroidx/compose/ui/graphics/AndroidColorFilter_androidKt;->asAndroidColorFilter(Landroidx/compose/ui/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    move-result-object p1

    .line 52
    invoke-virtual {p0}, Landroidx/compose/ui/graphics/RenderEffect;->asAndroidRenderEffect()Landroid/graphics/RenderEffect;

    move-result-object p0

    .line 50
    invoke-static {p1, p0}, Landroid/graphics/RenderEffect;->createColorFilterEffect(Landroid/graphics/ColorFilter;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    move-result-object p0

    .line 52
    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    invoke-static {p0}, Landroidx/compose/ui/graphics/AndroidRenderEffect_androidKt;->asComposeRenderEffect(Landroid/graphics/RenderEffect;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p0

    return-object p0

    .line 56
    :cond_0
    invoke-static {p1}, Landroidx/compose/ui/graphics/AndroidColorFilter_androidKt;->asAndroidColorFilter(Landroidx/compose/ui/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    move-result-object p0

    .line 55
    invoke-static {p0}, Landroid/graphics/RenderEffect;->createColorFilterEffect(Landroid/graphics/ColorFilter;)Landroid/graphics/RenderEffect;

    move-result-object p0

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    invoke-static {p0}, Landroidx/compose/ui/graphics/AndroidRenderEffect_androidKt;->asComposeRenderEffect(Landroid/graphics/RenderEffect;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p0

    return-object p0
.end method

.method public static final RuntimeShaderEffect(Ldev/nino/squareglass/backdrop/RuntimeShader;Ljava/lang/String;)Landroidx/compose/ui/graphics/RenderEffect;
    .locals 1

    const-string v0, "runtimeShader"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "uniformShaderName"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    invoke-static {p0}, Ldev/nino/squareglass/backdrop/RuntimeShaderKt;->asAndroidRuntimeShader(Ldev/nino/squareglass/backdrop/RuntimeShader;)Landroid/graphics/RuntimeShader;

    move-result-object p0

    .line 38
    invoke-static {p0, p1}, Landroid/graphics/RenderEffect;->createRuntimeShaderEffect(Landroid/graphics/RuntimeShader;Ljava/lang/String;)Landroid/graphics/RenderEffect;

    move-result-object p0

    const-string p1, "createRuntimeShaderEffect(...)"

    invoke-static {p0, p1}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    invoke-static {p0}, Landroidx/compose/ui/graphics/AndroidRenderEffect_androidKt;->asComposeRenderEffect(Landroid/graphics/RenderEffect;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p0

    return-object p0
.end method

.method public static final chain(Landroidx/compose/ui/graphics/RenderEffect;Landroidx/compose/ui/graphics/RenderEffect;)Landroidx/compose/ui/graphics/RenderEffect;
    .locals 1

    const-string v0, "other"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p0, :cond_0

    .line 25
    invoke-virtual {p1}, Landroidx/compose/ui/graphics/RenderEffect;->asAndroidRenderEffect()Landroid/graphics/RenderEffect;

    move-result-object p1

    .line 26
    invoke-virtual {p0}, Landroidx/compose/ui/graphics/RenderEffect;->asAndroidRenderEffect()Landroid/graphics/RenderEffect;

    move-result-object p0

    .line 24
    invoke-static {p1, p0}, Landroid/graphics/RenderEffect;->createChainEffect(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    move-result-object p0

    .line 26
    const-string p1, "createChainEffect(...)"

    invoke-static {p0, p1}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    invoke-static {p0}, Landroidx/compose/ui/graphics/AndroidRenderEffect_androidKt;->asComposeRenderEffect(Landroid/graphics/RenderEffect;)Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object p0

    return-object p0

    :cond_0
    return-object p1
.end method
