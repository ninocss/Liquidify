.class public final Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;
.super Ljava/lang/Object;
.source "HighlightStyle.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Ambient"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHighlightStyle.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HighlightStyle.kt\ndev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient\n+ 2 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 3 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 4 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,148:1\n57#2:149\n61#2:152\n60#3:150\n70#3:153\n22#4:151\n*S KotlinDebug\n*F\n+ 1 HighlightStyle.kt\ndev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient\n*L\n100#1:149\n100#1:152\n100#1:150\n100#1:153\n100#1:151\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0000\u0008\u0087\u0008\u0018\u00002\u00020\u0001B\u0011\u0012\u0008\u0008\u0003\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u001e\u0010\u0012\u001a\u0004\u0018\u00010\u0013*\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0018H\u0016J\t\u0010\u0019\u001a\u00020\u0003H\u00c6\u0003J\u0013\u0010\u001a\u001a\u00020\u00002\u0008\u0008\u0003\u0010\u0002\u001a\u00020\u0003H\u00c6\u0001J\u0014\u0010\u001b\u001a\u00020\u001c2\u0008\u0010\u001d\u001a\u0004\u0018\u00010\u001eH\u00d6\u0083\u0004J\n\u0010\u001f\u001a\u00020 H\u00d6\u0081\u0004J\n\u0010!\u001a\u00020\"H\u00d6\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007R\u0016\u0010\u0008\u001a\u00020\tX\u0096\u0004\u00a2\u0006\n\n\u0002\u0010\u000c\u001a\u0004\u0008\n\u0010\u000bR\u0016\u0010\r\u001a\u00020\u000eX\u0096\u0004\u00a2\u0006\n\n\u0002\u0010\u0011\u001a\u0004\u0008\u000f\u0010\u0010\u00a8\u0006#"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;",
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;",
        "intensity",
        "",
        "<init>",
        "(F)V",
        "getIntensity",
        "()F",
        "color",
        "Landroidx/compose/ui/graphics/Color;",
        "getColor-0d7_KjU",
        "()J",
        "J",
        "blendMode",
        "Landroidx/compose/ui/graphics/BlendMode;",
        "getBlendMode-0nO6VwU",
        "()I",
        "I",
        "createShader",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "runtimeShaderCache",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCache;",
        "component1",
        "copy",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final blendMode:I

.field private final color:J

.field private final intensity:F


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v2, v0, v1}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;-><init>(FILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(F)V
    .locals 9

    .line 82
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 84
    iput p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->intensity:F

    .line 87
    sget-object v0, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v1

    const/16 v7, 0xe

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move v3, p1

    invoke-static/range {v1 .. v8}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->color:J

    .line 89
    sget-object p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;->Companion:Landroidx/compose/ui/graphics/drawscope/DrawScope$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope$Companion;->getDefaultBlendMode-0nO6VwU()I

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->blendMode:I

    return-void
.end method

.method public synthetic constructor <init>(FILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    const p1, 0x3ec28f5c    # 0.38f

    .line 83
    :cond_0
    invoke-direct {p0, p1}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;-><init>(F)V

    return-void
.end method

.method public static synthetic copy$default(Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;FILjava/lang/Object;)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;
    .locals 0

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    iget p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->intensity:F

    :cond_0
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->copy(F)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()F
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->intensity:F

    return p0
.end method

.method public final copy(F)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;
    .locals 0

    new-instance p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;

    invoke-direct {p0, p1}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;-><init>(F)V

    return-object p0
.end method

.method public createShader(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;Ldev/nino/squareglass/backdrop/RuntimeShaderCache;)Ldev/nino/squareglass/backdrop/RuntimeShader;
    .locals 4

    const-string p0, "<this>"

    invoke-static {p1, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "shape"

    invoke-static {p2, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "runtimeShaderCache"

    invoke-static {p3, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 95
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRuntimeShaderSupported()Z

    move-result p0

    if-eqz p0, :cond_0

    .line 97
    const-string p0, "Ambient"

    .line 98
    const-string v0, "\nuniform float2 size;\nuniform float4 cornerRadii;\nuniform float angle;\nuniform float falloff;\n\n\nfloat radiusAt(float2 coord, float4 radii) {\n    if (coord.x >= 0.0) {\n        if (coord.y <= 0.0) return radii.y;\n        else return radii.z;\n    } else {\n        if (coord.y <= 0.0) return radii.x;\n        else return radii.w;\n    }\n}\n\nfloat sdRoundedRect(float2 coord, float2 halfSize, float radius) {\n    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n    float outside = length(max(cornerCoord, 0.0)) - radius;\n    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);\n    return outside + inside;\n}\n\nfloat2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {\n    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {\n        return sign(coord) * normalize(max(cornerCoord, 0.0));\n    } else {\n        float gradX = step(cornerCoord.y, cornerCoord.x);\n        return sign(coord) * float2(gradX, 1.0 - gradX);\n    }\n}\n\nhalf4 main(float2 coord) {\n    float2 halfSize = size * 0.5;\n    float2 centeredCoord = coord - halfSize;\n    float radius = radiusAt(coord, cornerRadii);\n    \n    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n    float2 grad = gradSdRoundedRect(centeredCoord, halfSize, gradRadius);\n    float2 normal = float2(cos(angle), sin(angle));\n    float d = dot(grad, normal);\n    float intensity = pow(abs(d), falloff);\n    float t = step(0.0, d);\n    return half4(t, t, t, 1.0) * intensity;\n}"

    .line 96
    invoke-interface {p3, p0, v0}, Ldev/nino/squareglass/backdrop/RuntimeShaderCache;->obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;

    move-result-object p0

    .line 100
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    const/16 p3, 0x20

    shr-long/2addr v0, p3

    long-to-int p3, v0

    .line 151
    invoke-static {p3}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p3

    .line 100
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    long-to-int v0, v0

    .line 151
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    .line 100
    const-string v1, "size"

    invoke-interface {p0, v1, p3, v0}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;FF)V

    .line 101
    const-string p3, "cornerRadii"

    invoke-static {p1, p2}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyleKt;->access$getCornerRadii(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;)[F

    move-result-object p1

    invoke-interface {p0, p3, p1}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;[F)V

    .line 102
    const-string p1, "angle"

    const p2, 0x3f490fdb

    invoke-interface {p0, p1, p2}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    .line 103
    const-string p1, "falloff"

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-interface {p0, p1, p2}, Ldev/nino/squareglass/backdrop/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->intensity:F

    iget p1, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->intensity:F

    invoke-static {p0, p1}, Ljava/lang/Float;->compare(FF)I

    move-result p0

    if-eqz p0, :cond_2

    return v2

    :cond_2
    return v0
.end method

.method public getBlendMode-0nO6VwU()I
    .locals 0

    .line 89
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->blendMode:I

    return p0
.end method

.method public getColor-0d7_KjU()J
    .locals 2

    .line 87
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->color:J

    return-wide v0
.end method

.method public final getIntensity()F
    .locals 0

    .line 84
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->intensity:F

    return p0
.end method

.method public hashCode()I
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->intensity:F

    invoke-static {p0}, Ljava/lang/Float;->hashCode(F)I

    move-result p0

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;->intensity:F

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Ambient(intensity="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
