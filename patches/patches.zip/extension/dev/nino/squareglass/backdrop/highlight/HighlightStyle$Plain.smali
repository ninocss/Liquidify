.class public final Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;
.super Ljava/lang/Object;
.source "HighlightStyle.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Plain"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0000\u0008\u0087\u0008\u0018\u00002\u00020\u0001B\u001b\u0012\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u001e\u0010\u000e\u001a\u0004\u0018\u00010\u000f*\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\u0010\u0010\u0015\u001a\u00020\u0003H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0016\u0010\tJ\u0010\u0010\u0017\u001a\u00020\u0005H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0018\u0010\u000cJ$\u0010\u0019\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005H\u00c6\u0001\u00a2\u0006\u0004\u0008\u001a\u0010\u001bJ\u0014\u0010\u001c\u001a\u00020\u001d2\u0008\u0010\u001e\u001a\u0004\u0018\u00010\u001fH\u00d6\u0083\u0004J\n\u0010 \u001a\u00020!H\u00d6\u0081\u0004J\n\u0010\"\u001a\u00020#H\u00d6\u0081\u0004R\u0016\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\n\n\u0002\u0010\n\u001a\u0004\u0008\u0008\u0010\tR\u0016\u0010\u0004\u001a\u00020\u0005X\u0096\u0004\u00a2\u0006\n\n\u0002\u0010\r\u001a\u0004\u0008\u000b\u0010\u000c\u00a8\u0006$"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;",
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;",
        "color",
        "Landroidx/compose/ui/graphics/Color;",
        "blendMode",
        "Landroidx/compose/ui/graphics/BlendMode;",
        "<init>",
        "(JILkotlin/jvm/internal/DefaultConstructorMarker;)V",
        "getColor-0d7_KjU",
        "()J",
        "J",
        "getBlendMode-0nO6VwU",
        "()I",
        "I",
        "createShader",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "runtimeShaderCache",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCache;",
        "component1",
        "component1-0d7_KjU",
        "component2",
        "component2-0nO6VwU",
        "copy",
        "copy-xETnrds",
        "(JI)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final blendMode:I

.field private final color:J


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method private constructor <init>(JI)V
    .locals 0

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->color:J

    .line 44
    iput p3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->blendMode:I

    return-void
.end method

.method public synthetic constructor <init>(JIILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 8

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_0

    .line 43
    sget-object p1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v0

    const/16 v6, 0xe

    const/4 v7, 0x0

    const v2, 0x3ec28f5c    # 0.38f

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide p1

    :cond_0
    and-int/lit8 p4, p4, 0x2

    if-eqz p4, :cond_1

    .line 44
    sget-object p3, Landroidx/compose/ui/graphics/BlendMode;->Companion:Landroidx/compose/ui/graphics/BlendMode$Companion;

    invoke-virtual {p3}, Landroidx/compose/ui/graphics/BlendMode$Companion;->getPlus-0nO6VwU()I

    move-result p3

    :cond_1
    const/4 p4, 0x0

    .line 42
    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;-><init>(JILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public synthetic constructor <init>(JILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;-><init>(JI)V

    return-void
.end method

.method public static synthetic copy-xETnrds$default(Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;JIILjava/lang/Object;)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;
    .locals 0

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_0

    iget-wide p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->color:J

    :cond_0
    and-int/lit8 p4, p4, 0x2

    if-eqz p4, :cond_1

    iget p3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->blendMode:I

    :cond_1
    invoke-virtual {p0, p1, p2, p3}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->copy-xETnrds(JI)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1-0d7_KjU()J
    .locals 2

    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->color:J

    return-wide v0
.end method

.method public final component2-0nO6VwU()I
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->blendMode:I

    return p0
.end method

.method public final copy-xETnrds(JI)Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;
    .locals 1

    new-instance p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;

    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, p3, v0}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;-><init>(JILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object p0
.end method

.method public createShader(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;Ldev/nino/squareglass/backdrop/RuntimeShaderCache;)Ldev/nino/squareglass/backdrop/RuntimeShader;
    .locals 0

    const-string p0, "<this>"

    invoke-static {p1, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "shape"

    invoke-static {p2, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "runtimeShaderCache"

    invoke-static {p3, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;

    iget-wide v3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->color:J

    iget-wide v5, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->color:J

    invoke-static {v3, v4, v5, v6}, Landroidx/compose/ui/graphics/Color;->equals-impl0(JJ)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->blendMode:I

    iget p1, p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->blendMode:I

    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/BlendMode;->equals-impl0(II)Z

    move-result p0

    if-nez p0, :cond_3

    return v2

    :cond_3
    return v0
.end method

.method public getBlendMode-0nO6VwU()I
    .locals 0

    .line 44
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->blendMode:I

    return p0
.end method

.method public getColor-0d7_KjU()J
    .locals 2

    .line 43
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->color:J

    return-wide v0
.end method

.method public hashCode()I
    .locals 2

    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->color:J

    invoke-static {v0, v1}, Landroidx/compose/ui/graphics/Color;->hashCode-impl(J)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->blendMode:I

    invoke-static {p0}, Landroidx/compose/ui/graphics/BlendMode;->hashCode-impl(I)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->color:J

    invoke-static {v0, v1}, Landroidx/compose/ui/graphics/Color;->toString-impl(J)Ljava/lang/String;

    move-result-object v0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;->blendMode:I

    invoke-static {p0}, Landroidx/compose/ui/graphics/BlendMode;->toString-impl(I)Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Plain(color="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", blendMode="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
