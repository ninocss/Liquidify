.class public final synthetic Ldev/nino/squareglass/backdrop/highlight/HighlightNode$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/graphics/Outline;

.field public final synthetic f$1:Landroidx/compose/ui/graphics/Path;

.field public final synthetic f$2:Ldev/nino/squareglass/backdrop/highlight/HighlightNode;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/highlight/HighlightNode;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode$$ExternalSyntheticLambda0;->f$0:Landroidx/compose/ui/graphics/Outline;

    iput-object p2, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode$$ExternalSyntheticLambda0;->f$1:Landroidx/compose/ui/graphics/Path;

    iput-object p3, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode$$ExternalSyntheticLambda0;->f$2:Ldev/nino/squareglass/backdrop/highlight/HighlightNode;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode$$ExternalSyntheticLambda0;->f$0:Landroidx/compose/ui/graphics/Outline;

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode$$ExternalSyntheticLambda0;->f$1:Landroidx/compose/ui/graphics/Path;

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/HighlightNode$$ExternalSyntheticLambda0;->f$2:Ldev/nino/squareglass/backdrop/highlight/HighlightNode;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static {v0, v1, p0, p1}, Ldev/nino/squareglass/backdrop/highlight/HighlightNode;->$r8$lambda$ogFYlbp980MSiZCM629gH3MX1Ug(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/highlight/HighlightNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
