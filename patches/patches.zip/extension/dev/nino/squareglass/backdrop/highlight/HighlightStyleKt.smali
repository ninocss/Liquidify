.class public final Ldev/nino/squareglass/backdrop/highlight/HighlightStyleKt;
.super Ljava/lang/Object;
.source "HighlightStyle.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHighlightStyle.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HighlightStyle.kt\ndev/nino/squareglass/backdrop/highlight/HighlightStyleKt\n+ 2 MathHelpers.kt\nandroidx/compose/ui/util/MathHelpersKt\n*L\n1#1,148:1\n74#2:149\n74#2:150\n74#2:151\n74#2:152\n*S KotlinDebug\n*F\n+ 1 HighlightStyle.kt\ndev/nino/squareglass/backdrop/highlight/HighlightStyleKt\n*L\n142#1:149\n143#1:150\n144#1:151\n145#1:152\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0000\n\u0002\u0010\u0014\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004H\u0002\u00a8\u0006\u0005"
    }
    d2 = {
        "getCornerRadii",
        "",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final synthetic access$getCornerRadii(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;)[F
    .locals 0

    .line 1
    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyleKt;->getCornerRadii(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;)[F

    move-result-object p0

    return-object p0
.end method

.method private static final getCornerRadii(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Shape;)[F
    .locals 11

    .line 125
    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    .line 126
    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Size;->getMinDimension-impl(J)F

    move-result v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    .line 127
    instance-of v3, p1, Landroidx/compose/foundation/shape/CornerBasedShape;

    if-eqz v3, :cond_0

    check-cast p1, Landroidx/compose/foundation/shape/CornerBasedShape;

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez p1, :cond_2

    new-array p0, v3, [F

    :goto_1
    if-ge v4, v3, :cond_1

    aput v2, p0, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    return-object p0

    .line 128
    :cond_2
    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    move-result-object v5

    sget-object v6, Landroidx/compose/ui/unit/LayoutDirection;->Ltr:Landroidx/compose/ui/unit/LayoutDirection;

    const/4 v7, 0x1

    if-ne v5, v6, :cond_3

    move v5, v7

    goto :goto_2

    :cond_3
    move v5, v4

    :goto_2
    if-eqz v5, :cond_4

    .line 130
    invoke-virtual {p1}, Landroidx/compose/foundation/shape/CornerBasedShape;->getTopStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v6

    move-object v8, p0

    check-cast v8, Landroidx/compose/ui/unit/Density;

    invoke-interface {v6, v0, v1, v8}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v6

    goto :goto_3

    .line 131
    :cond_4
    invoke-virtual {p1}, Landroidx/compose/foundation/shape/CornerBasedShape;->getTopEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v6

    move-object v8, p0

    check-cast v8, Landroidx/compose/ui/unit/Density;

    invoke-interface {v6, v0, v1, v8}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v6

    :goto_3
    if-eqz v5, :cond_5

    .line 133
    invoke-virtual {p1}, Landroidx/compose/foundation/shape/CornerBasedShape;->getTopEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v8

    move-object v9, p0

    check-cast v9, Landroidx/compose/ui/unit/Density;

    invoke-interface {v8, v0, v1, v9}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v8

    goto :goto_4

    .line 134
    :cond_5
    invoke-virtual {p1}, Landroidx/compose/foundation/shape/CornerBasedShape;->getTopStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v8

    move-object v9, p0

    check-cast v9, Landroidx/compose/ui/unit/Density;

    invoke-interface {v8, v0, v1, v9}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v8

    :goto_4
    if-eqz v5, :cond_6

    .line 136
    invoke-virtual {p1}, Landroidx/compose/foundation/shape/CornerBasedShape;->getBottomEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v9

    move-object v10, p0

    check-cast v10, Landroidx/compose/ui/unit/Density;

    invoke-interface {v9, v0, v1, v10}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v9

    goto :goto_5

    .line 137
    :cond_6
    invoke-virtual {p1}, Landroidx/compose/foundation/shape/CornerBasedShape;->getBottomStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object v9

    move-object v10, p0

    check-cast v10, Landroidx/compose/ui/unit/Density;

    invoke-interface {v9, v0, v1, v10}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result v9

    :goto_5
    if-eqz v5, :cond_7

    .line 139
    invoke-virtual {p1}, Landroidx/compose/foundation/shape/CornerBasedShape;->getBottomStart()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object p1

    check-cast p0, Landroidx/compose/ui/unit/Density;

    invoke-interface {p1, v0, v1, p0}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result p0

    goto :goto_6

    .line 140
    :cond_7
    invoke-virtual {p1}, Landroidx/compose/foundation/shape/CornerBasedShape;->getBottomEnd()Landroidx/compose/foundation/shape/CornerSize;

    move-result-object p1

    check-cast p0, Landroidx/compose/ui/unit/Density;

    invoke-interface {p1, v0, v1, p0}, Landroidx/compose/foundation/shape/CornerSize;->toPx-TmRCtEA(JLandroidx/compose/ui/unit/Density;)F

    move-result p0

    :goto_6
    cmpl-float p1, v6, v2

    if-lez p1, :cond_8

    move v6, v2

    :cond_8
    cmpl-float p1, v8, v2

    if-lez p1, :cond_9

    move v8, v2

    :cond_9
    cmpl-float p1, v9, v2

    if-lez p1, :cond_a

    move v9, v2

    :cond_a
    cmpl-float p1, p0, v2

    if-lez p1, :cond_b

    goto :goto_7

    :cond_b
    move v2, p0

    .line 152
    :goto_7
    new-array p0, v3, [F

    aput v6, p0, v4

    aput v8, p0, v7

    const/4 p1, 0x2

    aput v9, p0, p1

    const/4 p1, 0x3

    aput v2, p0, p1

    return-object p0
.end method
