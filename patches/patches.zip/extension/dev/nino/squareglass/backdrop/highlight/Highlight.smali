.class public final Ldev/nino/squareglass/backdrop/highlight/Highlight;
.super Ljava/lang/Object;
.source "Highlight.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHighlight.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Highlight.kt\ndev/nino/squareglass/backdrop/highlight/Highlight\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/Dp\n*L\n1#1,38:1\n123#2:39\n58#3:40\n*S KotlinDebug\n*F\n+ 1 Highlight.kt\ndev/nino/squareglass/backdrop/highlight/Highlight\n*L\n20#1:39\n21#1:40\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0013\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\u0008\u0087\u0008\u0018\u0000 \"2\u00020\u0001:\u0001\"B/\u0012\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0003\u0012\u0008\u0008\u0003\u0010\u0005\u001a\u00020\u0006\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0004\u0008\t\u0010\nJ\u0010\u0010\u0012\u001a\u00020\u0003H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0013\u0010\u000cJ\u0010\u0010\u0014\u001a\u00020\u0003H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0015\u0010\u000cJ\t\u0010\u0016\u001a\u00020\u0006H\u00c6\u0003J\t\u0010\u0017\u001a\u00020\u0008H\u00c6\u0003J8\u0010\u0018\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00032\u0008\u0008\u0003\u0010\u0005\u001a\u00020\u00062\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0008H\u00c6\u0001\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0014\u0010\u001b\u001a\u00020\u001c2\u0008\u0010\u001d\u001a\u0004\u0018\u00010\u0001H\u00d6\u0083\u0004J\n\u0010\u001e\u001a\u00020\u001fH\u00d6\u0081\u0004J\n\u0010 \u001a\u00020!H\u00d6\u0081\u0004R\u0013\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\n\n\u0002\u0010\r\u001a\u0004\u0008\u000b\u0010\u000cR\u0013\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\n\n\u0002\u0010\r\u001a\u0004\u0008\u000e\u0010\u000cR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u000cR\u0011\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011\u00a8\u0006#"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
        "",
        "width",
        "Landroidx/compose/ui/unit/Dp;",
        "blurRadius",
        "alpha",
        "",
        "style",
        "Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;",
        "<init>",
        "(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;Lkotlin/jvm/internal/DefaultConstructorMarker;)V",
        "getWidth-D9Ej5fM",
        "()F",
        "F",
        "getBlurRadius-D9Ej5fM",
        "getAlpha",
        "getStyle",
        "()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;",
        "component1",
        "component1-D9Ej5fM",
        "component2",
        "component2-D9Ej5fM",
        "component3",
        "component4",
        "copy",
        "copy-i1RSzL4",
        "(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;)Ldev/nino/squareglass/backdrop/highlight/Highlight;",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "",
        "Companion",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field private static final Ambient:Ldev/nino/squareglass/backdrop/highlight/Highlight;

.field public static final Companion:Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;

.field private static final Default:Ldev/nino/squareglass/backdrop/highlight/Highlight;

.field private static final Plain:Ldev/nino/squareglass/backdrop/highlight/Highlight;


# instance fields
.field private final alpha:F

.field private final blurRadius:F

.field private final style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

.field private final width:F


# direct methods
.method static constructor <clinit>()V
    .locals 11

    new-instance v0, Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Companion:Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;

    .line 29
    new-instance v2, Ldev/nino/squareglass/backdrop/highlight/Highlight;

    const/16 v7, 0xf

    const/4 v8, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/backdrop/highlight/Highlight;-><init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v2, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Default:Ldev/nino/squareglass/backdrop/highlight/Highlight;

    .line 32
    new-instance v3, Ldev/nino/squareglass/backdrop/highlight/Highlight;

    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;->Companion:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;->getAmbient()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Ambient;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v6, 0x0

    invoke-direct/range {v3 .. v9}, Ldev/nino/squareglass/backdrop/highlight/Highlight;-><init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v3, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Ambient:Ldev/nino/squareglass/backdrop/highlight/Highlight;

    .line 35
    new-instance v4, Ldev/nino/squareglass/backdrop/highlight/Highlight;

    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;->Companion:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;->getPlain()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Plain;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v4 .. v10}, Ldev/nino/squareglass/backdrop/highlight/Highlight;-><init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v4, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Plain:Ldev/nino/squareglass/backdrop/highlight/Highlight;

    return-void
.end method

.method private constructor <init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;)V
    .locals 1

    const-string v0, "style"

    invoke-static {p4, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    iput p1, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->width:F

    .line 21
    iput p2, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->blurRadius:F

    .line 22
    iput p3, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->alpha:F

    .line 23
    iput-object p4, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    return-void
.end method

.method public synthetic constructor <init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 6

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_0

    const/high16 p1, 0x3f000000    # 0.5f

    .line 39
    invoke-static {p1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result p1

    :cond_0
    move v1, p1

    and-int/lit8 p1, p5, 0x2

    if-eqz p1, :cond_1

    const/high16 p1, 0x40000000    # 2.0f

    div-float p1, v1, p1

    .line 40
    invoke-static {p1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result p2

    :cond_1
    move v2, p2

    and-int/lit8 p1, p5, 0x4

    if-eqz p1, :cond_2

    const/high16 p3, 0x3f800000    # 1.0f

    :cond_2
    move v3, p3

    and-int/lit8 p1, p5, 0x8

    if-eqz p1, :cond_3

    .line 23
    sget-object p1, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;->Companion:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;

    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Companion;->getDefault()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle$Default;

    move-result-object p1

    move-object p4, p1

    check-cast p4, Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    :cond_3
    move-object v4, p4

    const/4 v5, 0x0

    move-object v0, p0

    .line 19
    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/backdrop/highlight/Highlight;-><init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public synthetic constructor <init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/backdrop/highlight/Highlight;-><init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;)V

    return-void
.end method

.method public static final synthetic access$getAmbient$cp()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    .line 18
    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Ambient:Ldev/nino/squareglass/backdrop/highlight/Highlight;

    return-object v0
.end method

.method public static final synthetic access$getDefault$cp()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    .line 18
    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Default:Ldev/nino/squareglass/backdrop/highlight/Highlight;

    return-object v0
.end method

.method public static final synthetic access$getPlain$cp()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    .line 18
    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Plain:Ldev/nino/squareglass/backdrop/highlight/Highlight;

    return-object v0
.end method

.method public static synthetic copy-i1RSzL4$default(Ldev/nino/squareglass/backdrop/highlight/Highlight;FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;ILjava/lang/Object;)Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 0

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_0

    iget p1, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->width:F

    :cond_0
    and-int/lit8 p6, p5, 0x2

    if-eqz p6, :cond_1

    iget p2, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->blurRadius:F

    :cond_1
    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_2

    iget p3, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->alpha:F

    :cond_2
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_3

    iget-object p4, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    :cond_3
    invoke-virtual {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->copy-i1RSzL4(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;)Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1-D9Ej5fM()F
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->width:F

    return p0
.end method

.method public final component2-D9Ej5fM()F
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->blurRadius:F

    return p0
.end method

.method public final component3()F
    .locals 0

    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->alpha:F

    return p0
.end method

.method public final component4()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;
    .locals 0

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    return-object p0
.end method

.method public final copy-i1RSzL4(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;)Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 6

    const-string p0, "style"

    invoke-static {p4, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;

    const/4 v5, 0x0

    move v1, p1

    move v2, p2

    move v3, p3

    move-object v4, p4

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/backdrop/highlight/Highlight;-><init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Ldev/nino/squareglass/backdrop/highlight/Highlight;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Ldev/nino/squareglass/backdrop/highlight/Highlight;

    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->width:F

    iget v3, p1, Ldev/nino/squareglass/backdrop/highlight/Highlight;->width:F

    invoke-static {v1, v3}, Landroidx/compose/ui/unit/Dp;->equals-impl0(FF)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->blurRadius:F

    iget v3, p1, Ldev/nino/squareglass/backdrop/highlight/Highlight;->blurRadius:F

    invoke-static {v1, v3}, Landroidx/compose/ui/unit/Dp;->equals-impl0(FF)Z

    move-result v1

    if-nez v1, :cond_3

    return v2

    :cond_3
    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->alpha:F

    iget v3, p1, Ldev/nino/squareglass/backdrop/highlight/Highlight;->alpha:F

    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_4

    return v2

    :cond_4
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    iget-object p1, p1, Ldev/nino/squareglass/backdrop/highlight/Highlight;->style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    invoke-static {p0, p1}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_5

    return v2

    :cond_5
    return v0
.end method

.method public final getAlpha()F
    .locals 0

    .line 22
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->alpha:F

    return p0
.end method

.method public final getBlurRadius-D9Ej5fM()F
    .locals 0

    .line 21
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->blurRadius:F

    return p0
.end method

.method public final getStyle()Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;
    .locals 0

    .line 23
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    return-object p0
.end method

.method public final getWidth-D9Ej5fM()F
    .locals 0

    .line 20
    iget p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->width:F

    return p0
.end method

.method public hashCode()I
    .locals 2

    iget v0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->width:F

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->hashCode-impl(F)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->blurRadius:F

    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->hashCode-impl(F)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->alpha:F

    invoke-static {v1}, Ljava/lang/Float;->hashCode(F)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    iget v0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->width:F

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->toString-impl(F)Ljava/lang/String;

    move-result-object v0

    iget v1, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->blurRadius:F

    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->toString-impl(F)Ljava/lang/String;

    move-result-object v1

    iget v2, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->alpha:F

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->style:Ldev/nino/squareglass/backdrop/highlight/HighlightStyle;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Highlight(width="

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", blurRadius="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", alpha="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v0, ", style="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
