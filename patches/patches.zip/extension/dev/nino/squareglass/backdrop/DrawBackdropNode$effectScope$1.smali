.class public final Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;
.super Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;
.source "DrawBackdropModifier.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/backdrop/DrawBackdropNode;-><init>(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001R\u0014\u0010\u0002\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0004\u0010\u0005\u00a8\u0006\u0006"
    }
    d2 = {
        "dev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "getShape",
        "()Landroidx/compose/ui/graphics/Shape;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V
    .locals 0

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;->this$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    .line 381
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;-><init>()V

    return-void
.end method


# virtual methods
.method public getShape()Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 383
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;->this$0:Ldev/nino/squareglass/backdrop/DrawBackdropNode;

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getShapeProvider()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    move-result-object p0

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->getInnerShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    return-object p0
.end method
