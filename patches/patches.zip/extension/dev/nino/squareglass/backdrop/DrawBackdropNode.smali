.class final Ldev/nino/squareglass/backdrop/DrawBackdropNode;
.super Landroidx/compose/ui/Modifier$Node;
.source "DrawBackdropModifier.kt"

# interfaces
.implements Landroidx/compose/ui/node/LayoutModifierNode;
.implements Landroidx/compose/ui/node/DrawModifierNode;
.implements Landroidx/compose/ui/node/GlobalPositionAwareModifierNode;
.implements Landroidx/compose/ui/node/ObserverModifierNode;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDrawBackdropModifier.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DrawBackdropModifier.kt\ndev/nino/squareglass/backdrop/DrawBackdropNode\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 4 SnapshotFloatState.kt\nandroidx/compose/runtime/PrimitiveSnapshotStateKt__SnapshotFloatStateKt\n+ 5 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 6 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 7 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n+ 8 IntSize.kt\nandroidx/compose/ui/unit/IntSizeKt\n+ 9 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 10 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 11 IntOffset.kt\nandroidx/compose/ui/unit/IntOffsetKt\n+ 12 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n+ 13 MathHelpers.kt\nandroidx/compose/ui/util/MathHelpersKt\n*L\n1#1,797:1\n1915#2,2:798\n231#2,2:822\n85#3:800\n117#3,2:801\n80#4:803\n113#4,2:804\n57#5:806\n61#5:809\n57#5:856\n61#5:859\n60#6:807\n70#6:810\n80#6:813\n80#6:825\n60#6:857\n70#6:860\n80#6:863\n80#6:865\n22#7:808\n22#7:811\n22#7:858\n22#7:861\n30#8:812\n30#8:862\n1#9:814\n410#10,7:815\n32#11:824\n32#11:864\n185#12:826\n249#12,14:827\n185#12:841\n249#12,14:842\n65#13,10:866\n*S KotlinDebug\n*F\n+ 1 DrawBackdropModifier.kt\ndev/nino/squareglass/backdrop/DrawBackdropNode\n*L\n396#1:798,2\n516#1:822,2\n406#1:800\n406#1:801,2\n408#1:803\n408#1:804,2\n493#1:806\n494#1:809\n543#1:856\n544#1:859\n493#1:807\n494#1:810\n492#1:813\n521#1:825\n543#1:857\n544#1:860\n542#1:863\n649#1:865\n493#1:808\n494#1:811\n543#1:858\n544#1:861\n492#1:812\n542#1:862\n508#1:815,7\n521#1:824\n649#1:864\n524#1:826\n524#1:827,14\n664#1:841\n664#1:842,14\n655#1:866,10\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00cf\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008+\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0014\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\t\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\t*\u0001O\u0008\u0002\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u00042\u00020\u0005B\u0099\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\t\u0012\u0017\u0010\n\u001a\u0013\u0012\u0004\u0012\u00020\u000c\u0012\u0004\u0012\u00020\r0\u000b\u00a2\u0006\u0002\u0008\u000e\u0012\u0019\u0010\u000f\u001a\u0015\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\r\u0018\u00010\u000b\u00a2\u0006\u0002\u0008\u000e\u0012\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0012\u0012\u0019\u0010\u0013\u001a\u0015\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r\u0018\u00010\u000b\u00a2\u0006\u0002\u0008\u000e\u0012=\u0010\u0015\u001a9\u0012\u0004\u0012\u00020\u0014\u0012$\u0012\"\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r0\u000b\u00a2\u0006\u0002\u0008\u000e\u00a2\u0006\u000c\u0008\u0017\u0012\u0008\u0008\u0018\u0012\u0004\u0008\u0008(\u0019\u0012\u0004\u0012\u00020\r0\u0016\u00a2\u0006\u0002\u0008\u000e\u0012\u0019\u0010\u001a\u001a\u0015\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r\u0018\u00010\u000b\u00a2\u0006\u0002\u0008\u000e\u0012\u0019\u0010\u001b\u001a\u0015\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r\u0018\u00010\u000b\u00a2\u0006\u0002\u0008\u000e\u0012\u0006\u0010\u001c\u001a\u00020\u001d\u0012\u000c\u0010\u001e\u001a\u0008\u0012\u0004\u0012\u00020 0\u001f\u0012\u000c\u0010!\u001a\u0008\u0012\u0004\u0012\u00020 0\u001f\u0012\u000e\u0010\"\u001a\n\u0012\u0004\u0012\u00020#\u0018\u00010\u001f\u00a2\u0006\u0004\u0008$\u0010%J\r\u0010V\u001a\u00020\rH\u0000\u00a2\u0006\u0002\u0008WJ\u000f\u0010s\u001a\u0004\u0018\u00010#H\u0002\u00a2\u0006\u0002\u0010tJ\u0010\u0010u\u001a\u00020 2\u0006\u0010v\u001a\u00020wH\u0002J\u000f\u0010x\u001a\u0004\u0018\u00010oH\u0002\u00a2\u0006\u0002\u0008yJ\u0016\u0010\u0080\u0001\u001a\u00020 *\u00020\u00142\u0007\u0010\u0081\u0001\u001a\u00020#H\u0002J,\u0010\u0083\u0001\u001a\u00030\u0084\u0001*\u00030\u0085\u00012\u0008\u0010\u0086\u0001\u001a\u00030\u0087\u00012\u0008\u0010\u0088\u0001\u001a\u00030\u0089\u0001H\u0016\u00a2\u0006\u0006\u0008\u008a\u0001\u0010\u008b\u0001J\u000e\u0010\u008c\u0001\u001a\u00020\r*\u00030\u008d\u0001H\u0016J\u0012\u0010\u008e\u0001\u001a\u00020\r2\u0007\u0010\u008f\u0001\u001a\u00020ZH\u0016J\t\u0010\u0090\u0001\u001a\u00020\rH\u0016J\u0007\u0010\u0091\u0001\u001a\u00020\rJ\t\u0010\u0092\u0001\u001a\u00020\rH\u0002J\t\u0010\u0093\u0001\u001a\u00020\rH\u0002J\t\u0010\u0094\u0001\u001a\u00020\rH\u0016J\t\u0010\u0095\u0001\u001a\u00020\rH\u0016R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008&\u0010\'\"\u0004\u0008(\u0010)R\u001a\u0010\u0008\u001a\u00020\tX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008*\u0010+\"\u0004\u0008,\u0010-R+\u0010\n\u001a\u0013\u0012\u0004\u0012\u00020\u000c\u0012\u0004\u0012\u00020\r0\u000b\u00a2\u0006\u0002\u0008\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008.\u0010/\"\u0004\u00080\u00101R-\u0010\u000f\u001a\u0015\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\r\u0018\u00010\u000b\u00a2\u0006\u0002\u0008\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00082\u0010/\"\u0004\u00083\u00101R\u001c\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00084\u00105\"\u0004\u00086\u00107R-\u0010\u0013\u001a\u0015\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r\u0018\u00010\u000b\u00a2\u0006\u0002\u0008\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00088\u0010/\"\u0004\u00089\u00101RQ\u0010\u0015\u001a9\u0012\u0004\u0012\u00020\u0014\u0012$\u0012\"\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r0\u000b\u00a2\u0006\u0002\u0008\u000e\u00a2\u0006\u000c\u0008\u0017\u0012\u0008\u0008\u0018\u0012\u0004\u0008\u0008(\u0019\u0012\u0004\u0012\u00020\r0\u0016\u00a2\u0006\u0002\u0008\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008:\u0010;\"\u0004\u0008<\u0010=R-\u0010\u001a\u001a\u0015\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r\u0018\u00010\u000b\u00a2\u0006\u0002\u0008\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008>\u0010/\"\u0004\u0008?\u00101R-\u0010\u001b\u001a\u0015\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r\u0018\u00010\u000b\u00a2\u0006\u0002\u0008\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008@\u0010/\"\u0004\u0008A\u00101R\u001a\u0010\u001c\u001a\u00020\u001dX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008B\u0010C\"\u0004\u0008D\u0010ER \u0010\u001e\u001a\u0008\u0012\u0004\u0012\u00020 0\u001fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008F\u0010G\"\u0004\u0008H\u0010IR \u0010!\u001a\u0008\u0012\u0004\u0012\u00020 0\u001fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008J\u0010G\"\u0004\u0008K\u0010IR\"\u0010\"\u001a\n\u0012\u0004\u0012\u00020#\u0018\u00010\u001fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008L\u0010G\"\u0004\u0008M\u0010IR\u0010\u0010N\u001a\u00020OX\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010PR\u0010\u0010Q\u001a\u0004\u0018\u00010RX\u0082\u000e\u00a2\u0006\u0002\n\u0000R.\u0010S\u001a\"\u0012\u0004\u0012\u00020#\u0012\u0004\u0012\u00020R\u0018\u00010Tj\u0010\u0012\u0004\u0012\u00020#\u0012\u0004\u0012\u00020R\u0018\u0001`UX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001f\u0010X\u001a\u0013\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\r0\u000b\u00a2\u0006\u0002\u0008\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R/\u0010[\u001a\u0004\u0018\u00010Z2\u0008\u0010Y\u001a\u0004\u0018\u00010Z8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008`\u0010a\u001a\u0004\u0008\\\u0010]\"\u0004\u0008^\u0010_R+\u0010b\u001a\u00020\u001d2\u0006\u0010Y\u001a\u00020\u001d8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008e\u0010f\u001a\u0004\u0008c\u0010C\"\u0004\u0008d\u0010ER\u001a\u0010g\u001a\u00020 X\u0080\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008h\u0010i\"\u0004\u0008j\u0010kR\u0012\u0010l\u001a\u0004\u0018\u00010#X\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010mR\u0010\u0010n\u001a\u0004\u0018\u00010oX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010p\u001a\u00020qX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010rR\u001f\u0010z\u001a\u0013\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r0\u000b\u00a2\u0006\u0002\u0008\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010{\u001a\u00020 X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010|\u001a\u00020}X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010~\u001a\u0004\u0018\u00010RX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u007f\u001a\u00020}X\u0082\u000e\u00a2\u0006\u0002\n\u0000R \u0010\u0082\u0001\u001a\u0013\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020 0\u000b\u00a2\u0006\u0002\u0008\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0096\u0001"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/DrawBackdropNode;",
        "Landroidx/compose/ui/node/LayoutModifierNode;",
        "Landroidx/compose/ui/node/DrawModifierNode;",
        "Landroidx/compose/ui/node/GlobalPositionAwareModifierNode;",
        "Landroidx/compose/ui/node/ObserverModifierNode;",
        "Landroidx/compose/ui/Modifier$Node;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "shapeProvider",
        "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "effects",
        "Lkotlin/Function1;",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "layerBlock",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "exportedBackdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "onDrawBehind",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "onDrawBackdrop",
        "Lkotlin/Function2;",
        "Lkotlin/ParameterName;",
        "name",
        "drawBackdrop",
        "onDrawSurface",
        "onDrawFront",
        "backdropScale",
        "",
        "frozen",
        "Lkotlin/Function0;",
        "",
        "heldWhileMoving",
        "loopBucket",
        "",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)V",
        "getBackdrop",
        "()Ldev/nino/squareglass/backdrop/Backdrop;",
        "setBackdrop",
        "(Ldev/nino/squareglass/backdrop/Backdrop;)V",
        "getShapeProvider",
        "()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "setShapeProvider",
        "(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V",
        "getEffects",
        "()Lam0/l;",
        "setEffects",
        "(Lam0/l;)V",
        "getLayerBlock",
        "setLayerBlock",
        "getExportedBackdrop",
        "()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "setExportedBackdrop",
        "(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V",
        "getOnDrawBehind",
        "setOnDrawBehind",
        "getOnDrawBackdrop",
        "()Lam0/p;",
        "setOnDrawBackdrop",
        "(Lam0/p;)V",
        "getOnDrawSurface",
        "setOnDrawSurface",
        "getOnDrawFront",
        "setOnDrawFront",
        "getBackdropScale",
        "()F",
        "setBackdropScale",
        "(F)V",
        "getFrozen",
        "()Lam0/a;",
        "setFrozen",
        "(Lam0/a;)V",
        "getHeldWhileMoving",
        "setHeldWhileMoving",
        "getLoopBucket",
        "setLoopBucket",
        "effectScope",
        "dev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1",
        "Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;",
        "graphicsLayer",
        "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
        "loopPool",
        "Ljava/util/HashMap;",
        "Lkotlin/collections/HashMap;",
        "clearLoopPool",
        "clearLoopPool$extension_debug",
        "layoutLayerBlock",
        "<set-?>",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layoutCoordinates",
        "getLayoutCoordinates",
        "()Landroidx/compose/ui/layout/LayoutCoordinates;",
        "setLayoutCoordinates",
        "(Landroidx/compose/ui/layout/LayoutCoordinates;)V",
        "layoutCoordinates$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "padding",
        "getPadding",
        "setPadding",
        "padding$delegate",
        "Landroidx/compose/runtime/MutableFloatState;",
        "surfaceDirty",
        "getSurfaceDirty$extension_debug",
        "()Z",
        "setSurfaceDirty$extension_debug",
        "(Z)V",
        "recordedBackdropVersion",
        "Ljava/lang/Integer;",
        "recordedBackdropOffset",
        "Landroidx/compose/ui/geometry/Offset;",
        "recordedBackdropSize",
        "Landroidx/compose/ui/unit/IntSize;",
        "J",
        "currentBackdropVersion",
        "()Ljava/lang/Integer;",
        "isFullyStatic",
        "rect",
        "Landroidx/compose/ui/geometry/Rect;",
        "currentBackdropOffset",
        "currentBackdropOffset-_m7T9-E",
        "recordBackdropBlock",
        "wasHolding",
        "lastRecordedAt",
        "",
        "handoverLayer",
        "handoverStartedAt",
        "drawBucketedLayer",
        "bucket",
        "drawBackdropLayer",
        "measure",
        "Landroidx/compose/ui/layout/MeasureResult;",
        "Landroidx/compose/ui/layout/MeasureScope;",
        "measurable",
        "Landroidx/compose/ui/layout/Measurable;",
        "constraints",
        "Landroidx/compose/ui/unit/Constraints;",
        "measure-3p2s80s",
        "(Landroidx/compose/ui/layout/MeasureScope;Landroidx/compose/ui/layout/Measurable;J)Landroidx/compose/ui/layout/MeasureResult;",
        "draw",
        "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
        "onGloballyPositioned",
        "coordinates",
        "onObservedReadsChanged",
        "invalidateDrawCache",
        "observeEffects",
        "updateEffects",
        "onAttach",
        "onDetach",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

.field private backdropScale:F

.field private final drawBackdropLayer:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private final effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

.field private effects:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

.field private frozen:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

.field private handoverLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

.field private handoverStartedAt:J

.field private heldWhileMoving:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private lastRecordedAt:J

.field private layerBlock:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final layoutCoordinates$delegate:Landroidx/compose/runtime/MutableState;

.field private final layoutLayerBlock:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private loopBucket:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private loopPool:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
            ">;"
        }
    .end annotation
.end field

.field private onDrawBackdrop:Lam0/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private onDrawBehind:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private onDrawFront:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private onDrawSurface:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final padding$delegate:Landroidx/compose/runtime/MutableFloatState;

.field private final recordBackdropBlock:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private recordedBackdropOffset:Landroidx/compose/ui/geometry/Offset;

.field private recordedBackdropSize:J

.field private recordedBackdropVersion:Ljava/lang/Integer;

.field private shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

.field private surfaceDirty:Z

.field private wasHolding:Z


# direct methods
.method public static synthetic $r8$lambda$I-L8i1xLfYrJgkimNDCz5fWjPto(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordBackdropBlock$lambda$0$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Is_0B9nOtBZ7AXlUsBT7-Rz1l-s(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Z
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$OPDpUOFRR29Yy0lWmnn2f9y1VLU(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->observeEffects$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ool3Ic07woIxzHkPNg5yFJEQKpk(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/GraphicsLayerScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layoutLayerBlock$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/GraphicsLayerScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$blAnFOTM4rp5t-3a3sk7D-LM098(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->draw$lambda$0$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$cDNRgMkmCCT41WNKX0S2n0HuyxU(Landroidx/compose/ui/layout/Placeable;Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/layout/Placeable$PlacementScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->measure_3p2s80s$lambda$0(Landroidx/compose/ui/layout/Placeable;Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/layout/Placeable$PlacementScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$szALJv8OfRqpSdzKHh4BuuELJN0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordBackdropBlock$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$xL3YVuhnPxEZuLKCZUWShLvDFww(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer$lambda$0$1(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public constructor <init>(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;",
            "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;F",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shapeProvider"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "effects"

    invoke-static {p3, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDrawBackdrop"

    invoke-static {p7, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "frozen"

    invoke-static {p11, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "heldWhileMoving"

    invoke-static {p12, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 364
    invoke-direct {p0}, Landroidx/compose/ui/Modifier$Node;-><init>()V

    .line 365
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    .line 366
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    .line 367
    iput-object p3, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effects:Lam0/l;

    .line 368
    iput-object p4, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layerBlock:Lam0/l;

    .line 369
    iput-object p5, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    .line 370
    iput-object p6, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBehind:Lam0/l;

    .line 371
    iput-object p7, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBackdrop:Lam0/p;

    .line 372
    iput-object p8, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawSurface:Lam0/l;

    .line 373
    iput-object p9, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawFront:Lam0/l;

    .line 374
    iput p10, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdropScale:F

    .line 375
    iput-object p11, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->frozen:Lam0/a;

    .line 376
    iput-object p12, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->heldWhileMoving:Lam0/a;

    .line 377
    iput-object p13, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->loopBucket:Lam0/a;

    .line 381
    new-instance p1, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;-><init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    .line 400
    new-instance p1, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda2;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda2;-><init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layoutLayerBlock:Lam0/l;

    const/4 p1, 0x0

    .line 406
    invoke-static {}, Landroidx/compose/runtime/SnapshotStateKt;->neverEqualPolicy()Landroidx/compose/runtime/SnapshotMutationPolicy;

    move-result-object p2

    invoke-static {p1, p2}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layoutCoordinates$delegate:Landroidx/compose/runtime/MutableState;

    const/4 p1, 0x0

    .line 408
    invoke-static {p1}, Landroidx/compose/runtime/PrimitiveSnapshotStateKt;->mutableFloatStateOf(F)Landroidx/compose/runtime/MutableFloatState;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->padding$delegate:Landroidx/compose/runtime/MutableFloatState;

    const/4 p1, 0x1

    .line 415
    iput-boolean p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    .line 419
    sget-object p1, Landroidx/compose/ui/unit/IntSize;->Companion:Landroidx/compose/ui/unit/IntSize$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/unit/IntSize$Companion;->getZero-YbymL2g()J

    move-result-wide p1

    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropSize:J

    .line 440
    new-instance p1, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda3;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda3;-><init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordBackdropBlock:Lam0/l;

    .line 533
    new-instance p1, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda4;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda4;-><init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer:Lam0/l;

    return-void
.end method

.method private final currentBackdropOffset-_m7T9-E()Landroidx/compose/ui/geometry/Offset;
    .locals 10

    .line 430
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    instance-of v1, v0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    check-cast v0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    goto :goto_0

    :cond_0
    move-object v0, v2

    :goto_0
    if-nez v0, :cond_1

    return-object v2

    .line 431
    :cond_1
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getLayerCoordinates$extension_debug()Landroidx/compose/ui/layout/LayoutCoordinates;

    move-result-object v3

    if-nez v3, :cond_2

    return-object v2

    .line 432
    :cond_2
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getLayoutCoordinates()Landroidx/compose/ui/layout/LayoutCoordinates;

    move-result-object v4

    if-nez v4, :cond_3

    return-object v2

    :cond_3
    const/4 v8, 0x6

    const/4 v9, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    .line 434
    :try_start_0
    invoke-static/range {v3 .. v9}, Landroidx/compose/ui/layout/LayoutCoordinates;->localPositionOf-S_NoaFU$default(Landroidx/compose/ui/layout/LayoutCoordinates;Landroidx/compose/ui/layout/LayoutCoordinates;JZILjava/lang/Object;)J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Offset;->box-impl(J)Landroidx/compose/ui/geometry/Offset;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    return-object v2
.end method

.method private final currentBackdropVersion()Ljava/lang/Integer;
    .locals 2

    .line 421
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    instance-of v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    check-cast p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    goto :goto_0

    :cond_0
    move-object p0, v1

    :goto_0
    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getContentVersion$extension_debug()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :cond_1
    return-object v1
.end method

.method private static final draw$lambda$0$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 1

    const-string v0, "$this$recordLayer"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 721
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBehind:Lam0/l;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 722
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer:Lam0/l;

    invoke-interface {v0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 723
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawSurface:Lam0/l;

    if-eqz v0, :cond_1

    invoke-interface {v0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 724
    :cond_1
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawFront:Lam0/l;

    if-eqz p0, :cond_2

    invoke-interface {p0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 725
    :cond_2
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final drawBackdropLayer$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Z
    .locals 26

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "$this$drawBackdropLayer"

    invoke-static {v1, v2}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 534
    iget-object v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->loopBucket:Lam0/a;

    if-eqz v2, :cond_0

    invoke-interface {v2}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    if-eqz v2, :cond_1

    .line 536
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBucketedLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;I)Z

    move-result v0

    return v0

    .line 538
    :cond_1
    iget-object v8, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v8, :cond_1a

    .line 540
    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getPadding()F

    move-result v9

    .line 541
    iget v10, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdropScale:F

    .line 543
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v3

    const/16 v11, 0x20

    shr-long/2addr v3, v11

    long-to-int v3, v3

    .line 858
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v3

    mul-float/2addr v3, v10

    float-to-int v3, v3

    float-to-int v12, v9

    mul-int/lit8 v4, v12, 0x2

    add-int/2addr v3, v4

    const/4 v5, 0x1

    .line 543
    invoke-static {v3, v5}, Ldev/nino/squareglass/HostCompat;->coerceAtLeast(II)I

    move-result v3

    .line 544
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v13

    const-wide v15, 0xffffffffL

    and-long/2addr v13, v15

    long-to-int v6, v13

    .line 861
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v6

    mul-float/2addr v6, v10

    float-to-int v6, v6

    add-int/2addr v6, v4

    .line 544
    invoke-static {v6, v5}, Ldev/nino/squareglass/HostCompat;->coerceAtLeast(II)I

    move-result v4

    int-to-long v13, v3

    shl-long/2addr v13, v11

    int-to-long v3, v4

    and-long/2addr v3, v15

    or-long/2addr v3, v13

    .line 862
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/IntSize;->constructor-impl(J)J

    move-result-wide v13

    .line 546
    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->currentBackdropVersion()Ljava/lang/Integer;

    move-result-object v3

    .line 547
    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->currentBackdropOffset-_m7T9-E()Landroidx/compose/ui/geometry/Offset;

    move-result-object v4

    move-object/from16 v17, v3

    const/4 v6, 0x0

    .line 556
    iget-wide v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropSize:J

    sget-object v18, Landroidx/compose/ui/unit/IntSize;->Companion:Landroidx/compose/ui/unit/IntSize$Companion;

    move/from16 v20, v6

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/unit/IntSize$Companion;->getZero-YbymL2g()J

    move-result-wide v5

    invoke-static {v2, v3, v5, v6}, Landroidx/compose/ui/unit/IntSize;->equals-impl0(JJ)Z

    move-result v2

    .line 557
    iget-boolean v3, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    if-nez v3, :cond_3

    .line 558
    iget-object v3, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropOffset:Landroidx/compose/ui/geometry/Offset;

    invoke-static {v4, v3}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    .line 559
    iget-wide v5, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropSize:J

    invoke-static {v13, v14, v5, v6}, Landroidx/compose/ui/unit/IntSize;->equals-impl0(JJ)Z

    move-result v3

    if-nez v3, :cond_2

    goto :goto_1

    :cond_2
    move/from16 v3, v20

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v3, 0x1

    :goto_2
    if-eqz v17, :cond_6

    .line 560
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Integer;->intValue()I

    move-result v5

    iget-object v6, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropVersion:Ljava/lang/Integer;

    if-nez v6, :cond_4

    goto :goto_3

    :cond_4
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    if-eq v5, v6, :cond_5

    goto :goto_3

    :cond_5
    move/from16 v5, v20

    goto :goto_4

    :cond_6
    :goto_3
    const/4 v5, 0x1

    :goto_4
    if-eqz v5, :cond_7

    if-nez v3, :cond_7

    if-eqz v4, :cond_7

    move/from16 v18, v11

    move/from16 v21, v12

    .line 567
    invoke-virtual {v4}, Landroidx/compose/ui/geometry/Offset;->unbox-impl()J

    move-result-wide v11

    move-object/from16 v22, v8

    invoke-static {v13, v14}, Landroidx/compose/ui/unit/IntSizeKt;->toSize-ozmzZPI(J)J

    move-result-wide v7

    invoke-static {v11, v12, v7, v8}, Landroidx/compose/ui/geometry/RectKt;->Rect-tz77jQw(JJ)Landroidx/compose/ui/geometry/Rect;

    move-result-object v6

    invoke-direct {v0, v6}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->isFullyStatic(Landroidx/compose/ui/geometry/Rect;)Z

    move-result v6

    if-eqz v6, :cond_8

    const/4 v6, 0x1

    goto :goto_5

    :cond_7
    move-object/from16 v22, v8

    move/from16 v18, v11

    move/from16 v21, v12

    :cond_8
    move/from16 v6, v20

    .line 592
    :goto_5
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v7

    .line 593
    iget-wide v11, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->lastRecordedAt:J

    sub-long v11, v7, v11

    long-to-float v11, v11

    const v12, 0x49742400    # 1000000.0f

    div-float/2addr v11, v12

    const/high16 v23, 0x42dc0000    # 110.0f

    cmpl-float v11, v11, v23

    if-ltz v11, :cond_9

    const/4 v11, 0x1

    goto :goto_6

    :cond_9
    move/from16 v11, v20

    :goto_6
    move/from16 v23, v12

    .line 594
    iget-object v12, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->frozen:Lam0/a;

    invoke-interface {v12}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Boolean;

    invoke-virtual {v12}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v12

    if-eqz v12, :cond_b

    if-nez v2, :cond_b

    if-nez v11, :cond_b

    if-eqz v3, :cond_a

    .line 597
    iget-object v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->heldWhileMoving:Lam0/a;

    invoke-interface {v2}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_b

    :cond_a
    const/4 v11, 0x1

    goto :goto_7

    :cond_b
    move/from16 v11, v20

    .line 608
    :goto_7
    iget-boolean v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->wasHolding:Z

    if-eqz v2, :cond_c

    if-nez v11, :cond_c

    const/4 v2, 0x1

    goto :goto_8

    :cond_c
    move/from16 v2, v20

    :goto_8
    if-eqz v11, :cond_e

    :cond_d
    move/from16 v19, v20

    goto :goto_a

    :cond_e
    if-eqz v2, :cond_f

    :goto_9
    const/16 v19, 0x1

    goto :goto_a

    :cond_f
    if-nez v3, :cond_10

    if-eqz v5, :cond_d

    :cond_10
    if-nez v6, :cond_d

    goto :goto_9

    :goto_a
    if-eqz v2, :cond_12

    .line 624
    iget-object v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-nez v2, :cond_11

    .line 625
    move-object v2, v0

    check-cast v2, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v2}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v2

    invoke-interface {v2}, Landroidx/compose/ui/graphics/GraphicsContext;->createGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object v2

    iput-object v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    :cond_11
    move-object v3, v2

    .line 627
    move-object v2, v0

    check-cast v2, Landroidx/compose/ui/node/DelegatableNode;

    move-object v6, v4

    iget-wide v4, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropSize:J

    move-object v12, v6

    new-instance v6, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda6;

    move-wide/from16 v24, v15

    move-object/from16 v15, v22

    invoke-direct {v6, v15}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda6;-><init>(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    move/from16 v16, v9

    move-object v9, v12

    move-object/from16 v12, v17

    invoke-static/range {v1 .. v6}, Ldev/nino/squareglass/backdrop/internal/LayerRecorderKt;->recordLayer-TdoYBX4(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/node/DelegatableNode;Landroidx/compose/ui/graphics/layer/GraphicsLayer;JLam0/l;)V

    const/4 v1, 0x0

    .line 630
    invoke-virtual {v3, v1}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    .line 631
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    iput-wide v1, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverStartedAt:J

    goto :goto_b

    :cond_12
    move-wide/from16 v24, v15

    move-object/from16 v12, v17

    move-object/from16 v15, v22

    move/from16 v16, v9

    move-object v9, v4

    .line 633
    :goto_b
    iput-boolean v11, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->wasHolding:Z

    if-eqz v19, :cond_13

    .line 637
    move-object v2, v0

    check-cast v2, Landroidx/compose/ui/node/DelegatableNode;

    .line 640
    iget-object v6, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordBackdropBlock:Lam0/l;

    move-object/from16 v1, p1

    move-wide v4, v13

    move-object v3, v15

    .line 636
    invoke-static/range {v1 .. v6}, Ldev/nino/squareglass/backdrop/internal/LayerRecorderKt;->recordLayer-TdoYBX4(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/node/DelegatableNode;Landroidx/compose/ui/graphics/layer/GraphicsLayer;JLam0/l;)V

    .line 642
    iput-object v12, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropVersion:Ljava/lang/Integer;

    .line 643
    iput-object v9, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropOffset:Landroidx/compose/ui/geometry/Offset;

    .line 644
    iput-wide v4, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropSize:J

    .line 645
    iput-wide v7, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->lastRecordedAt:J

    goto :goto_c

    :cond_13
    move-object/from16 v1, p1

    :goto_c
    const/4 v2, 0x0

    cmpg-float v3, v16, v2

    if-nez v3, :cond_14

    .line 650
    sget-object v3, Landroidx/compose/ui/unit/IntOffset;->Companion:Landroidx/compose/ui/unit/IntOffset$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/unit/IntOffset$Companion;->getZero-nOcc-ac()J

    move-result-wide v3

    goto :goto_d

    :cond_14
    move/from16 v3, v21

    neg-int v3, v3

    int-to-long v3, v3

    shl-long v5, v3, v18

    and-long v3, v3, v24

    or-long/2addr v3, v5

    .line 864
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/IntOffset;->constructor-impl(J)J

    move-result-wide v3

    .line 648
    :goto_d
    invoke-virtual {v15, v3, v4}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setTopLeft--gyyYBs(J)V

    .line 652
    iget-object v3, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    const-wide/16 v4, 0x0

    const/high16 v6, 0x3f800000    # 1.0f

    if-eqz v3, :cond_16

    .line 653
    iget-wide v7, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverStartedAt:J

    cmp-long v7, v7, v4

    if-eqz v7, :cond_16

    .line 654
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v7

    iget-wide v11, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverStartedAt:J

    sub-long/2addr v7, v11

    long-to-float v7, v7

    div-float v7, v7, v23

    const/high16 v8, 0x43340000    # 180.0f

    div-float/2addr v7, v8

    cmpg-float v8, v7, v2

    if-gez v8, :cond_15

    goto :goto_e

    :cond_15
    move v2, v7

    :goto_e
    cmpl-float v7, v2, v6

    if-lez v7, :cond_17

    :cond_16
    move v2, v6

    :cond_17
    cmpg-float v7, v2, v6

    if-gez v7, :cond_18

    if-eqz v3, :cond_18

    .line 673
    invoke-virtual {v15}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->getTopLeft-nOcc-ac()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setTopLeft--gyyYBs(J)V

    sub-float v4, v6, v2

    .line 674
    invoke-virtual {v3, v4}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setAlpha(F)V

    .line 675
    invoke-static {v1, v10, v3}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer$lambda$0$paint(Landroidx/compose/ui/graphics/drawscope/DrawScope;FLandroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    .line 676
    invoke-virtual {v15, v2}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setAlpha(F)V

    .line 677
    invoke-static {v1, v10, v15}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer$lambda$0$paint(Landroidx/compose/ui/graphics/drawscope/DrawScope;FLandroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    .line 678
    invoke-virtual {v15, v6}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setAlpha(F)V

    .line 681
    check-cast v0, Landroidx/compose/ui/node/DrawModifierNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DrawModifierNodeKt;->invalidateDraw(Landroidx/compose/ui/node/DrawModifierNode;)V

    return v19

    :cond_18
    if-eqz v3, :cond_19

    .line 684
    move-object v2, v0

    check-cast v2, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v2}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v2

    invoke-interface {v2, v3}, Landroidx/compose/ui/graphics/GraphicsContext;->releaseGraphicsLayer(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    const/4 v2, 0x0

    .line 685
    iput-object v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    .line 686
    iput-wide v4, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverStartedAt:J

    .line 688
    :cond_19
    invoke-static {v1, v10, v15}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer$lambda$0$paint(Landroidx/compose/ui/graphics/drawscope/DrawScope;FLandroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    return v19

    :cond_1a
    const/16 v20, 0x0

    return v20
.end method

.method private static final drawBackdropLayer$lambda$0$1(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 1

    const-string v0, "$this$recordLayer"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 628
    invoke-static {p1, p0}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    .line 629
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final drawBackdropLayer$lambda$0$paint(Landroidx/compose/ui/graphics/drawscope/DrawScope;FLandroidx/compose/ui/graphics/layer/GraphicsLayer;)V
    .locals 6

    const/high16 v0, 0x3f800000    # 1.0f

    cmpg-float v1, p1, v0

    if-nez v1, :cond_0

    .line 668
    invoke-static {p0, p2}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    return-void

    :cond_0
    div-float/2addr v0, p1

    .line 664
    sget-object p1, Landroidx/compose/ui/geometry/Offset;->Companion:Landroidx/compose/ui/geometry/Offset$Companion;

    invoke-virtual {p1}, Landroidx/compose/ui/geometry/Offset$Companion;->getZero-F1C5BW0()J

    move-result-wide v1

    .line 842
    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p1

    .line 846
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getSize-NH-jbRc()J

    move-result-wide v3

    .line 847
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v5

    invoke-interface {v5}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 849
    :try_start_0
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v5

    .line 841
    invoke-interface {v5, v0, v0, v1, v2}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->scale-0AR0LA0(FFJ)V

    .line 665
    invoke-static {p0, p2}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 852
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 853
    invoke-interface {p1, v3, v4}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    return-void

    :catchall_0
    move-exception p0

    .line 852
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p2

    invoke-interface {p2}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 853
    invoke-interface {p1, v3, v4}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    throw p0
.end method

.method private final drawBucketedLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;I)Z
    .locals 17

    move-object/from16 v0, p0

    .line 490
    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getPadding()F

    move-result v7

    .line 491
    iget v8, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdropScale:F

    .line 493
    invoke-interface/range {p1 .. p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v1

    const/16 v9, 0x20

    shr-long/2addr v1, v9

    long-to-int v1, v1

    .line 808
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    mul-float/2addr v1, v8

    float-to-int v1, v1

    float-to-int v10, v7

    mul-int/lit8 v2, v10, 0x2

    add-int/2addr v1, v2

    const/4 v11, 0x1

    .line 493
    invoke-static {v1, v11}, Ldev/nino/squareglass/HostCompat;->coerceAtLeast(II)I

    move-result v1

    .line 494
    invoke-interface/range {p1 .. p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v3

    const-wide v12, 0xffffffffL

    and-long/2addr v3, v12

    long-to-int v3, v3

    .line 811
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v3

    mul-float/2addr v3, v8

    float-to-int v3, v3

    add-int/2addr v3, v2

    .line 494
    invoke-static {v3, v11}, Ldev/nino/squareglass/HostCompat;->coerceAtLeast(II)I

    move-result v2

    int-to-long v3, v1

    shl-long/2addr v3, v9

    int-to-long v1, v2

    and-long/2addr v1, v12

    or-long/2addr v1, v3

    .line 812
    invoke-static {v1, v2}, Landroidx/compose/ui/unit/IntSize;->constructor-impl(J)J

    move-result-wide v4

    .line 496
    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->currentBackdropOffset-_m7T9-E()Landroidx/compose/ui/geometry/Offset;

    move-result-object v1

    .line 497
    iget-boolean v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    if-nez v2, :cond_0

    .line 498
    iget-object v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropOffset:Landroidx/compose/ui/geometry/Offset;

    invoke-static {v1, v2}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 499
    iget-wide v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropSize:J

    invoke-static {v4, v5, v2, v3}, Landroidx/compose/ui/unit/IntSize;->equals-impl0(JJ)Z

    move-result v2

    if-nez v2, :cond_1

    .line 501
    :cond_0
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->clearLoopPool$extension_debug()V

    .line 503
    :cond_1
    iput-object v1, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropOffset:Landroidx/compose/ui/geometry/Offset;

    .line 504
    iput-wide v4, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropSize:J

    .line 506
    iget-object v1, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->loopPool:Ljava/util/HashMap;

    if-nez v1, :cond_2

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->loopPool:Ljava/util/HashMap;

    :cond_2
    move-object v14, v1

    .line 508
    move-object v15, v14

    check-cast v15, Ljava/util/Map;

    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    .line 815
    invoke-interface {v15, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_3

    .line 510
    move-object v2, v0

    check-cast v2, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v2}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v3

    invoke-interface {v3}, Landroidx/compose/ui/graphics/GraphicsContext;->createGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object v3

    .line 511
    iget-object v6, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordBackdropBlock:Lam0/l;

    move/from16 v16, v9

    move-object v9, v1

    move-object/from16 v1, p1

    invoke-static/range {v1 .. v6}, Ldev/nino/squareglass/backdrop/internal/LayerRecorderKt;->recordLayer-TdoYBX4(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/node/DelegatableNode;Landroidx/compose/ui/graphics/layer/GraphicsLayer;JLam0/l;)V

    .line 512
    iget-object v2, v0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    invoke-virtual {v2}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;->getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    .line 818
    invoke-interface {v15, v9, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v2, v3

    goto :goto_0

    :cond_3
    move-object/from16 v1, p1

    move/from16 v16, v9

    const/4 v11, 0x0

    .line 508
    :goto_0
    check-cast v2, Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    .line 515
    invoke-virtual {v14}, Ljava/util/HashMap;->size()I

    move-result v3

    const/16 v4, 0x40

    if-le v3, v4, :cond_7

    .line 516
    invoke-virtual {v14}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v3

    const-string v4, "<get-keys>(...)"

    invoke-static {v3, v4}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Ljava/lang/Iterable;

    .line 822
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    check-cast v5, Ljava/lang/Integer;

    if-nez v5, :cond_5

    goto :goto_1

    .line 516
    :cond_5
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    move/from16 v6, p2

    if-eq v5, v6, :cond_4

    :goto_1
    const-string v3, "first(...)"

    invoke-static {v4, v3}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v3

    .line 517
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v14, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v3, :cond_7

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    invoke-interface {v0, v3}, Landroidx/compose/ui/graphics/GraphicsContext;->releaseGraphicsLayer(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    goto :goto_2

    .line 823
    :cond_6
    new-instance v0, Ljava/util/NoSuchElementException;

    const-string v1, "Collection contains no element matching the predicate."

    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7
    :goto_2
    const/4 v0, 0x0

    cmpg-float v0, v7, v0

    if-nez v0, :cond_8

    .line 522
    sget-object v0, Landroidx/compose/ui/unit/IntOffset;->Companion:Landroidx/compose/ui/unit/IntOffset$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/unit/IntOffset$Companion;->getZero-nOcc-ac()J

    move-result-wide v3

    goto :goto_3

    :cond_8
    neg-int v0, v10

    int-to-long v3, v0

    shl-long v5, v3, v16

    and-long/2addr v3, v12

    or-long/2addr v3, v5

    .line 824
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/IntOffset;->constructor-impl(J)J

    move-result-wide v3

    .line 520
    :goto_3
    invoke-virtual {v2, v3, v4}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setTopLeft--gyyYBs(J)V

    const/high16 v0, 0x3f800000    # 1.0f

    cmpg-float v3, v8, v0

    if-nez v3, :cond_9

    .line 528
    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    return v11

    :cond_9
    div-float/2addr v0, v8

    .line 524
    sget-object v3, Landroidx/compose/ui/geometry/Offset;->Companion:Landroidx/compose/ui/geometry/Offset$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/geometry/Offset$Companion;->getZero-F1C5BW0()J

    move-result-wide v3

    .line 827
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v5

    .line 831
    invoke-interface {v5}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getSize-NH-jbRc()J

    move-result-wide v6

    .line 832
    invoke-interface {v5}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v8

    invoke-interface {v8}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 834
    :try_start_0
    invoke-interface {v5}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v8

    .line 826
    invoke-interface {v8, v0, v0, v3, v4}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->scale-0AR0LA0(FFJ)V

    .line 525
    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 837
    invoke-interface {v5}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 838
    invoke-interface {v5, v6, v7}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    return v11

    :catchall_0
    move-exception v0

    .line 837
    invoke-interface {v5}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v1

    invoke-interface {v1}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 838
    invoke-interface {v5, v6, v7}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    throw v0
.end method

.method private final getLayoutCoordinates()Landroidx/compose/ui/layout/LayoutCoordinates;
    .locals 0

    .line 406
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layoutCoordinates$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 800
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/layout/LayoutCoordinates;

    return-object p0
.end method

.method private final getPadding()F
    .locals 0

    .line 408
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->padding$delegate:Landroidx/compose/runtime/MutableFloatState;

    check-cast p0, Landroidx/compose/runtime/FloatState;

    .line 803
    invoke-interface {p0}, Landroidx/compose/runtime/FloatState;->getFloatValue()F

    move-result p0

    return p0
.end method

.method private final isFullyStatic(Landroidx/compose/ui/geometry/Rect;)Z
    .locals 1

    .line 426
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    instance-of v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    if-eqz v0, :cond_0

    check-cast p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    const/4 v0, 0x0

    if-eqz p0, :cond_1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->isFullyStatic$extension_debug(Landroidx/compose/ui/geometry/Rect;)Z

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_1

    return p1

    :cond_1
    return v0
.end method

.method private static final layoutLayerBlock$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/GraphicsLayerScope;)Lkotlin/u;
    .locals 1

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 401
    invoke-interface {p1, v0}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->setClip(Z)V

    .line 402
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->getShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    invoke-interface {p1, p0}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->setShape(Landroidx/compose/ui/graphics/Shape;)V

    .line 403
    sget-object p0, Landroidx/compose/ui/graphics/CompositingStrategy;->Companion:Landroidx/compose/ui/graphics/CompositingStrategy$Companion;

    invoke-virtual {p0}, Landroidx/compose/ui/graphics/CompositingStrategy$Companion;->getOffscreen--NrFUSI()I

    move-result p0

    invoke-interface {p1, p0}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->setCompositingStrategy-aDBOjCE(I)V

    .line 404
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final measure_3p2s80s$lambda$0(Landroidx/compose/ui/layout/Placeable;Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/layout/Placeable$PlacementScope;)Lkotlin/u;
    .locals 9

    const-string v0, "$this$layout"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 703
    sget-object v0, Landroidx/compose/ui/unit/IntOffset;->Companion:Landroidx/compose/ui/unit/IntOffset$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/unit/IntOffset$Companion;->getZero-nOcc-ac()J

    move-result-wide v3

    iget-object v6, p1, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layoutLayerBlock:Lam0/l;

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v5, 0x0

    move-object v2, p0

    move-object v1, p2

    invoke-static/range {v1 .. v8}, Landroidx/compose/ui/layout/Placeable$PlacementScope;->placeWithLayer-aW-9-wM$default(Landroidx/compose/ui/layout/Placeable$PlacementScope;Landroidx/compose/ui/layout/Placeable;JFLam0/l;ILjava/lang/Object;)V

    .line 704
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final observeEffects()V
    .locals 2

    .line 754
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/Modifier$Node;

    new-instance v1, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda5;-><init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    invoke-static {v0, v1}, Landroidx/compose/ui/node/ObserverModifierNodeKt;->observeReads(Landroidx/compose/ui/Modifier$Node;Lam0/a;)V

    return-void
.end method

.method private static final observeEffects$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)Lkotlin/u;
    .locals 0

    .line 754
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->updateEffects()V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final recordBackdropBlock$lambda$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 8

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 441
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v0

    .line 442
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getPadding()F

    move-result v1

    .line 443
    iget v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdropScale:F

    const/4 v3, 0x0

    cmpg-float v3, v1, v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 446
    :cond_0
    invoke-interface {v0, v1, v1}, Landroidx/compose/ui/graphics/Canvas;->translate(FF)V

    :goto_0
    const/high16 v4, 0x3f800000    # 1.0f

    cmpg-float v5, v2, v4

    if-nez v5, :cond_1

    goto :goto_1

    .line 451
    :cond_1
    invoke-interface {v0, v2, v2}, Landroidx/compose/ui/graphics/Canvas;->scale(FF)V

    .line 453
    :goto_1
    iget-object v6, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBackdrop:Lam0/p;

    new-instance v7, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda7;

    invoke-direct {v7, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda7;-><init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    invoke-interface {v6, p1, v7}, Lam0/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-nez v5, :cond_2

    goto :goto_2

    :cond_2
    div-float/2addr v4, v2

    .line 463
    invoke-interface {v0, v4, v4}, Landroidx/compose/ui/graphics/Canvas;->scale(FF)V

    :goto_2
    if-nez v3, :cond_3

    goto :goto_3

    :cond_3
    neg-float p0, v1

    .line 466
    invoke-interface {v0, p0, p0}, Landroidx/compose/ui/graphics/Canvas;->translate(FF)V

    .line 468
    :goto_3
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final recordBackdropBlock$lambda$0$0(Ldev/nino/squareglass/backdrop/DrawBackdropNode;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 3

    const-string v0, "$this$onDrawBackdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 454
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    .line 456
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    check-cast v1, Landroidx/compose/ui/unit/Density;

    .line 457
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getLayoutCoordinates()Landroidx/compose/ui/layout/LayoutCoordinates;

    move-result-object v2

    .line 458
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layerBlock:Lam0/l;

    .line 455
    invoke-interface {v0, p1, v1, v2, p0}, Ldev/nino/squareglass/backdrop/Backdrop;->drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V

    .line 461
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final setLayoutCoordinates(Landroidx/compose/ui/layout/LayoutCoordinates;)V
    .locals 0

    .line 406
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layoutCoordinates$delegate:Landroidx/compose/runtime/MutableState;

    .line 801
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setPadding(F)V
    .locals 0

    .line 408
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->padding$delegate:Landroidx/compose/runtime/MutableFloatState;

    .line 804
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableFloatState;->setFloatValue(F)V

    return-void
.end method

.method private final updateEffects()V
    .locals 2

    .line 758
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRenderEffectSupported()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 760
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effects:Lam0/l;

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;->apply(Lam0/l;)V

    .line 761
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v0, :cond_1

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    invoke-virtual {v1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;->getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    .line 762
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;->getPadding()F

    move-result v0

    .line 763
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getPadding()F

    move-result v1

    cmpg-float v1, v0, v1

    if-nez v1, :cond_2

    return-void

    .line 764
    :cond_2
    invoke-direct {p0, v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setPadding(F)V

    const/4 v0, 0x1

    .line 765
    iput-boolean v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    return-void
.end method


# virtual methods
.method public final clearLoopPool$extension_debug()V
    .locals 3

    .line 394
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->loopPool:Ljava/util/HashMap;

    if-nez v0, :cond_0

    return-void

    .line 395
    :cond_0
    check-cast p0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {p0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object p0

    .line 396
    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v1

    const-string v2, "<get-values>(...)"

    invoke-static {v1, v2}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    .line 798
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    .line 396
    invoke-static {v2}, Ldev/nino/squareglass/HostCompat;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {p0, v2}, Landroidx/compose/ui/graphics/GraphicsContext;->releaseGraphicsLayer(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    goto :goto_0

    .line 397
    :cond_1
    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    return-void
.end method

.method public draw(Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V
    .locals 9

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 708
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    move-object v1, p1

    check-cast v1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    iget v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdropScale:F

    invoke-virtual {v0, v1, v2}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;->update(Landroidx/compose/ui/graphics/drawscope/DrawScope;F)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 709
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->updateEffects()V

    .line 712
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBehind:Lam0/l;

    if-eqz v0, :cond_1

    invoke-interface {v0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 713
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->drawBackdropLayer:Lam0/l;

    invoke-interface {v0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 714
    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawSurface:Lam0/l;

    if-eqz v2, :cond_2

    invoke-interface {v2, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 715
    :cond_2
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    .line 716
    iget-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawFront:Lam0/l;

    if-eqz v2, :cond_3

    invoke-interface {v2, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 718
    :cond_3
    iget-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    if-eqz p1, :cond_5

    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object v3

    if-eqz v3, :cond_5

    .line 719
    iget-boolean p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    if-nez p1, :cond_4

    if-eqz v0, :cond_5

    .line 720
    :cond_4
    move-object v2, p0

    check-cast v2, Landroidx/compose/ui/node/DelegatableNode;

    new-instance v6, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda0;

    invoke-direct {v6, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda0;-><init>(Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-wide/16 v4, 0x0

    invoke-static/range {v1 .. v8}, Ldev/nino/squareglass/backdrop/internal/LayerRecorderKt;->recordLayer-TdoYBX4$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/node/DelegatableNode;Landroidx/compose/ui/graphics/layer/GraphicsLayer;JLam0/l;ILjava/lang/Object;)V

    :cond_5
    const/4 p1, 0x0

    .line 728
    iput-boolean p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    return-void
.end method

.method public final getBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 0

    .line 365
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    return-object p0
.end method

.method public final getBackdropScale()F
    .locals 0

    .line 374
    iget p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdropScale:F

    return p0
.end method

.method public final getEffects()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 367
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effects:Lam0/l;

    return-object p0
.end method

.method public final getExportedBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;
    .locals 0

    .line 369
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-object p0
.end method

.method public final getFrozen()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 375
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->frozen:Lam0/a;

    return-object p0
.end method

.method public final getHeldWhileMoving()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 376
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->heldWhileMoving:Lam0/a;

    return-object p0
.end method

.method public final getLayerBlock()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 368
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layerBlock:Lam0/l;

    return-object p0
.end method

.method public final getLoopBucket()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 377
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->loopBucket:Lam0/a;

    return-object p0
.end method

.method public final getOnDrawBackdrop()Lam0/p;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 371
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBackdrop:Lam0/p;

    return-object p0
.end method

.method public final getOnDrawBehind()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 370
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBehind:Lam0/l;

    return-object p0
.end method

.method public final getOnDrawFront()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 373
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawFront:Lam0/l;

    return-object p0
.end method

.method public final getOnDrawSurface()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 372
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawSurface:Lam0/l;

    return-object p0
.end method

.method public final getShapeProvider()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;
    .locals 0

    .line 366
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-object p0
.end method

.method public final getSurfaceDirty$extension_debug()Z
    .locals 0

    .line 415
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    return p0
.end method

.method public final invalidateDrawCache()V
    .locals 0

    .line 750
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->observeEffects()V

    return-void
.end method

.method public bridge maxIntrinsicHeight(Landroidx/compose/ui/layout/IntrinsicMeasureScope;Landroidx/compose/ui/layout/IntrinsicMeasurable;I)I
    .locals 0

    .line 364
    invoke-super {p0, p1, p2, p3}, Landroidx/compose/ui/node/LayoutModifierNode;->maxIntrinsicHeight(Landroidx/compose/ui/layout/IntrinsicMeasureScope;Landroidx/compose/ui/layout/IntrinsicMeasurable;I)I

    move-result p0

    return p0
.end method

.method public bridge maxIntrinsicWidth(Landroidx/compose/ui/layout/IntrinsicMeasureScope;Landroidx/compose/ui/layout/IntrinsicMeasurable;I)I
    .locals 0

    .line 364
    invoke-super {p0, p1, p2, p3}, Landroidx/compose/ui/node/LayoutModifierNode;->maxIntrinsicWidth(Landroidx/compose/ui/layout/IntrinsicMeasureScope;Landroidx/compose/ui/layout/IntrinsicMeasurable;I)I

    move-result p0

    return p0
.end method

.method public measure-3p2s80s(Landroidx/compose/ui/layout/MeasureScope;Landroidx/compose/ui/layout/Measurable;J)Landroidx/compose/ui/layout/MeasureResult;
    .locals 7

    const-string v0, "$this$measure"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "measurable"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 701
    invoke-interface {p2, p3, p4}, Landroidx/compose/ui/layout/Measurable;->measure-BRTryo0(J)Landroidx/compose/ui/layout/Placeable;

    move-result-object p2

    .line 702
    invoke-virtual {p2}, Landroidx/compose/ui/layout/Placeable;->getWidth()I

    move-result v1

    invoke-virtual {p2}, Landroidx/compose/ui/layout/Placeable;->getHeight()I

    move-result v2

    new-instance v4, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda1;

    invoke-direct {v4, p2, p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/ui/layout/Placeable;Ldev/nino/squareglass/backdrop/DrawBackdropNode;)V

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v3, 0x0

    move-object v0, p1

    invoke-static/range {v0 .. v6}, Landroidx/compose/ui/layout/MeasureScope;->layout$default(Landroidx/compose/ui/layout/MeasureScope;IILjava/util/Map;Lam0/l;ILjava/lang/Object;)Landroidx/compose/ui/layout/MeasureResult;

    move-result-object p0

    return-object p0
.end method

.method public bridge minIntrinsicHeight(Landroidx/compose/ui/layout/IntrinsicMeasureScope;Landroidx/compose/ui/layout/IntrinsicMeasurable;I)I
    .locals 0

    .line 364
    invoke-super {p0, p1, p2, p3}, Landroidx/compose/ui/node/LayoutModifierNode;->minIntrinsicHeight(Landroidx/compose/ui/layout/IntrinsicMeasureScope;Landroidx/compose/ui/layout/IntrinsicMeasurable;I)I

    move-result p0

    return p0
.end method

.method public bridge minIntrinsicWidth(Landroidx/compose/ui/layout/IntrinsicMeasureScope;Landroidx/compose/ui/layout/IntrinsicMeasurable;I)I
    .locals 0

    .line 364
    invoke-super {p0, p1, p2, p3}, Landroidx/compose/ui/node/LayoutModifierNode;->minIntrinsicWidth(Landroidx/compose/ui/layout/IntrinsicMeasureScope;Landroidx/compose/ui/layout/IntrinsicMeasurable;I)I

    move-result p0

    return p0
.end method

.method public onAttach()V
    .locals 1

    .line 770
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    .line 771
    invoke-interface {v0}, Landroidx/compose/ui/graphics/GraphicsContext;->createGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    const/4 v0, 0x1

    .line 773
    iput-boolean v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    .line 774
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->observeEffects()V

    return-void
.end method

.method public onDetach()V
    .locals 3

    .line 778
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    .line 779
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    .line 780
    invoke-interface {v0, v1}, Landroidx/compose/ui/graphics/GraphicsContext;->releaseGraphicsLayer(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    .line 781
    iput-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    .line 783
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v1, :cond_1

    .line 784
    invoke-interface {v0, v1}, Landroidx/compose/ui/graphics/GraphicsContext;->releaseGraphicsLayer(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    .line 785
    iput-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->handoverLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    .line 787
    :cond_1
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->clearLoopPool$extension_debug()V

    .line 789
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effectScope:Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode$effectScope$1;->reset()V

    .line 790
    invoke-direct {p0, v2}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setLayoutCoordinates(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    .line 791
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    if-eqz v0, :cond_2

    invoke-virtual {v0, v2}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->setLayerCoordinates$extension_debug(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    .line 792
    :cond_2
    iput-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropVersion:Ljava/lang/Integer;

    .line 793
    iput-object v2, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropOffset:Landroidx/compose/ui/geometry/Offset;

    .line 794
    sget-object v0, Landroidx/compose/ui/unit/IntSize;->Companion:Landroidx/compose/ui/unit/IntSize$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/unit/IntSize$Companion;->getZero-YbymL2g()J

    move-result-wide v0

    iput-wide v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->recordedBackdropSize:J

    return-void
.end method

.method public onGloballyPositioned(Landroidx/compose/ui/layout/LayoutCoordinates;)V
    .locals 1

    const-string v0, "coordinates"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 732
    invoke-interface {p1}, Landroidx/compose/ui/layout/LayoutCoordinates;->isAttached()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 733
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-interface {v0}, Ldev/nino/squareglass/backdrop/Backdrop;->isCoordinatesDependent()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 734
    invoke-direct {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setLayoutCoordinates(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    goto :goto_0

    .line 736
    :cond_0
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->getLayoutCoordinates()Landroidx/compose/ui/layout/LayoutCoordinates;

    move-result-object v0

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    .line 737
    invoke-direct {p0, v0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->setLayoutCoordinates(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    .line 740
    :cond_1
    :goto_0
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    if-eqz p0, :cond_2

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->setLayerCoordinates$extension_debug(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    :cond_2
    return-void
.end method

.method public bridge onMeasureResultChanged()V
    .locals 0

    .line 364
    invoke-super {p0}, Landroidx/compose/ui/node/DrawModifierNode;->onMeasureResultChanged()V

    return-void
.end method

.method public onObservedReadsChanged()V
    .locals 1

    const/4 v0, 0x1

    .line 745
    iput-boolean v0, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    .line 746
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->invalidateDrawCache()V

    return-void
.end method

.method public final setBackdrop(Ldev/nino/squareglass/backdrop/Backdrop;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 365
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    return-void
.end method

.method public final setBackdropScale(F)V
    .locals 0

    .line 374
    iput p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->backdropScale:F

    return-void
.end method

.method public final setEffects(Lam0/l;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 367
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->effects:Lam0/l;

    return-void
.end method

.method public final setExportedBackdrop(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V
    .locals 0

    .line 369
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->exportedBackdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-void
.end method

.method public final setFrozen(Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 375
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->frozen:Lam0/a;

    return-void
.end method

.method public final setHeldWhileMoving(Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 376
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->heldWhileMoving:Lam0/a;

    return-void
.end method

.method public final setLayerBlock(Lam0/l;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    .line 368
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->layerBlock:Lam0/l;

    return-void
.end method

.method public final setLoopBucket(Lam0/a;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 377
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->loopBucket:Lam0/a;

    return-void
.end method

.method public final setOnDrawBackdrop(Lam0/p;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 371
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBackdrop:Lam0/p;

    return-void
.end method

.method public final setOnDrawBehind(Lam0/l;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    .line 370
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawBehind:Lam0/l;

    return-void
.end method

.method public final setOnDrawFront(Lam0/l;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    .line 373
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawFront:Lam0/l;

    return-void
.end method

.method public final setOnDrawSurface(Lam0/l;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    .line 372
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->onDrawSurface:Lam0/l;

    return-void
.end method

.method public final setShapeProvider(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 366
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-void
.end method

.method public final setSurfaceDirty$extension_debug(Z)V
    .locals 0

    .line 415
    iput-boolean p1, p0, Ldev/nino/squareglass/backdrop/DrawBackdropNode;->surfaceDirty:Z

    return-void
.end method
