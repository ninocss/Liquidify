.class public interface abstract Ldev/nino/squareglass/backdrop/BackdropEffectScope;
.super Ljava/lang/Object;
.source "BackdropEffectScope.kt"

# interfaces
.implements Landroidx/compose/ui/unit/Density;
.implements Ldev/nino/squareglass/backdrop/RuntimeShaderCache;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/backdrop/BackdropEffectScope$DefaultImpls;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\u0008v\u0018\u00002\u00020\u00012\u00020\u0002R\u0012\u0010\u0003\u001a\u00020\u0004X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0005\u0010\u0006R\u0012\u0010\u0007\u001a\u00020\u0008X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\t\u0010\nR\u0012\u0010\u000b\u001a\u00020\u000cX\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\r\u0010\u000eR\u0012\u0010\u000f\u001a\u00020\u0010X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0011\u0010\u0012R\u0018\u0010\u0013\u001a\u00020\u0010X\u00a6\u000e\u00a2\u0006\u000c\u001a\u0004\u0008\u0014\u0010\u0012\"\u0004\u0008\u0015\u0010\u0016R\u001a\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u00a6\u000e\u00a2\u0006\u000c\u001a\u0004\u0008\u0019\u0010\u001a\"\u0004\u0008\u001b\u0010\u001c\u0082\u0001\u0001\u001d\u00a8\u0006\u001e\u00c0\u0006\u0003"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "Landroidx/compose/ui/unit/Density;",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCache;",
        "size",
        "Landroidx/compose/ui/geometry/Size;",
        "getSize-NH-jbRc",
        "()J",
        "layoutDirection",
        "Landroidx/compose/ui/unit/LayoutDirection;",
        "getLayoutDirection",
        "()Landroidx/compose/ui/unit/LayoutDirection;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "getShape",
        "()Landroidx/compose/ui/graphics/Shape;",
        "contentScale",
        "",
        "getContentScale",
        "()F",
        "padding",
        "getPadding",
        "setPadding",
        "(F)V",
        "renderEffect",
        "Landroidx/compose/ui/graphics/RenderEffect;",
        "getRenderEffect",
        "()Landroidx/compose/ui/graphics/RenderEffect;",
        "setRenderEffect",
        "(Landroidx/compose/ui/graphics/RenderEffect;)V",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic access$roundToPx--R2X_6o$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)I
    .locals 0

    .line 19
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->roundToPx--R2X_6o(J)I

    move-result p0

    return p0
.end method

.method public static synthetic access$roundToPx-0680j_4$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)I
    .locals 0

    .line 19
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->roundToPx-0680j_4(F)I

    move-result p0

    return p0
.end method

.method public static synthetic access$toDp-GaN1DYA$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)F
    .locals 0

    .line 19
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toDp-GaN1DYA(J)F

    move-result p0

    return p0
.end method

.method public static synthetic access$toDp-u2uoSUM$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)F
    .locals 0

    .line 19
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toDp-u2uoSUM(F)F

    move-result p0

    return p0
.end method

.method public static synthetic access$toDp-u2uoSUM$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;I)F
    .locals 0

    .line 19
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toDp-u2uoSUM(I)F

    move-result p0

    return p0
.end method

.method public static synthetic access$toDpSize-k-rfVVM$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)J
    .locals 0

    .line 19
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toDpSize-k-rfVVM(J)J

    move-result-wide p0

    return-wide p0
.end method

.method public static synthetic access$toPx--R2X_6o$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)F
    .locals 0

    .line 19
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx--R2X_6o(J)F

    move-result p0

    return p0
.end method

.method public static synthetic access$toPx-0680j_4$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)F
    .locals 0

    .line 19
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result p0

    return p0
.end method

.method public static synthetic access$toRect$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;Landroidx/compose/ui/unit/DpRect;)Landroidx/compose/ui/geometry/Rect;
    .locals 0

    .line 19
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toRect(Landroidx/compose/ui/unit/DpRect;)Landroidx/compose/ui/geometry/Rect;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic access$toSize-XkaWNTQ$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;J)J
    .locals 0

    .line 19
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toSize-XkaWNTQ(J)J

    move-result-wide p0

    return-wide p0
.end method

.method public static synthetic access$toSp-0xMU5do$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)J
    .locals 0

    .line 19
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toSp-0xMU5do(F)J

    move-result-wide p0

    return-wide p0
.end method

.method public static synthetic access$toSp-kPz2Gy4$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;F)J
    .locals 0

    .line 19
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toSp-kPz2Gy4(F)J

    move-result-wide p0

    return-wide p0
.end method

.method public static synthetic access$toSp-kPz2Gy4$jd(Ldev/nino/squareglass/backdrop/BackdropEffectScope;I)J
    .locals 0

    .line 19
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toSp-kPz2Gy4(I)J

    move-result-wide p0

    return-wide p0
.end method


# virtual methods
.method public abstract getContentScale()F
.end method

.method public abstract getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;
.end method

.method public abstract getPadding()F
.end method

.method public abstract getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;
.end method

.method public abstract getShape()Landroidx/compose/ui/graphics/Shape;
.end method

.method public abstract getSize-NH-jbRc()J
.end method

.method public abstract setPadding(F)V
.end method

.method public abstract setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V
.end method
