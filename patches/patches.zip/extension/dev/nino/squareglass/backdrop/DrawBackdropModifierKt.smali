.class public final Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;
.super Ljava/lang/Object;
.source "DrawBackdropModifier.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000r\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u001a\u00a4\u0002\u0010\u0012\u001a\u00020\u0013*\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u000c\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u00170\u00012\u0017\u0010\u0018\u001a\u0013\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\t0\u0008\u00a2\u0006\u0002\u0008\n2\u001b\u0008\u0002\u0010\u001a\u001a\u0015\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\t\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\n2\n\u0008\u0002\u0010\u001c\u001a\u0004\u0018\u00010\u001d2\u001b\u0008\u0002\u0010\u001e\u001a\u0015\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\n2?\u0008\u0002\u0010\u001f\u001a9\u0012\u0004\u0012\u00020\u0007\u0012$\u0012\"\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t0\u0008\u00a2\u0006\u0002\u0008\n\u00a2\u0006\u000c\u0008 \u0012\u0008\u0008!\u0012\u0004\u0008\u0008(\"\u0012\u0004\u0012\u00020\t0\u0006\u00a2\u0006\u0002\u0008\n2\u001b\u0008\u0002\u0010#\u001a\u0015\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\n2\u001b\u0008\u0002\u0010$\u001a\u0015\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\n2\u0008\u0008\u0002\u0010%\u001a\u00020\u000c2\u000e\u0008\u0002\u0010&\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u00012\u000e\u0008\u0002\u0010\'\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u0001\u001a\u00f2\u0002\u0010\"\u001a\u00020\u0013*\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u000c\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u00170\u00012\u0017\u0010\u0018\u001a\u0013\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\t0\u0008\u00a2\u0006\u0002\u0008\n2\u0012\u0008\u0002\u0010(\u001a\u000c\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0018\u00010\u00012\u0012\u0008\u0002\u0010)\u001a\u000c\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0018\u00010\u00012\u0012\u0008\u0002\u0010*\u001a\u000c\u0012\u0006\u0012\u0004\u0018\u00010+\u0018\u00010\u00012\u001b\u0008\u0002\u0010\u001a\u001a\u0015\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\t\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\n2\n\u0008\u0002\u0010\u001c\u001a\u0004\u0018\u00010\u001d2\u001b\u0008\u0002\u0010\u001e\u001a\u0015\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\n2?\u0008\u0002\u0010\u001f\u001a9\u0012\u0004\u0012\u00020\u0007\u0012$\u0012\"\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t0\u0008\u00a2\u0006\u0002\u0008\n\u00a2\u0006\u000c\u0008 \u0012\u0008\u0008!\u0012\u0004\u0008\u0008(\"\u0012\u0004\u0012\u00020\t0\u0006\u00a2\u0006\u0002\u0008\n2\u001b\u0008\u0002\u0010#\u001a\u0015\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\n2\u001b\u0008\u0002\u0010$\u001a\u0015\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t\u0018\u00010\u0008\u00a2\u0006\u0002\u0008\n2\u0008\u0008\u0002\u0010%\u001a\u00020\u000c2\u000e\u0008\u0002\u0010&\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u00012\u000e\u0008\u0002\u0010\'\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u00012\u0010\u0008\u0002\u0010,\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0001\"\u0014\u0010\u0000\u001a\u0008\u0012\u0004\u0012\u00020\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u0014\u0010\u0003\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"6\u0010\u0005\u001a*\u0012\u0004\u0012\u00020\u0007\u0012\u0015\u0012\u0013\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\t0\u0008\u00a2\u0006\u0002\u0008\n\u0012\u0004\u0012\u00020\t0\u0006\u00a2\u0006\u0002\u0008\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u000b\u001a\u00020\u000cX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\r\u001a\u00020\u000cX\u0082T\u00a2\u0006\u0002\n\u0000\"\u0014\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0010\u001a\u00020\u0011X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006-"
    }
    d2 = {
        "DefaultHighlight",
        "Lkotlin/Function0;",
        "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
        "DefaultShadow",
        "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
        "DefaultOnDrawBackdrop",
        "Lkotlin/Function2;",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "Lkotlin/Function1;",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "HandoverMillis",
        "",
        "HoldRefreshMillis",
        "NeverFrozen",
        "",
        "LoopPoolMaxSize",
        "",
        "drawPlainBackdrop",
        "Landroidx/compose/ui/Modifier;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "effects",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "layerBlock",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "exportedBackdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "onDrawBehind",
        "onDrawBackdrop",
        "Lkotlin/ParameterName;",
        "name",
        "drawBackdrop",
        "onDrawSurface",
        "onDrawFront",
        "backdropScale",
        "frozen",
        "heldWhileMoving",
        "highlight",
        "shadow",
        "innerShadow",
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
        "loopBucket",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final DefaultHighlight:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
            ">;"
        }
    .end annotation
.end field

.field private static final DefaultOnDrawBackdrop:Lam0/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private static final DefaultShadow:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
            ">;"
        }
    .end annotation
.end field

.field private static final HandoverMillis:F = 180.0f

.field private static final HoldRefreshMillis:F = 110.0f

.field private static final LoopPoolMaxSize:I = 0x40

.field private static final NeverFrozen:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$-KI5cJsR1wAojbCB0z8PM-pasl0()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultHighlight$lambda$0()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$iD1ZXwoTRm3Iy20dhKH75hmRGF8()Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultShadow$lambda$0()Ldev/nino/squareglass/backdrop/shadow/Shadow;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$uAvdOHgJDIgX1cW8o10CmI_9A8Q(Landroidx/compose/ui/graphics/drawscope/DrawScope;Lam0/l;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultOnDrawBackdrop$lambda$0(Landroidx/compose/ui/graphics/drawscope/DrawScope;Lam0/l;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vITDOWFm-tIbBeRCKxs7ohcUULY()Z
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->NeverFrozen$lambda$0()Z

    move-result v0

    return v0
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 56
    new-instance v0, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda0;-><init>()V

    sput-object v0, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultHighlight:Lam0/a;

    .line 57
    new-instance v0, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda1;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda1;-><init>()V

    sput-object v0, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultShadow:Lam0/a;

    .line 58
    new-instance v0, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda2;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda2;-><init>()V

    sput-object v0, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultOnDrawBackdrop:Lam0/p;

    .line 77
    new-instance v0, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda3;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda3;-><init>()V

    sput-object v0, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->NeverFrozen:Lam0/a;

    return-void
.end method

.method private static final DefaultHighlight$lambda$0()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    .line 56
    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Companion:Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;->getDefault()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method private static final DefaultOnDrawBackdrop$lambda$0(Landroidx/compose/ui/graphics/drawscope/DrawScope;Lam0/l;)Lkotlin/u;
    .locals 1

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "it"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    invoke-interface {p1, p0}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final DefaultShadow$lambda$0()Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 1

    .line 57
    sget-object v0, Ldev/nino/squareglass/backdrop/shadow/Shadow;->Companion:Ldev/nino/squareglass/backdrop/shadow/Shadow$Companion;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/Shadow$Companion;->getDefault()Ldev/nino/squareglass/backdrop/shadow/Shadow;

    move-result-object v0

    return-object v0
.end method

.method private static final NeverFrozen$lambda$0()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public static final drawBackdrop(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)Landroidx/compose/ui/Modifier;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "Landroidx/compose/ui/graphics/Shape;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/highlight/Highlight;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/Shadow;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;",
            "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;F",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;)",
            "Landroidx/compose/ui/Modifier;"
        }
    .end annotation

    move-object/from16 v0, p2

    move-object/from16 v1, p4

    move-object/from16 v2, p5

    move-object/from16 v3, p6

    move-object/from16 v4, p7

    const-string v5, "<this>"

    invoke-static {p0, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "backdrop"

    invoke-static {p1, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "shape"

    invoke-static {v0, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "effects"

    move-object/from16 v7, p3

    invoke-static {v7, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "onDrawBackdrop"

    move-object/from16 v8, p10

    invoke-static {v8, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "frozen"

    move-object/from16 v11, p14

    invoke-static {v11, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "heldWhileMoving"

    move-object/from16 v12, p15

    invoke-static {v12, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 177
    new-instance v5, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-direct {v5, v0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;-><init>(Lam0/a;)V

    if-eqz v4, :cond_0

    .line 181
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-static {v0, v4}, Landroidx/compose/ui/graphics/GraphicsLayerModifierKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lam0/l;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    goto :goto_0

    .line 183
    :cond_0
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 179
    :goto_0
    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    if-eqz v3, :cond_1

    .line 188
    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;

    invoke-direct {v0, v5, v3}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowElement;-><init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V

    check-cast v0, Landroidx/compose/ui/Modifier;

    goto :goto_1

    .line 193
    :cond_1
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 186
    :goto_1
    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    if-eqz v2, :cond_2

    .line 198
    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/ShadowElement;

    invoke-direct {v0, v5, v2}, Ldev/nino/squareglass/backdrop/shadow/ShadowElement;-><init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V

    check-cast v0, Landroidx/compose/ui/Modifier;

    goto :goto_2

    .line 203
    :cond_2
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 196
    :goto_2
    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    if-eqz v1, :cond_3

    .line 208
    new-instance v0, Ldev/nino/squareglass/backdrop/highlight/HighlightElement;

    invoke-direct {v0, v5, v1}, Ldev/nino/squareglass/backdrop/highlight/HighlightElement;-><init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V

    check-cast v0, Landroidx/compose/ui/Modifier;

    goto :goto_3

    .line 213
    :cond_3
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 206
    :goto_3
    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    .line 217
    new-instance v0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;

    const v1, 0x3d4ccccd    # 0.05f

    const/high16 v2, 0x3f800000    # 1.0f

    move/from16 v3, p13

    .line 227
    invoke-static {v3, v1, v2}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result v10

    move-object v1, p1

    move-object/from16 v6, p9

    move-object/from16 v9, p12

    move-object/from16 v13, p16

    move-object v2, v5

    move-object v3, v7

    move-object v7, v8

    move-object/from16 v5, p8

    move-object/from16 v8, p11

    .line 217
    invoke-direct/range {v0 .. v13}, Ldev/nino/squareglass/backdrop/DrawBackdropElement;-><init>(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)V

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 216
    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic drawBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;
    .locals 19

    move/from16 v0, p17

    and-int/lit8 v1, v0, 0x8

    if-eqz v1, :cond_0

    .line 141
    sget-object v1, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultHighlight:Lam0/a;

    move-object v6, v1

    goto :goto_0

    :cond_0
    move-object/from16 v6, p4

    :goto_0
    and-int/lit8 v1, v0, 0x10

    if-eqz v1, :cond_1

    .line 142
    sget-object v1, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultShadow:Lam0/a;

    move-object v7, v1

    goto :goto_1

    :cond_1
    move-object/from16 v7, p5

    :goto_1
    and-int/lit8 v1, v0, 0x20

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    move-object v8, v2

    goto :goto_2

    :cond_2
    move-object/from16 v8, p6

    :goto_2
    and-int/lit8 v1, v0, 0x40

    if-eqz v1, :cond_3

    move-object v9, v2

    goto :goto_3

    :cond_3
    move-object/from16 v9, p7

    :goto_3
    and-int/lit16 v1, v0, 0x80

    if-eqz v1, :cond_4

    move-object v10, v2

    goto :goto_4

    :cond_4
    move-object/from16 v10, p8

    :goto_4
    and-int/lit16 v1, v0, 0x100

    if-eqz v1, :cond_5

    move-object v11, v2

    goto :goto_5

    :cond_5
    move-object/from16 v11, p9

    :goto_5
    and-int/lit16 v1, v0, 0x200

    if-eqz v1, :cond_6

    .line 147
    sget-object v1, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultOnDrawBackdrop:Lam0/p;

    move-object v12, v1

    goto :goto_6

    :cond_6
    move-object/from16 v12, p10

    :goto_6
    and-int/lit16 v1, v0, 0x400

    if-eqz v1, :cond_7

    move-object v13, v2

    goto :goto_7

    :cond_7
    move-object/from16 v13, p11

    :goto_7
    and-int/lit16 v1, v0, 0x800

    if-eqz v1, :cond_8

    move-object v14, v2

    goto :goto_8

    :cond_8
    move-object/from16 v14, p12

    :goto_8
    and-int/lit16 v1, v0, 0x1000

    if-eqz v1, :cond_9

    const/high16 v1, 0x3f800000    # 1.0f

    move v15, v1

    goto :goto_9

    :cond_9
    move/from16 v15, p13

    :goto_9
    and-int/lit16 v1, v0, 0x2000

    if-eqz v1, :cond_a

    .line 164
    sget-object v1, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->NeverFrozen:Lam0/a;

    move-object/from16 v16, v1

    goto :goto_a

    :cond_a
    move-object/from16 v16, p14

    :goto_a
    and-int/lit16 v1, v0, 0x4000

    if-eqz v1, :cond_b

    .line 166
    sget-object v1, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->NeverFrozen:Lam0/a;

    move-object/from16 v17, v1

    goto :goto_b

    :cond_b
    move-object/from16 v17, p15

    :goto_b
    const v1, 0x8000

    and-int/2addr v0, v1

    if-eqz v0, :cond_c

    move-object/from16 v18, v2

    move-object/from16 v3, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    move-object/from16 v2, p0

    goto :goto_c

    :cond_c
    move-object/from16 v18, p16

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    .line 137
    :goto_c
    invoke-static/range {v2 .. v18}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->drawBackdrop(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    return-object v0
.end method

.method public static final drawPlainBackdrop(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;)Landroidx/compose/ui/Modifier;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            "Lkotlin/jvm/functions/Function0<",
            "+",
            "Landroidx/compose/ui/graphics/Shape;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;",
            "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;F",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)",
            "Landroidx/compose/ui/Modifier;"
        }
    .end annotation

    move-object/from16 v0, p2

    move-object/from16 v4, p4

    const-string v1, "<this>"

    invoke-static {p0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "backdrop"

    invoke-static {p1, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "shape"

    invoke-static {v0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "effects"

    move-object/from16 v3, p3

    invoke-static {v3, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "onDrawBackdrop"

    move-object/from16 v7, p7

    invoke-static {v7, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "frozen"

    move-object/from16 v11, p11

    invoke-static {v11, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "heldWhileMoving"

    move-object/from16 v12, p12

    invoke-static {v12, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    new-instance v2, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-direct {v2, v0}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;-><init>(Lam0/a;)V

    if-eqz v4, :cond_0

    .line 113
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-static {v0, v4}, Landroidx/compose/ui/graphics/GraphicsLayerModifierKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lam0/l;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    goto :goto_0

    .line 115
    :cond_0
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 111
    :goto_0
    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    .line 119
    new-instance v0, Ldev/nino/squareglass/backdrop/DrawBackdropElement;

    const v1, 0x3d4ccccd    # 0.05f

    const/high16 v5, 0x3f800000    # 1.0f

    move/from16 v6, p10

    .line 129
    invoke-static {v6, v1, v5}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result v10

    const/4 v13, 0x0

    move-object v1, p1

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v8, p8

    move-object/from16 v9, p9

    .line 119
    invoke-direct/range {v0 .. v13}, Ldev/nino/squareglass/backdrop/DrawBackdropElement;-><init>(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;)V

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 118
    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic drawPlainBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;
    .locals 1

    and-int/lit8 p14, p13, 0x8

    const/4 v0, 0x0

    if-eqz p14, :cond_0

    move-object p4, v0

    :cond_0
    and-int/lit8 p14, p13, 0x10

    if-eqz p14, :cond_1

    move-object p5, v0

    :cond_1
    and-int/lit8 p14, p13, 0x20

    if-eqz p14, :cond_2

    move-object p6, v0

    :cond_2
    and-int/lit8 p14, p13, 0x40

    if-eqz p14, :cond_3

    .line 89
    sget-object p7, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->DefaultOnDrawBackdrop:Lam0/p;

    :cond_3
    and-int/lit16 p14, p13, 0x80

    if-eqz p14, :cond_4

    move-object p8, v0

    :cond_4
    and-int/lit16 p14, p13, 0x100

    if-eqz p14, :cond_5

    move-object p9, v0

    :cond_5
    and-int/lit16 p14, p13, 0x200

    if-eqz p14, :cond_6

    const/high16 p10, 0x3f800000    # 1.0f

    :cond_6
    and-int/lit16 p14, p13, 0x400

    if-eqz p14, :cond_7

    .line 106
    sget-object p11, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->NeverFrozen:Lam0/a;

    :cond_7
    and-int/lit16 p13, p13, 0x800

    if-eqz p13, :cond_8

    .line 107
    sget-object p12, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->NeverFrozen:Lam0/a;

    .line 82
    :cond_8
    invoke-static/range {p0 .. p12}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->drawPlainBackdrop(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method
