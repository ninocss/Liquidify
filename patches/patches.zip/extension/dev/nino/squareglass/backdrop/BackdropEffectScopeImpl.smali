.class public abstract Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;
.super Ljava/lang/Object;
.source "BackdropEffectScope.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/BackdropEffectScope;
.implements Ldev/nino/squareglass/backdrop/RuntimeShaderCache;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u000b\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008!\u0018\u00002\u00020\u00012\u00020\u0002B\u0007\u00a2\u0006\u0004\u0008\u0003\u0010\u0004J\u0018\u0010)\u001a\u00020*2\u0006\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020,H\u0016J\u0018\u0010.\u001a\u00020/2\u0006\u00100\u001a\u0002012\u0008\u0008\u0002\u0010\u001e\u001a\u00020\u0006J\u001f\u00102\u001a\u0002032\u0017\u00104\u001a\u0013\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020305\u00a2\u0006\u0002\u00086J\u0006\u00107\u001a\u000203R\u001a\u0010\u0005\u001a\u00020\u0006X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008\"\u0004\u0008\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u0006X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000c\u0010\u0008\"\u0004\u0008\r\u0010\nR\u001c\u0010\u000e\u001a\u00020\u000fX\u0096\u000e\u00a2\u0006\u0010\n\u0002\u0010\u0014\u001a\u0004\u0008\u0010\u0010\u0011\"\u0004\u0008\u0012\u0010\u0013R\u001a\u0010\u0015\u001a\u00020\u0016X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0017\u0010\u0018\"\u0004\u0008\u0019\u0010\u001aR\u001a\u0010\u001b\u001a\u00020\u0006X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001c\u0010\u0008\"\u0004\u0008\u001d\u0010\nR\u001a\u0010\u001e\u001a\u00020\u0006X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001f\u0010\u0008\"\u0004\u0008 \u0010\nR\u001c\u0010!\u001a\u0004\u0018\u00010\"X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008#\u0010$\"\u0004\u0008%\u0010&R\u000e\u0010\'\u001a\u00020(X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u00068"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;",
        "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCache;",
        "<init>",
        "()V",
        "density",
        "",
        "getDensity",
        "()F",
        "setDensity",
        "(F)V",
        "fontScale",
        "getFontScale",
        "setFontScale",
        "size",
        "Landroidx/compose/ui/geometry/Size;",
        "getSize-NH-jbRc",
        "()J",
        "setSize-uvyYCjk",
        "(J)V",
        "J",
        "layoutDirection",
        "Landroidx/compose/ui/unit/LayoutDirection;",
        "getLayoutDirection",
        "()Landroidx/compose/ui/unit/LayoutDirection;",
        "setLayoutDirection",
        "(Landroidx/compose/ui/unit/LayoutDirection;)V",
        "padding",
        "getPadding",
        "setPadding",
        "contentScale",
        "getContentScale",
        "setContentScale",
        "renderEffect",
        "Landroidx/compose/ui/graphics/RenderEffect;",
        "getRenderEffect",
        "()Landroidx/compose/ui/graphics/RenderEffect;",
        "setRenderEffect",
        "(Landroidx/compose/ui/graphics/RenderEffect;)V",
        "runtimeShaderCache",
        "Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;",
        "obtainRuntimeShader",
        "Ldev/nino/squareglass/backdrop/RuntimeShader;",
        "key",
        "",
        "string",
        "update",
        "",
        "scope",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "apply",
        "",
        "effects",
        "Lkotlin/Function1;",
        "Lkotlin/ExtensionFunctionType;",
        "reset",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private contentScale:F

.field private density:F

.field private fontScale:F

.field private layoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

.field private padding:F

.field private renderEffect:Landroidx/compose/ui/graphics/RenderEffect;

.field private final runtimeShaderCache:Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

.field private size:J


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 43
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, 0x3f800000    # 1.0f

    .line 45
    iput v0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->density:F

    .line 46
    iput v0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->fontScale:F

    .line 47
    sget-object v1, Landroidx/compose/ui/geometry/Size;->Companion:Landroidx/compose/ui/geometry/Size$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/geometry/Size$Companion;->getUnspecified-NH-jbRc()J

    move-result-wide v1

    iput-wide v1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->size:J

    .line 48
    sget-object v1, Landroidx/compose/ui/unit/LayoutDirection;->Ltr:Landroidx/compose/ui/unit/LayoutDirection;

    iput-object v1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->layoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

    .line 50
    iput v0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->contentScale:F

    .line 53
    new-instance v0, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->runtimeShaderCache:Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

    return-void
.end method

.method public static synthetic update$default(Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;Landroidx/compose/ui/graphics/drawscope/DrawScope;FILjava/lang/Object;)Z
    .locals 0

    if-nez p4, :cond_1

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const/high16 p2, 0x3f800000    # 1.0f

    .line 62
    :cond_0
    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->update(Landroidx/compose/ui/graphics/drawscope/DrawScope;F)Z

    move-result p0

    return p0

    :cond_1
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Super calls with default arguments not supported in this target, function: update"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final apply(Lam0/l;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/backdrop/BackdropEffectScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "effects"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    .line 86
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setPadding(F)V

    const/4 v0, 0x0

    .line 87
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    .line 88
    invoke-interface {p1, p0}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public getContentScale()F
    .locals 0

    .line 50
    iget p0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->contentScale:F

    return p0
.end method

.method public getDensity()F
    .locals 0

    .line 45
    iget p0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->density:F

    return p0
.end method

.method public getFontScale()F
    .locals 0

    .line 46
    iget p0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->fontScale:F

    return p0
.end method

.method public getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;
    .locals 0

    .line 48
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->layoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

    return-object p0
.end method

.method public getPadding()F
    .locals 0

    .line 49
    iget p0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->padding:F

    return p0
.end method

.method public getRenderEffect()Landroidx/compose/ui/graphics/RenderEffect;
    .locals 0

    .line 51
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->renderEffect:Landroidx/compose/ui/graphics/RenderEffect;

    return-object p0
.end method

.method public getSize-NH-jbRc()J
    .locals 2

    .line 47
    iget-wide v0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->size:J

    return-wide v0
.end method

.method public obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;
    .locals 1

    const-string v0, "key"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "string"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->runtimeShaderCache:Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;->obtainRuntimeShader(Ljava/lang/String;Ljava/lang/String;)Ldev/nino/squareglass/backdrop/RuntimeShader;

    move-result-object p0

    return-object p0
.end method

.method public final reset()V
    .locals 2

    const/high16 v0, 0x3f800000    # 1.0f

    .line 92
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setDensity(F)V

    .line 93
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setFontScale(F)V

    .line 94
    sget-object v0, Landroidx/compose/ui/geometry/Size;->Companion:Landroidx/compose/ui/geometry/Size$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Size$Companion;->getUnspecified-NH-jbRc()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setSize-uvyYCjk(J)V

    .line 95
    sget-object v0, Landroidx/compose/ui/unit/LayoutDirection;->Ltr:Landroidx/compose/ui/unit/LayoutDirection;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setLayoutDirection(Landroidx/compose/ui/unit/LayoutDirection;)V

    const/4 v0, 0x0

    .line 96
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setPadding(F)V

    const/4 v0, 0x0

    .line 97
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    .line 98
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->runtimeShaderCache:Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/RuntimeShaderCacheImpl;->clear()V

    return-void
.end method

.method public bridge roundToPx--R2X_6o(J)I
    .locals 0

    .line 43
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->roundToPx--R2X_6o(J)I

    move-result p0

    return p0
.end method

.method public bridge roundToPx-0680j_4(F)I
    .locals 0

    .line 43
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->roundToPx-0680j_4(F)I

    move-result p0

    return p0
.end method

.method public setContentScale(F)V
    .locals 0

    .line 50
    iput p1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->contentScale:F

    return-void
.end method

.method public setDensity(F)V
    .locals 0

    .line 45
    iput p1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->density:F

    return-void
.end method

.method public setFontScale(F)V
    .locals 0

    .line 46
    iput p1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->fontScale:F

    return-void
.end method

.method public setLayoutDirection(Landroidx/compose/ui/unit/LayoutDirection;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->layoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

    return-void
.end method

.method public setPadding(F)V
    .locals 0

    .line 49
    iput p1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->padding:F

    return-void
.end method

.method public setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V
    .locals 0

    .line 51
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->renderEffect:Landroidx/compose/ui/graphics/RenderEffect;

    return-void
.end method

.method public setSize-uvyYCjk(J)V
    .locals 0

    .line 47
    iput-wide p1, p0, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->size:J

    return-void
.end method

.method public bridge toDp-GaN1DYA(J)F
    .locals 0

    .line 43
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toDp-GaN1DYA(J)F

    move-result p0

    return p0
.end method

.method public bridge toDp-u2uoSUM(F)F
    .locals 0

    .line 43
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toDp-u2uoSUM(F)F

    move-result p0

    return p0
.end method

.method public bridge toDp-u2uoSUM(I)F
    .locals 0

    .line 43
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toDp-u2uoSUM(I)F

    move-result p0

    return p0
.end method

.method public bridge toDpSize-k-rfVVM(J)J
    .locals 0

    .line 43
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toDpSize-k-rfVVM(J)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge toPx--R2X_6o(J)F
    .locals 0

    .line 43
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx--R2X_6o(J)F

    move-result p0

    return p0
.end method

.method public bridge toPx-0680j_4(F)F
    .locals 0

    .line 43
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result p0

    return p0
.end method

.method public bridge toRect(Landroidx/compose/ui/unit/DpRect;)Landroidx/compose/ui/geometry/Rect;
    .locals 0

    .line 43
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toRect(Landroidx/compose/ui/unit/DpRect;)Landroidx/compose/ui/geometry/Rect;

    move-result-object p0

    return-object p0
.end method

.method public bridge toSize-XkaWNTQ(J)J
    .locals 0

    .line 43
    invoke-super {p0, p1, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toSize-XkaWNTQ(J)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge toSp-0xMU5do(F)J
    .locals 0

    .line 43
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toSp-0xMU5do(F)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge toSp-kPz2Gy4(F)J
    .locals 0

    .line 43
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toSp-kPz2Gy4(F)J

    move-result-wide p0

    return-wide p0
.end method

.method public bridge toSp-kPz2Gy4(I)J
    .locals 0

    .line 43
    invoke-super {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toSp-kPz2Gy4(I)J

    move-result-wide p0

    return-wide p0
.end method

.method public final update(Landroidx/compose/ui/graphics/drawscope/DrawScope;F)Z
    .locals 6

    const-string v0, "scope"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDensity()F

    move-result v0

    .line 64
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getFontScale()F

    move-result v1

    const/high16 v2, 0x3f800000    # 1.0f

    cmpg-float v2, p2, v2

    if-nez v2, :cond_0

    .line 65
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    goto :goto_0

    :cond_0
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    invoke-static {v2, v3, p2}, Landroidx/compose/ui/geometry/Size;->times-7Ah8Wj8(JF)J

    move-result-wide v2

    .line 66
    :goto_0
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    move-result-object p1

    .line 68
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->getDensity()F

    move-result v4

    cmpg-float v4, v0, v4

    if-nez v4, :cond_1

    .line 69
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->getFontScale()F

    move-result v4

    cmpg-float v4, v1, v4

    if-nez v4, :cond_1

    .line 70
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->getSize-NH-jbRc()J

    move-result-wide v4

    invoke-static {v2, v3, v4, v5}, Landroidx/compose/ui/geometry/Size;->equals-impl0(JJ)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 71
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    move-result-object v4

    if-ne p1, v4, :cond_1

    .line 72
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->getContentScale()F

    move-result v4

    cmpg-float v4, p2, v4

    if-nez v4, :cond_1

    const/4 v4, 0x0

    goto :goto_1

    :cond_1
    const/4 v4, 0x1

    :goto_1
    if-eqz v4, :cond_2

    .line 75
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setDensity(F)V

    .line 76
    invoke-virtual {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setFontScale(F)V

    .line 77
    invoke-virtual {p0, v2, v3}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setSize-uvyYCjk(J)V

    .line 78
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setLayoutDirection(Landroidx/compose/ui/unit/LayoutDirection;)V

    .line 79
    invoke-virtual {p0, p2}, Ldev/nino/squareglass/backdrop/BackdropEffectScopeImpl;->setContentScale(F)V

    :cond_2
    return v4
.end method
