.class public final synthetic Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    check-cast p2, Lam0/l;

    invoke-static {p1, p2}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->$r8$lambda$uAvdOHgJDIgX1cW8o10CmI_9A8Q(Landroidx/compose/ui/graphics/drawscope/DrawScope;Lam0/l;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
