.class public final Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;
.super Landroidx/compose/ui/Modifier$Node;
.source "InnerShadowModifier.kt"

# interfaces
.implements Landroidx/compose/ui/node/DrawModifierNode;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInnerShadowModifier.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InnerShadowModifier.kt\ndev/nino/squareglass/backdrop/shadow/InnerShadowNode\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,168:1\n1#2:169\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u000b\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\u0008\u0001\u0018\u00002\u00020\u00012\u00020\u0002B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u000e\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u000c\u0010\u001e\u001a\u00020\u001f*\u00020 H\u0016J\u0008\u0010!\u001a\u00020\u001fH\u0016J\u0008\u0010\"\u001a\u00020\u001fH\u0016J\u0014\u0010#\u001a\u00020\u001f*\u00020$2\u0006\u0010\u0005\u001a\u00020\u0007H\u0002R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\n\u0010\u000b\"\u0004\u0008\u000c\u0010\rR\"\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000e\u0010\u000f\"\u0004\u0008\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\u0013X\u0096D\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u001bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006%"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;",
        "Landroidx/compose/ui/node/DrawModifierNode;",
        "Landroidx/compose/ui/Modifier$Node;",
        "shapeProvider",
        "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "shadow",
        "Lkotlin/Function0;",
        "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V",
        "getShapeProvider",
        "()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
        "setShapeProvider",
        "(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V",
        "getShadow",
        "()Lam0/a;",
        "setShadow",
        "(Lam0/a;)V",
        "shouldAutoInvalidate",
        "",
        "getShouldAutoInvalidate",
        "()Z",
        "shadowLayer",
        "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
        "paint",
        "Landroidx/compose/ui/graphics/Paint;",
        "clipPath",
        "Landroidx/compose/ui/graphics/Path;",
        "prevRadius",
        "",
        "draw",
        "",
        "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
        "onAttach",
        "onDetach",
        "configurePaint",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private clipPath:Landroidx/compose/ui/graphics/Path;

.field private final paint:Landroidx/compose/ui/graphics/Paint;

.field private prevRadius:F

.field private shadow:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
            ">;"
        }
    .end annotation
.end field

.field private shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

.field private shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

.field private final shouldAutoInvalidate:Z


# direct methods
.method public static synthetic $r8$lambda$P1keyQrSmC2DCp6-APRcsKNXqKM(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;FFLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static/range {p0 .. p5}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->draw$lambda$1(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;FFLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/internal/ShapeProvider;",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
            ">;)V"
        }
    .end annotation

    const-string v0, "shapeProvider"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shadow"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    invoke-direct {p0}, Landroidx/compose/ui/Modifier$Node;-><init>()V

    .line 74
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    .line 75
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shadow:Lam0/a;

    .line 82
    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPaint_androidKt;->Paint()Landroidx/compose/ui/graphics/Paint;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->paint:Landroidx/compose/ui/graphics/Paint;

    const/high16 p1, 0x7fc00000    # Float.NaN

    .line 85
    iput p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->prevRadius:F

    return-void
.end method

.method private final configurePaint(Landroidx/compose/ui/graphics/drawscope/DrawScope;Ldev/nino/squareglass/backdrop/shadow/InnerShadow;)V
    .locals 0

    .line 161
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-virtual {p2}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getColor-0d7_KjU()J

    move-result-wide p1

    invoke-interface {p0, p1, p2}, Landroidx/compose/ui/graphics/Paint;->setColor-8_81llA(J)V

    return-void
.end method

.method private static final draw$lambda$1(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;FFLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 1

    const-string v0, "$this$record"

    invoke-static {p5, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 126
    invoke-interface {p5}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p5

    invoke-interface {p5}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p5

    .line 127
    invoke-interface {p5}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 128
    invoke-static {p5, p0, p1}, Ldev/nino/squareglass/backdrop/internal/OutlineKt;->clipOutline(Landroidx/compose/ui/graphics/Canvas;Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;)V

    .line 129
    iget-object p1, p2, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->paint:Landroidx/compose/ui/graphics/Paint;

    invoke-static {p5, p0, p1}, Landroidx/compose/ui/graphics/OutlineKt;->drawOutline(Landroidx/compose/ui/graphics/Canvas;Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Paint;)V

    .line 130
    invoke-interface {p5, p3, p4}, Landroidx/compose/ui/graphics/Canvas;->translate(FF)V

    .line 131
    invoke-static {}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowModifierKt;->access$getShadowMaskPaint$p()Landroidx/compose/ui/graphics/Paint;

    move-result-object p1

    invoke-static {p5, p0, p1}, Landroidx/compose/ui/graphics/OutlineKt;->drawOutline(Landroidx/compose/ui/graphics/Canvas;Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Paint;)V

    neg-float p0, p3

    neg-float p1, p4

    .line 132
    invoke-interface {p5, p0, p1}, Landroidx/compose/ui/graphics/Canvas;->translate(FF)V

    .line 133
    invoke-interface {p5}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 134
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public draw(Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V
    .locals 14

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    .line 90
    invoke-static {}, Ldev/nino/squareglass/backdrop/PlatformKt;->isRenderEffectSupported()Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_2

    .line 92
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shadow:Lam0/a;

    invoke-interface {v0}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;

    if-nez v0, :cond_1

    goto/16 :goto_2

    .line 94
    :cond_1
    iget-object v2, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v2, :cond_6

    .line 96
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getSize-NH-jbRc()J

    move-result-wide v3

    .line 97
    move-object v1, p1

    check-cast v1, Landroidx/compose/ui/unit/Density;

    .line 98
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    move-result-object v5

    .line 100
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getRadius-D9Ej5fM()F

    move-result v6

    invoke-interface {p1, v6}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->toPx-0680j_4(F)F

    move-result v6

    .line 101
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getOffset-RKDOV3M()J

    move-result-wide v7

    invoke-static {v7, v8}, Landroidx/compose/ui/unit/DpOffset;->getX-D9Ej5fM(J)F

    move-result v7

    invoke-interface {p1, v7}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->toPx-0680j_4(F)F

    move-result v12

    .line 102
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getOffset-RKDOV3M()J

    move-result-wide v7

    invoke-static {v7, v8}, Landroidx/compose/ui/unit/DpOffset;->getY-D9Ej5fM(J)F

    move-result v7

    invoke-interface {p1, v7}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->toPx-0680j_4(F)F

    move-result v13

    .line 104
    iget-object v7, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    invoke-virtual {v7}, Ldev/nino/squareglass/backdrop/internal/ShapeProvider;->getShape()Landroidx/compose/ui/graphics/Shape;

    move-result-object v7

    invoke-interface {v7, v3, v4, v5, v1}, Landroidx/compose/ui/graphics/Shape;->createOutline-Pq9zytI(JLandroidx/compose/ui/unit/LayoutDirection;Landroidx/compose/ui/unit/Density;)Landroidx/compose/ui/graphics/Outline;

    move-result-object v9

    .line 106
    instance-of v1, v9, Landroidx/compose/ui/graphics/Outline$Rounded;

    const/4 v3, 0x0

    if-eqz v1, :cond_3

    .line 107
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->clipPath:Landroidx/compose/ui/graphics/Path;

    if-nez v1, :cond_2

    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPath_androidKt;->Path()Landroidx/compose/ui/graphics/Path;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->clipPath:Landroidx/compose/ui/graphics/Path;

    :cond_2
    move-object v10, v1

    goto :goto_0

    :cond_3
    move-object v10, v3

    .line 112
    :goto_0
    move-object v1, p1

    check-cast v1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-direct {p0, v1, v0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->configurePaint(Landroidx/compose/ui/graphics/drawscope/DrawScope;Ldev/nino/squareglass/backdrop/shadow/InnerShadow;)V

    .line 114
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getAlpha()F

    move-result v4

    invoke-virtual {v2, v4}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setAlpha(F)V

    .line 115
    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/shadow/InnerShadow;->getBlendMode-0nO6VwU()I

    move-result v0

    invoke-virtual {v2, v0}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setBlendMode-s9anfk8(I)V

    .line 116
    iget v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->prevRadius:F

    cmpg-float v0, v0, v6

    if-nez v0, :cond_4

    goto :goto_1

    :cond_4
    const/4 v0, 0x0

    cmpl-float v0, v6, v0

    if-lez v0, :cond_5

    .line 119
    sget-object v0, Landroidx/compose/ui/graphics/TileMode;->Companion:Landroidx/compose/ui/graphics/TileMode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/TileMode$Companion;->getDecal-3opZhB0()I

    move-result v0

    invoke-static {v6, v6, v0}, Landroidx/compose/ui/graphics/RenderEffectKt;->BlurEffect-3YTHUZs(FFI)Landroidx/compose/ui/graphics/BlurEffect;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Landroidx/compose/ui/graphics/RenderEffect;

    .line 117
    :cond_5
    invoke-virtual {v2, v3}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setRenderEffect(Landroidx/compose/ui/graphics/RenderEffect;)V

    .line 123
    iput v6, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->prevRadius:F

    .line 125
    :goto_1
    new-instance v5, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$$ExternalSyntheticLambda0;

    move-object v11, p0

    move-object v8, v5

    invoke-direct/range {v8 .. v13}, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;FF)V

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-wide/16 v3, 0x0

    invoke-static/range {v1 .. v7}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->record-JVtK1S4$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;JLam0/l;ILjava/lang/Object;)V

    .line 136
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p0

    .line 137
    invoke-interface {p0}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 138
    invoke-static {p0, v9, v10}, Ldev/nino/squareglass/backdrop/internal/OutlineKt;->clipOutline(Landroidx/compose/ui/graphics/Canvas;Landroidx/compose/ui/graphics/Outline;Landroidx/compose/ui/graphics/Path;)V

    .line 139
    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    .line 140
    invoke-interface {p0}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    :cond_6
    :goto_2
    return-void
.end method

.method public final getShadow()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
            ">;"
        }
    .end annotation

    .line 75
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shadow:Lam0/a;

    return-object p0
.end method

.method public final getShapeProvider()Ldev/nino/squareglass/backdrop/internal/ShapeProvider;
    .locals 0

    .line 74
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-object p0
.end method

.method public getShouldAutoInvalidate()Z
    .locals 0

    .line 78
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shouldAutoInvalidate:Z

    return p0
.end method

.method public onAttach()V
    .locals 2

    .line 145
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    .line 147
    invoke-interface {v0}, Landroidx/compose/ui/graphics/GraphicsContext;->createGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object v0

    .line 148
    sget-object v1, Landroidx/compose/ui/graphics/layer/CompositingStrategy;->Companion:Landroidx/compose/ui/graphics/layer/CompositingStrategy$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/layer/CompositingStrategy$Companion;->getOffscreen-ke2Ky5w()I

    move-result v1

    invoke-virtual {v0, v1}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->setCompositingStrategy-Wpw9cng(I)V

    .line 146
    iput-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    return-void
.end method

.method public onDetach()V
    .locals 2

    .line 153
    move-object v0, p0

    check-cast v0, Landroidx/compose/ui/node/DelegatableNode;

    invoke-static {v0}, Landroidx/compose/ui/node/DelegatableNodeKt;->requireGraphicsContext(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/graphics/GraphicsContext;

    move-result-object v0

    .line 154
    iget-object v1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    if-eqz v1, :cond_0

    .line 155
    invoke-interface {v0, v1}, Landroidx/compose/ui/graphics/GraphicsContext;->releaseGraphicsLayer(Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    const/4 v0, 0x0

    .line 156
    iput-object v0, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shadowLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    :cond_0
    return-void
.end method

.method public bridge onMeasureResultChanged()V
    .locals 0

    .line 73
    invoke-super {p0}, Landroidx/compose/ui/node/DrawModifierNode;->onMeasureResultChanged()V

    return-void
.end method

.method public final setShadow(Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ldev/nino/squareglass/backdrop/shadow/InnerShadow;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shadow:Lam0/a;

    return-void
.end method

.method public final setShapeProvider(Ldev/nino/squareglass/backdrop/internal/ShapeProvider;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/shadow/InnerShadowNode;->shapeProvider:Ldev/nino/squareglass/backdrop/internal/ShapeProvider;

    return-void
.end method
