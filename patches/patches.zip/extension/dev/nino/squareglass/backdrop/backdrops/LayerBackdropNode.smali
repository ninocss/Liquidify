.class final Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;
.super Landroidx/compose/ui/Modifier$Node;
.source "LayerBackdropModifier.kt"

# interfaces
.implements Landroidx/compose/ui/node/DrawModifierNode;
.implements Landroidx/compose/ui/node/GlobalPositionAwareModifierNode;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u000b\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0002\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003B\u001d\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0007\u00a2\u0006\u0004\u0008\t\u0010\nJ\u000c\u0010\u0013\u001a\u00020\u0014*\u00020\u0015H\u0016J\u0010\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0018H\u0016J\u0008\u0010\u0019\u001a\u00020\u0014H\u0016R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000b\u0010\u000c\"\u0004\u0008\r\u0010\u000eR \u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010\"\u0004\u0008\u0011\u0010\u0012\u00a8\u0006\u001a"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;",
        "Landroidx/compose/ui/node/DrawModifierNode;",
        "Landroidx/compose/ui/node/GlobalPositionAwareModifierNode;",
        "Landroidx/compose/ui/Modifier$Node;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "frozen",
        "Lkotlin/Function0;",
        "",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;)V",
        "getBackdrop",
        "()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "setBackdrop",
        "(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V",
        "getFrozen",
        "()Lam0/a;",
        "setFrozen",
        "(Lam0/a;)V",
        "draw",
        "",
        "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
        "onGloballyPositioned",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "onDetach",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

.field private frozen:Lam0/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "frozen"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    invoke-direct {p0}, Landroidx/compose/ui/Modifier$Node;-><init>()V

    .line 75
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    .line 76
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->frozen:Lam0/a;

    return-void
.end method

.method static final draw$lambda$0(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 1

    const-string v0, "$this$recordLayer"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getOnDraw$extension_debug()Lam0/l;

    move-result-object p0

    invoke-interface {p0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public draw(Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V
    .locals 8

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getStaticRegions$extension_debug()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 105
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->frozen:Lam0/a;

    invoke-interface {v0}, Lam0/a;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getHasRecording$extension_debug()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 106
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getOnDraw$extension_debug()Lam0/l;

    move-result-object p0

    invoke-interface {p0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 109
    :cond_0
    move-object v0, p1

    check-cast v0, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    move-object v1, p0

    check-cast v1, Landroidx/compose/ui/node/DelegatableNode;

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {v2}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object v2

    new-instance v5, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode$0;

    invoke-direct {v5, p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode$0;-><init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-wide/16 v3, 0x0

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/backdrop/internal/LayerRecorderKt;->recordLayer-TdoYBX4$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/node/DelegatableNode;Landroidx/compose/ui/graphics/layer/GraphicsLayer;JLam0/l;ILjava/lang/Object;)V

    .line 110
    iget-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    move-result-object p1

    invoke-static {v0, p1}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V

    .line 113
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->contentRecorded$extension_debug()V

    return-void
.end method

.method public final getBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;
    .locals 0

    .line 75
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-object p0
.end method

.method public final getFrozen()Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 76
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->frozen:Lam0/a;

    return-object p0
.end method

.method public onDetach()V
    .locals 1

    .line 123
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->setLayerCoordinates$extension_debug(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    return-void
.end method

.method public onGloballyPositioned(Landroidx/compose/ui/layout/LayoutCoordinates;)V
    .locals 1

    const-string v0, "coordinates"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 117
    invoke-interface {p1}, Landroidx/compose/ui/layout/LayoutCoordinates;->isAttached()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 118
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->setLayerCoordinates$extension_debug(Landroidx/compose/ui/layout/LayoutCoordinates;)V

    :cond_0
    return-void
.end method

.method public bridge onMeasureResultChanged()V
    .locals 0

    .line 74
    invoke-super {p0}, Landroidx/compose/ui/node/DrawModifierNode;->onMeasureResultChanged()V

    return-void
.end method

.method public final setBackdrop(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-void
.end method

.method public final setFrozen(Lam0/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropNode;->frozen:Lam0/a;

    return-void
.end method
