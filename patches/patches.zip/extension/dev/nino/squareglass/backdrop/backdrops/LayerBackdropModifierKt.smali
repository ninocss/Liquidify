.class public final Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropModifierKt;
.super Ljava/lang/Object;
.source "LayerBackdropModifier.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\u001a\"\u0010\u0000\u001a\u00020\u0001*\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u000e\u0008\u0002\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005\u00a8\u0006\u0007"
    }
    d2 = {
        "layerBackdrop",
        "Landroidx/compose/ui/Modifier;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "frozen",
        "Lkotlin/Function0;",
        "",
        "extension_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$-qPqMlH0Y2F6r-MhBOKP6fjzGgw()Z
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropModifierKt;->layerBackdrop$lambda$0()Z

    move-result v0

    return v0
.end method

.method public static final layerBackdrop(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;)Landroidx/compose/ui/Modifier;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)",
            "Landroidx/compose/ui/Modifier;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "frozen"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    new-instance v0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;

    invoke-direct {v0, p1, p2}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropElement;-><init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;)V

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-interface {p0, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic layerBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;
    .locals 0

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    .line 33
    new-instance p2, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropModifierKt$$ExternalSyntheticLambda0;

    invoke-direct {p2}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropModifierKt$$ExternalSyntheticLambda0;-><init>()V

    .line 31
    :cond_0
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropModifierKt;->layerBackdrop(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method

.method private static final layerBackdrop$lambda$0()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
