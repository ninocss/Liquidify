.class final Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;
.super Landroidx/compose/ui/Modifier$Node;
.source "BackdropStaticRegion.kt"

# interfaces
.implements Landroidx/compose/ui/node/DrawModifierNode;
.implements Landroidx/compose/ui/node/GlobalPositionAwareModifierNode;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nBackdropStaticRegion.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BackdropStaticRegion.kt\ndev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,93:1\n1#2:94\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0002\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003B\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000b\u001a\u00020\u000cH\u0016J\u000c\u0010\u000f\u001a\u00020\u000e*\u00020\u0010H\u0016J\u0008\u0010\u0011\u001a\u00020\u000eH\u0016R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0008\u0010\t\"\u0004\u0008\n\u0010\u0007R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\u000cX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0012"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;",
        "Landroidx/compose/ui/node/DrawModifierNode;",
        "Landroidx/compose/ui/node/GlobalPositionAwareModifierNode;",
        "Landroidx/compose/ui/Modifier$Node;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V",
        "getBackdrop",
        "()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "setBackdrop",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "onGloballyPositioned",
        "",
        "draw",
        "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
        "onDetach",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

.field private coordinates:Landroidx/compose/ui/layout/LayoutCoordinates;


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V
    .locals 1

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    invoke-direct {p0}, Landroidx/compose/ui/Modifier$Node;-><init>()V

    .line 65
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-void
.end method


# virtual methods
.method public draw(Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V
    .locals 8

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    iget-object v2, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->coordinates:Landroidx/compose/ui/layout/LayoutCoordinates;

    .line 76
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getLayerCoordinates$extension_debug()Landroidx/compose/ui/layout/LayoutCoordinates;

    move-result-object v1

    if-eqz v2, :cond_0

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-wide/16 v3, 0x0

    const/4 v5, 0x0

    .line 79
    :try_start_0
    invoke-static/range {v1 .. v7}, Landroidx/compose/ui/layout/LayoutCoordinates;->localPositionOf-S_NoaFU$default(Landroidx/compose/ui/layout/LayoutCoordinates;Landroidx/compose/ui/layout/LayoutCoordinates;JZILjava/lang/Object;)J

    move-result-wide v0

    .line 80
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getStaticRegions$extension_debug()Ljava/util/ArrayList;

    move-result-object p0

    invoke-interface {v2}, Landroidx/compose/ui/layout/LayoutCoordinates;->getSize-YbymL2g()J

    move-result-wide v2

    invoke-static {v2, v3}, Landroidx/compose/ui/unit/IntSizeKt;->toSize-ozmzZPI(J)J

    move-result-wide v2

    invoke-static {v0, v1, v2, v3}, Landroidx/compose/ui/geometry/RectKt;->Rect-tz77jQw(JJ)Landroidx/compose/ui/geometry/Rect;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 86
    :catch_0
    :cond_0
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    return-void
.end method

.method public final getBackdrop()Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;
    .locals 0

    .line 65
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-object p0
.end method

.method public onDetach()V
    .locals 1

    const/4 v0, 0x0

    .line 90
    iput-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->coordinates:Landroidx/compose/ui/layout/LayoutCoordinates;

    return-void
.end method

.method public onGloballyPositioned(Landroidx/compose/ui/layout/LayoutCoordinates;)V
    .locals 1

    const-string v0, "coordinates"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    invoke-interface {p1}, Landroidx/compose/ui/layout/LayoutCoordinates;->isAttached()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->coordinates:Landroidx/compose/ui/layout/LayoutCoordinates;

    return-void
.end method

.method public bridge onMeasureResultChanged()V
    .locals 0

    .line 64
    invoke-super {p0}, Landroidx/compose/ui/node/DrawModifierNode;->onMeasureResultChanged()V

    return-void
.end method

.method public final setBackdrop(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V
    .locals 1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/BackdropStaticRegionNode;->backdrop:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-void
.end method
