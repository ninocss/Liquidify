.class public final Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;
.super Ljava/lang/Object;
.source "LayerBackdrop.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/Backdrop;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLayerBackdrop.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LayerBackdrop.kt\ndev/nino/squareglass/backdrop/backdrops/LayerBackdrop\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n+ 5 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 6 Offset.kt\nandroidx/compose/ui/geometry/Offset\n+ 7 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 8 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,142:1\n85#2:143\n117#2,2:144\n1807#3,3:146\n249#4,8:149\n257#4,6:163\n1#5:157\n65#6:158\n69#6:161\n60#7:159\n70#7:162\n22#8:160\n*S KotlinDebug\n*F\n+ 1 LayerBackdrop.kt\ndev/nino/squareglass/backdrop/backdrops/LayerBackdrop\n*L\n52#1:143\n52#1:144,2\n100#1:146,3\n120#1:149,8\n120#1:163,6\n131#1:158\n131#1:161\n131#1:159\n131#1:162\n131#1:160\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000h\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u0008\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0007\u0018\u00002\u00020\u0001B*\u0008\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0017\u0010\u0004\u001a\u0013\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005\u00a2\u0006\u0002\u0008\u0008\u00a2\u0006\u0004\u0008\t\u0010\nJ\r\u0010 \u001a\u00020\u0007H\u0000\u00a2\u0006\u0002\u0008!J\u0015\u0010(\u001a\u00020\u00102\u0006\u0010)\u001a\u00020$H\u0000\u00a2\u0006\u0002\u0008*J9\u0010/\u001a\u00020\u0007*\u0002002\u0006\u00101\u001a\u0002022\u0008\u00103\u001a\u0004\u0018\u00010\u00132\u0019\u00104\u001a\u0015\u0012\u0004\u0012\u000205\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0005\u00a2\u0006\u0002\u0008\u0008H\u0016J\u0008\u00106\u001a\u00020.H\u0002R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR%\u0010\u0004\u001a\u0013\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005\u00a2\u0006\u0002\u0008\u0008X\u0080\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u0014\u0010\u000f\u001a\u00020\u0010X\u0096D\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0011R/\u0010\u0014\u001a\u0004\u0018\u00010\u00132\u0008\u0010\u0012\u001a\u0004\u0018\u00010\u00138@@@X\u0080\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u0019\u0010\u001a\u001a\u0004\u0008\u0015\u0010\u0016\"\u0004\u0008\u0017\u0010\u0018R\u001e\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u001b\u001a\u00020\u001c@BX\u0080\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001e\u0010\u001fR$\u0010\"\u001a\u0012\u0012\u0004\u0012\u00020$0#j\u0008\u0012\u0004\u0012\u00020$`%X\u0080\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008&\u0010\'R\u0014\u0010+\u001a\u00020\u00108@X\u0080\u0004\u00a2\u0006\u0006\u001a\u0004\u0008,\u0010\u0011R\u0010\u0010-\u001a\u0004\u0018\u00010.X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00067"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "graphicsLayer",
        "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
        "onDraw",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "<init>",
        "(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Lam0/l;)V",
        "getGraphicsLayer",
        "()Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
        "getOnDraw$extension_debug",
        "()Lam0/l;",
        "isCoordinatesDependent",
        "",
        "()Z",
        "<set-?>",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layerCoordinates",
        "getLayerCoordinates$extension_debug",
        "()Landroidx/compose/ui/layout/LayoutCoordinates;",
        "setLayerCoordinates$extension_debug",
        "(Landroidx/compose/ui/layout/LayoutCoordinates;)V",
        "layerCoordinates$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "value",
        "",
        "contentVersion",
        "getContentVersion$extension_debug",
        "()I",
        "contentRecorded",
        "contentRecorded$extension_debug",
        "staticRegions",
        "Ljava/util/ArrayList;",
        "Landroidx/compose/ui/geometry/Rect;",
        "Lkotlin/collections/ArrayList;",
        "getStaticRegions$extension_debug",
        "()Ljava/util/ArrayList;",
        "isFullyStatic",
        "rect",
        "isFullyStatic$extension_debug",
        "hasRecording",
        "getHasRecording$extension_debug",
        "inverseLayerScope",
        "Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;",
        "drawBackdrop",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "coordinates",
        "layerBlock",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "obtainInverseLayerScope",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private contentVersion:I

.field private final graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

.field private inverseLayerScope:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

.field private final isCoordinatesDependent:Z

.field private final layerCoordinates$delegate:Landroidx/compose/runtime/MutableState;

.field private final onDraw:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final staticRegions:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/compose/ui/geometry/Rect;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Lam0/l;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/layer/GraphicsLayer;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "graphicsLayer"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDraw"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    .line 47
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->onDraw:Lam0/l;

    const/4 p1, 0x1

    .line 50
    iput-boolean p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->isCoordinatesDependent:Z

    const/4 p1, 0x0

    const/4 p2, 0x2

    .line 52
    invoke-static {p1, p1, p2, p1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->layerCoordinates$delegate:Landroidx/compose/runtime/MutableState;

    .line 89
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->staticRegions:Ljava/util/ArrayList;

    return-void
.end method

.method private final obtainInverseLayerScope()Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;
    .locals 1

    .line 138
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->inverseLayerScope:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->reset()V

    return-object v0

    .line 139
    :cond_0
    new-instance v0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->inverseLayerScope:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    return-object v0
.end method


# virtual methods
.method public final contentRecorded$extension_debug()V
    .locals 1

    .line 78
    iget v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->contentVersion:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->contentVersion:I

    return-void
.end method

.method public drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroidx/compose/ui/unit/Density;",
            "Landroidx/compose/ui/layout/LayoutCoordinates;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "density"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-nez p3, :cond_0

    goto :goto_1

    .line 119
    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->getLayerCoordinates$extension_debug()Landroidx/compose/ui/layout/LayoutCoordinates;

    move-result-object v1

    if-nez v1, :cond_1

    goto :goto_1

    .line 149
    :cond_1
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v8

    .line 153
    invoke-interface {v8}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getSize-NH-jbRc()J

    move-result-wide v9

    .line 154
    invoke-interface {v8}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 156
    :try_start_0
    invoke-interface {v8}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v0

    if-eqz p4, :cond_2

    .line 122
    invoke-direct {p0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->obtainInverseLayerScope()Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    move-result-object v2

    invoke-virtual {v2, v0, p2, p4}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->inverseTransform(Landroidx/compose/ui/graphics/drawscope/DrawTransform;Landroidx/compose/ui/unit/Density;Lam0/l;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v6, 0x6

    const/4 v7, 0x0

    const-wide/16 v3, 0x0

    const/4 v5, 0x0

    move-object v2, p3

    .line 126
    :try_start_1
    invoke-static/range {v1 .. v7}, Landroidx/compose/ui/layout/LayoutCoordinates;->localPositionOf-S_NoaFU$default(Landroidx/compose/ui/layout/LayoutCoordinates;Landroidx/compose/ui/layout/LayoutCoordinates;JZILjava/lang/Object;)J

    move-result-wide p2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 129
    :catch_0
    :try_start_2
    invoke-static {v2}, Landroidx/compose/ui/layout/LayoutCoordinatesKt;->positionInWindow(Landroidx/compose/ui/layout/LayoutCoordinates;)J

    move-result-wide p2

    invoke-static {v1}, Landroidx/compose/ui/layout/LayoutCoordinatesKt;->positionInWindow(Landroidx/compose/ui/layout/LayoutCoordinates;)J

    move-result-wide v1

    invoke-static {p2, p3, v1, v2}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    move-result-wide p2

    :goto_0
    const/16 p4, 0x20

    shr-long v1, p2, p4

    long-to-int p4, v1

    .line 160
    invoke-static {p4}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p4

    neg-float p4, p4

    const-wide v1, 0xffffffffL

    and-long/2addr p2, v1

    long-to-int p2, p2

    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p2

    neg-float p2, p2

    .line 131
    invoke-interface {v0, p4, p2}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 133
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    invoke-static {p1, p0}, Landroidx/compose/ui/graphics/layer/GraphicsLayerKt;->drawLayer(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/layer/GraphicsLayer;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 165
    invoke-interface {v8}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 166
    invoke-interface {v8, v9, v10}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    :goto_1
    return-void

    :catchall_0
    move-exception v0

    move-object p0, v0

    .line 165
    invoke-interface {v8}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 166
    invoke-interface {v8, v9, v10}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    throw p0
.end method

.method public final getContentVersion$extension_debug()I
    .locals 0

    .line 73
    iget p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->contentVersion:I

    return p0
.end method

.method public final getGraphicsLayer()Landroidx/compose/ui/graphics/layer/GraphicsLayer;
    .locals 0

    .line 46
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->graphicsLayer:Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    return-object p0
.end method

.method public final getHasRecording$extension_debug()Z
    .locals 0

    .line 109
    iget p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->contentVersion:I

    if-lez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final getLayerCoordinates$extension_debug()Landroidx/compose/ui/layout/LayoutCoordinates;
    .locals 0

    .line 52
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->layerCoordinates$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 143
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/layout/LayoutCoordinates;

    return-object p0
.end method

.method public final getOnDraw$extension_debug()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 47
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->onDraw:Lam0/l;

    return-object p0
.end method

.method public final getStaticRegions$extension_debug()Ljava/util/ArrayList;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Landroidx/compose/ui/geometry/Rect;",
            ">;"
        }
    .end annotation

    .line 89
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->staticRegions:Ljava/util/ArrayList;

    return-object p0
.end method

.method public isCoordinatesDependent()Z
    .locals 0

    .line 50
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->isCoordinatesDependent:Z

    return p0
.end method

.method public final isFullyStatic$extension_debug(Landroidx/compose/ui/geometry/Rect;)Z
    .locals 4

    const-string v0, "rect"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->staticRegions:Ljava/util/ArrayList;

    check-cast p0, Ljava/lang/Iterable;

    .line 146
    instance-of v0, p0, Ljava/util/Collection;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    return v1

    .line 147
    :cond_0
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/geometry/Rect;

    .line 101
    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Rect;->getLeft()F

    move-result v2

    invoke-virtual {p1}, Landroidx/compose/ui/geometry/Rect;->getLeft()F

    move-result v3

    cmpg-float v2, v2, v3

    if-gtz v2, :cond_1

    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Rect;->getTop()F

    move-result v2

    invoke-virtual {p1}, Landroidx/compose/ui/geometry/Rect;->getTop()F

    move-result v3

    cmpg-float v2, v2, v3

    if-gtz v2, :cond_1

    .line 102
    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Rect;->getRight()F

    move-result v2

    invoke-virtual {p1}, Landroidx/compose/ui/geometry/Rect;->getRight()F

    move-result v3

    cmpl-float v2, v2, v3

    if-ltz v2, :cond_1

    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Rect;->getBottom()F

    move-result v0

    invoke-virtual {p1}, Landroidx/compose/ui/geometry/Rect;->getBottom()F

    move-result v2

    cmpl-float v0, v0, v2

    if-ltz v0, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_2
    return v1
.end method

.method public final setLayerCoordinates$extension_debug(Landroidx/compose/ui/layout/LayoutCoordinates;)V
    .locals 0

    .line 52
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;->layerCoordinates$delegate:Landroidx/compose/runtime/MutableState;

    .line 144
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method
