.class final Ldev/nino/squareglass/backdrop/backdrops/Backdrop;
.super Ljava/lang/Object;
.source "Backdrop.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/Backdrop;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nBackdrop.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Backdrop.kt\ndev/nino/squareglass/backdrop/backdrops/Backdrop\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,47:1\n1#2:48\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0008\u0003\u0018\u00002\u00020\u0001BN\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012=\u0010\u0003\u001a9\u0012\u0004\u0012\u00020\u0005\u0012$\u0012\"\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0002\u0008\u0008\u00a2\u0006\u000c\u0008\t\u0012\u0008\u0008\n\u0012\u0004\u0008\u0008(\u000b\u0012\u0004\u0012\u00020\u00070\u0004\u00a2\u0006\u0002\u0008\u0008\u00a2\u0006\u0004\u0008\u000c\u0010\rJ9\u0010\u000b\u001a\u00020\u0007*\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u00162\u0008\u0010\u0017\u001a\u0004\u0018\u00010\u00182\u0019\u0010\u0019\u001a\u0015\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0006\u00a2\u0006\u0002\u0008\u0008H\u0016R\u0011\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u000fRH\u0010\u0003\u001a9\u0012\u0004\u0012\u00020\u0005\u0012$\u0012\"\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0002\u0008\u0008\u00a2\u0006\u000c\u0008\t\u0012\u0008\u0008\n\u0012\u0004\u0008\u0008(\u000b\u0012\u0004\u0012\u00020\u00070\u0004\u00a2\u0006\u0002\u0008\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0014\u00a8\u0006\u001b"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/Backdrop;",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "backdrop",
        "onDraw",
        "Lkotlin/Function2;",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "Lkotlin/Function1;",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "Lkotlin/ParameterName;",
        "name",
        "drawBackdrop",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/Backdrop;Lam0/p;)V",
        "getBackdrop",
        "()Ldev/nino/squareglass/backdrop/Backdrop;",
        "getOnDraw",
        "()Lam0/p;",
        "isCoordinatesDependent",
        "",
        "()Z",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layerBlock",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

.field private final isCoordinatesDependent:Z

.field private final onDraw:Lam0/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/backdrop/Backdrop;Lam0/p;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "backdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDraw"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    .line 34
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->onDraw:Lam0/p;

    .line 37
    invoke-interface {p1}, Ldev/nino/squareglass/backdrop/Backdrop;->isCoordinatesDependent()Z

    move-result p1

    iput-boolean p1, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->isCoordinatesDependent:Z

    return-void
.end method

.method static final drawBackdrop$lambda$0(Ldev/nino/squareglass/backdrop/backdrops/Backdrop;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 1

    const-string v0, "$this$onDraw"

    invoke-static {p4, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-interface {p0, p4, p1, p2, p3}, Ldev/nino/squareglass/backdrop/Backdrop;->drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroidx/compose/ui/unit/Density;",
            "Landroidx/compose/ui/layout/LayoutCoordinates;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "density"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->onDraw:Lam0/p;

    new-instance v1, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$0;

    invoke-direct {v1, p0, p2, p3, p4}, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$0;-><init>(Ldev/nino/squareglass/backdrop/backdrops/Backdrop;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V

    invoke-interface {v0, p1, v1}, Lam0/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final getBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 0

    .line 33
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->backdrop:Ldev/nino/squareglass/backdrop/Backdrop;

    return-object p0
.end method

.method public final getOnDraw()Lam0/p;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 34
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->onDraw:Lam0/p;

    return-object p0
.end method

.method public isCoordinatesDependent()Z
    .locals 0

    .line 37
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->isCoordinatesDependent:Z

    return p0
.end method
