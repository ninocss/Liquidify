.class public final synthetic Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/backdrop/backdrops/Backdrop;

.field public final synthetic f$1:Landroidx/compose/ui/unit/Density;

.field public final synthetic f$2:Landroidx/compose/ui/layout/LayoutCoordinates;

.field public final synthetic f$3:Lam0/l;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/Backdrop;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/backdrop/backdrops/Backdrop;

    iput-object p2, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;->f$1:Landroidx/compose/ui/unit/Density;

    iput-object p3, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;->f$2:Landroidx/compose/ui/layout/LayoutCoordinates;

    iput-object p4, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;->f$3:Lam0/l;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/backdrop/backdrops/Backdrop;

    iget-object v1, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;->f$1:Landroidx/compose/ui/unit/Density;

    iget-object v2, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;->f$2:Landroidx/compose/ui/layout/LayoutCoordinates;

    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Backdrop$$ExternalSyntheticLambda0;->f$3:Lam0/l;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static {v0, v1, v2, p0, p1}, Ldev/nino/squareglass/backdrop/backdrops/Backdrop;->$r8$lambda$vWw2R3KuvaaynEf8AcfIFEE_4Gg(Ldev/nino/squareglass/backdrop/backdrops/Backdrop;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;Landroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
