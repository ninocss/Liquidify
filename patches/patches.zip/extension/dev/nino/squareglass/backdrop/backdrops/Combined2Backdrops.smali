.class final Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;
.super Ljava/lang/Object;
.source "CombinedBackdrop.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/Backdrop;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCombinedBackdrop.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CombinedBackdrop.kt\ndev/nino/squareglass/backdrop/backdrops/Combined2Backdrops\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,109:1\n1#2:110\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0008\u0003\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0001\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J9\u0010\u000c\u001a\u00020\r*\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u00122\u0019\u0010\u0013\u001a\u0015\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\r\u0018\u00010\u0014\u00a2\u0006\u0002\u0008\u0016H\u0016R\u0011\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007R\u0011\u0010\u0003\u001a\u00020\u0001\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\u0007R\u0014\u0010\t\u001a\u00020\nX\u0096\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\u000b\u00a8\u0006\u0017"
    }
    d2 = {
        "Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "backdrop1",
        "backdrop2",
        "<init>",
        "(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/Backdrop;)V",
        "getBackdrop1",
        "()Ldev/nino/squareglass/backdrop/Backdrop;",
        "getBackdrop2",
        "isCoordinatesDependent",
        "",
        "()Z",
        "drawBackdrop",
        "",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layerBlock",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "Lkotlin/ExtensionFunctionType;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final backdrop1:Ldev/nino/squareglass/backdrop/Backdrop;

.field private final backdrop2:Ldev/nino/squareglass/backdrop/Backdrop;

.field private final isCoordinatesDependent:Z


# direct methods
.method public constructor <init>(Ldev/nino/squareglass/backdrop/Backdrop;Ldev/nino/squareglass/backdrop/Backdrop;)V
    .locals 1

    const-string v0, "backdrop1"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "backdrop2"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 51
    iput-object p1, p0, Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;->backdrop1:Ldev/nino/squareglass/backdrop/Backdrop;

    .line 52
    iput-object p2, p0, Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;->backdrop2:Ldev/nino/squareglass/backdrop/Backdrop;

    .line 56
    invoke-interface {p1}, Ldev/nino/squareglass/backdrop/Backdrop;->isCoordinatesDependent()Z

    move-result p1

    if-nez p1, :cond_1

    invoke-interface {p2}, Ldev/nino/squareglass/backdrop/Backdrop;->isCoordinatesDependent()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    iput-boolean p1, p0, Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;->isCoordinatesDependent:Z

    return-void
.end method


# virtual methods
.method public drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroidx/compose/ui/unit/Density;",
            "Landroidx/compose/ui/layout/LayoutCoordinates;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "density"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    iget-object v0, p0, Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;->backdrop1:Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-interface {v0, p1, p2, p3, p4}, Ldev/nino/squareglass/backdrop/Backdrop;->drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V

    .line 64
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;->backdrop2:Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-interface {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/backdrop/Backdrop;->drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V

    return-void
.end method

.method public final getBackdrop1()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 0

    .line 51
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;->backdrop1:Ldev/nino/squareglass/backdrop/Backdrop;

    return-object p0
.end method

.method public final getBackdrop2()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 0

    .line 52
    iget-object p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;->backdrop2:Ldev/nino/squareglass/backdrop/Backdrop;

    return-object p0
.end method

.method public isCoordinatesDependent()Z
    .locals 0

    .line 55
    iget-boolean p0, p0, Ldev/nino/squareglass/backdrop/backdrops/Combined2Backdrops;->isCoordinatesDependent:Z

    return p0
.end method
