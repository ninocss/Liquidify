.class final Ldev/nino/squareglass/SquareMenus$Presentation;
.super Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;
.source "SquareMenus.java"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareMenus;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Presentation"
.end annotation


# instance fields
.field final activity:Landroid/app/Activity;

.field final adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
            "*>;"
        }
    .end annotation
.end field

.field final afterUpdates:Ljava/lang/Runnable;

.field final anchored:Z

.field bars:Ldev/nino/squareglass/SystemBarTheme;

.field chosen:Z

.field final dialog:Landroid/app/Dialog;

.field final frame:Landroid/graphics/Rect;

.field glass:Ldev/nino/squareglass/LiquidMenuSurface;

.field final handleVisibility:I

.field playerBackground:Landroid/view/View;

.field playerSnapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

.field popup:Landroid/widget/PopupWindow;

.field released:Z

.field final requestedAction:I

.field final root:Landroid/view/View;

.field shell:Landroid/widget/FrameLayout;

.field songMenu:Ldev/nino/squareglass/SquareSongMenu;

.field final tapAction:Z

.field final timeout:Ljava/lang/Runnable;

.field final x:I

.field final y:I


# direct methods
.method public static synthetic $r8$lambda$iwVISFXVUtynylZVfxG_MTjFeHc(Ldev/nino/squareglass/SquareMenus$Presentation;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->lambda$select$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$lB7Znug5st6HPzUdGTBeNm36YqU(Ldev/nino/squareglass/SquareMenus$Presentation;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->lambda$new$0()V

    return-void
.end method

.method constructor <init>(Landroid/app/Dialog;Landroid/app/Activity;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Adapter;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Dialog;",
            "Landroid/app/Activity;",
            "Landroid/view/View;",
            "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
            "*>;)V"
        }
    .end annotation

    .line 174
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;-><init>()V

    .line 157
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    .line 171
    new-instance v1, Ldev/nino/squareglass/SquareMenus$Presentation$1;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareMenus$Presentation$1;-><init>(Ldev/nino/squareglass/SquareMenus$Presentation;)V

    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->timeout:Ljava/lang/Runnable;

    .line 172
    new-instance v1, Ldev/nino/squareglass/SquareMenus$Presentation$2;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareMenus$Presentation$2;-><init>(Ldev/nino/squareglass/SquareMenus$Presentation;)V

    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->afterUpdates:Ljava/lang/Runnable;

    .line 175
    iput-object p1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    iput-object p2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    iput-object p3, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    iput-object p4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    .line 176
    invoke-static {}, Ldev/nino/squareglass/PlayerWindow;->take()Ldev/nino/squareglass/PlayerWindow$Snapshot;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerSnapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    .line 177
    invoke-static {p2}, Ldev/nino/squareglass/SquareGestures;->request(Landroid/app/Activity;)I

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->requestedAction:I

    .line 178
    invoke-static {}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$sfgettouchedActivity()Ljava/lang/ref/WeakReference;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 p4, 0x1

    const/4 v1, 0x0

    if-ne p1, p2, :cond_0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    invoke-static {}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$sfgettouchedAt()J

    move-result-wide v4

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x9c4

    cmp-long p1, v2, v4

    if-gez p1, :cond_0

    move p1, p4

    goto :goto_0

    :cond_0
    move p1, v1

    :goto_0
    iput-boolean p1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->anchored:Z

    .line 179
    invoke-static {}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$sfgettouchX()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    iput v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->x:I

    invoke-static {}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$sfgettouchY()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    iput v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->y:I

    .line 180
    invoke-virtual {p2}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p2

    invoke-virtual {p2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p2

    invoke-virtual {p2, v0}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    if-eqz p1, :cond_1

    .line 183
    invoke-static {}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$sfgetcompletedTap()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$sfgetmoved()Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_1

    :cond_1
    move p4, v1

    :goto_1
    iput-boolean p4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->tapAction:Z

    const p1, 0x7f0b064a

    .line 184
    invoke-virtual {p3, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    if-nez p1, :cond_2

    const/16 p1, 0x8

    goto :goto_2

    .line 185
    :cond_2
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    :goto_2
    iput p1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->handleVisibility:I

    const-wide/16 p0, 0x0

    .line 187
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$sfputtouchedAt(J)V

    return-void
.end method

.method private synthetic lambda$new$0()V
    .locals 0

    .line 172
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->select()V

    return-void
.end method

.method private synthetic lambda$select$0()V
    .locals 1

    .line 264
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->released:Z

    if-nez v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    return-void
.end method


# virtual methods
.method makeShell(Z)V
    .locals 5

    .line 294
    new-instance v0, Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerSnapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LiquidMenuSurface;-><init>(Landroid/app/Activity;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    .line 295
    new-instance v0, Landroid/widget/FrameLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    .line 296
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Landroid/view/ViewGroup;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 297
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    .line 298
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v2

    .line 299
    iget-object v3, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    .line 300
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 301
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    invoke-virtual {v0, v4, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 302
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setBackgroundColor(I)V

    .line 304
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    if-eqz p1, :cond_1

    const/high16 p1, 0x41f00000    # 30.0f

    goto :goto_0

    :cond_1
    const/high16 p1, 0x41c00000    # 24.0f

    :goto_0
    invoke-virtual {v0, v2, p1, v1}, Ldev/nino/squareglass/LiquidMenuSurface;->paint(Landroid/widget/FrameLayout;FZ)V

    .line 305
    iget-object p1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, p0, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 1

    .line 347
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    if-ne p1, v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 1

    .line 348
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    if-ne p1, v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    return-void
.end method

.method public onChanged()V
    .locals 0

    .line 344
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->schedule()V

    return-void
.end method

.method public onItemRangeChanged(II)V
    .locals 0

    .line 346
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->schedule()V

    return-void
.end method

.method public onItemRangeInserted(II)V
    .locals 0

    .line 345
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->schedule()V

    return-void
.end method

.method release()V
    .locals 3

    .line 315
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->released:Z

    if-eqz v0, :cond_0

    goto/16 :goto_0

    :cond_0
    const/4 v0, 0x1

    .line 316
    iput-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->released:Z

    .line 317
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->timeout:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 318
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->afterUpdates:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 319
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->unregisterAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;)V

    .line 320
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->songMenu:Ldev/nino/squareglass/SquareSongMenu;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareSongMenu;->release()V

    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->songMenu:Ldev/nino/squareglass/SquareSongMenu;

    .line 321
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->bars:Ldev/nino/squareglass/SystemBarTheme;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ldev/nino/squareglass/SystemBarTheme;->release()V

    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->bars:Ldev/nino/squareglass/SystemBarTheme;

    .line 322
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ldev/nino/squareglass/LiquidMenuSurface;->release()V

    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    .line 323
    :cond_3
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerBackground:Landroid/view/View;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_4

    .line 324
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerBackground:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerBackground:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 325
    :cond_4
    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerBackground:Landroid/view/View;

    .line 326
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerSnapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->release()V

    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerSnapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    .line 327
    :cond_5
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 328
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    if-eqz v0, :cond_6

    .line 329
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    const-string v2, "enter"

    invoke-static {v0, v2}, Ldev/nino/squareglass/LiquidViewMotion;->cancel(Landroid/view/View;Ljava/lang/String;)V

    .line 330
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 331
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    .line 332
    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    :cond_6
    :goto_0
    return-void
.end method

.method schedule()V
    .locals 2

    .line 337
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->chosen:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->released:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 340
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    .line 341
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->afterUpdates:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 342
    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->afterUpdates:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    :cond_1
    :goto_0
    return-void
.end method

.method select()V
    .locals 13

    .line 205
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->chosen:Z

    if-nez v0, :cond_13

    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->released:Z

    if-eqz v0, :cond_0

    goto/16 :goto_5

    .line 206
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_12

    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_1

    goto/16 :goto_4

    .line 207
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemCount()I

    move-result v0

    if-nez v0, :cond_2

    goto/16 :goto_5

    .line 209
    :cond_2
    iget v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->requestedAction:I

    const/4 v1, 0x1

    if-eqz v0, :cond_5

    .line 210
    iput-boolean v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->chosen:Z

    .line 211
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    instance-of v2, v1, Landroid/view/ViewGroup;

    if-eqz v2, :cond_4

    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    check-cast v1, Landroid/view/ViewGroup;

    invoke-static {v2, v1, v0}, Ldev/nino/squareglass/SquareSongMenu;->perform(Landroidx/recyclerview/widget/RecyclerView$Adapter;Landroid/view/ViewGroup;I)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    .line 212
    :cond_3
    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    return-void

    .line 211
    :cond_4
    :goto_0
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->unavailable()V

    return-void

    .line 215
    :cond_5
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    invoke-virtual {v0, v2}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 216
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->tapAction:Z

    if-nez v0, :cond_6

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->sheet()V

    return-void

    .line 217
    :cond_6
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const/high16 v2, 0x41400000    # 12.0f

    invoke-static {v0, v2}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v0

    .line 218
    iget-object v3, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v3

    iget v3, v3, Landroid/content/res/Configuration;->fontScale:F

    .line 219
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const v5, 0x3fa66666    # 1.3f

    cmpl-float v3, v3, v5

    if-lez v3, :cond_7

    const/high16 v3, 0x43b00000    # 352.0f

    goto :goto_1

    :cond_7
    const/high16 v3, 0x43980000    # 304.0f

    :goto_1
    invoke-static {v4, v3}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v3

    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->width()I

    move-result v4

    mul-int/lit8 v5, v0, 0x2

    sub-int/2addr v4, v5

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v3

    .line 220
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const/high16 v6, 0x435c0000    # 220.0f

    invoke-static {v4, v6}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v4

    if-ge v3, v4, :cond_8

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->sheet()V

    return-void

    .line 221
    :cond_8
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const v6, 0x7f0b064a

    invoke-virtual {v4, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    if-eqz v4, :cond_9

    const/16 v6, 0x8

    .line 222
    invoke-virtual {v4, v6}, Landroid/view/View;->setVisibility(I)V

    .line 223
    :cond_9
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->height()I

    move-result v4

    sub-int/2addr v4, v5

    iget-object v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const/high16 v6, 0x440c0000    # 560.0f

    invoke-static {v5, v6}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 224
    iget-object v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const v6, 0x7f0b05b8

    invoke-virtual {v5, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    if-eqz v5, :cond_a

    .line 226
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    const/4 v7, -0x2

    .line 227
    iput v7, v6, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 228
    invoke-virtual {v5, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 230
    :cond_a
    iget-object v6, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const/high16 v7, 0x40000000    # 2.0f

    invoke-static {v3, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v8

    const/high16 v9, -0x80000000

    .line 231
    invoke-static {v4, v9}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v10

    .line 230
    invoke-virtual {v6, v8, v10}, Landroid/view/View;->measure(II)V

    .line 232
    iget-object v6, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v6}, Landroid/view/View;->getMeasuredHeight()I

    move-result v6

    if-gtz v6, :cond_b

    .line 233
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->sheet()V

    return-void

    :cond_b
    const/4 v8, 0x0

    if-eqz v5, :cond_d

    .line 237
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    .line 238
    invoke-virtual {v5}, Landroid/view/View;->getMeasuredHeight()I

    move-result v11

    sub-int/2addr v6, v11

    invoke-static {v8, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    .line 241
    iget-object v11, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const/high16 v12, 0x42400000    # 48.0f

    invoke-static {v11, v12}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v11

    add-int/2addr v11, v6

    if-le v11, v4, :cond_c

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->sheet()V

    return-void

    .line 242
    :cond_c
    iget-object v11, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-static {v11, v12}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v11

    invoke-virtual {v5}, Landroid/view/View;->getMeasuredHeight()I

    move-result v12

    sub-int v6, v4, v6

    invoke-static {v12, v6}, Ljava/lang/Math;->min(II)I

    move-result v6

    invoke-static {v11, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    iput v6, v10, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 243
    invoke-virtual {v5, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 244
    iget-object v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-static {v3, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    .line 245
    invoke-static {v4, v9}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    .line 244
    invoke-virtual {v5, v6, v4}, Landroid/view/View;->measure(II)V

    .line 246
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v6

    .line 248
    :cond_d
    iput-boolean v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->chosen:Z

    .line 249
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v4

    iget-object v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->timeout:Ljava/lang/Runnable;

    invoke-virtual {v4, v5}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 250
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v4

    iget-object v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->afterUpdates:Ljava/lang/Runnable;

    invoke-virtual {v4, v5}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 251
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    instance-of v4, v4, Landroid/view/ViewGroup;

    if-eqz v4, :cond_e

    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    check-cast v4, Landroid/view/ViewGroup;

    iget-object v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 252
    :cond_e
    invoke-virtual {p0, v8}, Ldev/nino/squareglass/SquareMenus$Presentation;->makeShell(Z)V

    .line 253
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getLayoutDirection()I

    move-result v4

    iget v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->x:I

    const/high16 v7, 0x41c00000    # 24.0f

    if-ne v4, v1, :cond_f

    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-static {v4, v7}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v4

    sub-int/2addr v5, v4

    goto :goto_2

    :cond_f
    sub-int/2addr v5, v3

    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-static {v4, v7}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v4

    add-int/2addr v5, v4

    .line 254
    :goto_2
    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->left:I

    add-int/2addr v4, v0

    iget-object v7, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    iget v7, v7, Landroid/graphics/Rect;->right:I

    sub-int/2addr v7, v3

    sub-int/2addr v7, v0

    invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v4

    .line 255
    iget v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->y:I

    iget-object v7, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-static {v7, v2}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v7

    add-int/2addr v5, v7

    add-int v7, v5, v6

    .line 256
    iget-object v9, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr v9, v0

    if-le v7, v9, :cond_10

    iget v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->y:I

    sub-int/2addr v5, v6

    iget-object v7, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    invoke-static {v7, v2}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v2

    sub-int/2addr v5, v2

    .line 257
    :cond_10
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->top:I

    add-int/2addr v2, v0

    iget-object v7, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->frame:Landroid/graphics/Rect;

    iget v7, v7, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr v7, v6

    sub-int/2addr v7, v0

    invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 258
    new-instance v2, Landroid/widget/PopupWindow;

    iget-object v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    invoke-direct {v2, v5, v3, v6, v1}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;IIZ)V

    iput-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    .line 259
    new-instance v5, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v5, v8}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v2, v5}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 260
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    iget-object v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const/high16 v7, 0x41200000    # 10.0f

    invoke-static {v5, v7}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smdp(Landroid/view/View;F)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v2, v5}, Landroid/widget/PopupWindow;->setElevation(F)V

    .line 261
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v2, v1}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    .line 262
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v2, v1}, Landroid/widget/PopupWindow;->setClippingEnabled(Z)V

    .line 263
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    const/4 v5, 0x2

    invoke-virtual {v2, v5}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    .line 264
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    new-instance v5, Ldev/nino/squareglass/SquareMenus$Presentation$0;

    invoke-direct {v5, p0}, Ldev/nino/squareglass/SquareMenus$Presentation$0;-><init>(Ldev/nino/squareglass/SquareMenus$Presentation;)V

    invoke-virtual {v2, v5}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 265
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    iget v5, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->x:I

    sub-int/2addr v5, v4

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v8, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v2, v3}, Landroid/widget/FrameLayout;->setPivotX(F)V

    .line 266
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    iget v3, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->y:I

    if-lt v0, v3, :cond_11

    const/4 v3, 0x0

    goto :goto_3

    :cond_11
    int-to-float v3, v6

    :goto_3
    invoke-virtual {v2, v3}, Landroid/widget/FrameLayout;->setPivotY(F)V

    .line 267
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->popup:Landroid/widget/PopupWindow;

    iget-object v3, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v3}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v3

    const/16 v5, 0x33

    invoke-virtual {v2, v3, v5, v4, v0}, Landroid/widget/PopupWindow;->showAtLocation(Landroid/view/View;III)V

    .line 268
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    invoke-static {v0, v1, v8}, Ldev/nino/squareglass/SurfaceMotion;->enter(Landroid/view/View;ZZ)V

    .line 269
    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const/16 v0, 0x20

    invoke-virtual {p0, v0}, Landroid/view/View;->sendAccessibilityEvent(I)V

    return-void

    .line 206
    :cond_12
    :goto_4
    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    :cond_13
    :goto_5
    return-void
.end method

.method sheet()V
    .locals 6

    .line 273
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->chosen:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->released:Z

    if-eqz v0, :cond_0

    goto/16 :goto_2

    :cond_0
    const/4 v0, 0x1

    .line 274
    iput-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->chosen:Z

    .line 275
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->timeout:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 276
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->afterUpdates:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 277
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_4

    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->isDestroyed()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    .line 278
    :cond_1
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const v2, 0x7f0b064a

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_2

    .line 279
    iget v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->handleVisibility:I

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 280
    :cond_2
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/SquareMenus$Presentation;->makeShell(Z)V

    .line 281
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    iget-object v3, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v4, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerSnapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    const/4 v5, 0x0

    if-eqz v4, :cond_3

    move v4, v0

    goto :goto_0

    :cond_3
    move v4, v5

    :goto_0
    invoke-static {v1, v2, v3, v4}, Ldev/nino/squareglass/SquareSongMenu;->install(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Adapter;Ldev/nino/squareglass/LiquidMenuSurface;Z)Ldev/nino/squareglass/SquareSongMenu;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->songMenu:Ldev/nino/squareglass/SquareSongMenu;

    .line 282
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    .line 283
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->shell:Landroid/widget/FrameLayout;

    invoke-static {v1, v5, v0}, Ldev/nino/squareglass/SurfaceMotion;->enter(Landroid/view/View;ZZ)V

    .line 284
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-static {v1}, Ldev/nino/squareglass/SystemBarTheme;->installWindow(Landroid/view/Window;)Ldev/nino/squareglass/SystemBarTheme;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->bars:Ldev/nino/squareglass/SystemBarTheme;

    .line 285
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerSnapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    if-eqz v1, :cond_5

    .line 286
    iget-object v1, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    .line 287
    iget-object v2, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerSnapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    iget-object v3, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v2, v3, v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->view(Landroid/content/Context;Z)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerBackground:Landroid/view/View;

    const/4 v2, 0x4

    .line 288
    invoke-virtual {v0, v2}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 289
    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->playerBackground:Landroid/view/View;

    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v0, v2, v2}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v1, p0, v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-void

    .line 277
    :cond_4
    :goto_1
    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    :cond_5
    :goto_2
    return-void
.end method

.method start()V
    .locals 3

    .line 191
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 192
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const v2, 0x7f0b0336

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 193
    invoke-static {v0}, Ldev/nino/squareglass/SquareMenus;->-$$Nest$smheader(Landroid/view/View;)V

    .line 194
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->root:Landroid/view/View;

    const v2, 0x7f0b05b8

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 195
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 196
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 197
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->registerAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;)V

    .line 198
    iget v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->requestedAction:I

    const-wide/16 v1, 0x384

    if-eqz v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemCount()I

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->timeout:Ljava/lang/Runnable;

    invoke-virtual {v0, p0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 199
    :cond_2
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->anchored:Z

    if-nez v0, :cond_3

    iget v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->requestedAction:I

    if-nez v0, :cond_3

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->sheet()V

    return-void

    .line 200
    :cond_3
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->adapter:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemCount()I

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->select()V

    return-void

    .line 201
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->timeout:Ljava/lang/Runnable;

    invoke-virtual {v0, p0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method timedOut()V
    .locals 1

    .line 312
    iget v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->requestedAction:I

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->unavailable()V

    return-void

    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareMenus$Presentation;->sheet()V

    return-void
.end method

.method unavailable()V
    .locals 3

    .line 309
    iget-object v0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->activity:Landroid/app/Activity;

    const-string v1, "This action is unavailable for this track"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 310
    iget-object p0, p0, Ldev/nino/squareglass/SquareMenus$Presentation;->dialog:Landroid/app/Dialog;

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method
