.class public final Ldev/nino/squareglass/NativeBackdrop;
.super Ljava/lang/Object;
.source "NativeBackdrop.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeBackdrop.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeBackdrop.kt\ndev/nino/squareglass/NativeBackdrop\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 5 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 6 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope\n*L\n1#1,108:1\n85#2:109\n117#2,2:110\n85#2:112\n117#2,2:113\n75#3:115\n75#3:134\n1128#4,6:116\n1128#4,6:122\n1128#4,6:128\n1128#4,6:135\n1#5:141\n66#6,5:142\n66#6,5:147\n66#6,5:152\n*S KotlinDebug\n*F\n+ 1 NativeBackdrop.kt\ndev/nino/squareglass/NativeBackdrop\n*L\n25#1:109\n25#1:110,2\n27#1:112\n27#1:113,2\n56#1:115\n91#1:134\n58#1:116,6\n63#1:122,6\n80#1:128,6\n92#1:135,6\n61#1:142,5\n66#1:147,5\n100#1:152,5\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aJ\u000e\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u001c\u001a\u00020\u0005J\u0008\u0010\u001d\u001a\u00020\u0018H\u0007J\u0015\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u001fH\u0007\u00a2\u0006\u0002\u0010!J\u0015\u0010\"\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u001fH\u0007\u00a2\u0006\u0002\u0010!R/\u0010\u0006\u001a\u0004\u0018\u00010\u00052\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u00058B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u000b\u0010\u000c\u001a\u0004\u0008\u0007\u0010\u0008\"\u0004\u0008\t\u0010\nR\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R+\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u000e8F@BX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u0014\u0010\u000c\u001a\u0004\u0008\u0010\u0010\u0011\"\u0004\u0008\u0012\u0010\u0013R\u0011\u0010\u0015\u001a\u00020\u000e8F\u00a2\u0006\u0006\u001a\u0004\u0008\u0016\u0010\u0011\u00a8\u0006#"
    }
    d2 = {
        "Ldev/nino/squareglass/NativeBackdrop;",
        "",
        "<init>",
        "()V",
        "<set-?>",
        "Ldev/nino/squareglass/NativeViewBackdrop;",
        "nativeSource",
        "getNativeSource",
        "()Ldev/nino/squareglass/NativeViewBackdrop;",
        "setNativeSource",
        "(Ldev/nino/squareglass/NativeViewBackdrop;)V",
        "nativeSource$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "playerSource",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "active",
        "getActive",
        "()Ldev/nino/squareglass/backdrop/Backdrop;",
        "setActive",
        "(Ldev/nino/squareglass/backdrop/Backdrop;)V",
        "active$delegate",
        "accessory",
        "getAccessory",
        "attachNative",
        "",
        "view",
        "Landroid/view/View;",
        "releaseNative",
        "source",
        "transition",
        "capturePlayer",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "capture",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

.field private static final active$delegate:Landroidx/compose/runtime/MutableState;

.field private static final nativeSource$delegate:Landroidx/compose/runtime/MutableState;

.field private static playerSource:Ldev/nino/squareglass/backdrop/Backdrop;


# direct methods
.method public static synthetic $r8$lambda$2AADHFN_DskU7cptAR596Bu0beI(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeBackdrop;->capturePlayer$lambda$1$0(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$P20C5kqcvvHJ3aU2oNox3xEnJtE(Lkotlin/jvm/internal/Ref$BooleanRef;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeBackdrop;->capture$lambda$0$0(Lkotlin/jvm/internal/Ref$BooleanRef;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$_KJssD2PgS3wzRB8DkyXaHnijog(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/NativeBackdrop;->capture$lambda$1$0$0(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V

    return-void
.end method

.method public static synthetic $r8$lambda$oHy-WQkFt3U6AU2WtlDQtcKRGwE(Landroid/view/View;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeBackdrop;->capturePlayer$lambda$0$0(Landroid/view/View;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qXGRIqEUD4jZolomROhTuAUz7ow(Landroidx/lifecycle/Lifecycle;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/NativeBackdrop;->capture$lambda$1$0(Landroidx/lifecycle/Lifecycle;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Ldev/nino/squareglass/NativeBackdrop;

    invoke-direct {v0}, Ldev/nino/squareglass/NativeBackdrop;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    const/4 v0, 0x0

    const/4 v1, 0x2

    .line 25
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    sput-object v2, Ldev/nino/squareglass/NativeBackdrop;->nativeSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 27
    invoke-static {}, Ldev/nino/squareglass/backdrop/backdrops/EmptyBackdropKt;->emptyBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v2

    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/NativeBackdrop;->active$delegate:Landroidx/compose/runtime/MutableState;

    const/16 v0, 0x8

    sput v0, Ldev/nino/squareglass/NativeBackdrop;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$getNativeSource(Ldev/nino/squareglass/NativeBackdrop;)Ldev/nino/squareglass/NativeViewBackdrop;
    .locals 0

    .line 24
    invoke-direct {p0}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$getPlayerSource$p()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 1

    .line 24
    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->playerSource:Ldev/nino/squareglass/backdrop/Backdrop;

    return-object v0
.end method

.method public static final synthetic access$setActive(Ldev/nino/squareglass/NativeBackdrop;Ldev/nino/squareglass/backdrop/Backdrop;)V
    .locals 0

    .line 24
    invoke-direct {p0, p1}, Ldev/nino/squareglass/NativeBackdrop;->setActive(Ldev/nino/squareglass/backdrop/Backdrop;)V

    return-void
.end method

.method public static final synthetic access$setPlayerSource$p(Ldev/nino/squareglass/backdrop/Backdrop;)V
    .locals 0

    .line 24
    sput-object p0, Ldev/nino/squareglass/NativeBackdrop;->playerSource:Ldev/nino/squareglass/backdrop/Backdrop;

    return-void
.end method

.method public static final capture(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 5

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(capture)N(original)79@3224L276,89@3524L36,90@3605L7,91@3669L741,91@3631L779:NativeBackdrop.kt#vqphja"

    const v1, -0x60fa2816

    .line 79
    invoke-static {p1, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.NativeBackdrop.capture (NativeBackdrop.kt:78)"

    invoke-static {v1, p2, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    const p2, -0xb106e02

    .line 80
    const-string v0, "CC(remember):NativeBackdrop.kt#9igjgp"

    invoke-static {p1, p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 128
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object p2

    .line 129
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    const/4 v2, 0x1

    if-ne p2, v1, :cond_1

    .line 81
    new-instance p2, Lkotlin/jvm/internal/Ref$BooleanRef;

    invoke-direct {p2}, Lkotlin/jvm/internal/Ref$BooleanRef;-><init>()V

    iput-boolean v2, p2, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 82
    new-instance v1, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda0;

    invoke-direct {v1, p2}, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;)V

    .line 131
    invoke-interface {p1, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    move-object p2, v1

    .line 80
    :cond_1
    check-cast p2, Lam0/l;

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v1, 0x30

    const/4 v3, 0x0

    .line 90
    invoke-static {v3, p2, p1, v1, v2}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropKt;->rememberLayerBackdrop(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Lam0/l;Landroidx/compose/runtime/Composer;II)Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    move-result-object p2

    .line 91
    invoke-static {}, Landroidx/lifecycle/compose/LocalLifecycleOwnerKt;->getLocalLifecycleOwner()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v1

    check-cast v1, Landroidx/compose/runtime/CompositionLocal;

    const v2, 0x789c5f52

    const-string v4, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    .line 134
    invoke-static {p1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, v1}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    check-cast v1, Landroidx/lifecycle/LifecycleOwner;

    .line 91
    invoke-interface {v1}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    move-result-object v1

    const v2, -0xb103491

    .line 92
    invoke-static {p1, v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, p2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    invoke-interface {p1, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v0, v2

    .line 135
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v0, :cond_2

    .line 136
    sget-object v0, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v0}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v2, v0, :cond_3

    .line 92
    :cond_2
    new-instance v2, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda1;

    invoke-direct {v2, v1, p2}, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda1;-><init>(Landroidx/lifecycle/Lifecycle;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    .line 138
    invoke-interface {p1, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 92
    :cond_3
    check-cast v2, Lam0/l;

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v0, 0x0

    invoke-static {v1, p2, v2, p1, v0}, Landroidx/compose/runtime/EffectsKt;->DisposableEffect(Ljava/lang/Object;Ljava/lang/Object;Lam0/l;Landroidx/compose/runtime/Composer;I)V

    const/4 v0, 0x2

    .line 105
    invoke-static {p0, p2, v3, v0, v3}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropModifierKt;->layerBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p2

    if-eqz p2, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 79
    :cond_4
    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method private static final capture$lambda$0$0(Lkotlin/jvm/internal/Ref$BooleanRef;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;
    .locals 1

    const-string v0, "$this$remember"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;->drawContent()V

    .line 84
    iget-boolean p1, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    .line 85
    iput-boolean p1, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 86
    const-string p0, "SquareGlass"

    const-string p1, "native page recorded for AndroidLiquidGlass"

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 88
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final capture$lambda$1$0(Landroidx/lifecycle/Lifecycle;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 2

    const-string v0, "$this$DisposableEffect"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    new-instance p2, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda2;

    invoke-direct {p2, p1}, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda2;-><init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    .line 98
    move-object v0, p2

    check-cast v0, Landroidx/lifecycle/LifecycleObserver;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/Lifecycle;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 99
    invoke-virtual {p0}, Landroidx/lifecycle/Lifecycle;->getCurrentState()Landroidx/lifecycle/Lifecycle$State;

    move-result-object v0

    sget-object v1, Landroidx/lifecycle/Lifecycle$State;->RESUMED:Landroidx/lifecycle/Lifecycle$State;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/Lifecycle$State;->isAtLeast(Landroidx/lifecycle/Lifecycle$State;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-direct {v0}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object v1

    if-nez v1, :cond_0

    sget-object v1, Ldev/nino/squareglass/NativeBackdrop;->playerSource:Ldev/nino/squareglass/backdrop/Backdrop;

    if-nez v1, :cond_0

    move-object v1, p1

    check-cast v1, Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-direct {v0, v1}, Ldev/nino/squareglass/NativeBackdrop;->setActive(Ldev/nino/squareglass/backdrop/Backdrop;)V

    .line 152
    :cond_0
    new-instance v0, Ldev/nino/squareglass/NativeBackdrop$capture$lambda$1$0$$inlined$onDispose$1;

    invoke-direct {v0, p0, p2, p1}, Ldev/nino/squareglass/NativeBackdrop$capture$lambda$1$0$$inlined$onDispose$1;-><init>(Landroidx/lifecycle/Lifecycle;Landroidx/lifecycle/LifecycleEventObserver;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    check-cast v0, Landroidx/compose/runtime/DisposableEffectResult;

    return-object v0
.end method

.method private static final capture$lambda$1$0$0(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .locals 1

    const-string v0, "<unused var>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "event"

    invoke-static {p2, p1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    sget-object p1, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;

    if-ne p2, p1, :cond_0

    sget-object p1, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-direct {p1}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ldev/nino/squareglass/NativeViewBackdrop;->requestCapture()V

    .line 95
    :cond_0
    sget-object p1, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;

    if-ne p2, p1, :cond_1

    sget-object p1, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-direct {p1}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object v0

    if-nez v0, :cond_1

    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->playerSource:Ldev/nino/squareglass/backdrop/Backdrop;

    if-nez v0, :cond_1

    move-object v0, p0

    check-cast v0, Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-direct {p1, v0}, Ldev/nino/squareglass/NativeBackdrop;->setActive(Ldev/nino/squareglass/backdrop/Backdrop;)V

    .line 96
    :cond_1
    sget-object p1, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;

    if-ne p2, p1, :cond_2

    sget-object p1, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-virtual {p1}, Ldev/nino/squareglass/NativeBackdrop;->getActive()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object p2

    if-ne p2, p0, :cond_2

    invoke-static {}, Ldev/nino/squareglass/backdrop/backdrops/EmptyBackdropKt;->emptyBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object p0

    invoke-direct {p1, p0}, Ldev/nino/squareglass/NativeBackdrop;->setActive(Ldev/nino/squareglass/backdrop/Backdrop;)V

    :cond_2
    return-void
.end method

.method public static final capturePlayer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 6

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(capturePlayer)N(original)54@2200L23,55@2253L7,57@2383L238,57@2360L261,62@2657L334,62@2630L361:NativeBackdrop.kt#vqphja"

    const v1, -0x4889e37

    .line 53
    invoke-static {p1, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.NativeBackdrop.capturePlayer (NativeBackdrop.kt:52)"

    invoke-static {v1, p2, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 54
    :cond_0
    sget-object p2, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {p2}, Ldev/nino/squareglass/DesignState;->getRevision()I

    const/4 p2, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 55
    invoke-static {v0, v0, p1, v1, p2}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropKt;->rememberLayerBackdrop(Landroidx/compose/ui/graphics/layer/GraphicsLayer;Lam0/l;Landroidx/compose/runtime/Composer;II)Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    move-result-object p2

    .line 56
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalView()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v2

    check-cast v2, Landroidx/compose/runtime/CompositionLocal;

    const v3, 0x789c5f52

    const-string v4, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    .line 115
    invoke-static {p1, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, v2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 56
    check-cast v2, Landroid/view/View;

    const v3, -0x4d9c7e9

    .line 58
    const-string v4, "CC(remember):NativeBackdrop.kt#9igjgp"

    invoke-static {p1, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .line 116
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    if-nez v3, :cond_1

    .line 117
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v5, v3, :cond_2

    .line 58
    :cond_1
    new-instance v5, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda3;

    invoke-direct {v5, v2}, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda3;-><init>(Landroid/view/View;)V

    .line 119
    invoke-interface {p1, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 58
    :cond_2
    check-cast v5, Lam0/l;

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v2, v5, p1, v1}, Landroidx/compose/runtime/EffectsKt;->DisposableEffect(Ljava/lang/Object;Lam0/l;Landroidx/compose/runtime/Composer;I)V

    const v2, -0x4d9a549

    .line 63
    invoke-static {p1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, p2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    .line 122
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    if-nez v2, :cond_3

    .line 123
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v3, v2, :cond_4

    .line 63
    :cond_3
    new-instance v3, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda4;

    invoke-direct {v3, p2}, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda4;-><init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    .line 125
    invoke-interface {p1, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 63
    :cond_4
    check-cast v3, Lam0/l;

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {p2, v3, p1, v1}, Landroidx/compose/runtime/EffectsKt;->DisposableEffect(Ljava/lang/Object;Lam0/l;Landroidx/compose/runtime/Composer;I)V

    .line 74
    const-string v1, "player"

    invoke-static {v1}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5

    const/4 v1, 0x2

    invoke-static {p0, p2, v0, v1, v0}, Ldev/nino/squareglass/backdrop/backdrops/LayerBackdropModifierKt;->layerBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    :cond_5
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p2

    if-eqz p2, :cond_6

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 53
    :cond_6
    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method private static final capturePlayer$lambda$0$0(Landroid/view/View;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 1

    const-string v0, "$this$DisposableEffect"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    instance-of p1, p0, Landroidx/compose/ui/window/DialogWindowProvider;

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    check-cast p0, Landroidx/compose/ui/window/DialogWindowProvider;

    goto :goto_0

    :cond_0
    move-object p0, v0

    :goto_0
    if-eqz p0, :cond_1

    invoke-interface {p0}, Landroidx/compose/ui/window/DialogWindowProvider;->getWindow()Landroid/view/Window;

    move-result-object p0

    goto :goto_1

    :cond_1
    move-object p0, v0

    :goto_1
    if-eqz p0, :cond_2

    .line 60
    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    invoke-static {p1}, Ldev/nino/squareglass/PlayerWindow;->attach(Landroid/view/View;)V

    invoke-static {p0}, Ldev/nino/squareglass/SystemBarTheme;->installPlayerWindow(Landroid/view/Window;)Ldev/nino/squareglass/SystemBarTheme;

    move-result-object v0

    .line 142
    :cond_2
    new-instance p0, Ldev/nino/squareglass/NativeBackdrop$capturePlayer$lambda$0$0$$inlined$onDispose$1;

    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeBackdrop$capturePlayer$lambda$0$0$$inlined$onDispose$1;-><init>(Ldev/nino/squareglass/SystemBarTheme;)V

    check-cast p0, Landroidx/compose/runtime/DisposableEffectResult;

    return-object p0
.end method

.method private static final capturePlayer$lambda$1$0(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 1

    const-string v0, "$this$DisposableEffect"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    move-object p1, p0

    check-cast p1, Ldev/nino/squareglass/backdrop/Backdrop;

    sput-object p1, Ldev/nino/squareglass/NativeBackdrop;->playerSource:Ldev/nino/squareglass/backdrop/Backdrop;

    .line 65
    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/NativeBackdrop;->setActive(Ldev/nino/squareglass/backdrop/Backdrop;)V

    .line 147
    new-instance p1, Ldev/nino/squareglass/NativeBackdrop$capturePlayer$lambda$1$0$$inlined$onDispose$1;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/NativeBackdrop$capturePlayer$lambda$1$0$$inlined$onDispose$1;-><init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V

    check-cast p1, Landroidx/compose/runtime/DisposableEffectResult;

    return-object p1
.end method

.method private final getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;
    .locals 0

    .line 25
    sget-object p0, Ldev/nino/squareglass/NativeBackdrop;->nativeSource$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 109
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/NativeViewBackdrop;

    return-object p0
.end method

.method private final setActive(Ldev/nino/squareglass/backdrop/Backdrop;)V
    .locals 0

    .line 27
    sget-object p0, Ldev/nino/squareglass/NativeBackdrop;->active$delegate:Landroidx/compose/runtime/MutableState;

    .line 113
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setNativeSource(Ldev/nino/squareglass/NativeViewBackdrop;)V
    .locals 0

    .line 25
    sget-object p0, Ldev/nino/squareglass/NativeBackdrop;->nativeSource$delegate:Landroidx/compose/runtime/MutableState;

    .line 110
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static final transition()V
    .locals 1

    .line 48
    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-direct {v0}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeViewBackdrop;->transition()V

    :cond_0
    return-void
.end method


# virtual methods
.method public final attachNative(Landroid/view/View;)V
    .locals 2

    const-string v0, "view"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    invoke-direct {p0}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Ldev/nino/squareglass/NativeViewBackdrop;->matches(Landroid/view/View;)Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    return-void

    .line 35
    :cond_0
    invoke-direct {p0}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeViewBackdrop;->release()V

    .line 36
    :cond_1
    new-instance v0, Ldev/nino/squareglass/NativeViewBackdrop;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/NativeViewBackdrop;-><init>(Landroid/view/View;)V

    .line 37
    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeBackdrop;->setNativeSource(Ldev/nino/squareglass/NativeViewBackdrop;)V

    .line 38
    sget-object p1, Ldev/nino/squareglass/NativeBackdrop;->playerSource:Ldev/nino/squareglass/backdrop/Backdrop;

    if-nez p1, :cond_2

    move-object p1, v0

    check-cast p1, Ldev/nino/squareglass/backdrop/Backdrop;

    :cond_2
    invoke-direct {p0, p1}, Ldev/nino/squareglass/NativeBackdrop;->setActive(Ldev/nino/squareglass/backdrop/Backdrop;)V

    return-void
.end method

.method public final getAccessory()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 1

    .line 31
    invoke-direct {p0}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object v0

    if-eqz v0, :cond_0

    check-cast v0, Ldev/nino/squareglass/backdrop/Backdrop;

    return-object v0

    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeBackdrop;->getActive()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object p0

    return-object p0
.end method

.method public final getActive()Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 0

    .line 27
    sget-object p0, Ldev/nino/squareglass/NativeBackdrop;->active$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 112
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/backdrop/Backdrop;

    return-object p0
.end method

.method public final releaseNative(Ldev/nino/squareglass/NativeViewBackdrop;)V
    .locals 1

    const-string v0, "source"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    invoke-direct {p0}, Ldev/nino/squareglass/NativeBackdrop;->getNativeSource()Ldev/nino/squareglass/NativeViewBackdrop;

    move-result-object v0

    if-ne v0, p1, :cond_1

    const/4 p1, 0x0

    .line 43
    invoke-direct {p0, p1}, Ldev/nino/squareglass/NativeBackdrop;->setNativeSource(Ldev/nino/squareglass/NativeViewBackdrop;)V

    .line 44
    sget-object p1, Ldev/nino/squareglass/NativeBackdrop;->playerSource:Ldev/nino/squareglass/backdrop/Backdrop;

    if-nez p1, :cond_0

    invoke-static {}, Ldev/nino/squareglass/backdrop/backdrops/EmptyBackdropKt;->emptyBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object p1

    :cond_0
    invoke-direct {p0, p1}, Ldev/nino/squareglass/NativeBackdrop;->setActive(Ldev/nino/squareglass/backdrop/Backdrop;)V

    :cond_1
    return-void
.end method
