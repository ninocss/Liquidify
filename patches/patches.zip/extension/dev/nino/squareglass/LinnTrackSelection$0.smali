.class public final synthetic Ldev/nino/squareglass/LinnTrackSelection$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnTrackSelection;

.field public final synthetic f$1:Ldev/nino/squareglass/LinnTrackSelection$Goal;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnTrackSelection;Ldev/nino/squareglass/LinnTrackSelection$Goal;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnTrackSelection$0;->f$0:Ldev/nino/squareglass/LinnTrackSelection;

    iput-object p2, p0, Ldev/nino/squareglass/LinnTrackSelection$0;->f$1:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection$0;->f$0:Ldev/nino/squareglass/LinnTrackSelection;

    iget-object p0, p0, Ldev/nino/squareglass/LinnTrackSelection$0;->f$1:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    invoke-static {v0, p0}, Ldev/nino/squareglass/LinnTrackSelection;->$r8$lambda$VBn2qe15B6tOimXG20sg09qEk2c(Ldev/nino/squareglass/LinnTrackSelection;Ldev/nino/squareglass/LinnTrackSelection$Goal;)V

    return-void
.end method
