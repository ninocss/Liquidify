.class interface abstract Ldev/nino/squareglass/OpenHome$NetworkBinding;
.super Ljava/lang/Object;
.source "OpenHome.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/OpenHome;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "NetworkBinding"
.end annotation


# virtual methods
.method public abstract bind(Ljava/net/DatagramSocket;Ljava/net/InetAddress;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract bind(Ljava/net/Socket;Ljava/net/InetAddress;)V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method
