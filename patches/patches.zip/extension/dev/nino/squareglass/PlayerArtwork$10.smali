.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/layout/Placeable;

.field public final synthetic f$1:I

.field public final synthetic f$2:F

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/layout/Placeable;IFLandroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$10;->f$0:Landroidx/compose/ui/layout/Placeable;

    iput p2, p0, Ldev/nino/squareglass/PlayerArtwork$10;->f$1:I

    iput p3, p0, Ldev/nino/squareglass/PlayerArtwork$10;->f$2:F

    iput-object p4, p0, Ldev/nino/squareglass/PlayerArtwork$10;->f$3:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PlayerArtwork$10;->f$0:Landroidx/compose/ui/layout/Placeable;

    iget v1, p0, Ldev/nino/squareglass/PlayerArtwork$10;->f$1:I

    iget v2, p0, Ldev/nino/squareglass/PlayerArtwork$10;->f$2:F

    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$10;->f$3:Landroidx/compose/runtime/MutableState;

    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    invoke-static {v0, v1, v2, p0, p1}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$VOEwv3fkFkHsRCL-pp6qwGV5gg8(Landroidx/compose/ui/layout/Placeable;IFLandroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/Placeable$PlacementScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
