.class final Ldev/nino/squareglass/PageCoordinator$HeroDecoration;
.super Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;
.source "PageCoordinator.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/PageCoordinator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "HeroDecoration"
.end annotation


# instance fields
.field final covers:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field

.field final page:Ldev/nino/squareglass/PageCoordinator$Page;

.field final paint:Landroid/graphics/Paint;

.field final seeds:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ldev/nino/squareglass/PageCoordinator$Page;)V
    .locals 2

    .line 332
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;-><init>()V

    .line 330
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    .line 331
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->covers:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->seeds:Ljava/util/ArrayList;

    .line 333
    iput-object p1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v1, p1, Ldev/nino/squareglass/PageCoordinator$Page;->snapshot:Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;

    iget-object v1, v1, Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;->seeds:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 334
    iget-object p1, p1, Ldev/nino/squareglass/PageCoordinator$Page;->snapshot:Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;

    iget-object p1, p1, Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;->covers:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/Drawable;

    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->covers:Ljava/util/ArrayList;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method collect(Landroid/view/View;)V
    .locals 4

    .line 346
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->covers:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x4

    if-lt v0, v1, :cond_0

    goto/16 :goto_2

    .line 347
    :cond_0
    instance-of v0, p1, Landroid/widget/ImageView;

    if-eqz v0, :cond_4

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0b00b8

    if-eq v0, v1, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0b03d3

    if-ne v0, v1, :cond_4

    .line 348
    :cond_1
    move-object v0, p1

    check-cast v0, Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 349
    :goto_0
    instance-of v1, v0, Lcoil/drawable/CrossfadeDrawable;

    if-eqz v1, :cond_2

    check-cast v0, Lcoil/drawable/CrossfadeDrawable;

    iget-object v0, v0, Lcoil/drawable/CrossfadeDrawable;->k:Landroid/graphics/drawable/Drawable;

    goto :goto_0

    .line 350
    :cond_2
    instance-of v1, v0, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz v1, :cond_4

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v1

    const/4 v2, 0x1

    if-le v1, v2, :cond_4

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v1

    if-eqz v1, :cond_4

    .line 351
    invoke-static {v0}, Ldev/nino/squareglass/SquareDetails;->coverSeed(Landroid/graphics/drawable/Drawable;)I

    move-result v1

    .line 352
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->seeds:Ljava/util/ArrayList;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4

    .line 353
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/16 v2, 0xff

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->covers:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->seeds:Ljava/util/ArrayList;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 354
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v2, v2, Ldev/nino/squareglass/PageCoordinator$Page;->snapshot:Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;

    iget-object v2, v2, Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;->covers:Ljava/util/ArrayList;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v0, v0, Ldev/nino/squareglass/PageCoordinator$Page;->snapshot:Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;

    iget-object v0, v0, Ldev/nino/squareglass/PageCoordinator$HeroSnapshot;->seeds:Ljava/util/ArrayList;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 355
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v0, v0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_3

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v0, v0, Ldev/nino/squareglass/PageCoordinator$Page;->primary:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_3
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v0, v0, Ldev/nino/squareglass/PageCoordinator$Page;->heroView:Landroid/view/View;

    if-eqz v0, :cond_4

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v0, v0, Ldev/nino/squareglass/PageCoordinator$Page;->heroView:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 359
    :cond_4
    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_5

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    :goto_1
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_5

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->collect(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_5
    :goto_2
    return-void
.end method

.method draw(Landroid/graphics/Canvas;FFF)V
    .locals 13

    move v4, p2

    .line 370
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v2, 0x0

    move/from16 v3, p3

    invoke-virtual {p1, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    move/from16 v5, p4

    invoke-virtual {p1, v2, v2, p2, v5}, Landroid/graphics/Canvas;->clipRect(FFFF)Z

    .line 371
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    const/4 v9, 0x0

    invoke-virtual {v2, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    iget-object v3, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-boolean v3, v3, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->surface(Z)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v3, 0x0

    iget-object v6, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    const/4 v2, 0x0

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 372
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->covers:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/high16 v10, 0x40000000    # 2.0f

    const/4 v11, 0x1

    if-eqz v1, :cond_9

    .line 373
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v1, v1, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    const v2, 0x7f0b0564

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-nez v1, :cond_0

    move-object v1, v9

    goto :goto_0

    :cond_0
    const v2, 0x7f0b035d

    .line 374
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    :goto_0
    if-nez v1, :cond_1

    move-object v1, v9

    goto :goto_1

    .line 375
    :cond_1
    invoke-virtual {v1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    :goto_1
    if-nez v1, :cond_8

    .line 377
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v1, v1, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    const-string v2, "Artists"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const v1, 0x7f0801e1

    goto :goto_2

    :cond_2
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v1, v1, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    const-string v2, "Albums"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const v1, 0x7f08018e

    goto :goto_2

    .line 378
    :cond_3
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v1, v1, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    const-string v2, "Downloads"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    const v1, 0x7f080268

    goto :goto_2

    :cond_4
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v1, v1, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    const-string v2, "Updates"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    const v1, 0x7f0803f5

    goto :goto_2

    .line 379
    :cond_5
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v1, v1, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    const-string v2, "Mixes & Radio"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    const v1, 0x7f08035c

    goto :goto_2

    :cond_6
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v1, v1, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    const-string v2, "My Tracks"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    const v1, 0x7f080553

    goto :goto_2

    :cond_7
    const v1, 0x7f08045e

    .line 380
    :goto_2
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v2, v2, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    :cond_8
    if-eqz v1, :cond_c

    .line 382
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v2

    if-eqz v2, :cond_c

    .line 383
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-boolean v2, v2, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-static {v2}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const v2, 0x3eae147b    # 0.34f

    mul-float/2addr v2, p2

    .line 384
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    const v3, 0x3f28f5c3    # 0.66f

    mul-float/2addr v3, p2

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-virtual {v1, v2, v2, v3, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    goto :goto_6

    .line 387
    :cond_9
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->covers:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ne v1, v11, :cond_a

    move v2, v11

    goto :goto_3

    :cond_a
    const/4 v2, 0x4

    :goto_3
    if-ne v2, v11, :cond_b

    move v4, p2

    goto :goto_4

    :cond_b
    div-float v4, p2, v10

    :goto_4
    const/4 v3, 0x0

    :goto_5
    if-ge v3, v2, :cond_c

    .line 390
    iget-object v5, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->covers:Ljava/util/ArrayList;

    rem-int v6, v3, v1

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/graphics/drawable/Drawable;

    rem-int/lit8 v6, v3, 0x2

    int-to-float v6, v6

    mul-float/2addr v6, v4

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    div-int/lit8 v7, v3, 0x2

    int-to-float v7, v7

    mul-float/2addr v7, v4

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    int-to-float v8, v6

    add-float/2addr v8, v4

    .line 391
    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    int-to-float v12, v7

    add-float/2addr v12, v4

    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    move-result v12

    invoke-virtual {v5, v6, v7, v8, v12}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v5, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_5

    .line 394
    :cond_c
    :goto_6
    iget-object v1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-boolean v1, v1, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->surface(Z)I

    move-result v1

    const v2, 0xffffff

    and-int/2addr v1, v2

    .line 395
    iget-object v12, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/LinearGradient;

    const/high16 v3, -0x67000000

    or-int/2addr v3, v1

    iget-object v4, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-boolean v4, v4, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-virtual {p0, v4}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->surface(Z)I

    move-result v4

    filled-new-array {v3, v1, v1, v3, v4}, [I

    move-result-object v6

    const/4 v1, 0x5

    new-array v7, v1, [F

    fill-array-data v7, :array_0

    sget-object v8, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v1, v2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move v5, p2

    invoke-direct/range {v1 .. v8}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v12, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 396
    iget-object v6, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    move v4, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 397
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    iget-object v3, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-boolean v3, v3, Ldev/nino/squareglass/PageCoordinator$Page;->dark:Z

    invoke-static {v3}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    const-string v3, "sans-serif"

    invoke-static {v3, v11}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 398
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    iget-object v3, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    const/high16 v4, 0x41e00000    # 28.0f

    invoke-virtual {v3, v4}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 399
    iget-object v2, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object v2, v2, Ldev/nino/squareglass/PageCoordinator$Page;->title:Ljava/lang/String;

    div-float v3, p2, v10

    iget-object v4, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    const/high16 v5, 0x41f00000    # 30.0f

    invoke-virtual {v4, v5}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result v4

    int-to-float v4, v4

    add-float/2addr v4, p2

    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v2, v3, v4, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3e4ccccd    # 0.2f
        0x3f0ccccd    # 0.55f
        0x3f59999a    # 0.85f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V
    .locals 0

    .line 343
    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result p2

    if-nez p2, :cond_0

    invoke-virtual {p0, p3}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->height(Landroidx/recyclerview/widget/RecyclerView;)I

    move-result p0

    iput p0, p1, Landroid/graphics/Rect;->top:I

    :cond_0
    return-void
.end method

.method height(Landroidx/recyclerview/widget/RecyclerView;)I
    .locals 1

    .line 337
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v0

    if-gtz v0, :cond_0

    .line 338
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    :cond_0
    if-gtz v0, :cond_1

    .line 339
    iget-object p1, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object p1, p1, Ldev/nino/squareglass/PageCoordinator$Page;->root:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    iget v0, p1, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 340
    :cond_1
    iget-object p0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->page:Ldev/nino/squareglass/PageCoordinator$Page;

    iget-object p1, p0, Ldev/nino/squareglass/PageCoordinator$Page;->movingAction:Landroid/view/View;

    if-nez p1, :cond_2

    const/high16 p1, 0x42b00000    # 88.0f

    goto :goto_0

    :cond_2
    const/high16 p1, 0x43180000    # 152.0f

    :goto_0
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/PageCoordinator$Page;->dp(F)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public onDraw(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V
    .locals 2

    const/4 v0, 0x0

    .line 364
    :goto_0
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p2, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p2, v1}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {p2, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_1
    if-nez v0, :cond_2

    .line 365
    invoke-virtual {p3}, Landroidx/recyclerview/widget/RecyclerView$State;->getItemCount()I

    move-result p3

    if-lez p3, :cond_2

    return-void

    :cond_2
    if-nez v0, :cond_3

    const/4 p3, 0x0

    goto :goto_2

    .line 366
    :cond_3
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result p3

    invoke-virtual {p0, p2}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->height(Landroidx/recyclerview/widget/RecyclerView;)I

    move-result v0

    sub-int/2addr p3, v0

    int-to-float p3, p3

    :goto_2
    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    .line 367
    invoke-virtual {p0, p2}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->height(Landroidx/recyclerview/widget/RecyclerView;)I

    move-result p2

    int-to-float p2, p2

    invoke-virtual {p0, p1, v0, p3, p2}, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->draw(Landroid/graphics/Canvas;FFF)V

    return-void
.end method

.method surface(Z)I
    .locals 1

    .line 361
    iget-object v0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->seeds:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result p0

    return p0

    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/PageCoordinator$HeroDecoration;->seeds:Ljava/util/ArrayList;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-static {p0, p1}, Ldev/nino/squareglass/CoverColors;->surface(IZ)I

    move-result p0

    return p0
.end method
