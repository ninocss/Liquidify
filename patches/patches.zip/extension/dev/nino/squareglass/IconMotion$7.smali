.class public final synthetic Ldev/nino/squareglass/IconMotion$7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableIntState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/IconMotion$7;->f$0:Landroidx/compose/animation/core/Animatable;

    iput-object p2, p0, Ldev/nino/squareglass/IconMotion$7;->f$1:Landroidx/compose/runtime/MutableIntState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/IconMotion$7;->f$0:Landroidx/compose/animation/core/Animatable;

    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$7;->f$1:Landroidx/compose/runtime/MutableIntState;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/IconMotion;->$r8$lambda$BMOtxV--Ke_F2PVMdEdrSsa5Lsc(Landroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
