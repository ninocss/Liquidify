.class public final synthetic Ldev/nino/squareglass/LinnPlayer$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:J

.field public final synthetic f$2:I

.field public final synthetic f$3:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;JII)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$0;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-wide p2, p0, Ldev/nino/squareglass/LinnPlayer$0;->f$1:J

    iput p4, p0, Ldev/nino/squareglass/LinnPlayer$0;->f$2:I

    iput p5, p0, Ldev/nino/squareglass/LinnPlayer$0;->f$3:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$0;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-wide v1, p0, Ldev/nino/squareglass/LinnPlayer$0;->f$1:J

    iget v3, p0, Ldev/nino/squareglass/LinnPlayer$0;->f$2:I

    iget p0, p0, Ldev/nino/squareglass/LinnPlayer$0;->f$3:I

    invoke-static {v0, v1, v2, v3, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$_8o0jQO4NdqV5ltaY5URG_dHFmI(Ldev/nino/squareglass/LinnPlayer;JII)V

    return-void
.end method
