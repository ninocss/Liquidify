.class public final synthetic Ldev/nino/squareglass/LinnPlayer$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:J

.field public final synthetic f$2:Lcom/aspiro/wamp/enums/MusicServiceState;

.field public final synthetic f$3:I

.field public final synthetic f$4:I

.field public final synthetic f$5:Ldev/nino/squareglass/OpenHome;

.field public final synthetic f$6:I

.field public final synthetic f$7:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;JLcom/aspiro/wamp/enums/MusicServiceState;IILdev/nino/squareglass/OpenHome;II)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-wide p2, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$1:J

    iput-object p4, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$2:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput p5, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$3:I

    iput p6, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$4:I

    iput-object p7, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$5:Ldev/nino/squareglass/OpenHome;

    iput p8, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$6:I

    iput p9, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$7:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-wide v1, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$1:J

    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$2:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget v4, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$3:I

    iget v5, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$4:I

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$5:Ldev/nino/squareglass/OpenHome;

    iget v7, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$6:I

    iget v8, p0, Ldev/nino/squareglass/LinnPlayer$2;->f$7:I

    invoke-static/range {v0 .. v8}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$i1GphCa2Y40br91Z-c20rkMd_vA(Ldev/nino/squareglass/LinnPlayer;JLcom/aspiro/wamp/enums/MusicServiceState;IILdev/nino/squareglass/OpenHome;II)V

    return-void
.end method
