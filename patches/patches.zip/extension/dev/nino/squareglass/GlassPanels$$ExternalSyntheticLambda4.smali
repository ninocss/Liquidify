.class public final synthetic Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(ZZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda4;->f$0:Z

    iput-boolean p2, p0, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda4;->f$1:Z

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-boolean v0, p0, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda4;->f$0:Z

    iget-boolean p0, p0, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda4;->f$1:Z

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/GlassPanels;->$r8$lambda$2rWKAtZBD0Ppy5VrI5OdT44UeXY(ZZLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
