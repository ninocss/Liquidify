.class public final synthetic Ldev/nino/squareglass/SquareOutput$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareOutput$Request;

.field public final synthetic f$1:Ljava/lang/Object;

.field public final synthetic f$2:Z


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareOutput$Request;Ljava/lang/Object;Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$$ExternalSyntheticLambda1;->f$0:Ldev/nino/squareglass/SquareOutput$Request;

    iput-object p2, p0, Ldev/nino/squareglass/SquareOutput$$ExternalSyntheticLambda1;->f$1:Ljava/lang/Object;

    iput-boolean p3, p0, Ldev/nino/squareglass/SquareOutput$$ExternalSyntheticLambda1;->f$2:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$$ExternalSyntheticLambda1;->f$0:Ldev/nino/squareglass/SquareOutput$Request;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$$ExternalSyntheticLambda1;->f$1:Ljava/lang/Object;

    iget-boolean p0, p0, Ldev/nino/squareglass/SquareOutput$$ExternalSyntheticLambda1;->f$2:Z

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/SquareOutput;->lambda$result$3(Ldev/nino/squareglass/SquareOutput$Request;Ljava/lang/Object;Z)V

    return-void
.end method
