.class public final synthetic Ldev/nino/squareglass/SleepTimer$16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/widget/LinearLayout;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/LinearLayout;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$16;->f$0:Landroid/widget/LinearLayout;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$16;->f$0:Landroid/widget/LinearLayout;

    invoke-static {p0}, Ldev/nino/squareglass/SleepTimer;->lambda$content$9(Landroid/widget/LinearLayout;)V

    return-void
.end method
