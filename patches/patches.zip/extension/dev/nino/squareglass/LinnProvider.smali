.class public final Ldev/nino/squareglass/LinnProvider;
.super Ljava/lang/Object;
.source "LinnProvider.java"

# interfaces
.implements Lcom/aspiro/wamp/broadcast/o;
.implements Lcom/aspiro/wamp/broadcast/q;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnProvider$Phase;,
        Ldev/nino/squareglass/LinnProvider$Device;
    }
.end annotation


# static fields
.field static instance:Ldev/nino/squareglass/LinnProvider;

.field static previousOutput:Ljava/lang/Object;


# instance fields
.field final app:Landroid/app/Application;

.field volatile attemptExpires:J

.field volatile connected:Ldev/nino/squareglass/LinnProvider$Device;

.field volatile connecting:Z

.field final controls:Ljava/util/concurrent/ScheduledExecutorService;

.field final descriptions:Ljava/util/concurrent/ExecutorService;

.field final devices:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Ldev/nino/squareglass/LinnProvider$Device;",
            ">;"
        }
    .end annotation
.end field

.field final discovery:Ljava/util/concurrent/ScheduledExecutorService;

.field error:Ljava/lang/String;

.field volatile generation:I

.field final io:Ljava/util/concurrent/ScheduledExecutorService;

.field final listeners:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lcom/aspiro/wamp/broadcast/l;",
            ">;"
        }
    .end annotation
.end field

.field final main:Landroid/os/Handler;

.field private multicast:Landroid/net/wifi/WifiManager$MulticastLock;

.field final nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

.field final observations:Ljava/util/concurrent/ScheduledExecutorService;

.field volatile pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

.field volatile phase:Ldev/nino/squareglass/LinnProvider$Phase;

.field volatile player:Ldev/nino/squareglass/LinnPlayer;

.field final probing:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field volatile resuming:Z

.field private scan:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field private volatile scanRevision:I

.field private volatile scanSocket:Ldev/nino/squareglass/LinnDiscovery;

.field volatile scanning:Z

.field volatile status:Ljava/lang/String;

.field final warming:Ljava/util/concurrent/ExecutorService;


# direct methods
.method public static synthetic $r8$lambda$2Oif7dmuUvDerlQxzRjjYmOp-Yc(Ldev/nino/squareglass/LinnProvider;Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$2(Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$6yos42bJ7LF1iNW5WMJUfNykryM(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$startScanning$0(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$8PQWCPbvaFjUW4qWAtwPAJll5ys(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$cancelPending$1(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$8xvVZldc7e-oyfKtPaO02mtkpHM(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$1(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$ASTpsM-6QmW3x4J9RJJeYg20KVU(Ldev/nino/squareglass/LinnProvider;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$disconnect$1(Lcom/aspiro/wamp/broadcast/o$a;)V

    return-void
.end method

.method public static synthetic $r8$lambda$C5-KHAT7lwITSm96RdLjvJASFA8(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$0(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$E84mqVg35V9udAGA8RCqMGOeKQM(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$cancelPending$0(Ldev/nino/squareglass/LinnPlayer;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$HRP-KBhs76g5oxTVnAhlzAPMz6w(Ldev/nino/squareglass/LinnProvider;ILjava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$cancelPending$2(ILjava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$I9Bd14rjlEU7DYbb7aScz9Gflzo(Ldev/nino/squareglass/LinnProvider;ILjava/lang/String;Ldev/nino/squareglass/LinnDiscovery$Result;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnProvider;->lambda$probe$0(ILjava/lang/String;Ldev/nino/squareglass/LinnDiscovery$Result;)V

    return-void
.end method

.method public static synthetic $r8$lambda$JEKwYdNfW4zVJkOVgmrH88irsOE(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$fail$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$KSiDzmC9G5OnGaAAM21ewjtvLR0(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$discover$2(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$NRCArMq53K_bjiwnS2HJ1Boi-l8(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnProvider$Device;ZLdev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$0(ILdev/nino/squareglass/LinnProvider$Device;ZLdev/nino/squareglass/LinnPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$PBhnG2EntXHWViDY823CrwPMUXY(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$disconnect$2(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    return-void
.end method

.method public static synthetic $r8$lambda$R_5M9YtCFkgIqqA-ra_TEZzyRZk(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$new$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$SIEBN24T3e3LtMcWEoAQFIgvjkY(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnProvider$Device;Ldev/nino/squareglass/OpenHome;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnProvider;->lambda$probe$1(ILdev/nino/squareglass/LinnProvider$Device;Ldev/nino/squareglass/OpenHome;)V

    return-void
.end method

.method public static synthetic $r8$lambda$U-SezvwHkaPK8-pV9LHVRz5etsU(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnDiscovery$Result;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$discover$0(ILdev/nino/squareglass/LinnDiscovery$Result;)V

    return-void
.end method

.method public static synthetic $r8$lambda$UwK1_pduPgaEwNWpgtl4UTwLCjQ(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$2(ILdev/nino/squareglass/LinnPlayer;Ljava/lang/Throwable;)V

    return-void
.end method

.method public static synthetic $r8$lambda$XOZ6mDeLvoo7rYWQXrPyUZl6Pzo(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$disconnect$0(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Z3oXZgY_R1TkXqRRtL1ieydEL3g(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$new$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$_edkY1QVjBDHAjeXuHZeW4_AZvA(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/OpenHome;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$probe$3(ILdev/nino/squareglass/OpenHome;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ax5556ZbJkfwpna-pNfxocxZ3RA(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$1(ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$kpH75q0BKWCY8moE0TwgkQfLfj4(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$init$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$m-xFfeQWEE1kUJlMjrGKkHMx_Xo(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$discover$1(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$qMEcuJI_vwXD3hBE0lfqWA71kGs(Ldev/nino/squareglass/LinnProvider;ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$3(ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method public static synthetic $r8$lambda$sMYMrliqXRNlfWJUktkPnVcRziU(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$notifyDevices$0(I)V

    return-void
.end method

.method public constructor <init>(Landroid/app/Application;)V
    .locals 2

    .line 60
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    .line 18
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    .line 19
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    .line 20
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->observations:Ljava/util/concurrent/ScheduledExecutorService;

    .line 21
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    const/4 v0, 0x2

    .line 22
    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/LinnProvider;->descriptions:Ljava/util/concurrent/ExecutorService;

    .line 23
    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->warming:Ljava/util/concurrent/ExecutorService;

    .line 24
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->probing:Ljava/util/concurrent/ConcurrentHashMap;

    .line 25
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 26
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    .line 27
    new-instance v0, Ldev/nino/squareglass/LinnNativeVolume;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnNativeVolume;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    .line 33
    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    .line 34
    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    .line 43
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 61
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    sput-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    .line 62
    new-instance v0, Ldev/nino/squareglass/LinnProvider$23;

    invoke-direct {v0}, Ldev/nino/squareglass/LinnProvider$23;-><init>()V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    .line 63
    :try_start_0
    new-instance v0, Ldev/nino/squareglass/LinnNetwork;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$24;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnProvider$24;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-direct {v0, p1, v1}, Ldev/nino/squareglass/LinnNetwork;-><init>(Landroid/app/Application;Ljava/lang/Runnable;)V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->network:Ldev/nino/squareglass/OpenHome$NetworkBinding;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 67
    :catch_0
    sget-object p0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    const-string p1, "network_binding=unavailable"

    invoke-interface {p0, p1}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    return-void
.end method

.method public static addAddress(Ljava/lang/String;)V
    .locals 3

    .line 187
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-nez v0, :cond_0

    return-void

    .line 188
    :cond_0
    const-string v1, "http://"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "[0-9]{1,3}(\\.[0-9]{1,3}){3}"

    invoke-virtual {p0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string p0, "Enter a local IP or the discovered device description URL."

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void

    .line 189
    :cond_1
    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$7;

    invoke-direct {v2, p0, v0}, Ldev/nino/squareglass/LinnProvider$7;-><init>(Ljava/lang/String;Ldev/nino/squareglass/LinnProvider;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static canRestoreSelection(Ljava/lang/Object;)Z
    .locals 1

    .line 308
    instance-of v0, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-eqz v0, :cond_0

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    iget-boolean v0, v0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    check-cast p0, Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public static confirmed(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 338
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    .line 339
    instance-of v1, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_1

    if-eqz v0, :cond_0

    iget-object p0, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz p0, :cond_0

    iget-object p0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz p0, :cond_0

    iget-object p0, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    return-object p0

    :cond_0
    sget-object p0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    :cond_1
    return-object p0
.end method

.method public static directSelection(Ljava/lang/Object;)Z
    .locals 2

    .line 310
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    .line 311
    instance-of v1, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_2

    if-eqz v0, :cond_2

    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v1, :cond_2

    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v1, :cond_0

    goto :goto_0

    .line 312
    :cond_0
    iget-boolean v1, v0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v1, :cond_1

    check-cast p0, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/LinnProvider;->connect(Lp2/a;)V

    :cond_1
    const/4 p0, 0x1

    return p0

    :cond_2
    :goto_0
    const/4 p0, 0x0

    return p0
.end method

.method static explain(Ljava/lang/Throwable;)Ljava/lang/String;
    .locals 1

    .line 326
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    .line 327
    invoke-virtual {p0}, Ljava/lang/Throwable;->getSuppressed()[Ljava/lang/Throwable;

    move-result-object p0

    array-length p0, p0

    if-lez p0, :cond_0

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ". Wiederherstellung nicht best\u00e4tigt; Ger\u00e4tezustand vor erneutem Versuch pr\u00fcfen."

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v0
.end method

.method public static label(Ljava/lang/Object;)Ljava/lang/String;
    .locals 3

    .line 334
    instance-of v0, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_0

    sget-object v1, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-eqz v1, :cond_0

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_0

    move-object v1, p0

    check-cast v1, Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    sget-object v2, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    return-object p0

    :cond_0
    if-eqz v0, :cond_2

    check-cast p0, Ldev/nino/squareglass/LinnProvider$Device;

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->verified:Z

    if-eqz p0, :cond_1

    const-string p0, "Linn \u00b7 OpenHome"

    return-object p0

    :cond_1
    const-string p0, "Zuletzt verwendet \u00b7 Ger\u00e4t pr\u00fcfen\u2026"

    return-object p0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method static synthetic lambda$addAddress$0(Ljava/lang/String;Ldev/nino/squareglass/LinnProvider;)V
    .locals 6

    .line 192
    :try_start_0
    const-string v0, "http://"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/16 v0, 0xdac

    invoke-static {p0, v0}, Ldev/nino/squareglass/OpenHome;->discover(Ljava/lang/String;I)Ljava/util/Set;

    move-result-object p0

    .line 193
    :goto_0
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v0, 0x0

    move v1, v0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 194
    invoke-static {v1}, Ldev/nino/squareglass/OpenHome;->cached(Ljava/lang/String;)Ldev/nino/squareglass/OpenHome;

    move-result-object v2

    new-instance v3, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v3, v2}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    iget-object v4, p1, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v5, v3, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v4, v5, v3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 195
    iget-object v3, p1, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v4, "squareglass_linn"

    invoke-virtual {v3, v4, v0}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "location"

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "uuid"

    iget-object v4, v2, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-interface {v1, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "name"

    iget-object v2, v2, Ldev/nino/squareglass/OpenHome;->name:Ljava/lang/String;

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v1, 0x1

    goto :goto_1

    :cond_1
    if-eqz v1, :cond_2

    .line 198
    iget-object p0, p1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$0;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/LinnProvider$0;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 197
    :cond_2
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "No Linn renderer answered at this address."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    .line 199
    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$addAddress$1(Ldev/nino/squareglass/LinnProvider;)V
    .locals 1

    .line 198
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {v0}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->changed()V

    return-void
.end method

.method private synthetic lambda$cancelPending$0(Ldev/nino/squareglass/LinnPlayer;I)V
    .locals 8

    .line 292
    const-string v0, "Playlist"

    sget-object v1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v4, 0x12a05f200L

    add-long/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 294
    :try_start_0
    iget-boolean v1, p1, Ldev/nino/squareglass/LinnPlayer;->rollbackConfirmed:Z

    if-eqz v1, :cond_1

    .line 295
    iget-boolean v1, p1, Ldev/nino/squareglass/LinnPlayer;->transferred:Z

    if-eqz v1, :cond_0

    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v2, "Pause"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/String;

    invoke-virtual {v1, v0, v2, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v3, "Id"

    invoke-virtual {v1, v0, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    const-string v5, "Paused"

    const-wide/16 v6, 0x1388

    invoke-virtual/range {v2 .. v7}, Ldev/nino/squareglass/OpenHome;->confirm(JLjava/lang/String;J)V

    .line 296
    :cond_0
    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->close()V

    .line 297
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$14;

    invoke-direct {v0, p0, p2}, Ldev/nino/squareglass/LinnProvider$14;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 305
    :goto_0
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    .line 294
    :cond_1
    :try_start_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Wiederherstellung nicht best\u00e4tigt; Ger\u00e4tezustand vor erneutem Versuch pr\u00fcfen."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    move-exception v0

    move-object p1, v0

    .line 304
    :try_start_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$15;

    invoke-direct {v1, p0, p2, p1}, Ldev/nino/squareglass/LinnProvider$15;-><init>(Ldev/nino/squareglass/LinnProvider;ILjava/lang/Exception;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    move-object p0, v0

    .line 305
    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    throw p0
.end method

.method private synthetic lambda$cancelPending$1(I)V
    .locals 1

    .line 298
    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    return-void

    :cond_0
    const/4 p1, 0x0

    .line 299
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

    const/4 p1, 0x0

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    .line 300
    sget-object p1, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->restoreLocalSelection(Ljava/lang/Object;)V

    .line 301
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-nez p1, :cond_1

    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    goto :goto_0

    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    iget-boolean p1, p1, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz p1, :cond_2

    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    goto :goto_0

    :cond_2
    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    :goto_0
    const-string v0, ""

    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 302
    const-string p0, "Verbindung abgebrochen"

    invoke-static {p0}, Ldev/nino/squareglass/SquareOutput;->linnFailure(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$cancelPending$2(ILjava/lang/Exception;)V
    .locals 1

    .line 304
    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne p1, v0, :cond_0

    const/4 p1, 0x0

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    invoke-virtual {p2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$connect$0(ILdev/nino/squareglass/LinnProvider$Device;ZLdev/nino/squareglass/LinnPlayer;)V
    .locals 9

    const-string v1, "Linn adapter connection failed: "

    .line 219
    sget-object v0, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 220
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    iget-wide v2, p0, Ldev/nino/squareglass/LinnProvider;->attemptExpires:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 221
    const-string v0, "Queue transfer started"

    const-string v2, "SquareLinn"

    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 223
    :try_start_0
    invoke-virtual {p2}, Ldev/nino/squareglass/LinnProvider$Device;->resolve()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/LinkageError; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p3, :cond_0

    .line 224
    :try_start_1
    iget-object v0, p2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->preflight()Ljava/lang/String;

    invoke-virtual {p4}, Ldev/nino/squareglass/LinnPlayer;->prepareReady()V

    invoke-virtual {p4}, Ldev/nino/squareglass/LinnPlayer;->adoptExisting()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/LinkageError; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    move-exception v0

    move-object p2, v0

    move-object v4, p0

    move v5, p1

    move-object v6, p4

    goto :goto_3

    :cond_0
    :try_start_2
    invoke-virtual {p4}, Ldev/nino/squareglass/LinnPlayer;->transfer()V

    const/4 v0, 0x1

    iput-boolean v0, p4, Ldev/nino/squareglass/LinnPlayer;->transferred:Z

    .line 225
    :goto_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v3, Ldev/nino/squareglass/LinnProvider$1;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/LinkageError; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object v4, p0

    move v5, p1

    move-object v7, p2

    move v8, p3

    move-object v6, p4

    :try_start_3
    invoke-direct/range {v3 .. v8}, Ldev/nino/squareglass/LinnProvider$1;-><init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/LinkageError; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 244
    :goto_1
    sget-object p0, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catch_1
    move-exception v0

    goto :goto_2

    :catch_2
    move-exception v0

    move-object v4, p0

    move v5, p1

    move-object v6, p4

    :goto_2
    move-object p2, v0

    .line 239
    :goto_3
    :try_start_4
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p0, v4, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance p1, Ldev/nino/squareglass/LinnProvider$2;

    invoke-direct {p1, v4, v5, v6, p2}, Ldev/nino/squareglass/LinnProvider$2;-><init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ljava/lang/Throwable;)V

    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v0

    move-object p0, v0

    .line 244
    sget-object p1, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    throw p0
.end method

.method private synthetic lambda$connect$1(ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V
    .locals 2

    .line 226
    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->close()V

    return-void

    .line 227
    :cond_0
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz p1, :cond_1

    if-eq p1, p2, :cond_1

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->close()V

    .line 228
    :cond_1
    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    const/4 p1, 0x0

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    const/4 v0, 0x0

    .line 229
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

    .line 230
    invoke-static {p2}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    .line 231
    invoke-static {p3}, Ldev/nino/squareglass/NativeOutputBridge;->confirmSelection(Ljava/lang/Object;)V

    .line 232
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    invoke-virtual {v0, v1, p1}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object v0, p3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v0, v0, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    const-string v1, "location"

    invoke-interface {p1, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object v0, p3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v0, v0, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    .line 233
    const-string v1, "uuid"

    invoke-interface {p1, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object p3, p3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object p3, p3, Ldev/nino/squareglass/OpenHome;->name:Ljava/lang/String;

    const-string v0, "name"

    invoke-interface {p1, v0, p3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-boolean p3, p2, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    xor-int/lit8 p3, p3, 0x1

    const-string v0, "autoResume"

    invoke-interface {p1, v0, p3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 234
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p3, p0}, Lcom/aspiro/wamp/broadcast/l;->a(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    .line 235
    :cond_2
    iget-boolean p1, p2, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez p1, :cond_3

    if-eqz p4, :cond_3

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    .line 236
    :cond_3
    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->start()V

    .line 237
    iget-boolean p1, p2, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz p1, :cond_4

    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    goto :goto_1

    :cond_4
    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    :goto_1
    iget-boolean p2, p2, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz p2, :cond_5

    const-string p2, "Bereit \u2013 Musik ausw\u00e4hlen"

    goto :goto_2

    :cond_5
    const-string p2, ""

    :goto_2
    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$connect$2(ILdev/nino/squareglass/LinnPlayer;Ljava/lang/Throwable;)V
    .locals 1

    .line 240
    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    return-void

    .line 241
    :cond_0
    iget-boolean p1, p2, Ldev/nino/squareglass/LinnPlayer;->rollbackConfirmed:Z

    if-eqz p1, :cond_1

    const/4 p1, 0x0

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

    :cond_1
    const/4 p1, 0x0

    .line 242
    iput-boolean p1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    sget-object p1, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->restoreLocalSelection(Ljava/lang/Object;)V

    invoke-static {p3}, Ldev/nino/squareglass/LinnProvider;->explain(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$disconnect$0(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 13

    .line 251
    const-string v0, "Time"

    sget-object v1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v4, 0x165a0bc00L

    add-long/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v1, 0x0

    .line 253
    :try_start_0
    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v2, :cond_1

    .line 254
    iget-boolean v3, v2, Ldev/nino/squareglass/LinnPlayer;->rollbackConfirmed:Z

    if-eqz v3, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Linn recovery was not confirmed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 255
    :cond_1
    :goto_0
    const-string v3, "Pause"

    const-string v4, "Id"

    const-string v5, "Playlist"

    if-eqz v2, :cond_2

    :try_start_1
    iget-boolean v6, v2, Ldev/nino/squareglass/LinnPlayer;->transferred:Z

    if-eqz v6, :cond_2

    .line 256
    iget-object v6, v2, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v6, v6, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-array v7, v1, [Ljava/lang/String;

    invoke-virtual {v6, v5, v3, v7}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 257
    iget-object v6, v2, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v7, v6, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v6, v2, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v6, v6, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v6, v5, v4}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8

    const-string v10, "Paused"

    const-wide/16 v11, 0x1388

    invoke-virtual/range {v7 .. v12}, Ldev/nino/squareglass/OpenHome;->confirm(JLjava/lang/String;J)V

    .line 258
    invoke-virtual {v2}, Ldev/nino/squareglass/LinnPlayer;->close()V

    :cond_2
    if-nez p1, :cond_3

    .line 260
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$27;

    invoke-direct {v0, p0, p2}, Ldev/nino/squareglass/LinnProvider$27;-><init>(Ldev/nino/squareglass/LinnProvider;Lcom/aspiro/wamp/broadcast/o$a;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 283
    :goto_1
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    .line 261
    :cond_3
    :try_start_2
    iget-boolean v2, p1, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v2, :cond_4

    .line 262
    iget-object v2, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-array v6, v1, [Ljava/lang/String;

    invoke-virtual {v2, v5, v3, v6}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 263
    iget-object v2, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v6, v2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v2, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v2, v5, v4}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    const-string v9, "Paused"

    const-wide/16 v10, 0x1388

    invoke-virtual/range {v6 .. v11}, Ldev/nino/squareglass/OpenHome;->confirm(JLjava/lang/String;J)V

    .line 264
    iget-object v2, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-array v3, v1, [Ljava/lang/String;

    invoke-virtual {v2, v0, v0, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    .line 265
    const-string v2, "Seconds"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    mul-int/lit16 v0, v0, 0x3e8

    iput v0, p1, Ldev/nino/squareglass/LinnPlayer;->position:I

    .line 266
    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0, v5, v4}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    if-ltz v0, :cond_4

    .line 267
    iget-object v2, p1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p1, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 269
    :cond_4
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 270
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$28;

    invoke-direct {v2, p0, p1, p2}, Ldev/nino/squareglass/LinnProvider$28;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1

    .line 282
    :catch_0
    :try_start_3
    iput-boolean v1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    const-string p1, "Could not confirm Linn pause. Retry before switching outputs."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto/16 :goto_1

    :catchall_0
    move-exception v0

    move-object p0, v0

    .line 283
    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    throw p0
.end method

.method private synthetic lambda$disconnect$1(Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 2

    const/4 v0, 0x0

    .line 260
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    invoke-static {p1}, Ldev/nino/squareglass/NativeLinnBridge;->disconnected(Ljava/lang/Object;)V

    return-void
.end method

.method private synthetic lambda$disconnect$2(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 4

    const/4 v0, 0x0

    .line 271
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->close()V

    .line 272
    sget-object v1, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v2, ""

    invoke-virtual {p0, v1, v2}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 273
    iget-boolean v1, p1, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v1, :cond_0

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->persist()V

    .line 274
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v2, "squareglass_linn"

    invoke-virtual {v1, v2, v0}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "autoResume"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 275
    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget v2, p1, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget v3, p1, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {v1, v2, v3}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    .line 276
    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-static {v1}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    .line 278
    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v1}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    iget-boolean v1, p1, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v1, :cond_1

    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    iget v2, p1, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-interface {v1, v2, v0, v0}, Lcom/aspiro/wamp/player/k0;->onActionPlayPosition(IZZ)V

    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    iget p1, p1, Ldev/nino/squareglass/LinnPlayer;->position:I

    invoke-interface {v0, p1}, Lcom/aspiro/wamp/player/k0;->onActionSeekTo(I)V

    .line 279
    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {v0, p0}, Lcom/aspiro/wamp/broadcast/l;->d(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    .line 280
    :cond_2
    invoke-static {p2}, Ldev/nino/squareglass/NativeLinnBridge;->disconnected(Ljava/lang/Object;)V

    return-void
.end method

.method private synthetic lambda$discover$0(ILdev/nino/squareglass/LinnDiscovery$Result;)V
    .locals 1

    .line 143
    iget-object v0, p2, Ldev/nino/squareglass/LinnDiscovery$Result;->location:Ljava/lang/String;

    invoke-virtual {p0, v0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->probe(Ljava/lang/String;ILdev/nino/squareglass/LinnDiscovery$Result;)V

    return-void
.end method

.method private synthetic lambda$discover$1(I)V
    .locals 8

    .line 145
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_4

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-eq p1, v0, :cond_0

    goto :goto_1

    .line 146
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "LINN_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v2, "squareglass_linn"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "uuid"

    const-string v4, ""

    invoke-interface {v1, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 147
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ldev/nino/squareglass/LinnProvider$Device;

    iget-wide v4, v2, Ldev/nino/squareglass/LinnProvider$Device;->expires:J

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v6

    cmp-long v4, v4, v6

    if-gez v4, :cond_1

    iget-object v4, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eq v2, v4, :cond_1

    .line 148
    iget-object v4, v2, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    iput-boolean v3, v2, Ldev/nino/squareglass/LinnProvider$Device;->verified:Z

    goto :goto_0

    :cond_2
    iget-object v4, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v5, v2, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v4, v5, v2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    goto :goto_0

    .line 150
    :cond_3
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->notifyDevices(I)V

    :cond_4
    :goto_1
    return-void
.end method

.method private synthetic lambda$discover$2(I)V
    .locals 0

    .line 153
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->discover(I)V

    return-void
.end method

.method private synthetic lambda$fail$0()V
    .locals 3

    .line 321
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-nez v0, :cond_0

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->restoreLocalSelection(Ljava/lang/Object;)V

    .line 322
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    invoke-static {p0}, Ldev/nino/squareglass/SquareOutput;->linnFailure(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$init$0()V
    .locals 1

    const/4 v0, 0x0

    .line 81
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnProvider;->resume(I)V

    return-void
.end method

.method static synthetic lambda$new$0(Ljava/lang/String;)V
    .locals 1

    .line 62
    const-string v0, "SquareLinn"

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private synthetic lambda$new$1()V
    .locals 2

    .line 63
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$26;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnProvider$26;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic lambda$new$2()V
    .locals 3

    .line 64
    invoke-static {}, Ldev/nino/squareglass/OpenHome;->invalidateDescriptions()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldev/nino/squareglass/LinnProvider$Device;

    const/4 v2, 0x0

    iput-boolean v2, v1, Ldev/nino/squareglass/LinnProvider$Device;->verified:Z

    goto :goto_0

    .line 65
    :cond_0
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnProvider;->startScanning()V

    .line 66
    :cond_1
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz p0, :cond_2

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Ldev/nino/squareglass/LinnPlayer;->nextRecovery:J

    const/4 v0, 0x3

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->eventChanged()V

    :cond_2
    return-void
.end method

.method private synthetic lambda$notifyDevices$0(I)V
    .locals 1

    .line 155
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_1

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-ne p1, v0, :cond_1

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p1}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->linnDevicesChanged()V

    :cond_1
    return-void
.end method

.method private synthetic lambda$probe$0(ILjava/lang/String;Ldev/nino/squareglass/LinnDiscovery$Result;)V
    .locals 6

    .line 160
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_b

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-eq p1, v0, :cond_0

    goto/16 :goto_3

    .line 161
    :cond_0
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v3, 0xb2d05e00L

    add-long/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 163
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v3, v1, Ldev/nino/squareglass/LinnProvider$Device;->location:Ljava/lang/String;

    invoke-virtual {v3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_0

    :cond_2
    move-object v1, v2

    :goto_0
    if-eqz p3, :cond_5

    if-eqz v1, :cond_5

    .line 164
    iget-object v0, v1, Ldev/nino/squareglass/LinnProvider$Device;->bootId:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, v1, Ldev/nino/squareglass/LinnProvider$Device;->bootId:Ljava/lang/String;

    iget-object v3, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->bootId:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    :cond_3
    iget-object v0, v1, Ldev/nino/squareglass/LinnProvider$Device;->configId:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_5

    iget-object v0, v1, Ldev/nino/squareglass/LinnProvider$Device;->configId:Ljava/lang/String;

    iget-object v1, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->configId:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    :cond_4
    invoke-static {}, Ldev/nino/squareglass/OpenHome;->invalidateDescriptions()V

    .line 165
    :cond_5
    sget-object v0, Ldev/nino/squareglass/OpenHome;->descriptions:Ldev/nino/squareglass/LinnCache;

    invoke-virtual {v0, p2}, Ldev/nino/squareglass/LinnCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/OpenHome;

    if-eqz v0, :cond_6

    if-eqz p3, :cond_6

    .line 166
    iget-object v1, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->uuid:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_6

    iget-object v1, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->uuid:Ljava/lang/String;

    iget-object v3, v0, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    invoke-static {}, Ldev/nino/squareglass/OpenHome;->invalidateDescriptions()V

    goto :goto_1

    :cond_6
    move-object v2, v0

    .line 167
    :goto_1
    invoke-static {p2}, Ldev/nino/squareglass/OpenHome;->cached(Ljava/lang/String;)Ldev/nino/squareglass/OpenHome;

    move-result-object v0

    if-eqz p3, :cond_8

    .line 168
    iget-object v1, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->uuid:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_8

    iget-object v1, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->uuid:Ljava/lang/String;

    iget-object v3, v0, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    goto :goto_2

    :cond_7
    new-instance p3, Ljava/io/IOException;

    const-string v0, "Renderer identity changed during discovery"

    invoke-direct {p3, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p3

    :cond_8
    :goto_2
    if-eqz v2, :cond_9

    if-nez p3, :cond_9

    .line 169
    const-string v1, "Playlist"

    const-string v2, "TransportState"

    invoke-virtual {v0, v1, v2}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 170
    :cond_9
    new-instance v1, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v1, v0}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    if-eqz p3, :cond_a

    .line 171
    iget-object v2, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->bootId:Ljava/lang/String;

    iput-object v2, v1, Ldev/nino/squareglass/LinnProvider$Device;->bootId:Ljava/lang/String;

    iget-object v2, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->configId:Ljava/lang/String;

    iput-object v2, v1, Ldev/nino/squareglass/LinnProvider$Device;->configId:Ljava/lang/String;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    iget-wide v4, p3, Ldev/nino/squareglass/LinnDiscovery$Result;->leaseNanos:J

    add-long/2addr v2, v4

    iput-wide v2, v1, Ldev/nino/squareglass/LinnProvider$Device;->expires:J

    .line 172
    :cond_a
    iget-object p3, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$21;

    invoke-direct {v2, p0, p1, v1, v0}, Ldev/nino/squareglass/LinnProvider$21;-><init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnProvider$Device;Ldev/nino/squareglass/OpenHome;)V

    invoke-virtual {p3, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 180
    iget-object p3, p0, Ldev/nino/squareglass/LinnProvider;->warming:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$22;

    invoke-direct {v1, p0, p1, v0}, Ldev/nino/squareglass/LinnProvider$22;-><init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/OpenHome;)V

    invoke-interface {p3, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 182
    sget-object p3, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p3}, Ljava/lang/ThreadLocal;->remove()V

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->probing:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0, p2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    return-void

    :catchall_0
    move-exception p3

    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->remove()V

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->probing:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0, p2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    throw p3

    :catch_0
    sget-object p3, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p3}, Ljava/lang/ThreadLocal;->remove()V

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->probing:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0, p2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    return-void

    .line 160
    :cond_b
    :goto_3
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->probing:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0, p2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    return-void
.end method

.method private synthetic lambda$probe$1(ILdev/nino/squareglass/LinnProvider$Device;Ldev/nino/squareglass/OpenHome;)V
    .locals 2

    .line 173
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_2

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-eq p1, v0, :cond_0

    goto :goto_0

    .line 174
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v1, p2, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v0, v1, p2}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 175
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    iget-object v1, p2, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 176
    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v0, :cond_1

    iget-object v1, v0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    if-eq v1, p3, :cond_1

    iget-object p3, p0, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$11;

    invoke-direct {v1, v0, p2}, Ldev/nino/squareglass/LinnProvider$11;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-interface {p3, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 178
    :cond_1
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->notifyDevices(I)V

    :cond_2
    :goto_0
    return-void
.end method

.method static synthetic lambda$probe$2(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    .line 176
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->readdress(Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method private synthetic lambda$probe$3(ILdev/nino/squareglass/OpenHome;)V
    .locals 5

    .line 180
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v3, 0xee6b2800L

    add-long/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :try_start_0
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_0

    iget p0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-ne p1, p0, :cond_0

    invoke-virtual {p2}, Ldev/nino/squareglass/OpenHome;->checkCapabilities()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catch_0
    :cond_0
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catchall_0
    move-exception p0

    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    throw p0
.end method

.method private synthetic lambda$resume$0(I)V
    .locals 0

    add-int/lit8 p1, p1, 0x1

    .line 88
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->resume(I)V

    return-void
.end method

.method private synthetic lambda$resume$1(I)V
    .locals 0

    add-int/lit8 p1, p1, 0x1

    .line 89
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->resume(I)V

    return-void
.end method

.method private synthetic lambda$resume$2(Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;I)V
    .locals 10

    .line 94
    const-string v1, ""

    const-string v2, "sessionUuid"

    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v5, 0x2cb417800L

    add-long/2addr v3, v5

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v3, 0x0

    .line 97
    :try_start_0
    invoke-static {p1}, Ldev/nino/squareglass/OpenHome;->cached(Ljava/lang/String;)Ldev/nino/squareglass/OpenHome;

    move-result-object p1

    iget-object v0, p1, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-interface {p2, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "Playlist"

    const-string v4, "TransportState"

    invoke-virtual {p1, v0, v4}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    goto :goto_1

    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Renderer address changed"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception v0

    move-object p1, v0

    move-object v5, p0

    goto/16 :goto_4

    :catch_0
    move-exception v0

    move-object p1, v0

    const/16 v0, 0xdac

    .line 99
    :try_start_1
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->discover(I)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_1
    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz v4, :cond_2

    :try_start_2
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 100
    :try_start_3
    invoke-static {v4}, Ldev/nino/squareglass/OpenHome;->cached(Ljava/lang/String;)Ldev/nino/squareglass/OpenHome;

    move-result-object v4

    .line 101
    iget-object v5, v4, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-interface {p2, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    if-eqz v5, :cond_1

    move-object p2, v4

    goto :goto_0

    :cond_2
    const/4 p2, 0x0

    :goto_0
    if-eqz p2, :cond_3

    move-object p1, p2

    .line 105
    :goto_1
    :try_start_4
    new-instance v9, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v9, p1}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    new-instance v8, Ldev/nino/squareglass/LinnPlayer;

    invoke-direct {v8, p0, v9, p3}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    invoke-virtual {v8}, Ldev/nino/squareglass/LinnPlayer;->reattach()V

    .line 106
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v4, Ldev/nino/squareglass/LinnProvider$16;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    move-object v5, p0

    move-object v7, p3

    move v6, p4

    :try_start_5
    invoke-direct/range {v4 .. v9}, Ldev/nino/squareglass/LinnProvider$16;-><init>(Ldev/nino/squareglass/LinnProvider;ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-virtual {p1, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_3

    :cond_3
    move-object v5, p0

    move v6, p4

    .line 103
    throw p1
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :catchall_1
    move-exception v0

    move-object v5, p0

    :goto_2
    move-object p1, v0

    goto :goto_4

    :catch_2
    move-object v5, p0

    move v6, p4

    .line 113
    :catch_3
    :try_start_6
    iget p0, v5, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne v6, p0, :cond_4

    const-string p0, "Could not reattach Linn. Its device queue was left unchanged."

    invoke-virtual {v5, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 114
    :cond_4
    :goto_3
    iput-boolean v3, v5, Ldev/nino/squareglass/LinnProvider;->resuming:Z

    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catchall_2
    move-exception v0

    goto :goto_2

    :goto_4
    iput-boolean v3, v5, Ldev/nino/squareglass/LinnProvider;->resuming:Z

    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    throw p1
.end method

.method private synthetic lambda$resume$3(ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 1

    .line 107
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v0, :cond_2

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v0, :cond_2

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne p1, v0, :cond_2

    invoke-interface {p2}, Lcom/aspiro/wamp/player/k0;->getState()Lcom/aspiro/wamp/enums/MusicServiceState;

    move-result-object p1

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne p1, v0, :cond_0

    goto :goto_1

    .line 108
    :cond_0
    invoke-interface {p2}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    invoke-virtual {p3}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    .line 109
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object p2, p4, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {p1, p2, p4}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p4, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    .line 110
    invoke-static {p3}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    invoke-static {p4}, Ldev/nino/squareglass/NativeOutputBridge;->confirmSelection(Ljava/lang/Object;)V

    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p2, p0}, Lcom/aspiro/wamp/broadcast/l;->a(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p3}, Ldev/nino/squareglass/LinnPlayer;->start()V

    .line 111
    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string p2, ""

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    return-void

    .line 107
    :cond_2
    :goto_1
    invoke-virtual {p3}, Ldev/nino/squareglass/LinnPlayer;->close()V

    return-void
.end method

.method static synthetic lambda$snapshot$0(Ljava/lang/String;Lp2/a;)Ljava/lang/Boolean;
    .locals 0

    .line 120
    iget-object p1, p1, Lp2/a;->a:Ljava/lang/String;

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    xor-int/lit8 p0, p0, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$snapshot$1(Lp2/a;)Ljava/lang/String;
    .locals 0

    .line 120
    iget-object p0, p0, Lp2/a;->b:Ljava/lang/String;

    return-object p0
.end method

.method private synthetic lambda$startScanning$0(I)V
    .locals 0

    .line 137
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->discover(I)V

    return-void
.end method

.method public static override(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 331
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-eqz v0, :cond_0

    .line 332
    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_0

    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v1, :cond_0

    iget-object p0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    :cond_0
    return-object p0
.end method

.method public static prepareSelection(Ljava/lang/Object;)V
    .locals 2

    .line 336
    instance-of p0, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz p0, :cond_0

    const-string p0, "SquareLinn"

    const-string v0, "Linn output selected"

    invoke-static {p0, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {}, Ldev/nino/squareglass/NativeOutputBridge;->active()Ljava/lang/Object;

    move-result-object p0

    sput-object p0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    return-void

    :cond_0
    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-eqz p0, :cond_1

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz p0, :cond_1

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    :cond_1
    return-void
.end method


# virtual methods
.method public addListener(Lcom/aspiro/wamp/broadcast/l;)V
    .locals 0

    .line 73
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->addIfAbsent(Ljava/lang/Object;)Z

    return-void
.end method

.method public addListener(Lcom/aspiro/wamp/broadcast/q$a;)V
    .locals 0

    return-void
.end method

.method public cancelPending()V
    .locals 6

    .line 287
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v0, :cond_1

    iget-boolean v1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v1, :cond_0

    goto :goto_0

    .line 288
    :cond_0
    iget v1, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    .line 289
    sget-object v2, Ldev/nino/squareglass/LinnProvider$Phase;->CONFIRMING:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v3, "Verbindung abbrechen\u2026"

    invoke-virtual {p0, v2, v3}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 290
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v4, 0x4a817c800L

    add-long/2addr v2, v4

    iput-wide v2, p0, Ldev/nino/squareglass/LinnProvider;->attemptExpires:J

    .line 291
    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Ldev/nino/squareglass/LinnProvider$17;

    invoke-direct {v3, p0, v0, v1}, Ldev/nino/squareglass/LinnProvider$17;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;I)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    :cond_1
    :goto_0
    return-void
.end method

.method public connect(Lp2/a;)V
    .locals 11

    .line 203
    const-string v0, "SquareLinn"

    const-string v1, "Native provider connect requested"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 204
    instance-of v0, p1, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_9

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v0, :cond_0

    goto/16 :goto_6

    .line 205
    :cond_0
    move-object v4, p1

    check-cast v4, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-static {}, Ldev/nino/squareglass/NativeLinnBridge;->player()Lcom/aspiro/wamp/player/k0;

    move-result-object p1

    .line 206
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    iget-object v1, v4, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v0, :cond_1

    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {v0, p0}, Lcom/aspiro/wamp/broadcast/l;->a(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    :cond_1
    if-eqz p1, :cond_8

    .line 207
    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->isLocal()Z

    move-result v0

    if-nez v0, :cond_2

    instance-of v0, p1, Ldev/nino/squareglass/LinnPlayer;

    if-nez v0, :cond_2

    goto/16 :goto_5

    .line 208
    :cond_2
    new-instance v6, Ldev/nino/squareglass/LinnPlayer;

    invoke-direct {v6, p0, v4, p1}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    .line 209
    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object v0

    if-nez v0, :cond_3

    const-string p1, "TIDAL player is still starting. Retry shortly."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void

    .line 210
    :cond_3
    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_5

    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object p1

    invoke-interface {p1}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_4

    goto :goto_1

    :cond_4
    const/4 p1, 0x0

    move v5, p1

    goto :goto_2

    :cond_5
    :goto_1
    move v5, v1

    :goto_2
    if-nez v5, :cond_6

    .line 211
    :try_start_0
    invoke-virtual {v6}, Ldev/nino/squareglass/LinnPlayer;->capture()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :catch_0
    move-exception v0

    move-object p1, v0

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void

    .line 212
    :cond_6
    :goto_3
    iput-boolean v1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    const-string p1, ""

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 213
    iget p1, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    add-int/lit8 v3, p1, 0x1

    iput v3, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    .line 214
    iput v3, v6, Ldev/nino/squareglass/LinnPlayer;->generation:I

    .line 215
    iput-object v6, p0, Ldev/nino/squareglass/LinnProvider;->pendingPlayer:Ldev/nino/squareglass/LinnPlayer;

    .line 216
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    sget-object p1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    if-eqz v5, :cond_7

    const-wide/16 v7, 0x2ee0

    goto :goto_4

    :cond_7
    iget-object v2, v6, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    int-to-long v7, v2

    const-wide/16 v9, 0x96

    mul-long/2addr v7, v9

    const-wide/16 v9, 0x4e20

    add-long/2addr v7, v9

    const-wide/32 v9, 0x1d4c0

    invoke-static {v9, v10, v7, v8}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v7

    :goto_4
    invoke-virtual {p1, v7, v8}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v7

    add-long/2addr v0, v7

    iput-wide v0, p0, Ldev/nino/squareglass/LinnProvider;->attemptExpires:J

    .line 217
    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->CHECKING:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v0, "Ger\u00e4t pr\u00fcfen\u2026"

    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 218
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$12;

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Ldev/nino/squareglass/LinnProvider$12;-><init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnProvider$Device;ZLdev/nino/squareglass/LinnPlayer;)V

    invoke-interface {p1, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_8
    :goto_5
    move-object v2, p0

    .line 207
    const-string p0, "The previous output must finish disconnecting before connecting Linn."

    invoke-virtual {v2, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_9
    :goto_6
    return-void
.end method

.method public disconnect(Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 3

    .line 248
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    .line 249
    iget v1, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    const/4 v2, 0x1

    add-int/2addr v1, v2

    iput v1, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    iput-boolean v2, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    .line 250
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$13;

    invoke-direct {v2, p0, v0, p1}, Ldev/nino/squareglass/LinnProvider$13;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method discover(I)V
    .locals 4

    .line 140
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_4

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-eq p1, v0, :cond_0

    goto :goto_3

    .line 141
    :cond_0
    :try_start_0
    new-instance v0, Ldev/nino/squareglass/LinnDiscovery;

    invoke-direct {v0}, Ldev/nino/squareglass/LinnDiscovery;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 142
    :try_start_1
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scanSocket:Ldev/nino/squareglass/LinnDiscovery;

    iget-boolean v1, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v1, :cond_2

    iget v1, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-eq p1, v1, :cond_1

    goto :goto_0

    .line 143
    :cond_1
    new-instance v1, Ldev/nino/squareglass/LinnProvider$4;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$4;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    const/4 v2, 0x0

    const/16 v3, 0x9c4

    invoke-virtual {v0, v2, v3, v1}, Ldev/nino/squareglass/LinnDiscovery;->search(Ljava/lang/String;ILjava/util/function/Consumer;)V

    .line 144
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$5;

    invoke-direct {v2, p0, p1}, Ldev/nino/squareglass/LinnProvider$5;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 152
    :try_start_2
    invoke-virtual {v0}, Ldev/nino/squareglass/LinnDiscovery;->close()V

    goto :goto_2

    :cond_2
    :goto_0
    invoke-virtual {v0}, Ldev/nino/squareglass/LinnDiscovery;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    return-void

    :catchall_0
    move-exception v1

    .line 141
    :try_start_3
    invoke-virtual {v0}, Ldev/nino/squareglass/LinnDiscovery;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v0

    :try_start_4
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1
    throw v1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 152
    :catch_0
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_3

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-ne p1, v0, :cond_3

    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    const-string v1, "discovery=unavailable"

    invoke-interface {v0, v1}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    .line 153
    :cond_3
    :goto_2
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_4

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-ne p1, v0, :cond_4

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$6;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$6;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    const-wide/16 v2, 0x8

    sget-object p1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, p1}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    :cond_4
    :goto_3
    return-void
.end method

.method fail(Ljava/lang/String;)V
    .locals 1

    .line 316
    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->ERROR:Ldev/nino/squareglass/LinnProvider$Phase;

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    if-nez p1, :cond_0

    .line 317
    const-string p1, "Linn request failed. Retry."

    :cond_0
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 318
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    .line 319
    const-string p1, "SquareLinn"

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 320
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$30;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnProvider$30;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public get()Lcom/aspiro/wamp/broadcast/o;
    .locals 0

    return-object p0
.end method

.method public getAllAvailableDevices()Lio/reactivex/Single;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/Single<",
            "Ljava/util/List<",
            "Lp2/a;",
            ">;>;"
        }
    .end annotation

    .line 122
    new-instance v0, Ldev/nino/squareglass/LinnProvider$25;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnProvider$25;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-static {v0}, Lio/reactivex/Single;->fromCallable(Ljava/util/concurrent/Callable;)Lio/reactivex/Single;

    move-result-object p0

    return-object p0
.end method

.method public getBroadcastProviderButton()Lcom/aspiro/wamp/broadcast/p;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getBroadcastProviderGroupButton()Lcom/aspiro/wamp/broadcast/r;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getConnectedItem()Lp2/a;
    .locals 0

    .line 77
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    return-object p0
.end method

.method public getVolumeControl()Lfq/f;
    .locals 0

    .line 76
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    return-object p0
.end method

.method public init()V
    .locals 2

    .line 81
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$31;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnProvider$31;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public isAvailable()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isConnected()Z
    .locals 0

    .line 78
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public isConnecting()Z
    .locals 0

    .line 79
    iget-boolean p0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    return p0
.end method

.method public isValidItem(Lp2/a;)Z
    .locals 0

    .line 80
    instance-of p0, p1, Ldev/nino/squareglass/LinnProvider$Device;

    return p0
.end method

.method notifyDevices(I)V
    .locals 2

    .line 155
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$29;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$29;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V
    .locals 3

    .line 38
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "attempt="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget p0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " phase="

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    invoke-static {p2}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V

    return-void
.end method

.method probe(Ljava/lang/String;ILdev/nino/squareglass/LinnDiscovery$Result;)V
    .locals 3

    .line 157
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->probing:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, p1, v1}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_1

    .line 158
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ne v1, p2, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->probing:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, p1, v0, v2}, Ljava/util/concurrent/ConcurrentHashMap;->replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 159
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->descriptions:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$3;

    invoke-direct {v1, p0, p2, p1, p3}, Ldev/nino/squareglass/LinnProvider$3;-><init>(Ldev/nino/squareglass/LinnProvider;ILjava/lang/String;Ldev/nino/squareglass/LinnDiscovery$Result;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public refreshAvailability()V
    .locals 0

    return-void
.end method

.method resume(I)V
    .locals 9

    .line 83
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v0, :cond_5

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->resuming:Z

    if-nez v0, :cond_5

    const/16 v0, 0x28

    if-lt p1, v0, :cond_0

    goto/16 :goto_1

    .line 84
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v6

    .line 85
    const-string v0, "location"

    const-string v1, ""

    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "sessionLocation"

    invoke-interface {v6, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 86
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_5

    const-string v0, "sessionUuid"

    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_5

    const-string v0, "autoResume"

    const/4 v1, 0x1

    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_1

    :cond_1
    const-wide/16 v2, 0xfa

    .line 88
    :try_start_0
    invoke-static {}, Ldev/nino/squareglass/NativeLinnBridge;->player()Lcom/aspiro/wamp/player/k0;

    move-result-object v7
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v7, :cond_4

    .line 89
    invoke-interface {v7}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 90
    :cond_2
    invoke-interface {v7}, Lcom/aspiro/wamp/player/k0;->isLocal()Z

    move-result p1

    if-eqz p1, :cond_5

    invoke-interface {v7}, Lcom/aspiro/wamp/player/k0;->getState()Lcom/aspiro/wamp/enums/MusicServiceState;

    move-result-object p1

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne p1, v0, :cond_3

    goto :goto_1

    .line 91
    :cond_3
    iget v8, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    .line 92
    iput-boolean v1, p0, Ldev/nino/squareglass/LinnProvider;->resuming:Z

    .line 93
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Ldev/nino/squareglass/LinnProvider$20;

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Ldev/nino/squareglass/LinnProvider$20;-><init>(Ldev/nino/squareglass/LinnProvider;Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;I)V

    invoke-interface {p1, v3}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_4
    :goto_0
    move-object v4, p0

    .line 89
    iget-object p0, v4, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$19;

    invoke-direct {v0, v4, p1}, Ldev/nino/squareglass/LinnProvider$19;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {p0, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :catch_0
    move-object v4, p0

    .line 88
    iget-object p0, v4, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$18;

    invoke-direct {v0, v4, p1}, Ldev/nino/squareglass/LinnProvider$18;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {p0, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_5
    :goto_1
    return-void
.end method

.method snapshot()Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lp2/a;",
            ">;"
        }
    .end annotation

    .line 118
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 119
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "LINN_"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v2, "squareglass_linn"

    const/4 v3, 0x0

    invoke-virtual {p0, v2, v3}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v2, "uuid"

    const-string v3, ""

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 120
    new-instance v1, Ldev/nino/squareglass/LinnProvider$8;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnProvider$8;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, Ljava/util/Comparator;->comparing(Ljava/util/function/Function;)Ljava/util/Comparator;

    move-result-object p0

    new-instance v1, Ldev/nino/squareglass/LinnProvider$9;

    invoke-direct {v1}, Ldev/nino/squareglass/LinnProvider$9;-><init>()V

    invoke-interface {p0, v1}, Ljava/util/Comparator;->thenComparing(Ljava/util/function/Function;)Ljava/util/Comparator;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    return-object v0
.end method

.method public startScanning()V
    .locals 10

    .line 124
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    .line 125
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    invoke-virtual {v0}, Landroid/app/Application;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v3, "wifi"

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/wifi/WifiManager;

    if-eqz v0, :cond_0

    .line 126
    const-string v3, "SquareGlass Linn discovery"

    invoke-virtual {v0, v3}, Landroid/net/wifi/WifiManager;->createMulticastLock(Ljava/lang/String;)Landroid/net/wifi/WifiManager$MulticastLock;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0, v2}, Landroid/net/wifi/WifiManager$MulticastLock;->setReferenceCounted(Z)V

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->acquire()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 127
    :catch_0
    iput-object v1, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    :cond_0
    :goto_0
    const/4 v0, 0x1

    .line 128
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    iget v3, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    add-int/2addr v3, v0

    iput v3, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    .line 129
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v0, :cond_1

    invoke-interface {v0, v2}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    .line 130
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scanSocket:Ldev/nino/squareglass/LinnDiscovery;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnDiscovery;->close()V

    .line 131
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v4, "squareglass_linn"

    invoke-virtual {v0, v4, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 132
    const-string v2, "location"

    const-string v4, ""

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v5, "uuid"

    invoke-interface {v0, v5, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 133
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_4

    .line 134
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_3

    iget-object v5, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "LINN_"

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ldev/nino/squareglass/LinnProvider$Device;

    const-string v8, "name"

    const-string v9, "Linn Majik DSM"

    invoke-interface {v0, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v4, v0, v2}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    :cond_3
    invoke-virtual {p0, v2, v3, v1}, Ldev/nino/squareglass/LinnProvider;->probe(Ljava/lang/String;ILdev/nino/squareglass/LinnDiscovery$Result;)V

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/LinnProvider;->notifyDevices(I)V

    .line 137
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$10;

    invoke-direct {v1, p0, v3}, Ldev/nino/squareglass/LinnProvider$10;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    const-wide/16 v2, 0x0

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, v4}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    return-void
.end method

.method public stopScanning()V
    .locals 2

    const/4 v0, 0x0

    .line 185
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    iget v1, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v1, :cond_0

    invoke-interface {v1, v0}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scanSocket:Ldev/nino/squareglass/LinnDiscovery;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnDiscovery;->close()V

    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->release()V

    :cond_2
    const/4 v0, 0x0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    :cond_3
    return-void
.end method
