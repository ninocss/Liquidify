.class public final Ldev/nino/squareglass/LinnProvider;
.super Ljava/lang/Object;
.source "LinnProvider.java"

# interfaces
.implements Lcom/aspiro/wamp/broadcast/o;
.implements Lcom/aspiro/wamp/broadcast/q;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnProvider$Device;
    }
.end annotation


# static fields
.field static instance:Ldev/nino/squareglass/LinnProvider;

.field static previousOutput:Ljava/lang/Object;


# instance fields
.field final app:Landroid/app/Application;

.field volatile connected:Ldev/nino/squareglass/LinnProvider$Device;

.field volatile connecting:Z

.field final devices:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Ldev/nino/squareglass/LinnProvider$Device;",
            ">;"
        }
    .end annotation
.end field

.field final discovery:Ljava/util/concurrent/ScheduledExecutorService;

.field error:Ljava/lang/String;

.field final io:Ljava/util/concurrent/ScheduledExecutorService;

.field final listeners:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lcom/aspiro/wamp/broadcast/l;",
            ">;"
        }
    .end annotation
.end field

.field final main:Landroid/os/Handler;

.field private multicast:Landroid/net/wifi/WifiManager$MulticastLock;

.field final nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

.field volatile player:Ldev/nino/squareglass/LinnPlayer;

.field private scan:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field private volatile scanRevision:I

.field volatile scanning:Z


# direct methods
.method public static synthetic $r8$lambda$07lbsbJGdvzA5h19_GLaIslDctk(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$1(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method public static synthetic $r8$lambda$6yos42bJ7LF1iNW5WMJUfNykryM(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$startScanning$0(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$8xvVZldc7e-oyfKtPaO02mtkpHM(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$1(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$BPQuN1OHp8BUFYv6XzsGqU30fXg(Ldev/nino/squareglass/LinnProvider;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$2(Ljava/lang/Throwable;)V

    return-void
.end method

.method public static synthetic $r8$lambda$C5-KHAT7lwITSm96RdLjvJASFA8(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$0(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$JEKwYdNfW4zVJkOVgmrH88irsOE(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$fail$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$KSiDzmC9G5OnGaAAM21ewjtvLR0(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$discover$2(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$NXlKwN-ohRsfXh16Ko6Zko-tDRY(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$0(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method public static synthetic $r8$lambda$UWm4GzP177QAttUIuBNjhp01Htk(Ldev/nino/squareglass/LinnProvider;)Ljava/util/List;
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$getAllAvailableDevices$0()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$XOZ6mDeLvoo7rYWQXrPyUZl6Pzo(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$disconnect$0(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    return-void
.end method

.method public static synthetic $r8$lambda$hwj_k9beWVkgWxe-o8GG63ZLf58(Ldev/nino/squareglass/LinnProvider;Lcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$3(Lcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method public static synthetic $r8$lambda$kpH75q0BKWCY8moE0TwgkQfLfj4(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$init$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$m-xFfeQWEE1kUJlMjrGKkHMx_Xo(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$discover$1(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$o7eH5uW5Prq1znTvCzGg01bnxxE(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$disconnect$1(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    return-void
.end method

.method public static synthetic $r8$lambda$v3WZyxs8NtaATzewWuwa7bNw200(Ldev/nino/squareglass/LinnProvider;Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$2(Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;)V

    return-void
.end method

.method public constructor <init>(Landroid/app/Application;)V
    .locals 2

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    .line 18
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    .line 19
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    .line 20
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 21
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    .line 22
    new-instance v0, Ldev/nino/squareglass/LinnNativeVolume;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnNativeVolume;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    .line 29
    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 35
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    sput-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    return-void
.end method

.method public static addAddress(Ljava/lang/String;)V
    .locals 3

    .line 109
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-nez v0, :cond_0

    return-void

    .line 110
    :cond_0
    const-string v1, "http://"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "[0-9]{1,3}(\\.[0-9]{1,3}){3}"

    invoke-virtual {p0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string p0, "Enter a local IP or the discovered device description URL."

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void

    .line 111
    :cond_1
    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$7;

    invoke-direct {v2, p0, v0}, Ldev/nino/squareglass/LinnProvider$7;-><init>(Ljava/lang/String;Ldev/nino/squareglass/LinnProvider;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static confirmed(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 183
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    .line 184
    instance-of v1, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_1

    if-eqz v0, :cond_0

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v0, :cond_1

    :cond_0
    sget-object p0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    :cond_1
    return-object p0
.end method

.method public static label(Ljava/lang/Object;)Ljava/lang/String;
    .locals 0

    .line 179
    instance-of p0, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz p0, :cond_0

    const-string p0, "Linn Majik DSM \u00b7 OpenHome"

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method static synthetic lambda$addAddress$0(Ljava/lang/String;Ldev/nino/squareglass/LinnProvider;)V
    .locals 5

    .line 114
    :try_start_0
    const-string v0, "http://"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/16 v0, 0xdac

    invoke-static {p0, v0}, Ldev/nino/squareglass/OpenHome;->discover(Ljava/lang/String;I)Ljava/util/Set;

    move-result-object p0

    .line 115
    :goto_0
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v0, 0x0

    move v1, v0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 116
    new-instance v2, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    new-instance v3, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v3, v2}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    iget-object v2, p1, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v4, v3, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v2, v4, v3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    iget-object v2, p1, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v3, "squareglass_linn"

    invoke-virtual {v2, v3, v0}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "location"

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v1, 0x1

    goto :goto_1

    :cond_1
    if-eqz v1, :cond_2

    .line 120
    iget-object p0, p1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$0;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/LinnProvider$0;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 119
    :cond_2
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "No Linn renderer answered at this address."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    .line 121
    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$addAddress$1(Ldev/nino/squareglass/LinnProvider;)V
    .locals 1

    .line 120
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {v0}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->changed()V

    return-void
.end method

.method private synthetic lambda$connect$0(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 3

    .line 133
    const-string v0, "Queue transfer started"

    const-string v1, "SquareLinn"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 135
    :try_start_0
    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->transfer()V

    .line 136
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$2;

    invoke-direct {v2, p0, p1, p2}, Ldev/nino/squareglass/LinnProvider$2;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/LinkageError; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    .line 144
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Linn adapter connection failed: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {v1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p2, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$3;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/LinnProvider$3;-><init>(Ldev/nino/squareglass/LinnProvider;Ljava/lang/Throwable;)V

    invoke-virtual {p2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic lambda$connect$1(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 3

    .line 137
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    .line 138
    invoke-static {p1}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    .line 139
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v2, "squareglass_linn"

    invoke-virtual {v1, v2, v0}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, v1, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    const-string v2, "location"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object p2, p2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object p2, p2, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    .line 140
    const-string v1, "uuid"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 141
    iget-object p2, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {v0, p0}, Lcom/aspiro/wamp/broadcast/l;->a(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    .line 142
    :cond_0
    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->start()V

    return-void
.end method

.method private synthetic lambda$connect$2(Ljava/lang/Throwable;)V
    .locals 1

    const/4 v0, 0x0

    .line 145
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    .line 146
    sget-object p0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    if-eqz p0, :cond_0

    invoke-static {p0}, Ldev/nino/squareglass/NativeOutputBridge;->select(Ljava/lang/Object;)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$disconnect$0(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 4

    .line 155
    :try_start_0
    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Playlist"

    const-string v2, "Pause"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/String;

    invoke-virtual {v0, v1, v2, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 156
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 157
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$15;

    invoke-direct {v1, p0, p1, p2}, Ldev/nino/squareglass/LinnProvider$15;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 167
    :catch_0
    const-string p1, "Could not confirm Linn pause. Retry before switching outputs."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$disconnect$1(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 4

    const/4 v0, 0x0

    .line 158
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->close()V

    .line 159
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "sessionUuid"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "queue"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "mapping"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 160
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget v1, p1, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget v3, p1, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {v0, v1, v3}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    .line 161
    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-static {v0}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    .line 163
    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    iget v1, p1, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-interface {v0, v1, v2, v2}, Lcom/aspiro/wamp/player/k0;->onActionPlayPosition(IZZ)V

    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    iget p1, p1, Ldev/nino/squareglass/LinnPlayer;->position:I

    invoke-interface {v0, p1}, Lcom/aspiro/wamp/player/k0;->onActionSeekTo(I)V

    .line 164
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {v0, p0}, Lcom/aspiro/wamp/broadcast/l;->d(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    .line 165
    :cond_0
    invoke-static {p2}, Ldev/nino/squareglass/NativeLinnBridge;->disconnected(Ljava/lang/Object;)V

    return-void
.end method

.method static synthetic lambda$discover$0(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    .line 99
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->readdress(Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method private synthetic lambda$discover$1(I)V
    .locals 1

    .line 103
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_0

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-ne p1, v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p1}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_0
    return-void
.end method

.method private synthetic lambda$discover$2(I)V
    .locals 0

    .line 105
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->discover(I)V

    return-void
.end method

.method private synthetic lambda$fail$0()V
    .locals 3

    .line 173
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    invoke-static {p0}, Ldev/nino/squareglass/SquareOutput;->linnFailure(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$getAllAvailableDevices$0()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 78
    new-instance v0, Ljava/util/ArrayList;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    return-object v0
.end method

.method private synthetic lambda$init$0()V
    .locals 1

    const/4 v0, 0x0

    .line 48
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnProvider;->resume(I)V

    return-void
.end method

.method private synthetic lambda$resume$0(I)V
    .locals 0

    add-int/lit8 p1, p1, 0x1

    .line 55
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->resume(I)V

    return-void
.end method

.method private synthetic lambda$resume$1(I)V
    .locals 0

    add-int/lit8 p1, p1, 0x1

    .line 56
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->resume(I)V

    return-void
.end method

.method private synthetic lambda$resume$2(Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;)V
    .locals 5

    .line 60
    :try_start_0
    new-instance v0, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception p1

    const/16 v0, 0xdac

    .line 62
    :try_start_1
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->discover(I)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_1
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    .line 63
    :try_start_2
    new-instance v2, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    .line 64
    iget-object v1, v2, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    const-string v3, "sessionUuid"

    const-string v4, ""

    invoke-interface {p2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    if-eqz v1, :cond_0

    move-object v0, v2

    goto :goto_0

    :cond_1
    const/4 p2, 0x0

    move-object v0, p2

    :goto_0
    if-eqz v0, :cond_2

    .line 68
    :goto_1
    :try_start_3
    new-instance p1, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {p1, v0}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    new-instance p2, Ldev/nino/squareglass/LinnPlayer;

    invoke-direct {p2, p0, p1, p3}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->reattach()V

    .line 69
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$1;

    invoke-direct {v1, p0, p3, p2, p1}, Ldev/nino/squareglass/LinnProvider$1;-><init>(Ldev/nino/squareglass/LinnProvider;Lcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_2

    .line 66
    :cond_2
    throw p1
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 75
    :catch_2
    const-string p1, "Could not reattach Linn. Its device queue was left unchanged."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :goto_2
    return-void
.end method

.method private synthetic lambda$resume$3(Lcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 1

    .line 70
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v0, :cond_2

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v0, :cond_0

    goto :goto_1

    .line 71
    :cond_0
    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    .line 72
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v0, p3, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {p1, v0, p3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    .line 73
    invoke-static {p2}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p3, p0}, Lcom/aspiro/wamp/broadcast/l;->a(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->start()V

    :cond_2
    :goto_1
    return-void
.end method

.method private synthetic lambda$startScanning$0(I)V
    .locals 0

    .line 86
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->discover(I)V

    return-void
.end method

.method public static override(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 176
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-eqz v0, :cond_0

    .line 177
    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_0

    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v1, :cond_0

    iget-object p0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    :cond_0
    return-object p0
.end method

.method public static prepareSelection(Ljava/lang/Object;)V
    .locals 1

    .line 181
    instance-of p0, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz p0, :cond_0

    const-string p0, "SquareLinn"

    const-string v0, "Linn output selected"

    invoke-static {p0, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {}, Ldev/nino/squareglass/NativeOutputBridge;->active()Ljava/lang/Object;

    move-result-object p0

    sput-object p0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    :cond_0
    return-void
.end method


# virtual methods
.method public addListener(Lcom/aspiro/wamp/broadcast/l;)V
    .locals 0

    .line 40
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->addIfAbsent(Ljava/lang/Object;)Z

    return-void
.end method

.method public addListener(Lcom/aspiro/wamp/broadcast/q$a;)V
    .locals 0

    return-void
.end method

.method public connect(Lp2/a;)V
    .locals 3

    .line 125
    const-string v0, "SquareLinn"

    const-string v1, "Native provider connect requested"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 126
    instance-of v0, p1, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v0, :cond_0

    goto :goto_1

    .line 127
    :cond_0
    check-cast p1, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-static {}, Ldev/nino/squareglass/NativeLinnBridge;->player()Lcom/aspiro/wamp/player/k0;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 128
    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->isLocal()Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_0

    .line 129
    :cond_1
    new-instance v1, Ldev/nino/squareglass/LinnPlayer;

    invoke-direct {v1, p0, p1, v0}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    .line 130
    :try_start_0
    invoke-virtual {v1}, Ldev/nino/squareglass/LinnPlayer;->capture()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v0, 0x1

    .line 131
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 132
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$9;

    invoke-direct {v2, p0, v1, p1}, Ldev/nino/squareglass/LinnProvider$9;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-interface {v0, v2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :catch_0
    move-exception p1

    .line 130
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void

    .line 128
    :cond_2
    :goto_0
    const-string p1, "Switch to This phone before connecting Linn."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_3
    :goto_1
    return-void
.end method

.method public disconnect(Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 3

    .line 151
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-nez v0, :cond_0

    .line 152
    invoke-static {p1}, Ldev/nino/squareglass/NativeLinnBridge;->disconnected(Ljava/lang/Object;)V

    return-void

    .line 153
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$10;

    invoke-direct {v2, p0, v0, p1}, Ldev/nino/squareglass/LinnProvider$10;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method discover(I)V
    .locals 5

    const/16 v0, 0xdac

    .line 90
    :try_start_0
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->discover(I)Ljava/util/Set;

    move-result-object v0

    .line 91
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v2, "squareglass_linn"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "location"

    const-string v3, ""

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 92
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 93
    :cond_0
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_0
    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 94
    iget-boolean v2, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v2, :cond_5

    iget v2, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-eq p1, v2, :cond_2

    goto :goto_2

    .line 96
    :cond_2
    :try_start_1
    new-instance v2, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    new-instance v3, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v3, v2}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    .line 97
    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v4, v3, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v2, v4, v3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v2, :cond_1

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    iget-object v4, v3, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 99
    iput-object v3, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v2, :cond_1

    iget-boolean v4, v2, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v4, :cond_3

    iget-object v4, v2, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v4, v4, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v4, v4, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    invoke-virtual {v4, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    :cond_3
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v4, Ldev/nino/squareglass/LinnProvider$4;

    invoke-direct {v4, v2, v3}, Ldev/nino/squareglass/LinnProvider$4;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-interface {v1, v4}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    .line 103
    :cond_4
    :try_start_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$5;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$5;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    .line 104
    :catch_1
    const-string v0, "Linn discovery failed. Check the local network and retry."

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    .line 105
    :goto_1
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_5

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-ne p1, v0, :cond_5

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$6;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$6;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    const-wide/16 v2, 0x8

    sget-object p1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, p1}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    :cond_5
    :goto_2
    return-void
.end method

.method fail(Ljava/lang/String;)V
    .locals 1

    if-nez p1, :cond_0

    .line 171
    const-string p1, "Linn request failed. Retry."

    :cond_0
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 172
    const-string v0, "SquareLinn"

    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 173
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$16;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnProvider$16;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public get()Lcom/aspiro/wamp/broadcast/o;
    .locals 0

    return-object p0
.end method

.method public getAllAvailableDevices()Lio/reactivex/Single;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/Single<",
            "Ljava/util/List<",
            "Lp2/a;",
            ">;>;"
        }
    .end annotation

    .line 78
    new-instance v0, Ldev/nino/squareglass/LinnProvider$14;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnProvider$14;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-static {v0}, Lio/reactivex/Single;->fromCallable(Ljava/util/concurrent/Callable;)Lio/reactivex/Single;

    move-result-object p0

    return-object p0
.end method

.method public getBroadcastProviderButton()Lcom/aspiro/wamp/broadcast/p;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getBroadcastProviderGroupButton()Lcom/aspiro/wamp/broadcast/r;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getConnectedItem()Lp2/a;
    .locals 0

    .line 44
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    return-object p0
.end method

.method public getVolumeControl()Lfq/f;
    .locals 0

    .line 43
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    return-object p0
.end method

.method public init()V
    .locals 4

    .line 48
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$17;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnProvider$17;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    const-wide/16 v2, 0x9c4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public isAvailable()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isConnected()Z
    .locals 0

    .line 45
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public isConnecting()Z
    .locals 0

    .line 46
    iget-boolean p0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    return p0
.end method

.method public isValidItem(Lp2/a;)Z
    .locals 0

    .line 47
    instance-of p0, p1, Ldev/nino/squareglass/LinnProvider$Device;

    return p0
.end method

.method public refreshAvailability()V
    .locals 0

    return-void
.end method

.method resume(I)V
    .locals 6

    .line 50
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v0, :cond_4

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v0, :cond_4

    const/4 v0, 0x5

    if-lt p1, v0, :cond_0

    goto :goto_1

    .line 51
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 52
    const-string v1, "location"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 53
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_4

    const-string v3, "sessionUuid"

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_1

    :cond_1
    const-wide/16 v2, 0x7d0

    .line 55
    :try_start_0
    invoke-static {}, Ldev/nino/squareglass/NativeLinnBridge;->player()Lcom/aspiro/wamp/player/k0;

    move-result-object v4
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v4, :cond_3

    .line 56
    invoke-interface {v4}, Lcom/aspiro/wamp/player/k0;->isLocal()Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_0

    .line 57
    :cond_2
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$13;

    invoke-direct {v2, p0, v1, v0, v4}, Ldev/nino/squareglass/LinnProvider$13;-><init>(Ldev/nino/squareglass/LinnProvider;Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;)V

    invoke-interface {p1, v2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    .line 56
    :cond_3
    :goto_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$12;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$12;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 55
    :catch_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$11;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$11;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    :goto_1
    return-void
.end method

.method public startScanning()V
    .locals 5

    .line 80
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 81
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    invoke-virtual {v0}, Landroid/app/Application;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v2, "wifi"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/wifi/WifiManager;

    if-eqz v0, :cond_0

    .line 82
    const-string v2, "SquareGlass Linn discovery"

    invoke-virtual {v0, v2}, Landroid/net/wifi/WifiManager;->createMulticastLock(Ljava/lang/String;)Landroid/net/wifi/WifiManager$MulticastLock;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0, v1}, Landroid/net/wifi/WifiManager$MulticastLock;->setReferenceCounted(Z)V

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->acquire()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    .line 83
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    :cond_0
    :goto_0
    const/4 v0, 0x1

    .line 84
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    iget v2, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    add-int/2addr v2, v0

    iput v2, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    .line 85
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v0, :cond_1

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    .line 86
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$8;

    invoke-direct {v1, p0, v2}, Ldev/nino/squareglass/LinnProvider$8;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    const-wide/16 v2, 0x0

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, v4}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    return-void
.end method

.method public stopScanning()V
    .locals 2

    const/4 v0, 0x0

    .line 107
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    iget v1, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v1, :cond_0

    invoke-interface {v1, v0}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->release()V

    :cond_1
    const/4 v0, 0x0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    :cond_2
    return-void
.end method
