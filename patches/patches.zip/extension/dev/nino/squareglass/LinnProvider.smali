.class public final Ldev/nino/squareglass/LinnProvider;
.super Ljava/lang/Object;
.source "LinnProvider.java"

# interfaces
.implements Lcom/aspiro/wamp/broadcast/o;
.implements Lcom/aspiro/wamp/broadcast/q;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnProvider$Phase;,
        Ldev/nino/squareglass/LinnProvider$Device;
    }
.end annotation


# static fields
.field static instance:Ldev/nino/squareglass/LinnProvider;

.field static previousOutput:Ljava/lang/Object;


# instance fields
.field final app:Landroid/app/Application;

.field volatile connected:Ldev/nino/squareglass/LinnProvider$Device;

.field volatile connecting:Z

.field final controls:Ljava/util/concurrent/ScheduledExecutorService;

.field final devices:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Ldev/nino/squareglass/LinnProvider$Device;",
            ">;"
        }
    .end annotation
.end field

.field final discovery:Ljava/util/concurrent/ScheduledExecutorService;

.field error:Ljava/lang/String;

.field volatile generation:I

.field final io:Ljava/util/concurrent/ScheduledExecutorService;

.field final listeners:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lcom/aspiro/wamp/broadcast/l;",
            ">;"
        }
    .end annotation
.end field

.field final main:Landroid/os/Handler;

.field private multicast:Landroid/net/wifi/WifiManager$MulticastLock;

.field final nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

.field final observations:Ljava/util/concurrent/ScheduledExecutorService;

.field volatile phase:Ldev/nino/squareglass/LinnProvider$Phase;

.field volatile player:Ldev/nino/squareglass/LinnPlayer;

.field private scan:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field private volatile scanRevision:I

.field volatile scanning:Z

.field volatile status:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$8bpyRBACWU42OQnAf8guzmCMZqE(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$4(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$BRRnsmLdjKoT-iNggEXdqnO-JJ0(Ldev/nino/squareglass/LinnProvider;Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$6(Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$CTDuiVyVcSW9DDHmn5SIrYtz-zY(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$startScanning$8(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$CrV_PUYpQcAu7cVX95OXHWCNYdU(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$init$3()V

    return-void
.end method

.method public static synthetic $r8$lambda$HsBScKsuKn3r05ojAaApsffFdho(Ldev/nino/squareglass/LinnProvider;)Ljava/util/List;
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$getAllAvailableDevices$7()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$R_5M9YtCFkgIqqA-ra_TEZzyRZk(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$new$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$Z3oXZgY_R1TkXqRRtL1ieydEL3g(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$new$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$bfNVpUDmY_J-UuaJAHUBqLCXrSQ(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$discover$10(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$daaD_MAfbwAa3OFRBCY7ZpwSKBw(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnProvider$Device;ZLdev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$16(ILdev/nino/squareglass/LinnProvider$Device;ZLdev/nino/squareglass/LinnPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$eabi_a-4yx_ML4EFC40OQuAbMsE(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$disconnect$17(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    return-void
.end method

.method public static synthetic $r8$lambda$edIH-PUW7MzyCq6SL1VnaR5Av2I(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$14(ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$fPO7TtSihZl6yvBBAAfPwhZ0KDA(Ldev/nino/squareglass/LinnProvider;ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LinnProvider;->lambda$resume$5(ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method public static synthetic $r8$lambda$iWBe_nAm1-OfP5MbDAueYQFWQ6c(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnProvider;->lambda$fail$19()V

    return-void
.end method

.method public static synthetic $r8$lambda$mvKyce674-feww_FGYu1a5QaHN8(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$disconnect$18(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    return-void
.end method

.method public static synthetic $r8$lambda$vNAY7fh9BfeMIjxYwKaV4IdiepI(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnProvider;->lambda$discover$11(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$vNEffUSex7a_SXrsm2LPqHfZNY8(Ldev/nino/squareglass/LinnProvider;ILjava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->lambda$connect$15(ILjava/lang/Throwable;)V

    return-void
.end method

.method public constructor <init>(Landroid/app/Application;)V
    .locals 2

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    .line 18
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    .line 19
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    .line 20
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->observations:Ljava/util/concurrent/ScheduledExecutorService;

    .line 21
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    .line 22
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 23
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    .line 24
    new-instance v0, Ldev/nino/squareglass/LinnNativeVolume;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnNativeVolume;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    .line 29
    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    .line 30
    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    .line 36
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 43
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    sput-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    .line 44
    new-instance v0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda15;

    invoke-direct {v0}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda15;-><init>()V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    .line 45
    :try_start_0
    new-instance v0, Ldev/nino/squareglass/LinnNetwork;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda16;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda16;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-direct {v0, p1, v1}, Ldev/nino/squareglass/LinnNetwork;-><init>(Landroid/app/Application;Ljava/lang/Runnable;)V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->network:Ldev/nino/squareglass/OpenHome$NetworkBinding;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 48
    :catch_0
    sget-object p0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    const-string p1, "network_binding=unavailable"

    invoke-interface {p0, p1}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    return-void
.end method

.method public static addAddress(Ljava/lang/String;)V
    .locals 3

    .line 125
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-nez v0, :cond_0

    return-void

    .line 126
    :cond_0
    const-string v1, "http://"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "[0-9]{1,3}(\\.[0-9]{1,3}){3}"

    invoke-virtual {p0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string p0, "Enter a local IP or the discovered device description URL."

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void

    .line 127
    :cond_1
    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda5;

    invoke-direct {v2, p0, v0}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda5;-><init>(Ljava/lang/String;Ldev/nino/squareglass/LinnProvider;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static confirmed(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 224
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    .line 225
    instance-of v1, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_1

    if-eqz v0, :cond_0

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v0, :cond_1

    :cond_0
    sget-object p0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    :cond_1
    return-object p0
.end method

.method static explain(Ljava/lang/Throwable;)Ljava/lang/String;
    .locals 1

    .line 212
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    .line 213
    invoke-virtual {p0}, Ljava/lang/Throwable;->getSuppressed()[Ljava/lang/Throwable;

    move-result-object p0

    array-length p0, p0

    if-lez p0, :cond_0

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ". Wiederherstellung nicht best\u00e4tigt; Ger\u00e4tezustand vor erneutem Versuch pr\u00fcfen."

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v0
.end method

.method public static label(Ljava/lang/Object;)Ljava/lang/String;
    .locals 2

    .line 220
    instance-of v0, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_0

    sget-object v1, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-eqz v1, :cond_0

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_0

    check-cast p0, Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    sget-object v1, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_0

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    return-object p0

    :cond_0
    if-eqz v0, :cond_1

    const-string p0, "Linn Majik DSM \u00b7 OpenHome"

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method static synthetic lambda$addAddress$12(Ldev/nino/squareglass/LinnProvider;)V
    .locals 1

    .line 136
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {v0}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->changed()V

    return-void
.end method

.method static synthetic lambda$addAddress$13(Ljava/lang/String;Ldev/nino/squareglass/LinnProvider;)V
    .locals 5

    .line 130
    :try_start_0
    const-string v0, "http://"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/16 v0, 0xdac

    invoke-static {p0, v0}, Ldev/nino/squareglass/OpenHome;->discover(Ljava/lang/String;I)Ljava/util/Set;

    move-result-object p0

    .line 131
    :goto_0
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v0, 0x0

    move v1, v0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 132
    new-instance v2, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    new-instance v3, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v3, v2}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    iget-object v2, p1, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v4, v3, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v2, v4, v3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    iget-object v2, p1, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v3, "squareglass_linn"

    invoke-virtual {v2, v3, v0}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "location"

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v1, 0x1

    goto :goto_1

    :cond_1
    if-eqz v1, :cond_2

    .line 136
    iget-object p0, p1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda0;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda0;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 135
    :cond_2
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "No Linn renderer answered at this address."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    .line 137
    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$connect$14(ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V
    .locals 2

    .line 160
    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->close()V

    return-void

    .line 161
    :cond_0
    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    const/4 p1, 0x0

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    .line 162
    invoke-static {p2}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    .line 163
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    invoke-virtual {v0, v1, p1}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object v0, p3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v0, v0, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    const-string v1, "location"

    invoke-interface {p1, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object p3, p3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object p3, p3, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    .line 164
    const-string v0, "uuid"

    invoke-interface {p1, v0, p3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 165
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p3, p0}, Lcom/aspiro/wamp/broadcast/l;->a(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    .line 166
    :cond_1
    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->start()V

    .line 167
    iget-boolean p1, p2, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez p1, :cond_2

    if-eqz p4, :cond_2

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    .line 168
    :cond_2
    iget-boolean p1, p2, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz p1, :cond_3

    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    goto :goto_1

    :cond_3
    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    :goto_1
    iget-boolean p2, p2, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz p2, :cond_4

    const-string p2, "Bereit \u2013 Musik ausw\u00e4hlen"

    goto :goto_2

    :cond_4
    const-string p2, ""

    :goto_2
    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$connect$15(ILjava/lang/Throwable;)V
    .locals 1

    .line 171
    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    return-void

    :cond_0
    const/4 p1, 0x0

    .line 172
    iput-boolean p1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    invoke-static {p2}, Ldev/nino/squareglass/LinnProvider;->explain(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$connect$16(ILdev/nino/squareglass/LinnProvider$Device;ZLdev/nino/squareglass/LinnPlayer;)V
    .locals 9

    const-string v1, "Linn adapter connection failed: "

    .line 154
    sget-object v0, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 155
    const-string v0, "Queue transfer started"

    const-string v2, "SquareLinn"

    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 157
    :try_start_0
    iget-object v0, p2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->preflight()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/LinkageError; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p3, :cond_0

    .line 158
    :try_start_1
    invoke-virtual {p4}, Ldev/nino/squareglass/LinnPlayer;->prepareReady()V

    invoke-virtual {p4}, Ldev/nino/squareglass/LinnPlayer;->adoptExisting()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/LinkageError; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    move-exception v0

    move-object p2, v0

    move-object v4, p0

    move v5, p1

    goto :goto_2

    :cond_0
    :try_start_2
    invoke-virtual {p4}, Ldev/nino/squareglass/LinnPlayer;->transfer()V

    .line 159
    :goto_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v3, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda11;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/LinkageError; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object v4, p0

    move v5, p1

    move-object v7, p2

    move v8, p3

    move-object v6, p4

    :try_start_3
    invoke-direct/range {v3 .. v8}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda11;-><init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;Z)V

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/LinkageError; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 174
    sget-object p0, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catch_1
    move-exception v0

    goto :goto_1

    :catch_2
    move-exception v0

    move-object v4, p0

    move v5, p1

    :goto_1
    move-object p2, v0

    .line 170
    :goto_2
    :try_start_4
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p0, v4, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance p1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda12;

    invoke-direct {p1, v4, v5, p2}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda12;-><init>(Ldev/nino/squareglass/LinnProvider;ILjava/lang/Throwable;)V

    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 174
    sget-object p0, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catchall_0
    move-exception v0

    move-object p0, v0

    sget-object p1, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    throw p0
.end method

.method private synthetic lambda$disconnect$17(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 4

    const/4 v0, 0x0

    .line 188
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->close()V

    .line 189
    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 190
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "sessionUuid"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "queue"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "mapping"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 191
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget v1, p1, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget v3, p1, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {v0, v1, v3}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    .line 192
    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-static {v0}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    .line 194
    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    iget-boolean v0, p1, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v0, :cond_0

    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    iget v1, p1, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-interface {v0, v1, v2, v2}, Lcom/aspiro/wamp/player/k0;->onActionPlayPosition(IZZ)V

    iget-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    iget p1, p1, Ldev/nino/squareglass/LinnPlayer;->position:I

    invoke-interface {v0, p1}, Lcom/aspiro/wamp/player/k0;->onActionSeekTo(I)V

    .line 195
    :cond_0
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {v0, p0}, Lcom/aspiro/wamp/broadcast/l;->d(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    .line 196
    :cond_1
    invoke-static {p2}, Ldev/nino/squareglass/NativeLinnBridge;->disconnected(Ljava/lang/Object;)V

    return-void
.end method

.method private synthetic lambda$disconnect$18(Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 8

    .line 182
    const-string v0, "Playlist"

    :try_start_0
    iget-boolean v1, p1, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v1, :cond_0

    .line 183
    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v2, "Pause"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/String;

    invoke-virtual {v1, v0, v2, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 184
    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, p1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v3, "Id"

    invoke-virtual {v1, v0, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    const-string v5, "Paused"

    const-wide/16 v6, 0x4e20

    invoke-virtual/range {v2 .. v7}, Ldev/nino/squareglass/OpenHome;->confirm(JLjava/lang/String;J)V

    .line 186
    :cond_0
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, p1, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 187
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p1, p2}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda1;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 198
    :catch_0
    const-string p1, "Could not confirm Linn pause. Retry before switching outputs."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$discover$10(I)V
    .locals 1

    .line 119
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_0

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-ne p1, v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p1}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_0
    return-void
.end method

.method private synthetic lambda$discover$11(I)V
    .locals 0

    .line 121
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->discover(I)V

    return-void
.end method

.method static synthetic lambda$discover$9(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    .line 115
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->readdress(Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method

.method private synthetic lambda$fail$19()V
    .locals 3

    .line 207
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-nez v0, :cond_0

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v0, :cond_0

    sget-object v0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->restoreLocalSelection(Ljava/lang/Object;)V

    .line 208
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    invoke-static {p0}, Ldev/nino/squareglass/SquareOutput;->linnFailure(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$getAllAvailableDevices$7()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 94
    new-instance v0, Ljava/util/ArrayList;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    return-object v0
.end method

.method private synthetic lambda$init$3()V
    .locals 1

    const/4 v0, 0x0

    .line 62
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnProvider;->resume(I)V

    return-void
.end method

.method static synthetic lambda$new$0(Ljava/lang/String;)V
    .locals 1

    .line 44
    const-string v0, "SquareLinn"

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private synthetic lambda$new$1()V
    .locals 2

    .line 46
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnProvider;->startScanning()V

    .line 47
    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz p0, :cond_1

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Ldev/nino/squareglass/LinnPlayer;->nextRecovery:J

    :cond_1
    return-void
.end method

.method private synthetic lambda$new$2()V
    .locals 2

    .line 45
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda10;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda10;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic lambda$resume$4(I)V
    .locals 0

    add-int/lit8 p1, p1, 0x1

    .line 69
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->resume(I)V

    return-void
.end method

.method private synthetic lambda$resume$5(ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 1

    .line 85
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v0, :cond_2

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v0, :cond_2

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne p1, v0, :cond_2

    invoke-interface {p2}, Lcom/aspiro/wamp/player/k0;->getState()Lcom/aspiro/wamp/enums/MusicServiceState;

    move-result-object p1

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne p1, v0, :cond_0

    goto :goto_1

    .line 86
    :cond_0
    invoke-interface {p2}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    invoke-virtual {p3}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    .line 87
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object p2, p4, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {p1, p2, p4}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p4, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    .line 88
    invoke-static {p3}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p2, p0}, Lcom/aspiro/wamp/broadcast/l;->a(Lcom/aspiro/wamp/broadcast/o;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p3}, Ldev/nino/squareglass/LinnPlayer;->start()V

    .line 89
    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string p2, ""

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    return-void

    .line 85
    :cond_2
    :goto_1
    invoke-virtual {p3}, Ldev/nino/squareglass/LinnPlayer;->close()V

    return-void
.end method

.method private synthetic lambda$resume$6(Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;I)V
    .locals 7

    .line 75
    :try_start_0
    new-instance v0, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    move-object p1, v0

    const/16 v0, 0xdac

    .line 77
    :try_start_1
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->discover(I)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_1
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    .line 78
    :try_start_2
    new-instance v2, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    .line 79
    iget-object v1, v2, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    const-string v3, "sessionUuid"

    const-string v4, ""

    invoke-interface {p2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    if-eqz v1, :cond_0

    move-object v0, v2

    goto :goto_0

    :cond_1
    const/4 p2, 0x0

    move-object v0, p2

    :goto_0
    if-eqz v0, :cond_2

    .line 83
    :goto_1
    :try_start_3
    new-instance v6, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v6, v0}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    new-instance v5, Ldev/nino/squareglass/LinnPlayer;

    invoke-direct {v5, p0, v6, p3}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    invoke-virtual {v5}, Ldev/nino/squareglass/LinnPlayer;->reattach()V

    .line 84
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda9;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    move-object v2, p0

    move-object v4, p3

    move v3, p4

    :try_start_4
    invoke-direct/range {v1 .. v6}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda9;-><init>(Ldev/nino/squareglass/LinnProvider;ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-virtual {p1, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_2

    :cond_2
    move-object v2, p0

    .line 81
    throw p1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    :catch_2
    move-object v2, p0

    .line 91
    :catch_3
    const-string p0, "Could not reattach Linn. Its device queue was left unchanged."

    invoke-virtual {v2, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :goto_2
    return-void
.end method

.method private synthetic lambda$startScanning$8(I)V
    .locals 0

    .line 102
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->discover(I)V

    return-void
.end method

.method public static override(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 217
    sget-object v0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-eqz v0, :cond_0

    .line 218
    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v1, :cond_0

    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v1, :cond_0

    iget-object p0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    :cond_0
    return-object p0
.end method

.method public static prepareSelection(Ljava/lang/Object;)V
    .locals 2

    .line 222
    instance-of p0, p0, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz p0, :cond_0

    const-string p0, "SquareLinn"

    const-string v0, "Linn output selected"

    invoke-static {p0, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {}, Ldev/nino/squareglass/NativeOutputBridge;->active()Ljava/lang/Object;

    move-result-object p0

    sput-object p0, Ldev/nino/squareglass/LinnProvider;->previousOutput:Ljava/lang/Object;

    return-void

    :cond_0
    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    if-eqz p0, :cond_1

    iget-boolean p0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz p0, :cond_1

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    sget-object p0, Ldev/nino/squareglass/LinnProvider;->instance:Ldev/nino/squareglass/LinnProvider;

    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    :cond_1
    return-void
.end method


# virtual methods
.method public addListener(Lcom/aspiro/wamp/broadcast/l;)V
    .locals 0

    .line 54
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->addIfAbsent(Ljava/lang/Object;)Z

    return-void
.end method

.method public addListener(Lcom/aspiro/wamp/broadcast/q$a;)V
    .locals 0

    return-void
.end method

.method public connect(Lp2/a;)V
    .locals 7

    .line 141
    const-string v0, "SquareLinn"

    const-string v1, "Native provider connect requested"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 142
    instance-of v0, p1, Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v0, :cond_7

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-eqz v0, :cond_0

    goto/16 :goto_4

    .line 143
    :cond_0
    move-object v4, p1

    check-cast v4, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-static {}, Ldev/nino/squareglass/NativeLinnBridge;->player()Lcom/aspiro/wamp/player/k0;

    move-result-object p1

    if-eqz p1, :cond_6

    .line 144
    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->isLocal()Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_3

    .line 145
    :cond_1
    new-instance v6, Ldev/nino/squareglass/LinnPlayer;

    invoke-direct {v6, p0, v4, p1}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    .line 146
    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object v0

    if-nez v0, :cond_2

    const-string p1, "TIDAL player is still starting. Retry shortly."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void

    .line 147
    :cond_2
    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_4

    invoke-interface {p1}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object p1

    invoke-interface {p1}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_0

    :cond_3
    const/4 p1, 0x0

    move v5, p1

    goto :goto_1

    :cond_4
    :goto_0
    move v5, v1

    :goto_1
    if-nez v5, :cond_5

    .line 148
    :try_start_0
    invoke-virtual {v6}, Ldev/nino/squareglass/LinnPlayer;->capture()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception v0

    move-object p1, v0

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void

    .line 149
    :cond_5
    :goto_2
    iput-boolean v1, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    const-string p1, ""

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 150
    iget p1, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    add-int/lit8 v3, p1, 0x1

    iput v3, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    .line 151
    iput v3, v6, Ldev/nino/squareglass/LinnPlayer;->generation:I

    .line 152
    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->CHECKING:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v0, "Ger\u00e4t pr\u00fcfen\u2026"

    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 153
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda7;

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda7;-><init>(Ldev/nino/squareglass/LinnProvider;ILdev/nino/squareglass/LinnProvider$Device;ZLdev/nino/squareglass/LinnPlayer;)V

    invoke-interface {p1, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_6
    :goto_3
    move-object v2, p0

    .line 144
    const-string p0, "Switch to This phone before connecting Linn."

    invoke-virtual {v2, p0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_7
    :goto_4
    return-void
.end method

.method public disconnect(Lcom/aspiro/wamp/broadcast/o$a;)V
    .locals 3

    .line 178
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-nez v0, :cond_0

    .line 179
    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->DISCONNECTED:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    invoke-static {p1}, Ldev/nino/squareglass/NativeLinnBridge;->disconnected(Ljava/lang/Object;)V

    return-void

    .line 180
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda8;

    invoke-direct {v2, p0, v0, p1}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda8;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Lcom/aspiro/wamp/broadcast/o$a;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method discover(I)V
    .locals 5

    const/16 v0, 0xdac

    .line 106
    :try_start_0
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->discover(I)Ljava/util/Set;

    move-result-object v0

    .line 107
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v2, "squareglass_linn"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "location"

    const-string v3, ""

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 108
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 109
    :cond_0
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_0
    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 110
    iget-boolean v2, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v2, :cond_5

    iget v2, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-eq p1, v2, :cond_2

    goto :goto_2

    .line 112
    :cond_2
    :try_start_1
    new-instance v2, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    new-instance v3, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v3, v2}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    .line 113
    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v4, v3, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v2, v4, v3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz v2, :cond_1

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    iget-object v4, v3, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 115
    iput-object v3, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v2, :cond_1

    iget-boolean v4, v2, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v4, :cond_3

    iget-object v4, v2, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v4, v4, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v4, v4, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    invoke-virtual {v4, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    :cond_3
    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v4, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda2;

    invoke-direct {v4, v2, v3}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda2;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    invoke-interface {v1, v4}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    .line 119
    :cond_4
    :try_start_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda3;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    .line 120
    :catch_1
    const-string v0, "Linn discovery failed. Check the local network and retry."

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    .line 121
    :goto_1
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    if-eqz v0, :cond_5

    iget v0, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    if-ne p1, v0, :cond_5

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda4;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    const-wide/16 v2, 0x8

    sget-object p1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, p1}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    :cond_5
    :goto_2
    return-void
.end method

.method fail(Ljava/lang/String;)V
    .locals 1

    .line 202
    sget-object v0, Ldev/nino/squareglass/LinnProvider$Phase;->ERROR:Ldev/nino/squareglass/LinnProvider$Phase;

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    if-nez p1, :cond_0

    .line 203
    const-string p1, "Linn request failed. Retry."

    :cond_0
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    .line 204
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    .line 205
    const-string p1, "SquareLinn"

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->error:Ljava/lang/String;

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 206
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda18;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda18;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public get()Lcom/aspiro/wamp/broadcast/o;
    .locals 0

    return-object p0
.end method

.method public getAllAvailableDevices()Lio/reactivex/Single;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/Single<",
            "Ljava/util/List<",
            "Lp2/a;",
            ">;>;"
        }
    .end annotation

    .line 94
    new-instance v0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda17;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda17;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    invoke-static {v0}, Lio/reactivex/Single;->fromCallable(Ljava/util/concurrent/Callable;)Lio/reactivex/Single;

    move-result-object p0

    return-object p0
.end method

.method public getBroadcastProviderButton()Lcom/aspiro/wamp/broadcast/p;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getBroadcastProviderGroupButton()Lcom/aspiro/wamp/broadcast/r;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getConnectedItem()Lp2/a;
    .locals 0

    .line 58
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    return-object p0
.end method

.method public getVolumeControl()Lfq/f;
    .locals 0

    .line 57
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    return-object p0
.end method

.method public init()V
    .locals 4

    .line 62
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda19;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda19;-><init>(Ldev/nino/squareglass/LinnProvider;)V

    const-wide/16 v2, 0x9c4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public isAvailable()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isConnected()Z
    .locals 0

    .line 59
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public isConnecting()Z
    .locals 0

    .line 60
    iget-boolean p0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    return p0
.end method

.method public isValidItem(Lp2/a;)Z
    .locals 0

    .line 61
    instance-of p0, p1, Ldev/nino/squareglass/LinnProvider$Device;

    return p0
.end method

.method phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V
    .locals 3

    .line 32
    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider;->status:Ljava/lang/String;

    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "attempt="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget p0, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " phase="

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    invoke-static {p2}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V

    return-void
.end method

.method public refreshAvailability()V
    .locals 0

    return-void
.end method

.method resume(I)V
    .locals 9

    .line 64
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    if-nez v0, :cond_3

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->connecting:Z

    if-nez v0, :cond_3

    const/4 v0, 0x5

    if-lt p1, v0, :cond_0

    goto :goto_0

    .line 65
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v6

    .line 66
    const-string v0, "location"

    const-string v1, ""

    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 67
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    const-string v0, "sessionUuid"

    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    .line 69
    :cond_1
    :try_start_0
    invoke-static {}, Ldev/nino/squareglass/NativeLinnBridge;->player()Lcom/aspiro/wamp/player/k0;

    move-result-object v7
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v7, :cond_3

    .line 70
    invoke-interface {v7}, Lcom/aspiro/wamp/player/k0;->isLocal()Z

    move-result p1

    if-eqz p1, :cond_3

    invoke-interface {v7}, Lcom/aspiro/wamp/player/k0;->getState()Lcom/aspiro/wamp/enums/MusicServiceState;

    move-result-object p1

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne p1, v0, :cond_2

    goto :goto_0

    .line 71
    :cond_2
    iget v8, p0, Ldev/nino/squareglass/LinnProvider;->generation:I

    .line 72
    iget-object p1, p0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda14;

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda14;-><init>(Ldev/nino/squareglass/LinnProvider;Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;I)V

    invoke-interface {p1, v3}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :catch_0
    move-object v4, p0

    .line 69
    iget-object p0, v4, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda13;

    invoke-direct {v0, v4, p1}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda13;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    const-wide/16 v1, 0x7d0

    invoke-virtual {p0, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_3
    :goto_0
    return-void
.end method

.method public startScanning()V
    .locals 5

    .line 96
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 97
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    invoke-virtual {v0}, Landroid/app/Application;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v2, "wifi"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/wifi/WifiManager;

    if-eqz v0, :cond_0

    .line 98
    const-string v2, "SquareGlass Linn discovery"

    invoke-virtual {v0, v2}, Landroid/net/wifi/WifiManager;->createMulticastLock(Ljava/lang/String;)Landroid/net/wifi/WifiManager$MulticastLock;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0, v1}, Landroid/net/wifi/WifiManager$MulticastLock;->setReferenceCounted(Z)V

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->acquire()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    .line 99
    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    :cond_0
    :goto_0
    const/4 v0, 0x1

    .line 100
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    iget v2, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    add-int/2addr v2, v0

    iput v2, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    .line 101
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v0, :cond_1

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    .line 102
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->discovery:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0, v2}, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda6;-><init>(Ldev/nino/squareglass/LinnProvider;I)V

    const-wide/16 v2, 0x0

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, v4}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    return-void
.end method

.method public stopScanning()V
    .locals 2

    const/4 v0, 0x0

    .line 123
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnProvider;->scanning:Z

    iget v1, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Ldev/nino/squareglass/LinnProvider;->scanRevision:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider;->scan:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v1, :cond_0

    invoke-interface {v1, v0}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->release()V

    :cond_1
    const/4 v0, 0x0

    iput-object v0, p0, Ldev/nino/squareglass/LinnProvider;->multicast:Landroid/net/wifi/WifiManager$MulticastLock;

    :cond_2
    return-void
.end method
