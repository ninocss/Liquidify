.class public final synthetic Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/lifecycle/LifecycleEventObserver;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda2;->f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    return-void
.end method


# virtual methods
.method public final onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/NativeBackdrop$$ExternalSyntheticLambda2;->f$0:Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/NativeBackdrop;->$r8$lambda$_KJssD2PgS3wzRB8DkyXaHnijog(Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V

    return-void
.end method
