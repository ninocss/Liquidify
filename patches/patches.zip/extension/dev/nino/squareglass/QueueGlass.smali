.class public final Ldev/nino/squareglass/QueueGlass;
.super Ljava/lang/Object;
.source "QueueGlass.java"


# static fields
.field private static current:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Dialog;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 18
    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/QueueGlass;->current:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static dialog(Landroid/app/Dialog;)V
    .locals 1

    .line 20
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Ldev/nino/squareglass/QueueGlass;->current:Ljava/lang/ref/WeakReference;

    .line 21
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/SystemBarTheme;->installWindow(Landroid/view/Window;)Ldev/nino/squareglass/SystemBarTheme;

    :cond_0
    return-void
.end method

.method private static icons(Landroid/view/View;)V
    .locals 3

    .line 24
    instance-of v0, p0, Landroid/widget/ImageView;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0b04de

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0b0447

    if-ne v0, v1, :cond_1

    .line 25
    :cond_0
    move-object v0, p0

    check-cast v0, Landroid/widget/ImageView;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 26
    :cond_1
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    :goto_0
    move-object v1, p0

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    if-ge v0, v2, :cond_2

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Ldev/nino/squareglass/QueueGlass;->icons(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public static install(Landroid/view/View;)V
    .locals 8

    .line 29
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-eqz v0, :cond_9

    instance-of v0, p0, Landroid/view/ViewGroup;

    if-nez v0, :cond_0

    goto/16 :goto_2

    .line 30
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    .line 31
    :goto_0
    instance-of v1, v0, Landroid/content/ContextWrapper;

    if-eqz v1, :cond_2

    instance-of v1, v0, Landroid/app/Activity;

    if-nez v1, :cond_2

    .line 32
    move-object v1, v0

    check-cast v1, Landroid/content/ContextWrapper;

    invoke-virtual {v1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    if-ne v1, v0, :cond_1

    goto :goto_1

    :cond_1
    move-object v0, v1

    goto :goto_0

    .line 34
    :cond_2
    :goto_1
    instance-of v1, v0, Landroid/app/Activity;

    if-nez v1, :cond_3

    goto/16 :goto_2

    .line 35
    :cond_3
    new-instance v1, Ldev/nino/squareglass/LiquidMenuSurface;

    check-cast v0, Landroid/app/Activity;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Ldev/nino/squareglass/LiquidMenuSurface;-><init>(Landroid/app/Activity;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    .line 36
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v0, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v3, 0x0

    .line 37
    invoke-virtual {v1, v0, v2, v3}, Ldev/nino/squareglass/LiquidMenuSurface;->paint(Landroid/widget/FrameLayout;FZ)V

    const/4 v4, 0x4

    .line 38
    invoke-virtual {v0, v4}, Landroid/widget/FrameLayout;->setImportantForAccessibility(I)V

    .line 41
    move-object v4, p0

    check-cast v4, Landroid/view/ViewGroup;

    new-instance v5, Landroid/view/ViewGroup$LayoutParams;

    const/4 v6, -0x1

    invoke-direct {v5, v6, v6}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    const/4 v6, 0x1

    invoke-virtual {v4, v0, v6, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x7f0b04bd

    .line 42
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    :cond_4
    const v0, 0x7f0b06ef

    .line 43
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 44
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v2

    invoke-static {v2}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v2

    const v4, 0x7f0b06b4

    .line 45
    invoke-virtual {p0, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    .line 46
    instance-of v5, v4, Lcom/google/android/material/tabs/TabLayout;

    if-eqz v5, :cond_5

    .line 47
    check-cast v4, Lcom/google/android/material/tabs/TabLayout;

    invoke-virtual {v4, v2}, Lcom/google/android/material/tabs/TabLayout;->setSelectedTabIndicatorColor(I)V

    const v5, 0xffffff

    and-int/2addr v5, v2

    const/high16 v7, -0x67000000

    or-int/2addr v5, v7

    .line 48
    invoke-virtual {v4, v5, v2}, Lcom/google/android/material/tabs/TabLayout;->setTabTextColors(II)V

    .line 50
    :cond_5
    instance-of v4, v0, Landroidx/appcompat/widget/Toolbar;

    if-eqz v4, :cond_8

    .line 51
    check-cast v0, Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    if-eqz v4, :cond_6

    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v4, v2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    .line 52
    :cond_6
    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->getOverflowIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    if-eqz v4, :cond_7

    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->getOverflowIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v4, v2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    .line 53
    :cond_7
    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->getMenu()Landroid/view/Menu;

    move-result-object v0

    const-string v2, "Sleep timer"

    invoke-interface {v0, v2}, Landroid/view/Menu;->add(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    new-instance v2, Ldev/nino/squareglass/QueueGlass$0;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/QueueGlass$0;-><init>(Landroid/view/View;)V

    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    .line 58
    :cond_8
    invoke-static {p0}, Ldev/nino/squareglass/SquareExplore;->install(Landroid/view/View;)V

    .line 59
    invoke-static {p0, v3, v6}, Ldev/nino/squareglass/SurfaceMotion;->enter(Landroid/view/View;ZZ)V

    .line 60
    new-instance v0, Ldev/nino/squareglass/QueueGlass$2;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/QueueGlass$2;-><init>(Landroid/view/View;)V

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 61
    new-instance v0, Ldev/nino/squareglass/QueueGlass$1;

    invoke-direct {v0, v1, p0}, Ldev/nino/squareglass/QueueGlass$1;-><init>(Ldev/nino/squareglass/LiquidMenuSurface;Landroid/view/View;)V

    invoke-virtual {p0, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_9
    :goto_2
    return-void
.end method

.method static synthetic lambda$install$0(Landroid/view/View;Landroid/view/MenuItem;)Z
    .locals 2

    .line 53
    sget-object p1, Ldev/nino/squareglass/QueueGlass;->current:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/app/Dialog;

    .line 54
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    :goto_0
    instance-of v1, v0, Landroid/content/ContextWrapper;

    if-eqz v1, :cond_0

    instance-of v1, v0, Landroid/app/Activity;

    if-nez v1, :cond_0

    check-cast v0, Landroid/content/ContextWrapper;

    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    goto :goto_0

    :cond_0
    if-eqz p1, :cond_1

    .line 55
    instance-of v1, v0, Landroid/app/Activity;

    if-eqz v1, :cond_1

    check-cast v0, Landroid/app/Activity;

    invoke-static {p1, v0}, Ldev/nino/squareglass/SleepTimer;->showInDialog(Landroid/app/Dialog;Landroid/app/Activity;)V

    goto :goto_1

    .line 56
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/SleepTimer;->show(Landroid/content/Context;)V

    :goto_1
    const/4 p0, 0x1

    return p0
.end method

.method static synthetic lambda$install$1(Landroid/view/View;)V
    .locals 1

    .line 60
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p0}, Ldev/nino/squareglass/QueueGlass;->icons(Landroid/view/View;)V

    :cond_0
    return-void
.end method
