.class public final synthetic Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareLibrary;

.field public final synthetic f$1:I

.field public final synthetic f$2:I

.field public final synthetic f$3:I

.field public final synthetic f$4:Z

.field public final synthetic f$5:Ljava/lang/String;

.field public final synthetic f$6:Lam0/a;

.field public final synthetic f$7:Landroidx/compose/ui/Modifier;

.field public final synthetic f$8:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareLibrary;IIIZLjava/lang/String;Lam0/a;Landroidx/compose/ui/Modifier;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$0:Ldev/nino/squareglass/SquareLibrary;

    iput p2, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$1:I

    iput p3, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$2:I

    iput p4, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$3:I

    iput-boolean p5, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$4:Z

    iput-object p6, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$5:Ljava/lang/String;

    iput-object p7, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$6:Lam0/a;

    iput-object p8, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$7:Landroidx/compose/ui/Modifier;

    iput p9, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$8:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$0:Ldev/nino/squareglass/SquareLibrary;

    iget v1, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$1:I

    iget v2, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$2:I

    iget v3, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$3:I

    iget-boolean v4, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$4:Z

    iget-object v5, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$5:Ljava/lang/String;

    iget-object v6, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$6:Lam0/a;

    iget-object v7, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$7:Landroidx/compose/ui/Modifier;

    iget v8, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda4;->f$8:I

    move-object v9, p1

    check-cast v9, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v10

    invoke-static/range {v0 .. v10}, Ldev/nino/squareglass/SquareLibrary;->$r8$lambda$pMeMCb4DtBTmGUk-HmjZJPl_QVQ(Ldev/nino/squareglass/SquareLibrary;IIIZLjava/lang/String;Lam0/a;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
