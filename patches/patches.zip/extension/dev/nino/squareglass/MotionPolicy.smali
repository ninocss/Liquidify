.class public final Ldev/nino/squareglass/MotionPolicy;
.super Ljava/lang/Object;
.source "MotionPolicy.java"


# instance fields
.field private interaction:J

.field private lastFire:J

.field private touching:Z


# direct methods
.method public constructor <init>(J)V
    .locals 2

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, -0x2ee0

    .line 4
    iput-wide v0, p0, Ldev/nino/squareglass/MotionPolicy;->lastFire:J

    .line 6
    iput-wide p1, p0, Ldev/nino/squareglass/MotionPolicy;->interaction:J

    return-void
.end method

.method public static visible(FFFFFFFF)Z
    .locals 2

    cmpl-float v0, p2, p0

    if-lez v0, :cond_0

    cmpl-float v0, p3, p1

    if-lez v0, :cond_0

    const/4 v0, 0x0

    cmpl-float v1, p6, v0

    if-lez v1, :cond_0

    cmpl-float v0, p7, v0

    if-lez v0, :cond_0

    cmpl-float p2, p2, p4

    if-lez p2, :cond_0

    add-float/2addr p4, p6

    cmpg-float p0, p0, p4

    if-gez p0, :cond_0

    cmpl-float p0, p3, p5

    if-lez p0, :cond_0

    add-float/2addr p5, p7

    cmpg-float p0, p1, p5

    if-gez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public fired(J)V
    .locals 0

    .line 11
    iput-wide p1, p0, Ldev/nino/squareglass/MotionPolicy;->lastFire:J

    return-void
.end method

.method public ready(JZ)Z
    .locals 4

    if-eqz p3, :cond_0

    .line 9
    iget-boolean p3, p0, Ldev/nino/squareglass/MotionPolicy;->touching:Z

    if-nez p3, :cond_0

    iget-wide v0, p0, Ldev/nino/squareglass/MotionPolicy;->interaction:J

    sub-long v0, p1, v0

    const-wide/16 v2, 0x1388

    cmp-long p3, v0, v2

    if-ltz p3, :cond_0

    iget-wide v0, p0, Ldev/nino/squareglass/MotionPolicy;->lastFire:J

    sub-long/2addr p1, v0

    const-wide/16 v0, 0x2ee0

    cmp-long p0, p1, v0

    if-ltz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public touch(JZ)V
    .locals 0

    .line 7
    iput-wide p1, p0, Ldev/nino/squareglass/MotionPolicy;->interaction:J

    iput-boolean p3, p0, Ldev/nino/squareglass/MotionPolicy;->touching:Z

    return-void
.end method
