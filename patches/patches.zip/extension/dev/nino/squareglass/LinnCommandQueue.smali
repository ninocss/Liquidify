.class final Ldev/nino/squareglass/LinnCommandQueue;
.super Ljava/lang/Object;
.source "LinnCommandQueue.java"


# instance fields
.field private final executor:Ljava/util/concurrent/Executor;

.field private final revisions:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Ljava/util/concurrent/atomic/AtomicLong;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;)V
    .locals 1

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnCommandQueue;->revisions:Ljava/util/concurrent/ConcurrentHashMap;

    .line 11
    iput-object p1, p0, Ldev/nino/squareglass/LinnCommandQueue;->executor:Ljava/util/concurrent/Executor;

    return-void
.end method

.method static synthetic lambda$execute$0(Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLong;
    .locals 0

    .line 13
    new-instance p0, Ljava/util/concurrent/atomic/AtomicLong;

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    return-object p0
.end method

.method static synthetic lambda$execute$1(Ljava/util/concurrent/atomic/AtomicLong;JLjava/lang/Runnable;)V
    .locals 2

    .line 15
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    cmp-long p0, v0, p1

    if-nez p0, :cond_0

    invoke-interface {p3}, Ljava/lang/Runnable;->run()V

    :cond_0
    return-void
.end method


# virtual methods
.method execute(Ljava/lang/String;Ljava/lang/Runnable;)V
    .locals 3

    .line 13
    iget-object v0, p0, Ldev/nino/squareglass/LinnCommandQueue;->revisions:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v1, Ldev/nino/squareglass/LinnCommandQueue$0;

    invoke-direct {v1}, Ldev/nino/squareglass/LinnCommandQueue$0;-><init>()V

    invoke-virtual {v0, p1, v1}, Ljava/util/concurrent/ConcurrentHashMap;->computeIfAbsent(Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/concurrent/atomic/AtomicLong;

    .line 14
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    move-result-wide v0

    .line 15
    iget-object p0, p0, Ldev/nino/squareglass/LinnCommandQueue;->executor:Ljava/util/concurrent/Executor;

    new-instance v2, Ldev/nino/squareglass/LinnCommandQueue$1;

    invoke-direct {v2, p1, v0, v1, p2}, Ldev/nino/squareglass/LinnCommandQueue$1;-><init>(Ljava/util/concurrent/atomic/AtomicLong;JLjava/lang/Runnable;)V

    invoke-interface {p0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
