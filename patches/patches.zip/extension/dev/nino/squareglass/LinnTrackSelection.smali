.class final Ldev/nino/squareglass/LinnTrackSelection;
.super Ljava/lang/Object;
.source "LinnTrackSelection.java"

# interfaces
.implements Ljava/lang/AutoCloseable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnTrackSelection$Goal;
    }
.end annotation


# instance fields
.field private final completed:Ljava/lang/Runnable;

.field private final failed:Ljava/util/function/Consumer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/function/Consumer<",
            "Ljava/lang/Exception;",
            ">;"
        }
    .end annotation
.end field

.field private volatile goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

.field private final transport:Ljava/util/function/Supplier;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/function/Supplier<",
            "Ldev/nino/squareglass/OpenHome;",
            ">;"
        }
    .end annotation
.end field

.field private final valid:Ljava/util/function/BooleanSupplier;

.field private final worker:Ljava/util/concurrent/ScheduledExecutorService;


# direct methods
.method public static synthetic $r8$lambda$VBn2qe15B6tOimXG20sg09qEk2c(Ldev/nino/squareglass/LinnTrackSelection;Ldev/nino/squareglass/LinnTrackSelection$Goal;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnTrackSelection;->lambda$request$0(Ldev/nino/squareglass/LinnTrackSelection$Goal;)V

    return-void
.end method

.method public static synthetic $r8$lambda$bFXgu_drZhicCzuw_KqXX8-J1C4(Ldev/nino/squareglass/LinnTrackSelection;Ldev/nino/squareglass/LinnTrackSelection$Goal;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnTrackSelection;->lambda$step$0(Ldev/nino/squareglass/LinnTrackSelection$Goal;)V

    return-void
.end method

.method constructor <init>(Ljava/util/concurrent/ScheduledExecutorService;Ljava/util/function/Supplier;Ljava/util/function/BooleanSupplier;Ljava/lang/Runnable;Ljava/util/function/Consumer;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/ScheduledExecutorService;",
            "Ljava/util/function/Supplier<",
            "Ldev/nino/squareglass/OpenHome;",
            ">;",
            "Ljava/util/function/BooleanSupplier;",
            "Ljava/lang/Runnable;",
            "Ljava/util/function/Consumer<",
            "Ljava/lang/Exception;",
            ">;)V"
        }
    .end annotation

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    iput-object p1, p0, Ldev/nino/squareglass/LinnTrackSelection;->worker:Ljava/util/concurrent/ScheduledExecutorService;

    iput-object p2, p0, Ldev/nino/squareglass/LinnTrackSelection;->transport:Ljava/util/function/Supplier;

    iput-object p3, p0, Ldev/nino/squareglass/LinnTrackSelection;->valid:Ljava/util/function/BooleanSupplier;

    iput-object p4, p0, Ldev/nino/squareglass/LinnTrackSelection;->completed:Ljava/lang/Runnable;

    iput-object p5, p0, Ldev/nino/squareglass/LinnTrackSelection;->failed:Ljava/util/function/Consumer;

    return-void
.end method

.method private synthetic lambda$request$0(Ldev/nino/squareglass/LinnTrackSelection$Goal;)V
    .locals 0

    .line 32
    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnTrackSelection;->step(Ldev/nino/squareglass/LinnTrackSelection$Goal;)V

    return-void
.end method

.method private synthetic lambda$step$0(Ldev/nino/squareglass/LinnTrackSelection$Goal;)V
    .locals 0

    .line 89
    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnTrackSelection;->step(Ldev/nino/squareglass/LinnTrackSelection$Goal;)V

    return-void
.end method

.method private request(JIZZ)V
    .locals 6

    .line 32
    new-instance v0, Ldev/nino/squareglass/LinnTrackSelection$Goal;

    const/4 v1, 0x0

    invoke-static {v1, p3}, Ljava/lang/Math;->max(II)I

    move-result v3

    move-wide v1, p1

    move v4, p4

    move v5, p5

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/LinnTrackSelection$Goal;-><init>(JIZZ)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    iget-object p1, p0, Ldev/nino/squareglass/LinnTrackSelection;->worker:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance p2, Ldev/nino/squareglass/LinnTrackSelection$0;

    invoke-direct {p2, p0, v0}, Ldev/nino/squareglass/LinnTrackSelection$0;-><init>(Ldev/nino/squareglass/LinnTrackSelection;Ldev/nino/squareglass/LinnTrackSelection$Goal;)V

    invoke-interface {p1, p2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method private step(Ldev/nino/squareglass/LinnTrackSelection$Goal;)V
    .locals 13

    .line 36
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    if-eq v0, p1, :cond_0

    goto/16 :goto_a

    .line 37
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->valid:Ljava/util/function/BooleanSupplier;

    invoke-interface {v0}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_2

    .line 38
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    if-ne v0, p1, :cond_1

    iput-object v1, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    goto :goto_0

    :cond_1
    move v2, v3

    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v2, :cond_1f

    .line 39
    iget-object p0, p0, Ldev/nino/squareglass/LinnTrackSelection;->completed:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void

    :catchall_0
    move-exception v0

    move-object p1, v0

    .line 38
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    .line 41
    :cond_2
    iget-object v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->next:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v0, :cond_3

    iget-object v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->next:Ljava/util/concurrent/ScheduledFuture;

    invoke-interface {v0, v3}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    .line 42
    :cond_3
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    iget-wide v4, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->end:J

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v6

    sget-object v8, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    iget v9, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    if-nez v9, :cond_4

    const-wide/16 v9, 0x3

    goto :goto_1

    :cond_4
    const-wide/16 v9, 0x1

    :goto_1
    invoke-virtual {v8, v9, v10}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v8

    add-long/2addr v6, v8

    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 44
    :try_start_2
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    iget-wide v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->end:J

    cmp-long v0, v4, v6

    if-gez v0, :cond_1d

    .line 45
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->transport:Ljava/util/function/Supplier;

    invoke-interface {v0}, Ljava/util/function/Supplier;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Ldev/nino/squareglass/OpenHome;

    .line 46
    iget v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    const/4 v5, 0x4

    if-eqz v0, :cond_19

    const/4 v6, 0x2

    if-eq v0, v2, :cond_16

    const/4 v7, 0x3

    if-eq v0, v6, :cond_11

    if-eq v0, v7, :cond_a

    if-ne v0, v5, :cond_9

    .line 79
    iget v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I

    iget v8, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->millis:I

    if-eq v0, v8, :cond_5

    iput v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    goto/16 :goto_6

    .line 80
    :cond_5
    iget-object v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedPlay:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iget-boolean v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->play:Z

    if-eq v0, v6, :cond_6

    iput v7, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    goto/16 :goto_6

    .line 81
    :cond_6
    iget-wide v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->id:J

    invoke-static {v6, v7}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v0

    const-string v6, "Playlist"

    const-string v7, "Id"

    invoke-virtual {v4, v6, v7}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1a

    iget-boolean v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->play:Z

    if-eqz v0, :cond_7

    const-string v0, "Playing"

    goto :goto_2

    :cond_7
    const-string v0, "Paused"

    :goto_2
    const-string v6, "Playlist"

    const-string v7, "TransportState"

    invoke-virtual {v4, v6, v7}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 83
    monitor-enter p0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    :try_start_3
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    if-ne v0, p1, :cond_8

    iget-object v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedPlay:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iget-boolean v4, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->play:Z

    if-ne v0, v4, :cond_8

    iget v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I

    iget v4, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->millis:I

    if-ne v0, v4, :cond_8

    iput-object v1, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    move v3, v2

    :cond_8
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-eqz v3, :cond_1a

    .line 84
    :try_start_4
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->completed:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 91
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catchall_1
    move-exception v0

    .line 83
    :try_start_5
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :try_start_6
    throw v0

    .line 87
    :cond_9
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "Invalid selection phase"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 69
    :cond_a
    iget v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I

    iget v7, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->millis:I

    if-eq v0, v7, :cond_b

    iput v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    goto/16 :goto_6

    .line 70
    :cond_b
    iget-boolean v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->preserveTransport:Z

    if-eqz v0, :cond_d

    .line 71
    monitor-enter p0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    :try_start_7
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    if-ne v0, p1, :cond_c

    iget-boolean v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->preserveTransport:Z

    if-eqz v0, :cond_c

    iget v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I

    iget v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->millis:I

    if-ne v0, v6, :cond_c

    iput-object v1, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    move v0, v2

    goto :goto_3

    :cond_c
    move v0, v3

    :goto_3
    monitor-exit p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    if-eqz v0, :cond_d

    .line 72
    :try_start_8
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->completed:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_1
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 91
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :catchall_2
    move-exception v0

    .line 71
    :try_start_9
    monitor-exit p0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :try_start_a
    throw v0

    .line 74
    :cond_d
    iget-boolean v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->play:Z

    if-eqz v0, :cond_e

    .line 75
    const-string v6, "Playing"

    const-string v7, "Playlist"

    const-string v8, "TransportState"

    invoke-virtual {v4, v7, v8}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_10

    :cond_e
    const-string v6, "Playlist"

    if-eqz v0, :cond_f

    const-string v7, "Play"

    goto :goto_4

    :cond_f
    const-string v7, "Pause"

    :goto_4
    new-array v3, v3, [Ljava/lang/String;

    invoke-virtual {v4, v6, v7, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 76
    :cond_10
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedPlay:Ljava/lang/Boolean;

    iput v5, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    goto/16 :goto_6

    .line 54
    :cond_11
    iget v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->millis:I

    .line 55
    iget-boolean v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->selectStream:Z

    if-eqz v0, :cond_12

    iget v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I

    if-gez v0, :cond_12

    if-nez v6, :cond_12

    iput v3, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I

    iput v7, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    goto/16 :goto_6

    .line 56
    :cond_12
    iget v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_1
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    if-eq v0, v6, :cond_15

    .line 57
    :try_start_b
    const-string v0, "Playlist"

    const-string v8, "SeekSecondAbsolute"

    div-int/lit16 v9, v6, 0x3e8

    invoke-static {v9}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v9

    filled-new-array {v9}, [Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v0, v8, v9}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    iput v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I
    :try_end_b
    .catch Ldev/nino/squareglass/OpenHome$Fault; {:try_start_b .. :try_end_b} :catch_0
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_1
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    goto :goto_5

    :catch_0
    move-exception v0

    .line 59
    :try_start_c
    iget-object v8, v0, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v9, Ldev/nino/squareglass/OpenHome$Failure;->REJECTED:Ldev/nino/squareglass/OpenHome$Failure;

    if-ne v8, v9, :cond_13

    const-string v8, "803"

    iget-object v9, v0, Ldev/nino/squareglass/OpenHome$Fault;->code:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_13

    goto :goto_6

    .line 60
    :cond_13
    iget-object v8, v0, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v9, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    if-ne v8, v9, :cond_14

    .line 61
    iput v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->appliedSeek:I

    goto :goto_5

    .line 60
    :cond_14
    throw v0

    .line 64
    :cond_15
    :goto_5
    const-string v0, "Time"

    const-string v8, "Time"

    new-array v3, v3, [Ljava/lang/String;

    invoke-virtual {v4, v0, v8, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    .line 65
    const-string v3, "Seconds"

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    div-int/lit16 v6, v6, 0x3e8

    int-to-long v8, v6

    sub-long/2addr v3, v8

    invoke-static {v3, v4}, Ljava/lang/Math;->abs(J)J

    move-result-wide v3

    const-wide/16 v8, 0x2

    cmp-long v0, v3, v8

    if-gtz v0, :cond_1a

    iput v7, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    goto :goto_6

    .line 50
    :cond_16
    iget-wide v7, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->id:J

    invoke-static {v7, v8}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v0

    const-string v3, "Playlist"

    const-string v7, "Id"

    invoke-virtual {v4, v3, v7}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_17

    iput v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    goto :goto_6

    .line 51
    :cond_17
    iget-boolean v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->selectStream:Z

    if-eqz v0, :cond_18

    goto :goto_6

    :cond_18
    new-instance v6, Ldev/nino/squareglass/OpenHome$Fault;

    sget-object v7, Ldev/nino/squareglass/OpenHome$Failure;->CONFLICT:Ldev/nino/squareglass/OpenHome$Failure;

    const-string v8, "Seek"

    const-string v10, ""

    const-string v11, "Linn current track changed; retry seeking"

    const/4 v12, 0x0

    const/4 v9, 0x0

    invoke-direct/range {v6 .. v12}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v6

    .line 48
    :cond_19
    const-string v0, "Playlist"

    const-string v3, "SeekId"

    iget-wide v6, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->id:J

    invoke-static {v6, v7}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v6

    filled-new-array {v6}, [Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v0, v3, v6}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    iput v2, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    .line 89
    :cond_1a
    :goto_6
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    if-ne v0, p1, :cond_1e

    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->worker:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Ldev/nino/squareglass/LinnTrackSelection$1;

    invoke-direct {v3, p0, p1}, Ldev/nino/squareglass/LinnTrackSelection$1;-><init>(Ldev/nino/squareglass/LinnTrackSelection;Ldev/nino/squareglass/LinnTrackSelection$Goal;)V

    iget v4, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    if-eq v4, v2, :cond_1c

    iget v2, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->phase:I

    if-ne v2, v5, :cond_1b

    goto :goto_7

    :cond_1b
    const-wide/16 v4, 0x0

    goto :goto_8

    :cond_1c
    :goto_7
    const-wide/16 v4, 0x64

    :goto_8
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v3, v4, v5, v2}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p1, Ldev/nino/squareglass/LinnTrackSelection$Goal;->next:Ljava/util/concurrent/ScheduledFuture;

    goto :goto_9

    .line 44
    :cond_1d
    new-instance v2, Ldev/nino/squareglass/OpenHome$Fault;

    sget-object v3, Ldev/nino/squareglass/OpenHome$Failure;->TIMEOUT:Ldev/nino/squareglass/OpenHome$Failure;

    const-string v4, "Track selection"

    const-string v6, ""

    const-string v7, "Linn did not confirm the selected track"

    const/4 v8, 0x0

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_1
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    :catch_1
    move-exception v0

    .line 90
    :try_start_d
    iget-object v2, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    if-ne v2, p1, :cond_1e

    iput-object v1, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    iget-object p0, p0, Ldev/nino/squareglass/LinnTrackSelection;->failed:Ljava/util/function/Consumer;

    invoke-interface {p0, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_3

    .line 91
    :cond_1e
    :goto_9
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    :cond_1f
    :goto_a
    return-void

    :catchall_3
    move-exception v0

    move-object p0, v0

    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    throw p0
.end method


# virtual methods
.method active()Z
    .locals 0

    .line 29
    iget-object p0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public declared-synchronized close()V
    .locals 2

    monitor-enter p0

    .line 93
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    const/4 v1, 0x0

    iput-object v1, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;

    if-eqz v0, :cond_0

    iget-object v1, v0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->next:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v1, :cond_0

    iget-object v0, v0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->next:Ljava/util/concurrent/ScheduledFuture;

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method declared-synchronized play(Z)Z
    .locals 2

    monitor-enter p0

    .line 33
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    monitor-exit p0

    return v1

    :cond_0
    :try_start_1
    iput-boolean v1, v0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->preserveTransport:Z

    iput-boolean p1, v0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->play:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    const/4 p0, 0x1

    return p0

    :catchall_0
    move-exception p1

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method declared-synchronized seek(I)Z
    .locals 2

    monitor-enter p0

    .line 34
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnTrackSelection;->goal:Ldev/nino/squareglass/LinnTrackSelection$Goal;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    monitor-exit p0

    return v1

    :cond_0
    :try_start_1
    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, v0, Ldev/nino/squareglass/LinnTrackSelection$Goal;->millis:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    const/4 p0, 0x1

    return p0

    :catchall_0
    move-exception p1

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method declared-synchronized seekCurrent(JIZ)V
    .locals 7

    monitor-enter p0

    const/4 v6, 0x0

    move-object v1, p0

    move-wide v2, p1

    move v4, p3

    move v5, p4

    .line 31
    :try_start_0
    invoke-direct/range {v1 .. v6}, Ldev/nino/squareglass/LinnTrackSelection;->request(JIZZ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-void

    :catchall_0
    move-exception v0

    move-object p0, v0

    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method declared-synchronized select(JIZ)V
    .locals 7

    monitor-enter p0

    const/4 v6, 0x1

    move-object v1, p0

    move-wide v2, p1

    move v4, p3

    move v5, p4

    .line 30
    :try_start_0
    invoke-direct/range {v1 .. v6}, Ldev/nino/squareglass/LinnTrackSelection;->request(JIZZ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-void

    :catchall_0
    move-exception v0

    move-object p0, v0

    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method
