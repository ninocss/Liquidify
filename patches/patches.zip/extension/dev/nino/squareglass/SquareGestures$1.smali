.class Ldev/nino/squareglass/SquareGestures$1;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SquareGestures.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SquareGestures;->reset(Landroid/view/View;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/SquareGestures;

.field final synthetic val$row:Landroid/view/View;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/SquareGestures;Landroid/view/View;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 131
    iput-object p1, p0, Ldev/nino/squareglass/SquareGestures$1;->this$0:Ldev/nino/squareglass/SquareGestures;

    iput-object p2, p0, Ldev/nino/squareglass/SquareGestures$1;->val$row:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    .line 132
    iget-object p1, p0, Ldev/nino/squareglass/SquareGestures$1;->this$0:Ldev/nino/squareglass/SquareGestures;

    iget-object v0, p0, Ldev/nino/squareglass/SquareGestures$1;->val$row:Landroid/view/View;

    invoke-static {p1, v0}, Ldev/nino/squareglass/SquareGestures;->-$$Nest$mclear(Ldev/nino/squareglass/SquareGestures;Landroid/view/View;)V

    iget-object p0, p0, Ldev/nino/squareglass/SquareGestures$1;->this$0:Ldev/nino/squareglass/SquareGestures;

    const/4 p1, 0x0

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareGestures;->-$$Nest$fputreturning(Ldev/nino/squareglass/SquareGestures;Landroid/animation/ValueAnimator;)V

    return-void
.end method
