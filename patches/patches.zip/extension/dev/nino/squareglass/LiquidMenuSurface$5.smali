.class public final synthetic Ldev/nino/squareglass/LiquidMenuSurface$5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LiquidMenuSurface;

.field public final synthetic f$1:Ldev/nino/squareglass/backdrop/Backdrop;

.field public final synthetic f$2:F

.field public final synthetic f$3:Z

.field public final synthetic f$4:Z

.field public final synthetic f$5:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LiquidMenuSurface;Ldev/nino/squareglass/backdrop/Backdrop;FZZI)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$0:Ldev/nino/squareglass/LiquidMenuSurface;

    iput-object p2, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$1:Ldev/nino/squareglass/backdrop/Backdrop;

    iput p3, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$2:F

    iput-boolean p4, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$3:Z

    iput-boolean p5, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$4:Z

    iput p6, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$5:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$0:Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v1, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$1:Ldev/nino/squareglass/backdrop/Backdrop;

    iget v2, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$2:F

    iget-boolean v3, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$3:Z

    iget-boolean v4, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$4:Z

    iget v5, p0, Ldev/nino/squareglass/LiquidMenuSurface$5;->f$5:I

    move-object v6, p1

    check-cast v6, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/LiquidMenuSurface;->Pane$lambda$5(Ldev/nino/squareglass/LiquidMenuSurface;Ldev/nino/squareglass/backdrop/Backdrop;FZZILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
