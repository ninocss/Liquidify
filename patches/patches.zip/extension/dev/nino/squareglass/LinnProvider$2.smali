.class public final synthetic Ldev/nino/squareglass/LinnProvider$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;

.field public final synthetic f$1:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$2:Ldev/nino/squareglass/LinnProvider$Device;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$2;->f$0:Ldev/nino/squareglass/LinnProvider;

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider$2;->f$1:Ldev/nino/squareglass/LinnPlayer;

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider$2;->f$2:Ldev/nino/squareglass/LinnProvider$Device;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$2;->f$0:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider$2;->f$1:Ldev/nino/squareglass/LinnPlayer;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$2;->f$2:Ldev/nino/squareglass/LinnProvider$Device;

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$07lbsbJGdvzA5h19_GLaIslDctk(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method
