.class public final Ldev/nino/squareglass/LiquidMenuSurface;
.super Ljava/lang/Object;
.source "LiquidMenuSurface.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLiquidMenuSurface.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LiquidMenuSurface.kt\ndev/nino/squareglass/LiquidMenuSurface\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 5 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 6 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 7 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,190:1\n123#2:191\n123#2:192\n123#2:226\n123#2:232\n123#2:233\n113#2:234\n1128#3,6:193\n1128#3,6:199\n1128#3,6:205\n1128#3,6:211\n1128#3,6:217\n85#4:223\n117#4,2:224\n57#5:227\n61#5:230\n60#6:228\n70#6:231\n22#7:229\n*S KotlinDebug\n*F\n+ 1 LiquidMenuSurface.kt\ndev/nino/squareglass/LiquidMenuSurface\n*L\n161#1:191\n162#1:192\n172#1:226\n175#1:232\n176#1:233\n180#1:234\n169#1:193,6\n170#1:199,6\n179#1:205,6\n180#1:211,6\n181#1:217,6\n88#1:223\n88#1:224,2\n174#1:227\n174#1:230\n174#1:228\n174#1:231\n174#1:229\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000d\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0007\u0018\u00002\u00020\u0001:\u0001$B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J*\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0008\u0008\u0002\u0010\u001c\u001a\u00020\u001bH\u0007J\u000e\u0010\u001d\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u001eJ\u0006\u0010\u001f\u001a\u00020\u0015J-\u0010 \u001a\u00020\u00152\u0006\u0010!\u001a\u00020\"2\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001bH\u0003\u00a2\u0006\u0002\u0010#R\u0016\u0010\u0008\u001a\n \n*\u0004\u0018\u00010\t0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0010\u001a\u0012\u0012\u0004\u0012\u00020\u00120\u0011j\u0008\u0012\u0004\u0012\u00020\u0012`\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006%\u00b2\u0006\n\u0010!\u001a\u00020\"X\u008a\u008e\u0002"
    }
    d2 = {
        "Ldev/nino/squareglass/LiquidMenuSurface;",
        "",
        "activity",
        "Landroid/app/Activity;",
        "snapshot",
        "Ldev/nino/squareglass/PlayerWindow$Snapshot;",
        "<init>",
        "(Landroid/app/Activity;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V",
        "source",
        "Landroid/view/View;",
        "kotlin.jvm.PlatformType",
        "ownerSource",
        "node",
        "Landroid/graphics/RenderNode;",
        "sourceScreen",
        "",
        "surfaces",
        "Ljava/util/ArrayList;",
        "Landroidx/compose/ui/platform/ComposeView;",
        "Lkotlin/collections/ArrayList;",
        "paint",
        "",
        "container",
        "Landroid/widget/FrameLayout;",
        "radius",
        "",
        "emphasized",
        "",
        "sheet",
        "clearWithin",
        "Landroid/view/ViewGroup;",
        "release",
        "Pane",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "(Ldev/nino/squareglass/backdrop/Backdrop;FZZLandroidx/compose/runtime/Composer;I)V",
        "WindowBackdrop",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final node:Landroid/graphics/RenderNode;

.field private final ownerSource:Landroid/view/View;

.field private final source:Landroid/view/View;

.field private final sourceScreen:[I

.field private final surfaces:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/compose/ui/platform/ComposeView;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$0_nACt8_KEZeD7Z2NT9EOiak0bQ(Landroidx/compose/foundation/shape/RoundedCornerShape;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/LiquidMenuSurface;->Pane$lambda$0$0(Landroidx/compose/foundation/shape/RoundedCornerShape;)Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$8KDWgz0TOAv8ur2GLjXW8SAcBhw(Z)Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/LiquidMenuSurface;->Pane$lambda$3$0(Z)Ldev/nino/squareglass/backdrop/shadow/Shadow;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Z9hYlg3DrJ6oerbwhO2C2cmY2OM(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/LiquidMenuSurface;->Pane$lambda$1$0(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$dNcuHXncjURjmFYuukeXFiyJR_E(JFZZLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static/range {p0 .. p5}, Ldev/nino/squareglass/LiquidMenuSurface;->Pane$lambda$4$0(JFZZLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$lo_ikKwxi9KLVMupvv0WCDjFiCU()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/LiquidMenuSurface;->Pane$lambda$2$0()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V
    .locals 6

    const-string v0, "activity"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    if-eqz p2, :cond_0

    .line 46
    move-object v1, p1

    check-cast v1, Landroid/content/Context;

    invoke-virtual {p2, v1, v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->view(Landroid/content/Context;Z)Landroid/view/View;

    move-result-object v1

    if-nez v1, :cond_1

    :cond_0
    invoke-static {p1}, Ldev/nino/squareglass/PlayerWindow;->source(Landroid/app/Activity;)Landroid/view/View;

    move-result-object v1

    :cond_1
    iput-object v1, p0, Ldev/nino/squareglass/LiquidMenuSurface;->source:Landroid/view/View;

    .line 47
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const-string v2, "getDecorView(...)"

    invoke-static {p1, v2}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ldev/nino/squareglass/LiquidMenuSurface;->ownerSource:Landroid/view/View;

    .line 48
    new-instance p1, Landroid/graphics/RenderNode;

    const-string v2, "SquareGlass menu backdrop"

    invoke-direct {p1, v2}, Landroid/graphics/RenderNode;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Ldev/nino/squareglass/LiquidMenuSurface;->node:Landroid/graphics/RenderNode;

    const/4 v2, 0x2

    .line 49
    new-array v3, v2, [I

    iput-object v3, p0, Ldev/nino/squareglass/LiquidMenuSurface;->sourceScreen:[I

    .line 50
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Ldev/nino/squareglass/LiquidMenuSurface;->surfaces:Ljava/util/ArrayList;

    if-eqz p2, :cond_2

    .line 54
    iget v4, p2, Ldev/nino/squareglass/PlayerWindow$Snapshot;->width:I

    iget v5, p2, Ldev/nino/squareglass/PlayerWindow$Snapshot;->height:I

    invoke-virtual {v1, v0, v0, v4, v5}, Landroid/view/View;->layout(IIII)V

    .line 55
    iget v4, p2, Ldev/nino/squareglass/PlayerWindow$Snapshot;->x:I

    aput v4, v3, v0

    const/4 v4, 0x1

    iget v5, p2, Ldev/nino/squareglass/PlayerWindow$Snapshot;->y:I

    aput v5, v3, v4

    .line 59
    :cond_2
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v4

    if-eq v4, v2, :cond_4

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v2

    if-lez v2, :cond_4

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v2

    if-lez v2, :cond_4

    if-nez p2, :cond_3

    .line 60
    invoke-virtual {v1, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 61
    :cond_3
    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result p2

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-virtual {p1, v0, v0, p2, v2}, Landroid/graphics/RenderNode;->setPosition(IIII)Z

    .line 62
    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result p2

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v0

    invoke-virtual {p1, p2, v0}, Landroid/graphics/RenderNode;->beginRecording(II)Landroid/graphics/RecordingCanvas;

    move-result-object p2

    const-string v0, "beginRecording(...)"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    :try_start_0
    check-cast p2, Landroid/graphics/Canvas;

    invoke-virtual {v1, p2}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p1}, Landroid/graphics/RenderNode;->endRecording()V

    return-void

    :catchall_0
    move-exception p1

    iget-object p0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p0}, Landroid/graphics/RenderNode;->endRecording()V

    throw p1

    :cond_4
    return-void
.end method

.method private final Pane(Ldev/nino/squareglass/backdrop/Backdrop;FZZLandroidx/compose/runtime/Composer;I)V
    .locals 23

    move-object/from16 v2, p1

    move/from16 v4, p3

    move/from16 v0, p4

    move/from16 v1, p6

    const v3, -0x6a9e80ce

    move-object/from16 v5, p5

    .line 158
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    const-string v5, "C(Pane)N(backdrop,radius,emphasized,sheet)159@8109L4,186@9433L42:LiquidMenuSurface.kt#vqphja"

    invoke-static {v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v5, v1, 0x6

    const/4 v6, 0x2

    if-nez v5, :cond_2

    and-int/lit8 v5, v1, 0x8

    if-nez v5, :cond_0

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    goto :goto_0

    :cond_0
    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    :goto_0
    if-eqz v5, :cond_1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    move v5, v6

    :goto_1
    or-int/2addr v5, v1

    goto :goto_2

    :cond_2
    move v5, v1

    :goto_2
    and-int/lit8 v7, v1, 0x30

    move/from16 v10, p2

    if-nez v7, :cond_4

    invoke-interface {v9, v10}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v7

    if-eqz v7, :cond_3

    const/16 v7, 0x20

    goto :goto_3

    :cond_3
    const/16 v7, 0x10

    :goto_3
    or-int/2addr v5, v7

    :cond_4
    and-int/lit16 v7, v1, 0x180

    if-nez v7, :cond_6

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v7

    if-eqz v7, :cond_5

    const/16 v7, 0x100

    goto :goto_4

    :cond_5
    const/16 v7, 0x80

    :goto_4
    or-int/2addr v5, v7

    :cond_6
    and-int/lit16 v7, v1, 0xc00

    if-nez v7, :cond_8

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v7

    if-eqz v7, :cond_7

    const/16 v7, 0x800

    goto :goto_5

    :cond_7
    const/16 v7, 0x400

    :goto_5
    or-int/2addr v5, v7

    :cond_8
    and-int/lit16 v7, v5, 0x493

    const/16 v11, 0x492

    if-eq v7, v11, :cond_9

    const/4 v7, 0x1

    goto :goto_6

    :cond_9
    const/4 v7, 0x0

    :goto_6
    and-int/lit8 v11, v5, 0x1

    invoke-interface {v9, v7, v11}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_18

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_a

    const/4 v7, -0x1

    const-string v11, "dev.nino.squareglass.LiquidMenuSurface.Pane (LiquidMenuSurface.kt:157)"

    invoke-static {v3, v5, v7, v11}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 159
    :cond_a
    sget-object v3, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v3}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 160
    sget-object v3, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v7, 0x6

    invoke-virtual {v3, v9, v7}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v3

    if-eqz v0, :cond_b

    .line 191
    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v14

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v15

    const/16 v18, 0xc

    const/16 v19, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    .line 161
    invoke-static/range {v14 .. v19}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-a9UjIt4$default(FFFFILjava/lang/Object;)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v7

    goto :goto_7

    .line 192
    :cond_b
    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 162
    invoke-static {v7}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v7

    :goto_7
    if-eqz v3, :cond_c

    const-wide v14, 0xff33343aL

    .line 163
    invoke-static {v14, v15}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v14

    goto :goto_8

    :cond_c
    sget-object v11, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v14

    .line 164
    :goto_8
    invoke-static {v3}, Ldev/nino/squareglass/SquareSettings;->readableOpacity(Z)F

    move-result v11

    .line 165
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v12

    if-ne v12, v6, :cond_d

    const v5, -0x632807cb

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    .line 167
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 166
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    check-cast v7, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v5, v7}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    invoke-static {v3}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v3

    invoke-static {v3}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v15

    const/16 v18, 0x2

    const/16 v19, 0x0

    const/16 v17, 0x0

    invoke-static/range {v14 .. v19}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move-object/from16 p5, v9

    const/4 v0, 0x1

    goto/16 :goto_b

    :cond_d
    const v6, -0x3d013a39

    .line 167
    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "168@8606L9,169@8639L417,178@9082L21,179@9126L51,180@9207L206"

    invoke-static {v9, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v12, v6

    check-cast v12, Landroidx/compose/ui/Modifier;

    const v6, -0x3d013545

    .line 169
    const-string v13, "CC(remember):LiquidMenuSurface.kt#9igjgp"

    invoke-static {v9, v6, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    .line 193
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    if-nez v6, :cond_e

    .line 194
    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v8, v6, :cond_f

    .line 169
    :cond_e
    new-instance v8, Ldev/nino/squareglass/LiquidMenuSurface$0;

    invoke-direct {v8, v7}, Ldev/nino/squareglass/LiquidMenuSurface$0;-><init>(Landroidx/compose/foundation/shape/RoundedCornerShape;)V

    .line 196
    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 169
    :cond_f
    move-object/from16 v18, v8

    check-cast v18, Lam0/a;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v6, -0x3d012f8d

    .line 170
    invoke-static {v9, v6, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 199
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .line 200
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v6, v7, :cond_10

    .line 201
    new-instance v6, Ldev/nino/squareglass/LiquidMenuSurface$1;

    invoke-direct {v6}, Ldev/nino/squareglass/LiquidMenuSurface$1;-><init>()V

    .line 202
    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 170
    :cond_10
    move-object/from16 v19, v6

    check-cast v19, Lam0/l;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v6, -0x3d00f9b9

    .line 179
    invoke-static {v9, v6, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 205
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .line 206
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v6, v7, :cond_11

    .line 207
    new-instance v6, Ldev/nino/squareglass/LiquidMenuSurface$2;

    invoke-direct {v6}, Ldev/nino/squareglass/LiquidMenuSurface$2;-><init>()V

    .line 208
    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 179
    :cond_11
    move-object/from16 v20, v6

    check-cast v20, Lam0/a;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v6, -0x3d00f41b

    .line 180
    invoke-static {v9, v6, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v5, v5, 0x380

    const/16 v6, 0x100

    if-ne v5, v6, :cond_12

    const/4 v6, 0x1

    goto :goto_9

    :cond_12
    const/4 v6, 0x0

    .line 211
    :goto_9
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    if-nez v6, :cond_13

    .line 212
    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v7, v6, :cond_14

    .line 180
    :cond_13
    new-instance v7, Ldev/nino/squareglass/LiquidMenuSurface$3;

    invoke-direct {v7, v4}, Ldev/nino/squareglass/LiquidMenuSurface$3;-><init>(Z)V

    .line 214
    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 180
    :cond_14
    move-object/from16 v21, v7

    check-cast v21, Lam0/a;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v6, -0x3d00e960

    .line 181
    invoke-static {v9, v6, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v14, v15}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v6

    invoke-interface {v9, v11}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v7

    or-int/2addr v6, v7

    const/16 v7, 0x100

    if-ne v5, v7, :cond_15

    const/4 v5, 0x1

    goto :goto_a

    :cond_15
    const/4 v5, 0x0

    :goto_a
    or-int/2addr v5, v6

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    or-int/2addr v5, v6

    .line 217
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    if-nez v5, :cond_16

    .line 218
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v6, v5, :cond_17

    :cond_16
    move v8, v3

    .line 181
    new-instance v3, Ldev/nino/squareglass/LiquidMenuSurface$4;

    move v7, v4

    move v6, v11

    move-wide v4, v14

    invoke-direct/range {v3 .. v8}, Ldev/nino/squareglass/LiquidMenuSurface$4;-><init>(JFZZ)V

    .line 220
    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    move-object v6, v3

    .line 181
    :cond_17
    check-cast v6, Lam0/l;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object/from16 v3, v18

    const v18, 0xfbe0

    move-object/from16 v4, v19

    const/16 v19, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v5, v9

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v17, 0x1

    const/16 v16, 0x0

    move/from16 v22, v17

    const/16 v17, 0x0

    move-object/from16 p5, v5

    move-object v1, v12

    move-object/from16 v5, v20

    move/from16 v0, v22

    move-object v12, v6

    move-object/from16 v6, v21

    .line 167
    invoke-static/range {v1 .. v19}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->drawBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 187
    :goto_b
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v2, v0, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-interface {v0, v3}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move-object/from16 v5, p5

    const/4 v1, 0x0

    invoke-static {v0, v5, v1}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_c

    :cond_18
    move-object v5, v9

    .line 158
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 188
    :cond_19
    :goto_c
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_1a

    new-instance v0, Ldev/nino/squareglass/LiquidMenuSurface$5;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/LiquidMenuSurface$5;-><init>(Ldev/nino/squareglass/LiquidMenuSurface;Ldev/nino/squareglass/backdrop/Backdrop;FZZI)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_1a
    return-void
.end method

.method private static final Pane$lambda$0$0(Landroidx/compose/foundation/shape/RoundedCornerShape;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 169
    check-cast p0, Landroidx/compose/ui/graphics/Shape;

    return-object p0
.end method

.method private static final Pane$lambda$1$0(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 10

    const-string v0, "$this$drawBackdrop"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 171
    invoke-static {p0}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->vibrancy(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)V

    .line 172
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->blur()F

    move-result v0

    .line 226
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 172
    invoke-interface {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0, v3, v1, v2}, Ldev/nino/squareglass/backdrop/effects/BlurKt;->blur-3YTHUZs$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FIILjava/lang/Object;)V

    .line 173
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    if-nez v0, :cond_0

    .line 174
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v0

    const/16 v2, 0x20

    shr-long/2addr v0, v2

    long-to-int v0, v0

    .line 229
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    .line 174
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v1

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    long-to-int v1, v1

    .line 229
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    .line 174
    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const v1, 0x3eb33333    # 0.35f

    mul-float/2addr v0, v1

    .line 175
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v1

    const/high16 v2, 0x42700000    # 60.0f

    mul-float/2addr v1, v2

    .line 232
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 175
    invoke-interface {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v1

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->coerceAtMost(FF)F

    move-result v4

    .line 176
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v1

    mul-float/2addr v2, v1

    .line 233
    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 176
    invoke-interface {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v1

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->coerceAtMost(FF)F

    move-result v5

    const/16 v8, 0xc

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v3, p0

    .line 175
    invoke-static/range {v3 .. v9}, Ldev/nino/squareglass/backdrop/effects/LensKt;->lens$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZILjava/lang/Object;)V

    .line 178
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Pane$lambda$2$0()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    .line 179
    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Companion:Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;->getDefault()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method private static final Pane$lambda$3$0(Z)Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 10

    .line 180
    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/Shadow;

    if-eqz p0, :cond_0

    const/4 p0, 0x4

    goto :goto_0

    :cond_0
    const/16 p0, 0xc

    :goto_0
    int-to-float p0, p0

    .line 234
    invoke-static {p0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 180
    invoke-direct/range {v0 .. v9}, Ldev/nino/squareglass/backdrop/shadow/Shadow;-><init>(FJJFIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private static final Pane$lambda$4$0(JFZZLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 14

    const-string v0, "$this$drawBackdrop"

    move-object/from16 v1, p5

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 182
    sget v0, Ldev/nino/squareglass/ProbeDiagnostics;->glassDraws:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->glassDraws:I

    const/16 v8, 0xe

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-wide v2, p0

    move/from16 v4, p2

    .line 183
    invoke-static/range {v2 .. v9}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v2

    const/16 v12, 0x7e

    const/4 v13, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v1 .. v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    if-eqz p3, :cond_0

    .line 184
    invoke-static/range {p4 .. p4}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p0

    invoke-static {p0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    const/16 v6, 0xe

    const/4 v7, 0x0

    const v2, 0x3d75c28f    # 0.06f

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v2

    const/16 v12, 0x7e

    const/4 v13, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object/from16 v1, p5

    invoke-static/range {v1 .. v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 185
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final Pane$lambda$5(Ldev/nino/squareglass/LiquidMenuSurface;Ldev/nino/squareglass/backdrop/Backdrop;FZZILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 7

    or-int/lit8 p5, p5, 0x1

    invoke-static {p5}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/LiquidMenuSurface;->Pane(Ldev/nino/squareglass/backdrop/Backdrop;FZZLandroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final synthetic access$getNode$p(Ldev/nino/squareglass/LiquidMenuSurface;)Landroid/graphics/RenderNode;
    .locals 0

    .line 45
    iget-object p0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->node:Landroid/graphics/RenderNode;

    return-object p0
.end method

.method public static final synthetic access$getOwnerSource$p(Ldev/nino/squareglass/LiquidMenuSurface;)Landroid/view/View;
    .locals 0

    .line 45
    iget-object p0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->ownerSource:Landroid/view/View;

    return-object p0
.end method

.method public static final synthetic access$getSourceScreen$p(Ldev/nino/squareglass/LiquidMenuSurface;)[I
    .locals 0

    .line 45
    iget-object p0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->sourceScreen:[I

    return-object p0
.end method

.method public static synthetic paint$default(Ldev/nino/squareglass/LiquidMenuSurface;Landroid/widget/FrameLayout;FZZILjava/lang/Object;)V
    .locals 0

    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_0

    const/4 p4, 0x0

    .line 67
    :cond_0
    invoke-virtual {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/LiquidMenuSurface;->paint(Landroid/widget/FrameLayout;FZZ)V

    return-void
.end method

.method private static final paint$lambda$0(Landroidx/compose/runtime/MutableState;)Ldev/nino/squareglass/backdrop/Backdrop;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            ">;)",
            "Ldev/nino/squareglass/backdrop/Backdrop;"
        }
    .end annotation

    .line 88
    check-cast p0, Landroidx/compose/runtime/State;

    .line 223
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/backdrop/Backdrop;

    return-object p0
.end method

.method private static final paint$lambda$1(Landroidx/compose/runtime/MutableState;Ldev/nino/squareglass/backdrop/Backdrop;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            ">;",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            ")V"
        }
    .end annotation

    .line 224
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method static final paint$lambda$2(Landroidx/compose/ui/platform/ComposeView;[I[ILdev/nino/squareglass/LiquidMenuSurface;Landroidx/compose/runtime/MutableState;)Z
    .locals 5

    .line 95
    const-string v0, "null cannot be cast to non-null type android.view.View"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0, p1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v0, 0x0

    .line 96
    aget v1, p1, v0

    aget v2, p2, v0

    const/4 v3, 0x1

    if-ne v1, v2, :cond_0

    aget v2, p1, v3

    aget v4, p2, v3

    if-eq v2, v4, :cond_1

    .line 97
    :cond_0
    aput v1, p2, v0

    aget p1, p1, v3

    aput p1, p2, v3

    .line 98
    new-instance p1, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;

    invoke-direct {p1, p3, p0}, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;-><init>(Ldev/nino/squareglass/LiquidMenuSurface;Landroid/view/View;)V

    check-cast p1, Ldev/nino/squareglass/backdrop/Backdrop;

    invoke-static {p4, p1}, Ldev/nino/squareglass/LiquidMenuSurface;->paint$lambda$1(Landroidx/compose/runtime/MutableState;Ldev/nino/squareglass/backdrop/Backdrop;)V

    :cond_1
    return v3
.end method

.method static final paint$lambda$3(Ldev/nino/squareglass/LiquidMenuSurface;FZZLandroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 4

    const-string v0, "C107@5835L41:LiquidMenuSurface.kt#vqphja"

    invoke-static {p5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p6, 0x3

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    and-int/lit8 v1, p6, 0x1

    invoke-interface {p5, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, -0x1

    const-string v1, "dev.nino.squareglass.LiquidMenuSurface.paint.<anonymous> (LiquidMenuSurface.kt:107)"

    const v2, 0x2581a40d

    invoke-static {v2, p6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 108
    :cond_1
    invoke-static {p4}, Ldev/nino/squareglass/LiquidMenuSurface;->paint$lambda$0(Landroidx/compose/runtime/MutableState;)Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object p4

    const/4 p6, 0x0

    move v3, p2

    move p2, p1

    move-object p1, p4

    move p4, p3

    move p3, v3

    invoke-direct/range {p0 .. p6}, Ldev/nino/squareglass/LiquidMenuSurface;->Pane(Ldev/nino/squareglass/backdrop/Backdrop;FZZLandroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    :cond_2
    invoke-interface {p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_3
    :goto_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final clearWithin(Landroid/view/ViewGroup;)V
    .locals 2

    const-string v0, "container"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 121
    iget-object p0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->surfaces:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const-string v0, "iterator(...)"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 123
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "next(...)"

    invoke-static {v0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroidx/compose/ui/platform/ComposeView;

    .line 124
    move-object v1, v0

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    :goto_1
    if-eqz v1, :cond_1

    if-eq v1, p1, :cond_1

    .line 125
    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    goto :goto_1

    :cond_1
    if-ne v1, p1, :cond_0

    .line 127
    invoke-virtual {v0}, Landroidx/compose/ui/platform/ComposeView;->disposeComposition()V

    .line 128
    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    goto :goto_0

    :cond_2
    return-void
.end method

.method public final paint(Landroid/widget/FrameLayout;FZ)V
    .locals 8

    const-string v0, "container"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v6, 0x8

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    invoke-static/range {v1 .. v7}, Ldev/nino/squareglass/LiquidMenuSurface;->paint$default(Ldev/nino/squareglass/LiquidMenuSurface;Landroid/widget/FrameLayout;FZZILjava/lang/Object;)V

    return-void
.end method

.method public final paint(Landroid/widget/FrameLayout;FZZ)V
    .locals 12

    const-string v0, "container"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    new-instance v0, Ldev/nino/squareglass/LiquidMenuSurface$paint$1;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LiquidMenuSurface$paint$1;-><init>(Ldev/nino/squareglass/LiquidMenuSurface;)V

    check-cast v0, Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {p1, v0}, Landroid/widget/FrameLayout;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 81
    new-instance v6, Landroidx/compose/ui/platform/ComposeView;

    invoke-virtual {p1}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v7

    const-string v0, "getContext(...)"

    invoke-static {v7, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct/range {v6 .. v11}, Landroidx/compose/ui/platform/ComposeView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 82
    sget-object v0, Landroidx/compose/ui/platform/ViewCompositionStrategy$DisposeOnDetachedFromWindow;->INSTANCE:Landroidx/compose/ui/platform/ViewCompositionStrategy$DisposeOnDetachedFromWindow;

    check-cast v0, Landroidx/compose/ui/platform/ViewCompositionStrategy;

    invoke-virtual {v6, v0}, Landroidx/compose/ui/platform/ComposeView;->setViewCompositionStrategy(Landroidx/compose/ui/platform/ViewCompositionStrategy;)V

    .line 83
    move-object v7, v6

    check-cast v7, Landroid/view/View;

    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->ownerSource:Landroid/view/View;

    invoke-static {v0}, Landroidx/lifecycle/ViewTreeLifecycleOwner;->get(Landroid/view/View;)Landroidx/lifecycle/LifecycleOwner;

    move-result-object v0

    invoke-static {v7, v0}, Landroidx/lifecycle/ViewTreeLifecycleOwner;->set(Landroid/view/View;Landroidx/lifecycle/LifecycleOwner;)V

    .line 84
    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->ownerSource:Landroid/view/View;

    invoke-static {v0}, Landroidx/savedstate/ViewTreeSavedStateRegistryOwner;->get(Landroid/view/View;)Landroidx/savedstate/SavedStateRegistryOwner;

    move-result-object v0

    invoke-static {v7, v0}, Landroidx/savedstate/ViewTreeSavedStateRegistryOwner;->set(Landroid/view/View;Landroidx/savedstate/SavedStateRegistryOwner;)V

    const/4 v8, 0x0

    .line 85
    invoke-virtual {v7, v8}, Landroid/view/View;->setClickable(Z)V

    .line 86
    invoke-virtual {v7, v8}, Landroid/view/View;->setFocusable(Z)V

    const/4 v9, 0x4

    .line 87
    invoke-virtual {v7, v9}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 88
    new-instance v0, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;

    invoke-direct {v0, p0, v7}, Ldev/nino/squareglass/LiquidMenuSurface$WindowBackdrop;-><init>(Ldev/nino/squareglass/LiquidMenuSurface;Landroid/view/View;)V

    const/4 v2, 0x0

    const/4 v10, 0x2

    invoke-static {v0, v2, v10, v2}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    const/high16 v0, -0x80000000

    .line 89
    filled-new-array {v0, v0}, [I

    move-result-object v3

    .line 90
    new-array v2, v10, [I

    .line 91
    new-instance v0, Ldev/nino/squareglass/LiquidMenuSurface$6;

    move-object v4, p0

    move-object v1, v6

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/LiquidMenuSurface$6;-><init>(Landroidx/compose/ui/platform/ComposeView;[I[ILdev/nino/squareglass/LiquidMenuSurface;Landroidx/compose/runtime/MutableState;)V

    .line 102
    new-instance v1, Ldev/nino/squareglass/LiquidMenuSurface$paint$2;

    invoke-direct {v1, v0}, Ldev/nino/squareglass/LiquidMenuSurface$paint$2;-><init>(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    check-cast v1, Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v7, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 108
    new-instance v0, Ldev/nino/squareglass/LiquidMenuSurface$7;

    move-object v1, p0

    move v2, p2

    move v3, p3

    move/from16 v4, p4

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/LiquidMenuSurface$7;-><init>(Ldev/nino/squareglass/LiquidMenuSurface;FZZLandroidx/compose/runtime/MutableState;)V

    const v2, 0x2581a40d

    const/4 v3, 0x1

    invoke-static {v2, v3, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lam0/p;

    invoke-virtual {v6, v0}, Landroidx/compose/ui/platform/ComposeView;->setContent(Lam0/p;)V

    .line 109
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v0, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p1, v7, v8, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 110
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 111
    invoke-virtual {v0, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 112
    invoke-virtual {p1}, Landroid/widget/FrameLayout;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v2, p2

    const/16 v4, 0x8

    if-eqz p4, :cond_0

    .line 113
    new-array v4, v4, [F

    aput v2, v4, v8

    aput v2, v4, v3

    aput v2, v4, v10

    const/4 v5, 0x3

    aput v2, v4, v5

    const/4 v2, 0x0

    aput v2, v4, v9

    const/4 v5, 0x5

    aput v2, v4, v5

    const/4 v5, 0x6

    aput v2, v4, v5

    const/4 v5, 0x7

    aput v2, v4, v5

    goto :goto_1

    :cond_0
    new-array v5, v4, [F

    :goto_0
    if-ge v8, v4, :cond_1

    aput v2, v5, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_1
    move-object v4, v5

    :goto_1
    invoke-virtual {v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 115
    check-cast v0, Landroid/graphics/drawable/Drawable;

    invoke-virtual {p1, v0}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 116
    invoke-virtual {p1, v3}, Landroid/widget/FrameLayout;->setClipToOutline(Z)V

    .line 117
    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->surfaces:Ljava/util/ArrayList;

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final release()V
    .locals 3

    .line 134
    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->surfaces:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v1, "iterator(...)"

    invoke-static {v0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const-string v2, "next(...)"

    invoke-static {v1, v2}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Landroidx/compose/ui/platform/ComposeView;

    invoke-virtual {v1}, Landroidx/compose/ui/platform/ComposeView;->disposeComposition()V

    goto :goto_0

    .line 135
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->surfaces:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 136
    iget-object p0, p0, Ldev/nino/squareglass/LiquidMenuSurface;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p0}, Landroid/graphics/RenderNode;->discardDisplayList()V

    return-void
.end method
