.class public final synthetic Ldev/nino/squareglass/DesignEntry$20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Lam0/l;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableIntState;


# direct methods
.method public synthetic constructor <init>(Lam0/l;Landroidx/compose/runtime/MutableIntState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$20;->f$0:Lam0/l;

    iput-object p2, p0, Ldev/nino/squareglass/DesignEntry$20;->f$1:Landroidx/compose/runtime/MutableIntState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/DesignEntry$20;->f$0:Lam0/l;

    iget-object p0, p0, Ldev/nino/squareglass/DesignEntry$20;->f$1:Landroidx/compose/runtime/MutableIntState;

    check-cast p1, Landroidx/compose/foundation/lazy/LazyListScope;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/DesignEntry;->$r8$lambda$weg0_1bLB_29VIY3mZd0mvT7h3A(Lam0/l;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
