.class public final synthetic Ldev/nino/squareglass/LinnProvider$10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$10;->f$0:Ldev/nino/squareglass/LinnProvider;

    iput p2, p0, Ldev/nino/squareglass/LinnProvider$10;->f$1:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$10;->f$0:Ldev/nino/squareglass/LinnProvider;

    iget p0, p0, Ldev/nino/squareglass/LinnProvider$10;->f$1:I

    invoke-static {v0, p0}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$6yos42bJ7LF1iNW5WMJUfNykryM(Ldev/nino/squareglass/LinnProvider;I)V

    return-void
.end method
