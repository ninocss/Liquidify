.class Ldev/nino/squareglass/ProbeDiagnostics$1;
.super Landroid/content/BroadcastReceiver;
.source "ProbeDiagnostics.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/ProbeDiagnostics;->install(Landroid/app/Activity;Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$activity:Landroid/app/Activity;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .locals 0

    .line 81
    iput-object p1, p0, Ldev/nino/squareglass/ProbeDiagnostics$1;->val$activity:Landroid/app/Activity;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    .line 83
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    const-string v0, "dev.nino.squareglass.STYLES"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    .line 84
    iget-object p1, p0, Ldev/nino/squareglass/ProbeDiagnostics$1;->val$activity:Landroid/app/Activity;

    invoke-static {p0, p1}, Ldev/nino/squareglass/ProbeDiagnostics;->-$$Nest$smreportStyles(Landroid/content/BroadcastReceiver;Landroid/app/Activity;)V

    return-void

    .line 85
    :cond_0
    invoke-static {p0, p1}, Ldev/nino/squareglass/ProbeDiagnostics;->-$$Nest$smreport(Landroid/content/BroadcastReceiver;Landroid/content/Context;)V

    return-void
.end method
