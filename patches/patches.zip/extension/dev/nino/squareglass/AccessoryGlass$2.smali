.class public final synthetic Ldev/nino/squareglass/AccessoryGlass$2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:J


# direct methods
.method public synthetic constructor <init>(ZLjava/lang/String;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Ldev/nino/squareglass/AccessoryGlass$2;->f$0:Z

    iput-object p2, p0, Ldev/nino/squareglass/AccessoryGlass$2;->f$1:Ljava/lang/String;

    iput-wide p3, p0, Ldev/nino/squareglass/AccessoryGlass$2;->f$2:J

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    iget-boolean v0, p0, Ldev/nino/squareglass/AccessoryGlass$2;->f$0:Z

    iget-object v1, p0, Ldev/nino/squareglass/AccessoryGlass$2;->f$1:Ljava/lang/String;

    iget-wide v2, p0, Ldev/nino/squareglass/AccessoryGlass$2;->f$2:J

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    invoke-static {v0, v1, v2, v3, p1}, Ldev/nino/squareglass/AccessoryGlass;->$r8$lambda$tmi1IiUplOChNcKIcqmSQF09Mr0(ZLjava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
