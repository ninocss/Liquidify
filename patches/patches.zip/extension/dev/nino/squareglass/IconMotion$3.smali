.class public final synthetic Ldev/nino/squareglass/IconMotion$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/runtime/State;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/runtime/State;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/IconMotion$3;->f$0:Landroidx/compose/runtime/State;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$3;->f$0:Landroidx/compose/runtime/State;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->$r8$lambda$JfJUMPP2JMtf2r4tKuDq3URC6nU(Landroidx/compose/runtime/State;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
