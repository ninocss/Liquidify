.class public final Ldev/nino/squareglass/DesignEntry;
.super Ljava/lang/Object;
.source "DesignEntry.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDesignEntry.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DesignEntry.kt\ndev/nino/squareglass/DesignEntry\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 4 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 9 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 10 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 11 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 12 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 13 SnapshotFloatState.kt\nandroidx/compose/runtime/PrimitiveSnapshotStateKt__SnapshotFloatStateKt\n*L\n1#1,144:1\n1807#2,3:145\n1924#2,2:420\n1926#2:512\n113#3:148\n113#3:190\n113#3:265\n113#3:280\n113#3:318\n113#3:382\n113#3:428\n113#3:466\n113#3:535\n70#4:149\n67#4,9:150\n77#4:189\n70#4:319\n67#4,9:320\n77#4:359\n70#4:467\n67#4,9:468\n77#4:507\n80#5,6:159\n87#5,3:174\n90#5,2:183\n94#5:188\n80#5,6:201\n87#5,3:216\n90#5,2:225\n80#5,6:238\n87#5,3:253\n90#5,2:262\n94#5:268\n94#5:272\n80#5,6:291\n87#5,3:306\n90#5,2:315\n80#5,6:329\n87#5,3:344\n90#5,2:353\n94#5:358\n94#5:368\n80#5,6:393\n87#5,3:408\n90#5,2:417\n80#5,6:439\n87#5,3:454\n90#5,2:463\n80#5,6:477\n87#5,3:492\n90#5,2:501\n94#5:506\n94#5:510\n94#5:515\n80#5,6:546\n87#5,3:561\n90#5,2:570\n94#5:593\n80#5,6:612\n87#5,3:627\n90#5,2:636\n94#5:689\n391#6,9:165\n400#6,3:185\n391#6,9:207\n400#6:227\n391#6,9:244\n400#6:264\n401#6,2:266\n401#6,2:270\n391#6,9:297\n400#6:317\n391#6,9:335\n400#6,3:355\n401#6,2:366\n391#6,9:399\n400#6:419\n391#6,9:445\n400#6:465\n391#6,9:483\n400#6,3:503\n401#6,2:508\n401#6,2:513\n391#6,9:552\n400#6:572\n401#6,2:591\n391#6,9:618\n400#6:638\n401#6,2:687\n4360#7,6:177\n4360#7,6:219\n4360#7,6:256\n4360#7,6:309\n4360#7,6:347\n4360#7,6:411\n4360#7,6:457\n4360#7,6:495\n4360#7,6:564\n4360#7,6:630\n99#8:191\n96#8,9:192\n106#8:273\n99#8:281\n96#8,9:282\n106#8:369\n99#8:429\n96#8,9:430\n106#8:511\n87#9:228\n84#9,9:229\n94#9:269\n87#9:383\n84#9,9:384\n94#9:516\n87#9:536\n84#9,9:537\n94#9:594\n87#9:602\n84#9,9:603\n94#9:690\n1128#10,6:274\n1128#10,6:360\n1128#10,6:370\n1128#10,6:376\n1128#10,6:422\n1128#10,6:517\n1128#10,6:523\n1128#10,6:529\n1128#10,6:573\n1128#10,6:579\n1128#10,6:585\n1128#10,6:596\n1128#10,6:639\n1128#10,6:645\n1128#10,6:651\n1128#10,6:657\n1128#10,6:663\n1128#10,6:669\n1128#10,6:675\n1128#10,6:681\n75#11:595\n85#12:691\n117#12,2:692\n85#12:694\n117#12,2:695\n85#12:700\n117#12,2:701\n80#13:697\n113#13,2:698\n*S KotlinDebug\n*F\n+ 1 DesignEntry.kt\ndev/nino/squareglass/DesignEntry\n*L\n32#1:145,3\n80#1:420,2\n80#1:512\n53#1:148\n57#1:190\n58#1:265\n67#1:280\n69#1:318\n79#1:382\n83#1:428\n86#1:466\n96#1:535\n53#1:149\n53#1:150,9\n53#1:189\n69#1:319\n69#1:320,9\n69#1:359\n86#1:467\n86#1:468,9\n86#1:507\n53#1:159,6\n53#1:174,3\n53#1:183,2\n53#1:188\n56#1:201,6\n56#1:216,3\n56#1:225,2\n58#1:238,6\n58#1:253,3\n58#1:262,2\n58#1:268\n56#1:272\n66#1:291,6\n66#1:306,3\n66#1:315,2\n69#1:329,6\n69#1:344,3\n69#1:353,2\n69#1:358\n66#1:368\n79#1:393,6\n79#1:408,3\n79#1:417,2\n81#1:439,6\n81#1:454,3\n81#1:463,2\n86#1:477,6\n86#1:492,3\n86#1:501,2\n86#1:506\n81#1:510\n79#1:515\n96#1:546,6\n96#1:561,3\n96#1:570,2\n96#1:593\n111#1:612,6\n111#1:627,3\n111#1:636,2\n111#1:689\n53#1:165,9\n53#1:185,3\n56#1:207,9\n56#1:227\n58#1:244,9\n58#1:264\n58#1:266,2\n56#1:270,2\n66#1:297,9\n66#1:317\n69#1:335,9\n69#1:355,3\n66#1:366,2\n79#1:399,9\n79#1:419\n81#1:445,9\n81#1:465\n86#1:483,9\n86#1:503,3\n81#1:508,2\n79#1:513,2\n96#1:552,9\n96#1:572\n96#1:591,2\n111#1:618,9\n111#1:638\n111#1:687,2\n53#1:177,6\n56#1:219,6\n58#1:256,6\n66#1:309,6\n69#1:347,6\n79#1:411,6\n81#1:457,6\n86#1:495,6\n96#1:564,6\n111#1:630,6\n56#1:191\n56#1:192,9\n56#1:273\n66#1:281\n66#1:282,9\n66#1:369\n81#1:429\n81#1:430,9\n81#1:511\n58#1:228\n58#1:229,9\n58#1:269\n79#1:383\n79#1:384,9\n79#1:516\n96#1:536\n96#1:537,9\n96#1:594\n111#1:602\n111#1:603,9\n111#1:690\n67#1:274,6\n70#1:360,6\n77#1:370,6\n78#1:376,6\n81#1:422,6\n93#1:517,6\n94#1:523,6\n95#1:529,6\n97#1:573,6\n100#1:579,6\n104#1:585,6\n110#1:596,6\n112#1:639,6\n115#1:645,6\n118#1:651,6\n126#1:657,6\n128#1:663,6\n137#1:669,6\n138#1:675,6\n139#1:681,6\n109#1:595\n77#1:691\n77#1:692,2\n93#1:694\n93#1:695,2\n110#1:700\n110#1:701,2\n94#1:697\n94#1:698,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\n\n\u0002\u0010\u0007\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u001c\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\n\u0010\u0008\u001a\u0006\u0012\u0002\u0008\u00030\tH\u0007J\u0012\u0010\n\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u000c\u001a\u00020\rH\u0002J\u001f\u0010\u000e\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u00102\u0008\u0008\u0002\u0010\u0011\u001a\u00020\u0012H\u0003\u00a2\u0006\u0002\u0010\u0013J\u0015\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u0010H\u0003\u00a2\u0006\u0002\u0010\u0015J/\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u00102\n\u0008\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u00102\u000c\u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u001aH\u0003\u00a2\u0006\u0002\u0010\u001bJ\'\u0010\u001c\u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u00102\u0006\u0010\u001d\u001a\u00020\u00102\u0008\u0008\u0002\u0010\u001e\u001a\u00020\u0012H\u0003\u00a2\u0006\u0002\u0010\u001fJ?\u0010 \u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u00102\u000c\u0010!\u001a\u0008\u0012\u0004\u0012\u00020\u00100\t2\u0006\u0010\"\u001a\u00020#2\u0012\u0010$\u001a\u000e\u0012\u0004\u0012\u00020#\u0012\u0004\u0012\u00020\u00050%H\u0003\u00a2\u0006\u0002\u0010&J=\u0010\'\u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u00102\u0006\u0010\u001d\u001a\u00020\u00102\u0006\u0010(\u001a\u00020#2\u0006\u0010)\u001a\u00020#2\u0006\u0010\"\u001a\u00020#2\u0006\u0010*\u001a\u00020\u0010H\u0003\u00a2\u0006\u0002\u0010+J\r\u0010,\u001a\u00020\u0005H\u0003\u00a2\u0006\u0002\u0010-\u00a8\u0006.\u00b2\u0006\n\u0010/\u001a\u00020\u0012X\u008a\u008e\u0002\u00b2\u0006\n\u0010/\u001a\u00020\u0012X\u008a\u008e\u0002\u00b2\u0006\n\u0010\u0018\u001a\u000200X\u008a\u008e\u0002\u00b2\u0006\n\u0010/\u001a\u00020\u0012X\u008a\u008e\u0002"
    }
    d2 = {
        "Ldev/nino/squareglass/DesignEntry;",
        "",
        "<init>",
        "()V",
        "append",
        "",
        "scope",
        "Landroidx/compose/foundation/lazy/LazyListScope;",
        "items",
        "",
        "activity",
        "Landroid/app/Activity;",
        "context",
        "Landroid/content/Context;",
        "Label",
        "text",
        "",
        "secondary",
        "",
        "(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V",
        "Section",
        "(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "Row",
        "label",
        "value",
        "onClick",
        "Lkotlin/Function0;",
        "(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V",
        "Toggle",
        "key",
        "fallback",
        "(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V",
        "Choice",
        "values",
        "selected",
        "",
        "select",
        "Lkotlin/Function1;",
        "(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V",
        "Range",
        "low",
        "high",
        "suffix",
        "(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "Entry",
        "(Landroidx/compose/runtime/Composer;I)V",
        "extension_debug",
        "expanded",
        ""
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/DesignEntry;


# direct methods
.method public static synthetic $r8$lambda$02tyMQi2oK0tDd3uMrfQV8S-1O0(Landroid/content/Context;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$3$4$0(Landroid/content/Context;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$0w405_3mw7vj5iLkyDHy1zppq44(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$3$2$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$BOvWWZz2G9unKC8Ps1IaQ0Wlg78(Landroid/content/Context;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$3$1$0(Landroid/content/Context;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$EEAno2NmQDfQsjX_JHbpIa4dJfY(Ljava/lang/String;Z)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Toggle$lambda$0$0(Ljava/lang/String;Z)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$FD9d85Mo5TUk0QrMtA5ZVbtIqQI(Ljava/lang/String;Z)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Toggle$lambda$1$1$0(Ljava/lang/String;Z)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NGmDeWIIN5lOKcVCOrPT6MKavlQ(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$3$3$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$O-wJrYE1dQcHGo6og5jMyhkqKD0(Landroidx/compose/foundation/interaction/MutableInteractionSource;JLandroidx/compose/material3/SliderState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    invoke-static/range {p0 .. p5}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$7$3(Landroidx/compose/foundation/interaction/MutableInteractionSource;JLandroidx/compose/material3/SliderState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$PjCALtbMjYBWbJrWuOkF94ndvcU(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$3$5$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$X3l6cwUWp2EKAuwfUxjB-wR1QeE(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$6$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$cZjQMQ-j44EAiQXTSS17lVHn3rc(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$3$0$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$jBYzxjK_1-qhmzO1QfrRzpW5j7o(I)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$3$6$0(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$lCXgeMOjwNkyeBQxbTMqyeNm8Bc(Lam0/l;ILandroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$4$0$0$0(Lam0/l;ILandroidx/compose/runtime/MutableState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$mc35MTFjyqZEQmUi-cWocs-Ltzg(Landroidx/compose/runtime/MutableFloatState;F)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$7$1$0(Landroidx/compose/runtime/MutableFloatState;F)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pGULZsODhWJm_uDRrmh5h8Czu8Y(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$7$2$0(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rGdHxqhC0kBSemsADLU3Qa2-6IM(Landroid/content/Context;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$3$7$0(Landroid/content/Context;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wOX49nI7F15HqYBsCr4xg3bNycg(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$3$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/DesignEntry;

    invoke-direct {v0}, Ldev/nino/squareglass/DesignEntry;-><init>()V

    sput-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V
    .locals 38
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;I",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v3, p2

    move/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p6

    const v0, 0xc39184e

    move-object/from16 v1, p5

    .line 76
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    const-string v1, "C(Choice)N(label,values,selected,select)76@4011L34,77@4108L22,77@4054L76:DesignEntry.kt#vqphja"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v6, 0x6

    const/4 v2, 0x2

    move-object/from16 v8, p1

    if-nez v1, :cond_1

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    or-int/2addr v1, v6

    goto :goto_1

    :cond_1
    move v1, v6

    :goto_1
    and-int/lit8 v7, v6, 0x30

    if-nez v7, :cond_3

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    const/16 v7, 0x20

    goto :goto_2

    :cond_2
    const/16 v7, 0x10

    :goto_2
    or-int/2addr v1, v7

    :cond_3
    and-int/lit16 v7, v6, 0x180

    if-nez v7, :cond_5

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v7

    if-eqz v7, :cond_4

    const/16 v7, 0x100

    goto :goto_3

    :cond_4
    const/16 v7, 0x80

    :goto_3
    or-int/2addr v1, v7

    :cond_5
    and-int/lit16 v7, v6, 0xc00

    if-nez v7, :cond_7

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_6

    const/16 v7, 0x800

    goto :goto_4

    :cond_6
    const/16 v7, 0x400

    :goto_4
    or-int/2addr v1, v7

    :cond_7
    and-int/lit16 v7, v6, 0x6000

    if-nez v7, :cond_9

    move-object/from16 v7, p0

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8

    const/16 v9, 0x4000

    goto :goto_5

    :cond_8
    const/16 v9, 0x2000

    :goto_5
    or-int/2addr v1, v9

    goto :goto_6

    :cond_9
    move-object/from16 v7, p0

    :goto_6
    and-int/lit16 v9, v1, 0x2493

    const/16 v11, 0x2492

    const/4 v15, 0x1

    const/4 v12, 0x0

    if-eq v9, v11, :cond_a

    move v9, v15

    goto :goto_7

    :cond_a
    move v9, v12

    :goto_7
    and-int/lit8 v11, v1, 0x1

    invoke-interface {v10, v9, v11}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v9

    if-eqz v9, :cond_22

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v9

    if-eqz v9, :cond_b

    const/4 v9, -0x1

    const-string v11, "dev.nino.squareglass.DesignEntry.Choice (DesignEntry.kt:75)"

    invoke-static {v0, v1, v9, v11}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_b
    const v0, -0x1dabb5b0

    .line 77
    const-string v9, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v10, v0, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 370
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .line 371
    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    const/4 v13, 0x0

    if-ne v0, v11, :cond_c

    .line 77
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0, v13, v2, v13}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 373
    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 77
    :cond_c
    check-cast v0, Landroidx/compose/runtime/MutableState;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 78
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v11

    sub-int/2addr v11, v15

    invoke-static {v4, v12, v11}, Ldev/nino/squareglass/HostCompat;->coerceIn(III)I

    move-result v11

    invoke-interface {v3, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const v12, -0x1daba99c

    invoke-static {v10, v12, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 376
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .line 377
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v12, v13, :cond_d

    .line 78
    new-instance v12, Ldev/nino/squareglass/DesignEntry$19;

    invoke-direct {v12, v0}, Ldev/nino/squareglass/DesignEntry$19;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 379
    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 78
    :cond_d
    check-cast v12, Lam0/a;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    and-int/lit8 v13, v1, 0xe

    or-int/lit16 v13, v13, 0x180

    shr-int/lit8 v14, v1, 0x3

    and-int/lit16 v14, v14, 0x1c00

    or-int/2addr v13, v14

    move-object v14, v9

    move-object v9, v11

    move-object v11, v10

    move-object v10, v12

    move v12, v13

    const/4 v13, 0x0

    move-object/from16 v19, v14

    const/4 v14, 0x0

    invoke-direct/range {v7 .. v13}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    .line 79
    invoke-static {v0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v7

    if-eqz v7, :cond_21

    const v7, -0x1daba115

    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "78@4173L36,78@4152L797"

    invoke-static {v11, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    const/4 v8, 0x0

    invoke-static {v7, v8, v15, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const/16 v9, 0x36

    invoke-static {v7, v11, v9}, Ldev/nino/squareglass/SquareScreens;->settingsRow(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const/high16 v9, 0x41800000    # 16.0f

    .line 382
    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 79
    invoke-static {v7, v9, v8, v2, v14}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const v7, 0x4ff7456f

    const-string v9, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 383
    invoke-static {v11, v7, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 384
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 385
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    const/4 v10, 0x0

    .line 388
    invoke-static {v7, v9, v11, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    const v9, -0x451e1427

    .line 393
    const-string v12, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v11, v9, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 394
    invoke-static {v11, v10}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    .line 395
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 396
    invoke-static {v11, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 398
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v9

    const v8, -0x20f7d59c

    .line 399
    const-string v14, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v11, v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 400
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 401
    :cond_e
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 402
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_f

    .line 403
    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_8

    .line 405
    :cond_f
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 407
    :goto_8
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .line 408
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v9

    invoke-static {v8, v7, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 409
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v7

    invoke-static {v8, v13, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 410
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v7

    .line 412
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v9

    if-nez v9, :cond_10

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v9, v13}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_11

    .line 413
    :cond_10
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v8, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 414
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v8, v9, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 417
    :cond_11
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v7

    invoke-static {v8, v2, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v2, 0x7cc0ae6e

    .line 419
    const-string v7, "C89@4557L9:Column.kt#2w3rfo"

    .line 390
    invoke-static {v11, v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    const v2, 0x4bfa8916    # 3.2838188E7f

    const-string v7, "C:DesignEntry.kt#vqphja"

    .line 80
    invoke-static {v11, v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, -0x7129769a

    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*80@4418L69,80@4340L585"

    invoke-static {v11, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move-object v2, v3

    check-cast v2, Ljava/lang/Iterable;

    .line 421
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v7, 0x0

    :goto_9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_20

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    add-int/lit8 v22, v7, 0x1

    if-gez v7, :cond_12

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->throwIndexOverflow()V

    :cond_12
    move-object/from16 v23, v8

    check-cast v23, Ljava/lang/String;

    .line 81
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v8, v9, v15, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v24

    if-ne v7, v4, :cond_13

    move/from16 v25, v15

    goto :goto_a

    :cond_13
    const/16 v25, 0x0

    :goto_a
    sget-object v8, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/semantics/Role$Companion;->getRadioButton-o7Vup1c()I

    move-result v8

    invoke-static {v8}, Landroidx/compose/ui/semantics/Role;->box-impl(I)Landroidx/compose/ui/semantics/Role;

    move-result-object v27

    const v8, 0x293b245c

    move-object/from16 v9, v19

    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v8, v1, 0x1c00

    const/16 v10, 0x800

    if-ne v8, v10, :cond_14

    move v8, v15

    goto :goto_b

    :cond_14
    const/4 v8, 0x0

    :goto_b
    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v13

    or-int/2addr v8, v13

    .line 422
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    if-nez v8, :cond_15

    .line 423
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v13, v8, :cond_16

    .line 81
    :cond_15
    new-instance v13, Ldev/nino/squareglass/DesignEntry$20;

    invoke-direct {v13, v5, v7, v0}, Ldev/nino/squareglass/DesignEntry$20;-><init>(Lam0/l;ILandroidx/compose/runtime/MutableState;)V

    .line 425
    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 81
    :cond_16
    move-object/from16 v29, v13

    check-cast v29, Lam0/a;

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v30, 0xa

    const/16 v31, 0x0

    const/16 v26, 0x0

    const/16 v28, 0x0

    invoke-static/range {v24 .. v31}, Landroidx/compose/foundation/selection/SelectableKt;->selectable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZZLandroidx/compose/ui/semantics/Role;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/high16 v13, 0x40800000    # 4.0f

    .line 428
    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    move-object/from16 v19, v0

    const/4 v0, 0x0

    const/4 v10, 0x0

    .line 83
    invoke-static {v8, v10, v13, v15, v0}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v13

    const v0, 0x3255a44b

    .line 81
    const-string v10, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    .line 429
    invoke-static {v11, v0, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 430
    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v0}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v0

    const/16 v10, 0x30

    .line 434
    invoke-static {v0, v13, v11, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v0

    const v10, -0x451e1427

    .line 439
    invoke-static {v11, v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v13, 0x0

    .line 440
    invoke-static {v11, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v24

    invoke-static/range {v24 .. v25}, Ljava/lang/Long;->hashCode(J)I

    move-result v18

    .line 441
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 442
    invoke-static {v11, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 444
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v13

    const v15, -0x20f7d59c

    .line 445
    invoke-static {v11, v15, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 446
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v15

    instance-of v15, v15, Landroidx/compose/runtime/Applier;

    if-nez v15, :cond_17

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 447
    :cond_17
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 448
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v15

    if-eqz v15, :cond_18

    .line 449
    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_c

    .line 451
    :cond_18
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 453
    :goto_c
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .line 454
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v15

    invoke-static {v13, v0, v15}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 455
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v0

    invoke-static {v13, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 456
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v0

    .line 458
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v10

    if-nez v10, :cond_19

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-static {v10, v15}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1a

    .line 459
    :cond_19
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v13, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 460
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v13, v10, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 463
    :cond_1a
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v0

    invoke-static {v13, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v0, 0x56ccd6f5

    .line 465
    const-string v8, "C101@5233L9:Row.kt#2w3rfo"

    .line 436
    invoke-static {v11, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    const v0, -0x1e2cbab8

    const-string v8, "C84@4729L4,84@4788L4,83@4647L165,83@4579L234,85@4834L73:DesignEntry.kt#vqphja"

    .line 84
    invoke-static {v11, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    if-ne v7, v4, :cond_1b

    const/4 v0, 0x1

    goto :goto_d

    :cond_1b
    const/4 v0, 0x0

    :goto_d
    sget-object v7, Landroidx/compose/material3/RadioButtonDefaults;->INSTANCE:Landroidx/compose/material3/RadioButtonDefaults;

    .line 85
    sget-object v8, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v10, 0x6

    invoke-virtual {v8, v11, v10}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v8

    invoke-static {v8}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v8

    invoke-static {v8}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v26

    sget-object v8, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    invoke-virtual {v8, v11, v10}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v8

    invoke-static {v8}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v8

    invoke-static {v8}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v28

    const/16 v34, 0xe

    const/16 v35, 0x0

    const v30, 0x3f0ccccd    # 0.55f

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    invoke-static/range {v28 .. v35}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v28

    sget v8, Landroidx/compose/material3/RadioButtonDefaults;->$stable:I

    shl-int/lit8 v8, v8, 0xc

    const/16 v18, 0xc

    move-object v10, v12

    const-wide/16 v12, 0x0

    move-object/from16 v30, v14

    const-wide/16 v14, 0x0

    move/from16 p5, v0

    move/from16 v21, v1

    move-object/from16 v25, v2

    move/from16 v17, v8

    move-object v1, v10

    move-object/from16 v16, v11

    move-wide/from16 v10, v28

    move-object/from16 v0, v30

    const/4 v2, 0x0

    const/16 v20, 0x800

    const/16 v28, 0x0

    const/16 v29, 0x1

    move-wide/from16 v36, v26

    move-object/from16 v26, v9

    move-wide/from16 v8, v36

    const/16 v27, 0x0

    .line 84
    invoke-virtual/range {v7 .. v18}, Landroidx/compose/material3/RadioButtonDefaults;->colors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/RadioButtonColors;

    move-result-object v11

    move-object/from16 v10, v16

    const/16 v14, 0x30

    const/16 v15, 0x2c

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v13, v10

    const/4 v10, 0x0

    const/4 v12, 0x0

    move/from16 v7, p5

    invoke-static/range {v7 .. v15}, Landroidx/compose/material3/RadioButtonKt;->RadioButton(ZLam0/a;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/RadioButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;II)V

    move-object v11, v13

    .line 86
    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v12, v7

    check-cast v12, Landroidx/compose/ui/Modifier;

    const/high16 v7, 0x41400000    # 12.0f

    .line 466
    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v14

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v16

    const/16 v17, 0x4

    const/16 v18, 0x0

    const/4 v15, 0x0

    .line 86
    invoke-static/range {v12 .. v18}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const v8, 0x3e277f0a

    const-string v9, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    .line 467
    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 468
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v8

    .line 472
    invoke-static {v8, v2}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    const v13, -0x451e1427

    .line 477
    invoke-static {v11, v13, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 478
    invoke-static {v11, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v9

    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    move-result v9

    .line 479
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 480
    invoke-static {v11, v7}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 482
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v12

    const v15, -0x20f7d59c

    .line 483
    invoke-static {v11, v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 484
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 485
    :cond_1c
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 486
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_1d

    .line 487
    invoke-interface {v11, v12}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_e

    .line 489
    :cond_1d
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 491
    :goto_e
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .line 492
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v14

    invoke-static {v12, v8, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 493
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v8

    invoke-static {v12, v10, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 494
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v8

    .line 496
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v10

    if-nez v10, :cond_1e

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v10, v14}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1f

    .line 497
    :cond_1e
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 498
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v12, v9, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 501
    :cond_1f
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v8

    invoke-static {v12, v7, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v7, 0x6d423196

    .line 503
    const-string v8, "C72@3469L9:Box.kt#2w3rfo"

    .line 474
    invoke-static {v11, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v7, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    check-cast v7, Landroidx/compose/foundation/layout/BoxScope;

    const v7, 0x5458246b

    const-string v8, "C85@4894L11:DesignEntry.kt#vqphja"

    .line 86
    invoke-static {v11, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v7, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    move-object v10, v11

    const/16 v11, 0x180

    const/4 v12, 0x2

    const/4 v9, 0x0

    move-object/from16 v8, v23

    invoke-direct/range {v7 .. v12}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    move-object v11, v10

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 474
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 504
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 483
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 477
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 467
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 84
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 436
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 508
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 445
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 439
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 429
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object v14, v0

    move-object v12, v1

    move-object/from16 v0, v19

    move/from16 v1, v21

    move/from16 v7, v22

    move-object/from16 v2, v25

    move-object/from16 v19, v26

    move/from16 v15, v29

    goto/16 :goto_9

    .line 88
    :cond_20
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 80
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 390
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 513
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 399
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 393
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 383
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 79
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_f

    :cond_21
    const v0, 0x68432e54

    .line 89
    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_f
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_10

    :cond_22
    move-object v11, v10

    .line 76
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 90
    :cond_23
    :goto_10
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_24

    new-instance v0, Ldev/nino/squareglass/DesignEntry$21;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry$21;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/util/List;ILam0/l;I)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_24
    return-void
.end method

.method private static final Choice$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 77
    check-cast p0, Landroidx/compose/runtime/State;

    .line 691
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private static final Choice$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 77
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 692
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final Choice$lambda$3$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 1

    .line 78
    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {p0, v0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Choice$lambda$4$0$0$0(Lam0/l;ILandroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 1

    const/4 v0, 0x0

    .line 82
    invoke-static {p2, v0}, Ldev/nino/squareglass/DesignEntry;->Choice$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final Choice$lambda$5(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/util/List;ILam0/l;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 7

    or-int/lit8 p5, p5, 0x1

    invoke-static {p5}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Entry(Landroidx/compose/runtime/Composer;I)V
    .locals 18

    move/from16 v0, p2

    const v1, 0x7d26ac02

    move-object/from16 v2, p1

    .line 107
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v6

    const-string v2, "C(Entry)108@6258L7,109@6290L34,110@6333L2275:DesignEntry.kt#vqphja"

    invoke-static {v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v0, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-eqz v2, :cond_0

    move v3, v12

    goto :goto_0

    :cond_0
    move v3, v11

    :goto_0
    invoke-interface {v6, v3, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, -0x1

    const-string v3, "dev.nino.squareglass.DesignEntry.Entry (DesignEntry.kt:106)"

    invoke-static {v1, v0, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 108
    :cond_1
    sget-object v1, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v1}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 109
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalContext()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v1

    check-cast v1, Landroidx/compose/runtime/CompositionLocal;

    const v2, 0x789c5f52

    const-string v3, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    .line 595
    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 109
    check-cast v1, Landroid/content/Context;

    const v2, -0x31d43edc    # -7.203904E8f

    .line 110
    const-string v13, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v6, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 596
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .line 597
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    const/4 v14, 0x2

    const/4 v4, 0x0

    if-ne v2, v3, :cond_2

    .line 110
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v2, v4, v14, v4}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    .line 599
    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 110
    :cond_2
    move-object v9, v2

    check-cast v9, Landroidx/compose/runtime/MutableState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 111
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v3

    if-eqz v3, :cond_3

    sget-object v3, Ldev/nino/squareglass/material/LiquidMotion;->INSTANCE:Ldev/nino/squareglass/material/LiquidMotion;

    invoke-virtual {v3}, Ldev/nino/squareglass/material/LiquidMotion;->shape()Landroidx/compose/animation/core/SpringSpec;

    move-result-object v3

    goto :goto_1

    :cond_3
    invoke-static {v11, v12, v4}, Landroidx/compose/animation/core/AnimationSpecKt;->snap$default(IILjava/lang/Object;)Landroidx/compose/animation/core/SnapSpec;

    move-result-object v3

    :goto_1
    check-cast v3, Landroidx/compose/animation/core/FiniteAnimationSpec;

    invoke-static {v2, v3, v4, v14, v4}, Landroidx/compose/animation/AnimationModifierKt;->animateContentSize$default(Landroidx/compose/ui/Modifier;Landroidx/compose/animation/core/FiniteAnimationSpec;Lam0/p;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const v3, 0x4ff7456f

    const-string v4, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 602
    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 603
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v3

    .line 604
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 607
    invoke-static {v3, v4, v6, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    const v4, -0x451e1427

    .line 608
    const-string v5, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    .line 612
    invoke-static {v6, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 613
    invoke-static {v6, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 614
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 615
    invoke-static {v6, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 617
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v7

    const v8, -0x20f7d59c

    .line 616
    const-string v10, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    .line 618
    invoke-static {v6, v8, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 619
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 620
    :cond_4
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 621
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_5

    .line 622
    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_2

    .line 624
    :cond_5
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 626
    :goto_2
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .line 627
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v8

    invoke-static {v7, v3, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 628
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v3

    invoke-static {v7, v5, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 629
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v3

    .line 631
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-nez v5, :cond_6

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v5, v8}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_7

    .line 632
    :cond_6
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 633
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v7, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 636
    :cond_7
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v3

    invoke-static {v7, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v2, 0x7cc0ae6e

    .line 638
    const-string v3, "C89@4557L9:Column.kt#2w3rfo"

    .line 609
    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    const v2, 0x427d574d

    const-string v3, "C111@6524L22,111@6444L102:DesignEntry.kt#vqphja"

    .line 112
    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    invoke-static {v9}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v3

    if-eqz v3, :cond_8

    const-string v3, "Hide design & controls"

    goto :goto_3

    :cond_8
    const-string v3, "Design & controls"

    :goto_3
    move-object v4, v3

    const v3, 0x44359922

    invoke-static {v6, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 639
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 640
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v3, v5, :cond_9

    .line 112
    new-instance v3, Ldev/nino/squareglass/DesignEntry$9;

    invoke-direct {v3, v9}, Ldev/nino/squareglass/DesignEntry$9;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 642
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 112
    :cond_9
    move-object v5, v3

    check-cast v5, Lam0/a;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v7, 0xd86

    const/4 v8, 0x0

    const-string v3, "Liquidify"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    .line 113
    invoke-static {v9}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v3

    if-eqz v3, :cond_14

    const v3, 0x427f37cc

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "113@6590L21,114@6709L101,114@6628L182,117@6900L29,117@6827L102,118@6946L32,119@6995L34,120@7046L31,121@7094L44,122@7155L24,123@7196L51,125@7434L40,124@7264L210,126@7491L59,127@7639L148,127@7567L220,130@7804L25,131@7846L65,132@7928L85,133@8030L83,134@8130L25,136@8325L39,136@8252L112,137@8452L38,137@8381L109,138@8527L57,138@8507L77"

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 114
    const-string v3, "Appearance"

    const/16 v15, 0x36

    invoke-direct {v2, v3, v6, v15}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 115
    const-string v3, "Light"

    const-string v4, "Dark"

    const-string v5, "System"

    filled-new-array {v5, v3, v4}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeMode()I

    move-result v5

    const v3, 0x4435b091

    invoke-static {v6, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .line 645
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    if-nez v3, :cond_a

    .line 646
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v7, v3, :cond_b

    .line 115
    :cond_a
    new-instance v7, Ldev/nino/squareglass/DesignEntry$10;

    invoke-direct {v7, v1}, Ldev/nino/squareglass/DesignEntry$10;-><init>(Landroid/content/Context;)V

    .line 648
    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 115
    :cond_b
    check-cast v7, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6036

    const-string v3, "Color theme"

    move-object/from16 v17, v7

    move-object v7, v6

    move-object/from16 v6, v17

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    .line 118
    const-string v3, "Liquid"

    const-string v4, "Frosted"

    const-string v9, "Off"

    filled-new-array {v3, v4, v9}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v5

    const v3, 0x4435c829

    invoke-static {v6, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 651
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 652
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_c

    .line 653
    new-instance v3, Ldev/nino/squareglass/DesignEntry$11;

    invoke-direct {v3}, Ldev/nino/squareglass/DesignEntry$11;-><init>()V

    .line 654
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 118
    :cond_c
    check-cast v3, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6c36

    move-object v7, v6

    move-object v6, v3

    const-string v3, "Glass"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    const/16 v7, 0xc36

    const/4 v8, 0x4

    .line 119
    const-string v3, "Glass navigation"

    const-string v4, "nav"

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 120
    const-string v3, "Glass mini-player"

    const-string v4, "mini"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 121
    const-string v3, "Glass player"

    const-string v4, "player"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    const/16 v7, 0xdb6

    const/4 v8, 0x0

    .line 122
    const-string v3, "Reduce motion"

    const-string v4, "reduceMotion"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 123
    const-string v3, "Player & Home"

    invoke-direct {v2, v3, v6, v15}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    const/16 v7, 0xc36

    const/4 v8, 0x4

    .line 124
    const-string v3, "Mini-player swipe gestures"

    const-string v4, "miniGestures"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 125
    const-string v3, "For You, Staff Picks, Uploads"

    const-string v4, "Autoplay, Rediscover, Shuffle history"

    filled-new-array {v3, v4}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 126
    const-string v3, "homeActions"

    invoke-static {v3, v11, v11, v12}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v5

    const v3, 0x44360af4

    invoke-static {v6, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 657
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 658
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_d

    .line 659
    new-instance v3, Ldev/nino/squareglass/DesignEntry$12;

    invoke-direct {v3}, Ldev/nino/squareglass/DesignEntry$12;-><init>()V

    .line 660
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 126
    :cond_d
    check-cast v3, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6c36

    move-object v7, v6

    move-object v6, v3

    .line 125
    const-string v3, "Home shortcuts"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    const/16 v7, 0xc36

    const/4 v8, 0x4

    .line 127
    const-string v3, "Learn listening habits by time of day"

    const-string v4, "learnTime"

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    const v3, 0x44362500    # 728.5781f

    .line 128
    invoke-static {v6, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .line 663
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_e

    .line 664
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v4, v3, :cond_f

    .line 128
    :cond_e
    new-instance v4, Ldev/nino/squareglass/DesignEntry$13;

    invoke-direct {v4, v1}, Ldev/nino/squareglass/DesignEntry$13;-><init>(Landroid/content/Context;)V

    .line 666
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 128
    :cond_f
    move-object v5, v4

    check-cast v5, Lam0/a;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v7, 0xc36

    const/4 v8, 0x0

    const-string v3, "Clear listening profile"

    const-string v4, "Listening history stays on this device"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    .line 131
    const-string v3, "Advanced glass"

    invoke-direct {v2, v3, v6, v15}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 132
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->blur()F

    move-result v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v7

    const-string v8, "dp"

    const v10, 0x1b0db6

    const-string v3, "Blur"

    const-string v4, "blur"

    const/4 v5, 0x0

    move-object/from16 v16, v9

    move-object v9, v6

    const/16 v6, 0x18

    move-object/from16 v14, v16

    invoke-direct/range {v2 .. v10}, Ldev/nino/squareglass/DesignEntry;->Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v9

    .line 133
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->opacity()F

    move-result v3

    const/high16 v16, 0x42c80000    # 100.0f

    mul-float v3, v3, v16

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v7

    const-string v8, "%"

    const-string v3, "Surface tint"

    const-string v4, "opacity"

    const/16 v5, 0x14

    const/16 v6, 0x5a

    invoke-direct/range {v2 .. v10}, Ldev/nino/squareglass/DesignEntry;->Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v9

    .line 134
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v3

    mul-float v3, v3, v16

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v7

    const-string v8, "%"

    const-string v3, "Refraction"

    const-string v4, "lens"

    const/4 v5, 0x0

    const/16 v6, 0x64

    invoke-direct/range {v2 .. v10}, Ldev/nino/squareglass/DesignEntry;->Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v9

    .line 135
    const-string v3, "Track gestures"

    invoke-direct {v2, v3, v6, v15}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 136
    const-string v3, "Add to queue"

    const-string v4, "Favorite"

    const-string v5, "Play next"

    filled-new-array {v14, v5, v3, v4}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 137
    const-string v3, "swipeRight"

    const/4 v9, 0x3

    invoke-static {v3, v12, v11, v9}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v5

    const v3, 0x44367a53

    invoke-static {v6, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 669
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 670
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_10

    .line 671
    new-instance v3, Ldev/nino/squareglass/DesignEntry$14;

    invoke-direct {v3}, Ldev/nino/squareglass/DesignEntry$14;-><init>()V

    .line 672
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 137
    :cond_10
    check-cast v3, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6c36

    move-object v7, v6

    move-object v6, v3

    const-string v3, "Swipe right"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    .line 138
    const-string v3, "swipeLeft"

    const/4 v5, 0x2

    invoke-static {v3, v5, v11, v9}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v5

    const v3, 0x44368a32

    invoke-static {v6, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 675
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .line 676
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_11

    .line 677
    new-instance v3, Ldev/nino/squareglass/DesignEntry$15;

    invoke-direct {v3}, Ldev/nino/squareglass/DesignEntry$15;-><init>()V

    .line 678
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 138
    :cond_11
    check-cast v3, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x6c36

    move-object v7, v6

    move-object v6, v3

    const-string v3, "Swipe left"

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Choice(Ljava/lang/String;Ljava/util/List;ILam0/l;Landroidx/compose/runtime/Composer;I)V

    move-object v6, v7

    const v3, 0x443693a5

    .line 139
    invoke-static {v6, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .line 681
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_12

    .line 682
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v4, v3, :cond_13

    .line 139
    :cond_12
    new-instance v4, Ldev/nino/squareglass/DesignEntry$16;

    invoke-direct {v4, v1}, Ldev/nino/squareglass/DesignEntry$16;-><init>(Landroid/content/Context;)V

    .line 684
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 139
    :cond_13
    move-object v5, v4

    check-cast v5, Lam0/a;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v7, 0xc06

    const/4 v8, 0x2

    const-string v3, "Reset design"

    const/4 v4, 0x0

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    .line 113
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_4

    :cond_14
    const v1, 0x429ced36

    .line 140
    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 112
    :goto_4
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 609
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 687
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 618
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 612
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 602
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 690
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_5

    .line 107
    :cond_15
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 142
    :cond_16
    :goto_5
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_17

    new-instance v2, Ldev/nino/squareglass/DesignEntry$17;

    move-object/from16 v3, p0

    invoke-direct {v2, v3, v0}, Ldev/nino/squareglass/DesignEntry$17;-><init>(Ldev/nino/squareglass/DesignEntry;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_17
    return-void
.end method

.method private static final Entry$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 110
    check-cast p0, Landroidx/compose/runtime/State;

    .line 700
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private static final Entry$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 110
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 701
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final Entry$lambda$3$0$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 1

    .line 112
    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {p0, v0}, Ldev/nino/squareglass/DesignEntry;->Entry$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$3$1$0(Landroid/content/Context;I)Lkotlin/u;
    .locals 1

    .line 116
    const-string v0, "theme"

    invoke-static {v0, p1}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p1, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/DesignEntry;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->recreate()V

    .line 117
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$3$2$0(I)Lkotlin/u;
    .locals 0

    .line 118
    invoke-static {p0}, Ldev/nino/squareglass/SquareSettings;->preset(I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$3$3$0(I)Lkotlin/u;
    .locals 1

    .line 126
    const-string v0, "homeActions"

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$3$4$0(Landroid/content/Context;)Lkotlin/u;
    .locals 2

    .line 129
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->clearHistory()V

    const-string v0, "Listening profile cleared"

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 130
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$3$5$0(I)Lkotlin/u;
    .locals 1

    .line 137
    const-string v0, "swipeRight"

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$3$6$0(I)Lkotlin/u;
    .locals 1

    .line 138
    const-string v0, "swipeLeft"

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Entry$lambda$3$7$0(Landroid/content/Context;)Lkotlin/u;
    .locals 1

    .line 139
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->reset()V

    sget-object v0, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/DesignEntry;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->recreate()V

    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final Entry$lambda$4(Ldev/nino/squareglass/DesignEntry;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    or-int/lit8 p1, p1, 0x1

    invoke-static {p1}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result p1

    invoke-direct {p0, p2, p1}, Ldev/nino/squareglass/DesignEntry;->Entry(Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V
    .locals 29

    const v0, 0x4924224d

    move-object/from16 v1, p3

    .line 47
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v1

    const-string v2, "C(Label)N(text,secondary)47@2104L4,48@2117L174:DesignEntry.kt#vqphja"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, p4, 0x6

    move-object/from16 v5, p1

    if-nez v2, :cond_1

    invoke-interface {v1, v5}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    :goto_0
    or-int v2, p4, v2

    goto :goto_1

    :cond_1
    move/from16 v2, p4

    :goto_1
    and-int/lit8 v3, p5, 0x2

    const/16 v4, 0x10

    if-eqz v3, :cond_2

    or-int/lit8 v2, v2, 0x30

    goto :goto_3

    :cond_2
    and-int/lit8 v6, p4, 0x30

    if-nez v6, :cond_4

    move/from16 v6, p2

    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v7

    if-eqz v7, :cond_3

    const/16 v7, 0x20

    goto :goto_2

    :cond_3
    move v7, v4

    :goto_2
    or-int/2addr v2, v7

    goto :goto_4

    :cond_4
    :goto_3
    move/from16 v6, p2

    :goto_4
    and-int/lit8 v7, v2, 0x13

    const/16 v8, 0x12

    const/4 v9, 0x0

    if-eq v7, v8, :cond_5

    const/4 v7, 0x1

    goto :goto_5

    :cond_5
    move v7, v9

    :goto_5
    and-int/lit8 v8, v2, 0x1

    invoke-interface {v1, v7, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_b

    if-eqz v3, :cond_6

    move/from16 v26, v9

    goto :goto_6

    :cond_6
    move/from16 v26, v6

    :goto_6
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_7

    const/4 v3, -0x1

    const-string v6, "dev.nino.squareglass.DesignEntry.Label (DesignEntry.kt:46)"

    invoke-static {v0, v2, v3, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 48
    :cond_7
    sget-object v0, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v3}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v0

    .line 49
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v6

    if-eqz v26, :cond_8

    const v0, 0x3f266666    # 0.65f

    goto :goto_7

    :cond_8
    const/high16 v0, 0x3f800000    # 1.0f

    :goto_7
    move v8, v0

    const/16 v12, 0xe

    const/4 v13, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v6 .. v13}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v6

    const/16 v0, 0xe

    if-eqz v26, :cond_9

    .line 50
    invoke-static {v0}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v3

    goto :goto_8

    :cond_9
    invoke-static {v4}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v3

    :goto_8
    sget-object v8, Ldev/nino/squareglass/SquareTypography;->INSTANCE:Ldev/nino/squareglass/SquareTypography;

    invoke-virtual {v8}, Ldev/nino/squareglass/SquareTypography;->getFamily()Landroidx/compose/ui/text/font/FontFamily;

    move-result-object v9

    and-int/lit8 v23, v2, 0xe

    const/16 v24, 0x0

    const v25, 0x1ffb2

    const/4 v2, 0x0

    move-wide/from16 v27, v6

    move-wide v5, v3

    move-wide/from16 v3, v27

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    move-object/from16 v22, v1

    move-object/from16 v1, p1

    .line 49
    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILam0/l;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_a
    move/from16 v6, v26

    goto :goto_9

    :cond_b
    move-object/from16 v22, v1

    .line 47
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 51
    :goto_9
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_c

    new-instance v3, Ldev/nino/squareglass/DesignEntry$18;

    move-object/from16 v4, p0

    move-object/from16 v5, p1

    move/from16 v7, p4

    move/from16 v8, p5

    invoke-direct/range {v3 .. v8}, Ldev/nino/squareglass/DesignEntry$18;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;ZII)V

    invoke-interface {v0, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_c
    return-void
.end method

.method static final Label$lambda$0(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 6

    or-int/lit8 p3, p3, 0x1

    invoke-static {p3}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v4

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v5, p4

    move-object v3, p5

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 37

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v6, p5

    move-object/from16 v7, p6

    move/from16 v8, p8

    const v0, 0x1749c7df

    move-object/from16 v1, p7

    .line 92
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v12

    const-string v1, "C(Range)N(label,key,low,high,selected,suffix)92@5135L34,93@5191L79,94@5310L22,94@5279L53:DesignEntry.kt#vqphja"

    invoke-static {v12, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v8, 0x6

    const/4 v2, 0x2

    move-object/from16 v10, p1

    if-nez v1, :cond_1

    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    or-int/2addr v1, v8

    goto :goto_1

    :cond_1
    move v1, v8

    :goto_1
    and-int/lit8 v9, v8, 0x30

    if-nez v9, :cond_3

    invoke-interface {v12, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2

    const/16 v9, 0x20

    goto :goto_2

    :cond_2
    const/16 v9, 0x10

    :goto_2
    or-int/2addr v1, v9

    :cond_3
    and-int/lit16 v9, v8, 0x180

    if-nez v9, :cond_5

    invoke-interface {v12, v4}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v9

    if-eqz v9, :cond_4

    const/16 v9, 0x100

    goto :goto_3

    :cond_4
    const/16 v9, 0x80

    :goto_3
    or-int/2addr v1, v9

    :cond_5
    and-int/lit16 v9, v8, 0xc00

    if-nez v9, :cond_7

    invoke-interface {v12, v5}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v9

    if-eqz v9, :cond_6

    const/16 v9, 0x800

    goto :goto_4

    :cond_6
    const/16 v9, 0x400

    :goto_4
    or-int/2addr v1, v9

    :cond_7
    and-int/lit16 v9, v8, 0x6000

    if-nez v9, :cond_9

    invoke-interface {v12, v6}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v9

    if-eqz v9, :cond_8

    const/16 v9, 0x4000

    goto :goto_5

    :cond_8
    const/16 v9, 0x2000

    :goto_5
    or-int/2addr v1, v9

    :cond_9
    const/high16 v9, 0x30000

    and-int/2addr v9, v8

    if-nez v9, :cond_b

    invoke-interface {v12, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_a

    const/high16 v9, 0x20000

    goto :goto_6

    :cond_a
    const/high16 v9, 0x10000

    :goto_6
    or-int/2addr v1, v9

    :cond_b
    const/high16 v9, 0x180000

    and-int/2addr v9, v8

    if-nez v9, :cond_d

    move-object/from16 v9, p0

    invoke-interface {v12, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v16

    if-eqz v16, :cond_c

    const/high16 v16, 0x100000

    goto :goto_7

    :cond_c
    const/high16 v16, 0x80000

    :goto_7
    or-int v1, v1, v16

    goto :goto_8

    :cond_d
    move-object/from16 v9, p0

    :goto_8
    const v16, 0x92493

    and-int v11, v1, v16

    const v13, 0x92492

    if-eq v11, v13, :cond_e

    const/4 v11, 0x1

    goto :goto_9

    :cond_e
    const/4 v11, 0x0

    :goto_9
    and-int/lit8 v13, v1, 0x1

    invoke-interface {v12, v11, v13}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v11

    if-eqz v11, :cond_22

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v11

    if-eqz v11, :cond_f

    const/4 v11, -0x1

    const-string v13, "dev.nino.squareglass.DesignEntry.Range (DesignEntry.kt:91)"

    invoke-static {v0, v1, v11, v13}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_f
    const v0, 0x6bf75a21

    .line 93
    const-string v11, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v12, v0, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 517
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .line 518
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    const/16 v19, 0x0

    const/4 v15, 0x0

    if-ne v0, v13, :cond_10

    .line 93
    invoke-static/range {v19 .. v19}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0, v15, v2, v15}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 520
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 93
    :cond_10
    check-cast v0, Landroidx/compose/runtime/MutableState;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v2, 0x6bf7614e

    .line 94
    invoke-static {v12, v2, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, 0xe000

    and-int/2addr v2, v1

    const/16 v13, 0x4000

    if-ne v2, v13, :cond_11

    const/4 v2, 0x1

    goto :goto_a

    :cond_11
    move/from16 v2, v19

    .line 523
    :goto_a
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    if-nez v2, :cond_12

    .line 524
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v13, v2, :cond_13

    :cond_12
    sub-int v2, v6, v4

    int-to-float v2, v2

    sub-int v13, v5, v4

    int-to-float v13, v13

    div-float/2addr v2, v13

    .line 94
    invoke-static {v2}, Landroidx/compose/runtime/PrimitiveSnapshotStateKt;->mutableFloatStateOf(F)Landroidx/compose/runtime/MutableFloatState;

    move-result-object v13

    .line 526
    invoke-interface {v12, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 94
    :cond_13
    move-object v2, v13

    check-cast v2, Landroidx/compose/runtime/MutableFloatState;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 95
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v15, " "

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    const v14, 0x6bf76ff5

    invoke-static {v12, v14, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 529
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .line 530
    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v14, v6, :cond_14

    .line 95
    new-instance v14, Ldev/nino/squareglass/DesignEntry$0;

    invoke-direct {v14, v0}, Ldev/nino/squareglass/DesignEntry$0;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 532
    invoke-interface {v12, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 95
    :cond_14
    check-cast v14, Lam0/a;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    and-int/lit8 v6, v1, 0xe

    or-int/lit16 v6, v6, 0x180

    move-object/from16 v21, v0

    shr-int/lit8 v0, v1, 0x9

    and-int/lit16 v0, v0, 0x1c00

    or-int/2addr v0, v6

    move-object v6, v15

    const/4 v15, 0x0

    move-object/from16 v34, v11

    move-object v11, v13

    const/4 v8, 0x0

    move-object v13, v12

    move-object v12, v14

    move v14, v0

    const/4 v0, 0x1

    invoke-direct/range {v9 .. v15}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    move-object v12, v13

    .line 96
    invoke-static/range {v21 .. v21}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v9

    if-eqz v9, :cond_21

    const v9, 0x6bf7787c

    invoke-interface {v12, v9}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v9, "95@5375L36,95@5354L797"

    invoke-static {v12, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x0

    invoke-static {v9, v10, v0, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/16 v15, 0x36

    invoke-static {v8, v12, v15}, Ldev/nino/squareglass/SquareScreens;->settingsRow(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/high16 v9, 0x41a00000    # 20.0f

    .line 535
    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    const/high16 v10, 0x41400000    # 12.0f

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 96
    invoke-static {v8, v9, v10}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const v9, 0x4ff7456f

    const-string v10, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 536
    invoke-static {v12, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 537
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 538
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    const/4 v11, 0x0

    .line 541
    invoke-static {v9, v10, v12, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    const v10, -0x451e1427

    .line 542
    const-string v13, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    .line 546
    invoke-static {v12, v10, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 547
    invoke-static {v12, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    .line 548
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 549
    invoke-static {v12, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 551
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v14

    const v11, -0x20f7d59c

    .line 550
    const-string v15, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    .line 552
    invoke-static {v12, v11, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 553
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v11

    instance-of v11, v11, Landroidx/compose/runtime/Applier;

    if-nez v11, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 554
    :cond_15
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 555
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v11

    if-eqz v11, :cond_16

    .line 556
    invoke-interface {v12, v14}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_b

    .line 558
    :cond_16
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 560
    :goto_b
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .line 561
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v14

    invoke-static {v11, v9, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 562
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v9

    invoke-static {v11, v13, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 563
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v9

    .line 565
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v13

    if-nez v13, :cond_17

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v13, v14}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_18

    .line 566
    :cond_17
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 567
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v11, v10, v9}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 570
    :cond_18
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v9

    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v8, 0x7cc0ae6e

    .line 572
    const-string v9, "C89@4557L9:Column.kt#2w3rfo"

    .line 543
    invoke-static {v12, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v8, Landroidx/compose/foundation/layout/ColumnScope;

    const v8, 0x321f7154

    const-string v9, "C96@5485L37,97@5579L4,98@5598L60,100@5779L83,99@5698L10,103@6079L61,101@5886L153,99@5671L470:DesignEntry.kt#vqphja"

    .line 97
    invoke-static {v12, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v8, 0x5c74a033

    move-object/from16 v15, v34

    invoke-static {v12, v8, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 573
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .line 574
    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v8, v9, :cond_19

    .line 97
    invoke-static {}, Landroidx/compose/foundation/interaction/InteractionSourceKt;->MutableInteractionSource()Landroidx/compose/foundation/interaction/MutableInteractionSource;

    move-result-object v8

    .line 576
    invoke-interface {v12, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 97
    :cond_19
    check-cast v8, Landroidx/compose/foundation/interaction/MutableInteractionSource;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 98
    sget-object v9, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v10, 0x6

    invoke-virtual {v9, v12, v10}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v9

    invoke-static {v9}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v9

    invoke-static {v9}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v20

    .line 99
    sget-object v9, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    int-to-float v10, v4

    invoke-static {v2}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$4(Landroidx/compose/runtime/MutableFloatState;)F

    move-result v11

    sub-int v13, v5, v4

    int-to-float v13, v13

    mul-float/2addr v11, v13

    add-float/2addr v10, v11

    invoke-static {v10}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v13, 0x1b0

    const/4 v14, 0x0

    const/4 v11, 0x1

    const/16 v35, 0x0

    invoke-direct/range {v9 .. v14}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 100
    invoke-static {v2}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$4(Landroidx/compose/runtime/MutableFloatState;)F

    move-result v6

    .line 101
    sget-object v9, Landroidx/compose/material3/SliderDefaults;->INSTANCE:Landroidx/compose/material3/SliderDefaults;

    const/16 v26, 0xe

    const/16 v27, 0x0

    const v22, 0x3e19999a    # 0.15f

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    invoke-static/range {v20 .. v27}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v16

    move-wide/from16 v10, v20

    const/16 v32, 0x6

    const/16 v33, 0x3f4

    move-object/from16 v34, v15

    const-wide/16 v14, 0x0

    const-wide/16 v18, 0x0

    const-wide/16 v20, 0x0

    const-wide/16 v22, 0x0

    const-wide/16 v24, 0x0

    const-wide/16 v26, 0x0

    const-wide/16 v28, 0x0

    const/16 v31, 0x0

    move-object/from16 v30, v12

    move-wide v12, v10

    move/from16 v36, v6

    move-object/from16 v0, v34

    const/16 v6, 0x36

    invoke-virtual/range {v9 .. v33}, Landroidx/compose/material3/SliderDefaults;->colors-q0g_0yA(JJJJJJJJJJLandroidx/compose/runtime/Composer;III)Landroidx/compose/material3/SliderColors;

    move-result-object v14

    move-object/from16 v12, v30

    const v9, 0x5c74bab8

    .line 100
    invoke-static {v12, v9, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    .line 579
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    if-nez v9, :cond_1a

    .line 580
    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v13, v9, :cond_1b

    .line 100
    :cond_1a
    new-instance v13, Ldev/nino/squareglass/DesignEntry$1;

    invoke-direct {v13, v2}, Ldev/nino/squareglass/DesignEntry$1;-><init>(Landroidx/compose/runtime/MutableFloatState;)V

    .line 582
    invoke-interface {v12, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 100
    :cond_1b
    check-cast v13, Lam0/l;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v9, 0x5c74ea8b

    .line 104
    invoke-static {v12, v9, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v0, v1, 0x70

    const/16 v9, 0x20

    if-ne v0, v9, :cond_1c

    const/4 v15, 0x1

    goto :goto_c

    :cond_1c
    move/from16 v15, v35

    :goto_c
    and-int/lit16 v0, v1, 0x380

    const/16 v9, 0x100

    if-ne v0, v9, :cond_1d

    const/4 v0, 0x1

    goto :goto_d

    :cond_1d
    move/from16 v0, v35

    :goto_d
    or-int/2addr v0, v15

    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    or-int/2addr v0, v9

    and-int/lit16 v1, v1, 0x1c00

    const/16 v9, 0x800

    if-ne v1, v9, :cond_1e

    const/4 v15, 0x1

    goto :goto_e

    :cond_1e
    move/from16 v15, v35

    :goto_e
    or-int/2addr v0, v15

    .line 585
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_1f

    .line 586
    sget-object v0, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v0}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v1, v0, :cond_20

    .line 104
    :cond_1f
    new-instance v1, Ldev/nino/squareglass/DesignEntry$2;

    invoke-direct {v1, v3, v4, v5, v2}, Ldev/nino/squareglass/DesignEntry$2;-><init>(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)V

    .line 588
    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 104
    :cond_20
    check-cast v1, Lam0/a;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 102
    new-instance v0, Ldev/nino/squareglass/DesignEntry$3;

    invoke-direct {v0, v8, v10, v11}, Ldev/nino/squareglass/DesignEntry$3;-><init>(Landroidx/compose/foundation/interaction/MutableInteractionSource;J)V

    const v2, 0x4e8de2f2

    const/4 v9, 0x1

    invoke-static {v2, v9, v0, v12, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lkotlin/jvm/functions/Function3;

    const/16 v22, 0x0

    const/16 v23, 0x68c

    const/4 v11, 0x0

    move-object/from16 v30, v12

    const/4 v12, 0x0

    const/16 v16, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/high16 v21, 0x6180000

    move-object v15, v8

    move-object v10, v13

    move-object/from16 v20, v30

    move/from16 v9, v36

    move-object v13, v1

    .line 100
    invoke-static/range {v9 .. v23}, Landroidx/compose/material3/SliderKt;->Slider(FLam0/l;Landroidx/compose/ui/Modifier;ZLam0/a;Landroidx/compose/material3/SliderColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;ILkotlin/jvm/functions/Function3;Lkotlin/jvm/functions/Function3;Lfm0/d;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v12, v20

    .line 97
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 543
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 591
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 552
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 546
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 536
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 96
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_f

    :cond_21
    const v0, 0x130346e3

    .line 105
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_f
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_10

    .line 92
    :cond_22
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 106
    :cond_23
    :goto_10
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v9

    if-eqz v9, :cond_24

    new-instance v0, Ldev/nino/squareglass/DesignEntry$4;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v6, p5

    move/from16 v8, p8

    invoke-direct/range {v0 .. v8}, Ldev/nino/squareglass/DesignEntry$4;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;I)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_24
    return-void
.end method

.method private static final Range$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 93
    check-cast p0, Landroidx/compose/runtime/State;

    .line 694
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private static final Range$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 93
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 695
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final Range$lambda$4(Landroidx/compose/runtime/MutableFloatState;)F
    .locals 0

    .line 94
    check-cast p0, Landroidx/compose/runtime/FloatState;

    .line 697
    invoke-interface {p0}, Landroidx/compose/runtime/FloatState;->getFloatValue()F

    move-result p0

    return p0
.end method

.method private static final Range$lambda$5(Landroidx/compose/runtime/MutableFloatState;F)V
    .locals 0

    .line 698
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableFloatState;->setFloatValue(F)V

    return-void
.end method

.method private static final Range$lambda$6$0(Landroidx/compose/runtime/MutableState;)Lkotlin/u;
    .locals 1

    .line 95
    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {p0, v0}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Range$lambda$7$1$0(Landroidx/compose/runtime/MutableFloatState;F)Lkotlin/u;
    .locals 0

    .line 100
    invoke-static {p0, p1}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$5(Landroidx/compose/runtime/MutableFloatState;F)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Range$lambda$7$2$0(Ljava/lang/String;IILandroidx/compose/runtime/MutableFloatState;)Lkotlin/u;
    .locals 1

    int-to-float v0, p1

    .line 104
    invoke-static {p3}, Ldev/nino/squareglass/DesignEntry;->Range$lambda$4(Landroidx/compose/runtime/MutableFloatState;)F

    move-result p3

    sub-int/2addr p2, p1

    int-to-float p1, p2

    mul-float/2addr p3, p1

    add-float/2addr v0, p3

    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->roundToInt(F)I

    move-result p1

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Range$lambda$7$3(Landroidx/compose/foundation/interaction/MutableInteractionSource;JLandroidx/compose/material3/SliderState;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 27

    move-object/from16 v7, p4

    move/from16 v0, p5

    const-string v1, "it"

    move-object/from16 v2, p3

    invoke-static {v2, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "CN(it)101@5943L28,102@6015L22,101@5902L136:DesignEntry.kt#vqphja"

    invoke-static {v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v2, 0x10

    if-eq v1, v2, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    and-int/lit8 v2, v0, 0x1

    invoke-interface {v7, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.DesignEntry.Range.<anonymous>.<anonymous> (DesignEntry.kt:101)"

    const v3, 0x4e8de2f2

    invoke-static {v3, v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 102
    :cond_1
    sget-object v0, Landroidx/compose/material3/SliderDefaults;->INSTANCE:Landroidx/compose/material3/SliderDefaults;

    sget-object v1, Ldev/nino/squareglass/SliderMotion;->INSTANCE:Ldev/nino/squareglass/SliderMotion;

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x1b6

    move-object/from16 v4, p0

    invoke-virtual {v1, v2, v4, v7, v3}, Ldev/nino/squareglass/SliderMotion;->thumb(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v26

    .line 103
    sget-object v1, Landroidx/compose/material3/SliderDefaults;->INSTANCE:Landroidx/compose/material3/SliderDefaults;

    const/16 v24, 0x6

    const/16 v25, 0x3fe

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v14, 0x0

    const-wide/16 v16, 0x0

    const-wide/16 v18, 0x0

    const-wide/16 v20, 0x0

    const/16 v23, 0x0

    move-wide/from16 v2, p1

    move-object/from16 v22, p4

    invoke-virtual/range {v1 .. v25}, Landroidx/compose/material3/SliderDefaults;->colors-q0g_0yA(JJJJJJJJJJLandroidx/compose/runtime/Composer;III)Landroidx/compose/material3/SliderColors;

    move-result-object v3

    const v8, 0x30006

    const/16 v9, 0x18

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    move-object/from16 v1, p0

    move-object/from16 v7, p4

    move-object/from16 v2, v26

    .line 102
    invoke-virtual/range {v0 .. v9}, Landroidx/compose/material3/SliderDefaults;->Thumb-9LiSoMs(Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/ui/Modifier;Landroidx/compose/material3/SliderColors;ZJLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    :cond_2
    invoke-interface/range {p4 .. p4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 103
    :cond_3
    :goto_1
    sget-object v0, Lkotlin/u;->a:Lkotlin/u;

    return-object v0
.end method

.method static final Range$lambda$8(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 10

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move v5, p4

    move v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p8

    invoke-direct/range {v1 .. v9}, Ldev/nino/squareglass/DesignEntry;->Range(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move/from16 v5, p5

    const v0, 0x3b6458ba

    move-object/from16 v1, p4

    .line 55
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    const-string v1, "C(Row)N(label,value,onClick)55@2603L36,55@2585L339:DesignEntry.kt#vqphja"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v5, 0x6

    move-object/from16 v2, p1

    if-nez v1, :cond_1

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    :goto_0
    or-int/2addr v1, v5

    goto :goto_1

    :cond_1
    move v1, v5

    :goto_1
    and-int/lit8 v3, p6, 0x2

    if-eqz v3, :cond_2

    or-int/lit8 v1, v1, 0x30

    goto :goto_3

    :cond_2
    and-int/lit8 v4, v5, 0x30

    if-nez v4, :cond_4

    move-object/from16 v4, p2

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    const/16 v6, 0x20

    goto :goto_2

    :cond_3
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v1, v6

    goto :goto_4

    :cond_4
    :goto_3
    move-object/from16 v4, p2

    :goto_4
    and-int/lit16 v6, v5, 0x180

    move-object/from16 v15, p3

    if-nez v6, :cond_6

    invoke-interface {v9, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5

    const/16 v6, 0x100

    goto :goto_5

    :cond_5
    const/16 v6, 0x80

    :goto_5
    or-int/2addr v1, v6

    :cond_6
    and-int/lit16 v6, v1, 0x93

    const/16 v7, 0x92

    const/4 v8, 0x1

    const/4 v10, 0x0

    if-eq v6, v7, :cond_7

    move v6, v8

    goto :goto_6

    :cond_7
    move v6, v10

    :goto_6
    and-int/lit8 v7, v1, 0x1

    invoke-interface {v9, v6, v7}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v6

    if-eqz v6, :cond_13

    const/4 v6, 0x0

    if-eqz v3, :cond_8

    move-object v4, v6

    :cond_8
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_9

    const/4 v3, -0x1

    const-string v7, "dev.nino.squareglass.DesignEntry.Row (DesignEntry.kt:54)"

    invoke-static {v0, v1, v3, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 56
    :cond_9
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    invoke-static {v0, v3, v8, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v3, 0x36

    invoke-static {v0, v9, v3}, Ldev/nino/squareglass/SquareScreens;->settingsRow(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 57
    sget-object v3, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/semantics/Role$Companion;->getButton-o7Vup1c()I

    move-result v3

    invoke-static {v3}, Landroidx/compose/ui/semantics/Role;->box-impl(I)Landroidx/compose/ui/semantics/Role;

    move-result-object v13

    const/16 v16, 0xb

    const/16 v17, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v14, 0x0

    move/from16 v21, v10

    move-object v10, v0

    move/from16 v0, v21

    invoke-static/range {v10 .. v17}, Landroidx/compose/foundation/ClickableKt;->clickable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/high16 v6, 0x41a00000    # 20.0f

    .line 190
    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 57
    invoke-static {v3, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v6

    const v7, 0x3255a44b

    .line 56
    const-string v8, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    .line 191
    invoke-static {v9, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 192
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v7

    const/16 v8, 0x30

    .line 196
    invoke-static {v7, v6, v9, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    const v7, -0x451e1427

    .line 201
    const-string v8, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v9, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 202
    invoke-static {v9, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    .line 203
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 204
    invoke-static {v9, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 206
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v12

    const v13, -0x20f7d59c

    .line 207
    const-string v14, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v9, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 208
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v15

    instance-of v15, v15, Landroidx/compose/runtime/Applier;

    if-nez v15, :cond_a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 209
    :cond_a
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 210
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v15

    if-eqz v15, :cond_b

    .line 211
    invoke-interface {v9, v12}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_7

    .line 213
    :cond_b
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 215
    :goto_7
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .line 216
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v15

    invoke-static {v12, v6, v15}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 217
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v6

    invoke-static {v12, v11, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 218
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v6

    .line 220
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v11

    if-nez v11, :cond_c

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-static {v11, v15}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_d

    .line 221
    :cond_c
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v12, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 222
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v12, v10, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 225
    :cond_d
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v6

    invoke-static {v12, v3, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v3, 0x56ccd6f5

    .line 227
    const-string v6, "C101@5233L9:Row.kt#2w3rfo"

    .line 198
    invoke-static {v9, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    move-object v15, v3

    check-cast v15, Landroidx/compose/foundation/layout/RowScope;

    const v3, 0x6e473697

    const-string v6, "C57@2772L114,58@2899L15:DesignEntry.kt#vqphja"

    .line 58
    invoke-static {v9, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v16, v3

    check-cast v16, Landroidx/compose/ui/Modifier;

    const/16 v19, 0x2

    const/16 v20, 0x0

    const/high16 v17, 0x3f800000    # 1.0f

    const/16 v18, 0x0

    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const v6, 0x4ff7456f

    const-string v10, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    .line 228
    invoke-static {v9, v6, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 229
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v6

    .line 230
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    .line 233
    invoke-static {v6, v10, v9, v0}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 238
    invoke-static {v9, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 239
    invoke-static {v9, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    .line 240
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 241
    invoke-static {v9, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 243
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v8

    .line 244
    invoke-static {v9, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 245
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v10

    instance-of v10, v10, Landroidx/compose/runtime/Applier;

    if-nez v10, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 246
    :cond_e
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 247
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v10

    if-eqz v10, :cond_f

    .line 248
    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_8

    .line 250
    :cond_f
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 252
    :goto_8
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .line 253
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v10

    invoke-static {v8, v6, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 254
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v6

    invoke-static {v8, v7, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 255
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v6

    .line 257
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-nez v7, :cond_10

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v7, v10}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_11

    .line 258
    :cond_10
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 259
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v8, v0, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 262
    :cond_11
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v0

    invoke-static {v8, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v0, 0x7cc0ae6e

    .line 264
    const-string v3, "C89@4557L9:Column.kt#2w3rfo"

    .line 235
    invoke-static {v9, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    const v0, 0x7ccf959d

    const-string v3, "C57@2802L12:DesignEntry.kt#vqphja"

    .line 58
    invoke-static {v9, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v6, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    and-int/lit8 v0, v1, 0xe

    or-int/lit16 v10, v0, 0x180

    const/4 v11, 0x2

    const/4 v8, 0x0

    move-object v7, v2

    invoke-direct/range {v6 .. v11}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    if-eqz v4, :cond_12

    const v0, 0x7cd0063a

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "57@2834L29,57@2865L17"

    invoke-static {v9, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/high16 v2, 0x40800000    # 4.0f

    .line 265
    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 58
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v2, 0x6

    invoke-static {v0, v9, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    shr-int/lit8 v0, v1, 0x3

    and-int/lit8 v0, v0, 0xe

    or-int/lit16 v10, v0, 0x1b0

    const/4 v11, 0x0

    const/4 v8, 0x1

    move-object v7, v4

    invoke-direct/range {v6 .. v11}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_9

    :cond_12
    const v0, 0x7cd0c96e

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_9
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 235
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 266
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 244
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 238
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 228
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v10, 0x1b6

    const/4 v11, 0x0

    .line 59
    const-string v7, "\u203a"

    const/4 v8, 0x1

    invoke-direct/range {v6 .. v11}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 58
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 198
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 270
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 207
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 201
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 191
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 273
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_a

    .line 55
    :cond_13
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_14
    :goto_a
    move-object v3, v4

    .line 61
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_15

    new-instance v0, Ldev/nino/squareglass/DesignEntry$5;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v4, p3

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry$5;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Lam0/a;II)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_15
    return-void
.end method

.method static final Row$lambda$1(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Lam0/a;IILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 7

    or-int/lit8 p4, p4, 0x1

    invoke-static {p4}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v6, p5

    move-object v4, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 8

    const v0, -0x3d750320

    .line 52
    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    const-string p2, "C(Section)N(text)52@2358L90:DesignEntry.kt#vqphja"

    invoke-static {v4, p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 p2, p3, 0x6

    const/4 v1, 0x2

    if-nez p2, :cond_1

    invoke-interface {v4, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    const/4 p2, 0x4

    goto :goto_0

    :cond_0
    move p2, v1

    :goto_0
    or-int/2addr p2, p3

    goto :goto_1

    :cond_1
    move p2, p3

    :goto_1
    and-int/lit8 v2, p2, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x0

    if-eq v2, v1, :cond_2

    move v1, v3

    goto :goto_2

    :cond_2
    move v1, v5

    :goto_2
    and-int/lit8 v2, p2, 0x1

    invoke-interface {v4, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.DesignEntry.Section (DesignEntry.kt:51)"

    invoke-static {v0, p2, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 53
    :cond_3
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0, v1, v3, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/high16 v1, 0x42100000    # 36.0f

    .line 148
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    const/high16 v2, 0x41800000    # 16.0f

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 53
    invoke-static {v0, v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const v1, 0x3e277f0a

    const-string v2, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    .line 149
    invoke-static {v4, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 150
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v1

    .line 154
    invoke-static {v1, v5}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v1

    const v2, -0x451e1427

    .line 155
    const-string v3, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    .line 159
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 160
    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    .line 161
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 162
    invoke-static {v4, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 164
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v5

    const v6, -0x20f7d59c

    .line 163
    const-string v7, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    .line 165
    invoke-static {v4, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 166
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v6

    instance-of v6, v6, Landroidx/compose/runtime/Applier;

    if-nez v6, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 167
    :cond_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 168
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-eqz v6, :cond_5

    .line 169
    invoke-interface {v4, v5}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_3

    .line 171
    :cond_5
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 173
    :goto_3
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .line 174
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v6

    invoke-static {v5, v1, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 175
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v1

    invoke-static {v5, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 176
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v1

    .line 178
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-nez v3, :cond_6

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v3, v6}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7

    .line 179
    :cond_6
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 180
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v5, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 183
    :cond_7
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v1

    invoke-static {v5, v0, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v0, 0x6d423196

    .line 185
    const-string v1, "C72@3469L9:Box.kt#2w3rfo"

    .line 156
    invoke-static {v4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    const v0, -0x1782227

    const-string v1, "C52@2430L16:DesignEntry.kt#vqphja"

    .line 53
    invoke-static {v4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    and-int/lit8 p2, p2, 0xe

    or-int/lit16 v5, p2, 0x1b0

    const/4 v6, 0x0

    const/4 v3, 0x1

    move-object v2, p1

    invoke-direct/range {v1 .. v6}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 156
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 186
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 165
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 159
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 149
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 189
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_4

    :cond_8
    move-object v2, p1

    .line 52
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 54
    :cond_9
    :goto_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object p1

    if-eqz p1, :cond_a

    new-instance p2, Ldev/nino/squareglass/DesignEntry$22;

    invoke-direct {p2, p0, v2, p3}, Ldev/nino/squareglass/DesignEntry$22;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;I)V

    invoke-interface {p1, p2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_a
    return-void
.end method

.method static final Section$lambda$1(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    or-int/lit8 p2, p2, 0x1

    invoke-static {p2}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result p2

    invoke-direct {p0, p1, p3, p2}, Ldev/nino/squareglass/DesignEntry;->Section(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private final Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V
    .locals 46

    move-object/from16 v3, p2

    move/from16 v5, p5

    const v0, 0x2296a220

    move-object/from16 v1, p4

    .line 62
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    const-string v1, "C(Toggle)N(label,key,fallback)64@3130L4,65@3236L36,66@3314L36,65@3218L655:DesignEntry.kt#vqphja"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v5, 0x6

    move-object/from16 v2, p1

    if-nez v1, :cond_1

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    :goto_0
    or-int/2addr v1, v5

    goto :goto_1

    :cond_1
    move v1, v5

    :goto_1
    and-int/lit8 v4, v5, 0x30

    const/16 v12, 0x20

    if-nez v4, :cond_3

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    move v4, v12

    goto :goto_2

    :cond_2
    const/16 v4, 0x10

    :goto_2
    or-int/2addr v1, v4

    :cond_3
    and-int/lit8 v4, p6, 0x4

    if-eqz v4, :cond_4

    or-int/lit16 v1, v1, 0x180

    goto :goto_4

    :cond_4
    and-int/lit16 v6, v5, 0x180

    if-nez v6, :cond_6

    move/from16 v6, p3

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v7

    if-eqz v7, :cond_5

    const/16 v7, 0x100

    goto :goto_3

    :cond_5
    const/16 v7, 0x80

    :goto_3
    or-int/2addr v1, v7

    goto :goto_5

    :cond_6
    :goto_4
    move/from16 v6, p3

    :goto_5
    and-int/lit16 v7, v1, 0x93

    const/16 v8, 0x92

    const/4 v13, 0x1

    const/4 v14, 0x0

    if-eq v7, v8, :cond_7

    move v7, v13

    goto :goto_6

    :cond_7
    move v7, v14

    :goto_6
    and-int/lit8 v8, v1, 0x1

    invoke-interface {v9, v7, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_18

    if-eqz v4, :cond_8

    move v4, v13

    goto :goto_7

    :cond_8
    move v4, v6

    :goto_7
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_9

    const/4 v6, -0x1

    const-string v7, "dev.nino.squareglass.DesignEntry.Toggle (DesignEntry.kt:61)"

    invoke-static {v0, v1, v6, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 63
    :cond_9
    sget-object v0, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v0}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 64
    invoke-static {v3, v4}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result v0

    .line 65
    sget-object v6, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v7, 0x6

    invoke-virtual {v6, v9, v7}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v6

    invoke-static {v6}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v6

    invoke-static {v6}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v15

    .line 66
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v6, v7, v13, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const/16 v7, 0x36

    invoke-static {v6, v9, v7}, Ldev/nino/squareglass/SquareScreens;->settingsRow(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object v17

    .line 67
    sget-object v6, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/semantics/Role$Companion;->getSwitch-o7Vup1c()I

    move-result v6

    invoke-static {v6}, Landroidx/compose/ui/semantics/Role;->box-impl(I)Landroidx/compose/ui/semantics/Role;

    move-result-object v20

    const v6, -0x288938dc

    const-string v7, "CC(remember):DesignEntry.kt#9igjgp"

    invoke-static {v9, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v6, v1, 0x70

    if-ne v6, v12, :cond_a

    move v8, v13

    goto :goto_8

    :cond_a
    move v8, v14

    :goto_8
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v10

    or-int/2addr v8, v10

    .line 274
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    if-nez v8, :cond_b

    .line 275
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v10, v8, :cond_c

    .line 67
    :cond_b
    new-instance v10, Ldev/nino/squareglass/DesignEntry$6;

    invoke-direct {v10, v3, v0}, Ldev/nino/squareglass/DesignEntry$6;-><init>(Ljava/lang/String;Z)V

    .line 277
    invoke-interface {v9, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 67
    :cond_c
    move-object/from16 v22, v10

    check-cast v22, Lam0/a;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v23, 0xb

    const/16 v24, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v21, 0x0

    invoke-static/range {v17 .. v24}, Landroidx/compose/foundation/ClickableKt;->clickable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/high16 v10, 0x41a00000    # 20.0f

    .line 280
    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    const/high16 v11, 0x40c00000    # 6.0f

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 67
    invoke-static {v8, v10, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 68
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v10

    const v11, 0x3255a44b

    .line 66
    const-string v13, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    .line 281
    invoke-static {v9, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 282
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v11}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v11

    const/16 v13, 0x30

    .line 286
    invoke-static {v11, v10, v9, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    const v11, -0x451e1427

    .line 291
    const-string v13, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v9, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 292
    invoke-static {v9, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v17

    .line 293
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 294
    invoke-static {v9, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 296
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v11

    const v14, -0x20f7d59c

    move/from16 v43, v0

    .line 297
    const-string v0, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v9, v14, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 298
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 299
    :cond_d
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 300
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_e

    .line 301
    invoke-interface {v9, v11}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_9

    .line 303
    :cond_e
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 305
    :goto_9
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .line 306
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v14

    invoke-static {v11, v10, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 307
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v10

    invoke-static {v11, v12, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 308
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v10

    .line 310
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v12

    if-nez v12, :cond_f

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v12, v14}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_10

    .line 311
    :cond_f
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v11, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 312
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v11, v12, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 315
    :cond_10
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v10

    invoke-static {v11, v8, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v8, 0x56ccd6f5

    .line 317
    const-string v10, "C101@5233L9:Row.kt#2w3rfo"

    .line 288
    invoke-static {v9, v8, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    move-object/from16 v21, v8

    check-cast v21, Landroidx/compose/foundation/layout/RowScope;

    const v8, -0x59c16628

    const-string v10, "C68@3464L60,69@3568L28,69@3619L243,69@3537L326:DesignEntry.kt#vqphja"

    .line 69
    invoke-static {v9, v8, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v22, v8

    check-cast v22, Landroidx/compose/ui/Modifier;

    const/16 v25, 0x2

    const/16 v26, 0x0

    const/high16 v23, 0x3f800000    # 1.0f

    const/16 v24, 0x0

    invoke-static/range {v21 .. v26}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v27

    const/high16 v8, 0x41400000    # 12.0f

    .line 318
    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v30

    const/16 v32, 0xb

    const/16 v33, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v31, 0x0

    .line 69
    invoke-static/range {v27 .. v33}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const v10, 0x3e277f0a

    const-string v11, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    .line 319
    invoke-static {v9, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 320
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v10

    const/4 v12, 0x0

    .line 324
    invoke-static {v10, v12}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    const v11, -0x451e1427

    .line 329
    invoke-static {v9, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 330
    invoke-static {v9, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v11

    .line 331
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 332
    invoke-static {v9, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 334
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lam0/a;

    move-result-object v14

    const v12, -0x20f7d59c

    .line 335
    invoke-static {v9, v12, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 336
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 337
    :cond_11
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 338
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_12

    .line 339
    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->createNode(Lam0/a;)V

    goto :goto_a

    .line 341
    :cond_12
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 343
    :goto_a
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .line 344
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lam0/p;

    move-result-object v12

    invoke-static {v0, v10, v12}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 345
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lam0/p;

    move-result-object v10

    invoke-static {v0, v13, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    .line 346
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lam0/p;

    move-result-object v10

    .line 348
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v12

    if-nez v12, :cond_13

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v12, v13}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_14

    .line 349
    :cond_13
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v0, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 350
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v0, v11, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lam0/p;)V

    .line 353
    :cond_14
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lam0/p;

    move-result-object v10

    invoke-static {v0, v8, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lam0/p;)V

    const v0, 0x6d423196

    .line 355
    const-string v8, "C72@3469L9:Box.kt#2w3rfo"

    .line 326
    invoke-static {v9, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    const v0, 0x35bcfc81

    const-string v8, "C68@3510L12:DesignEntry.kt#vqphja"

    .line 69
    invoke-static {v9, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move v0, v6

    sget-object v6, Ldev/nino/squareglass/DesignEntry;->INSTANCE:Ldev/nino/squareglass/DesignEntry;

    and-int/lit8 v1, v1, 0xe

    or-int/lit16 v10, v1, 0x180

    const/4 v11, 0x2

    const/4 v8, 0x0

    move-object v1, v7

    move-object v7, v2

    invoke-direct/range {v6 .. v11}, Ldev/nino/squareglass/DesignEntry;->Label(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 326
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 356
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 335
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 329
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 319
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v2, -0x3cb39ce8

    .line 70
    invoke-static {v9, v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/16 v1, 0x20

    if-ne v0, v1, :cond_15

    const/4 v13, 0x1

    goto :goto_b

    :cond_15
    const/4 v13, 0x0

    .line 360
    :goto_b
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    if-nez v13, :cond_16

    .line 361
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_17

    .line 70
    :cond_16
    new-instance v0, Ldev/nino/squareglass/DesignEntry$7;

    invoke-direct {v0, v3}, Ldev/nino/squareglass/DesignEntry$7;-><init>(Ljava/lang/String;)V

    .line 363
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 70
    :cond_17
    check-cast v0, Lam0/l;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v6, Landroidx/compose/material3/SwitchDefaults;->INSTANCE:Landroidx/compose/material3/SwitchDefaults;

    const/16 v21, 0xe

    const/16 v22, 0x0

    const v17, 0x3e99999a    # 0.3f

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    .line 71
    invoke-static/range {v15 .. v22}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v1

    const v17, 0x3f266666    # 0.65f

    .line 72
    invoke-static/range {v15 .. v22}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v7

    const v17, 0x3dcccccd    # 0.1f

    invoke-static/range {v15 .. v22}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v10

    const/high16 v17, 0x3e800000    # 0.25f

    .line 73
    invoke-static/range {v15 .. v22}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v19

    sget v12, Landroidx/compose/material3/SwitchDefaults;->$stable:I

    shl-int/lit8 v41, v12, 0x12

    const v42, 0xff8c

    move-wide/from16 v17, v10

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v21, 0x0

    const-wide/16 v23, 0x0

    const-wide/16 v25, 0x0

    const-wide/16 v27, 0x0

    const-wide/16 v29, 0x0

    const-wide/16 v31, 0x0

    const-wide/16 v33, 0x0

    const-wide/16 v35, 0x0

    const-wide/16 v37, 0x0

    const/16 v40, 0x0

    move-wide/from16 v44, v15

    move-wide v15, v7

    move-wide/from16 v7, v44

    move-object/from16 v39, v9

    move-wide v9, v1

    .line 70
    invoke-virtual/range {v6 .. v42}, Landroidx/compose/material3/SwitchDefaults;->colors-V1nXRL4(JJJJJJJJJJJJJJJJLandroidx/compose/runtime/Composer;III)Landroidx/compose/material3/SwitchColors;

    move-result-object v11

    move-object/from16 v9, v39

    const/4 v14, 0x0

    const/16 v15, 0x5c

    const/4 v8, 0x0

    move-object v13, v9

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v12, 0x0

    move-object v7, v0

    move/from16 v6, v43

    invoke-static/range {v6 .. v15}, Landroidx/compose/material3/SwitchKt;->Switch(ZLam0/l;Landroidx/compose/ui/Modifier;Lam0/p;ZLandroidx/compose/material3/SwitchColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;II)V

    move-object v9, v13

    .line 69
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 288
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 366
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 297
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 291
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 281
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 369
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_c

    .line 62
    :cond_18
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v4, v6

    .line 75
    :cond_19
    :goto_c
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_1a

    new-instance v0, Ldev/nino/squareglass/DesignEntry$8;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry$8;-><init>(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;ZII)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lam0/p;)V

    :cond_1a
    return-void
.end method

.method private static final Toggle$lambda$0$0(Ljava/lang/String;Z)Lkotlin/u;
    .locals 0

    xor-int/lit8 p1, p1, 0x1

    .line 67
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final Toggle$lambda$1$1$0(Ljava/lang/String;Z)Lkotlin/u;
    .locals 0

    .line 70
    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareSettings;->put(Ljava/lang/String;Z)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final Toggle$lambda$2(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 7

    or-int/lit8 p4, p4, 0x1

    invoke-static {p4}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v6, p5

    move-object v4, p6

    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/DesignEntry;->Toggle(Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final synthetic access$Entry(Ldev/nino/squareglass/DesignEntry;Landroidx/compose/runtime/Composer;I)V
    .locals 0

    .line 27
    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/DesignEntry;->Entry(Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$Row(Ldev/nino/squareglass/DesignEntry;Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V
    .locals 0

    .line 27
    invoke-direct/range {p0 .. p6}, Ldev/nino/squareglass/DesignEntry;->Row(Ljava/lang/String;Ljava/lang/String;Lam0/a;Landroidx/compose/runtime/Composer;II)V

    return-void
.end method

.method public static final synthetic access$activity(Ldev/nino/squareglass/DesignEntry;Landroid/content/Context;)Landroid/app/Activity;
    .locals 0

    .line 27
    invoke-direct {p0, p1}, Ldev/nino/squareglass/DesignEntry;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    return-object p0
.end method

.method private final activity(Landroid/content/Context;)Landroid/app/Activity;
    .locals 1

    .line 43
    instance-of v0, p1, Landroid/app/Activity;

    if-eqz v0, :cond_0

    check-cast p1, Landroid/app/Activity;

    return-object p1

    .line 44
    :cond_0
    instance-of v0, p1, Landroid/content/ContextWrapper;

    if-eqz v0, :cond_1

    check-cast p1, Landroid/content/ContextWrapper;

    invoke-virtual {p1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p1

    const-string v0, "getBaseContext(...)"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, Ldev/nino/squareglass/DesignEntry;->activity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public static final append(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/util/List;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/foundation/lazy/LazyListScope;",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    const-string v0, "scope"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "items"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 32
    :cond_0
    check-cast p1, Ljava/lang/Iterable;

    .line 145
    instance-of v0, p1, Ljava/util/Collection;

    if-eqz v0, :cond_1

    move-object v0, p1

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    .line 146
    :cond_1
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    .line 32
    instance-of v1, v0, Ljm/f$a;

    if-eqz v1, :cond_3

    check-cast v0, Ljm/f$a;

    iget-object v0, v0, Ljm/f$a;->e:Lam0/a;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_2
    const/4 v0, 0x0

    .line 33
    :goto_1
    const-string v1, "com.aspiro.wamp.settings.items.profile.SettingsItemOfflineMode$viewState$1"

    .line 32
    invoke-static {v0, v1}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 34
    sget-object p1, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->INSTANCE:Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;

    invoke-virtual {p1}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->getLambda$329193799$extension_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v1, "squareglass.output"

    const/4 v2, 0x0

    move-object v0, p0

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 40
    sget-object p0, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->INSTANCE:Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;

    invoke-virtual {p0}, Ldev/nino/squareglass/ComposableSingletons$DesignEntryKt;->getLambda$-2113737026$extension_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string v7, "squareglass.design.v2"

    const/4 v8, 0x0

    move-object v6, v0

    invoke-static/range {v6 .. v11}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    return-void

    :cond_3
    move-object v0, p0

    move-object p0, v0

    goto :goto_0

    :cond_4
    return-void
.end method
