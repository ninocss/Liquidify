.class public final synthetic Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/DampedDragAnimation;

.field public final synthetic f$1:Landroidx/compose/ui/input/pointer/PointerInputScope;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;Landroidx/compose/ui/input/pointer/PointerInputScope;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$3;->f$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iput-object p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$3;->f$1:Landroidx/compose/ui/input/pointer/PointerInputScope;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$3;->f$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$3;->f$1:Landroidx/compose/ui/input/pointer/PointerInputScope;

    check-cast p1, Landroidx/compose/ui/input/pointer/PointerInputChange;

    check-cast p2, Landroidx/compose/ui/geometry/Offset;

    invoke-static {v0, p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;->invoke$lambda$3(Ldev/nino/squareglass/material/DampedDragAnimation;Landroidx/compose/ui/input/pointer/PointerInputScope;Landroidx/compose/ui/input/pointer/PointerInputChange;Landroidx/compose/ui/geometry/Offset;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
