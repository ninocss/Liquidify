.class public final Ldev/nino/squareglass/material/DampedDragAnimation;
.super Ljava/lang/Object;
.source "DampedDragAnimation.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDampedDragAnimation.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DampedDragAnimation.kt\ndev/nino/squareglass/material/DampedDragAnimation\n+ 2 Offset.kt\nandroidx/compose/ui/geometry/OffsetKt\n+ 3 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n*L\n1#1,164:1\n30#2:165\n53#3,3:166\n*S KotlinDebug\n*F\n+ 1 DampedDragAnimation.kt\ndev/nino/squareglass/material/DampedDragAnimation\n*L\n158#1:165\n158#1:166,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000v\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0013\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u000f\n\u0002\u0018\u0002\n\u0002\u0008\u0008\u0008\u0007\u0018\u00002\u00020\u0001B\u00da\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\u0005\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012,\u0010\u000b\u001a(\u0012\u0004\u0012\u00020\u0000\u0012\u0013\u0012\u00110\r\u00a2\u0006\u000c\u0008\u000e\u0012\u0008\u0008\u000f\u0012\u0004\u0008\u0008(\u0010\u0012\u0004\u0012\u00020\u00110\u000c\u00a2\u0006\u0002\u0008\u0012\u0012\u0017\u0010\u0013\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00110\u0014\u00a2\u0006\u0002\u0008\u0012\u0012\u0017\u0010\u0015\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00110\u0014\u00a2\u0006\u0002\u0008\u0012\u0012A\u0010\u0016\u001a=\u0012\u0004\u0012\u00020\u0000\u0012\u0013\u0012\u00110\u0018\u00a2\u0006\u000c\u0008\u000e\u0012\u0008\u0008\u000f\u0012\u0004\u0008\u0008(\u0019\u0012\u0013\u0012\u00110\r\u00a2\u0006\u000c\u0008\u000e\u0012\u0008\u0008\u000f\u0012\u0004\u0008\u0008(\u001a\u0012\u0004\u0012\u00020\u00110\u0017\u00a2\u0006\u0002\u0008\u0012\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u0006\u0010N\u001a\u00020\u0011J\u0006\u0010O\u001a\u00020\u0011J\u000e\u0010P\u001a\u00020\u00112\u0006\u0010<\u001a\u00020\u0005J\u000e\u0010Q\u001a\u00020\u00112\u0006\u0010<\u001a\u00020\u0005J\u0008\u0010R\u001a\u00020\u0011H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u001eR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001f\u0010 R\u0011\u0010\u0008\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008!\u0010\u001eR\u0011\u0010\t\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\"\u0010\u001eR\u0011\u0010\n\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008#\u0010\u001eR7\u0010\u000b\u001a(\u0012\u0004\u0012\u00020\u0000\u0012\u0013\u0012\u00110\r\u00a2\u0006\u000c\u0008\u000e\u0012\u0008\u0008\u000f\u0012\u0004\u0008\u0008(\u0010\u0012\u0004\u0012\u00020\u00110\u000c\u00a2\u0006\u0002\u0008\u0012\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008$\u0010%R\"\u0010\u0013\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00110\u0014\u00a2\u0006\u0002\u0008\u0012\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008&\u0010\'R\"\u0010\u0015\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00110\u0014\u00a2\u0006\u0002\u0008\u0012\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008(\u0010\'RL\u0010\u0016\u001a=\u0012\u0004\u0012\u00020\u0000\u0012\u0013\u0012\u00110\u0018\u00a2\u0006\u000c\u0008\u000e\u0012\u0008\u0008\u000f\u0012\u0004\u0008\u0008(\u0019\u0012\u0013\u0012\u00110\r\u00a2\u0006\u000c\u0008\u000e\u0012\u0008\u0008\u000f\u0012\u0004\u0008\u0008(\u001a\u0012\u0004\u0012\u00020\u00110\u0017\u00a2\u0006\u0002\u0008\u0012\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008)\u0010*R\u0014\u0010+\u001a\u0008\u0012\u0004\u0012\u00020\u00050,X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010-\u001a\u0008\u0012\u0004\u0012\u00020\u00050,X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010.\u001a\u0008\u0012\u0004\u0012\u00020\u00050,X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010/\u001a\u0008\u0012\u0004\u0012\u00020\u00050,X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u00100\u001a\u0008\u0012\u0004\u0012\u00020\u00050,X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u00101\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020302X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u00104\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020302X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020302X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u00106\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020302X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u00107\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020302X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00108\u001a\u000209X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010:\u001a\u00020;X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010<\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008=\u0010\u001eR\u0011\u0010>\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008?\u0010\u001eR\u0011\u0010@\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008A\u0010\u001eR\u0011\u0010B\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008C\u0010\u001eR\u0011\u0010D\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008E\u0010\u001eR\u0011\u0010F\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008G\u0010\u001eR\u0011\u0010H\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008I\u0010\u001eR\u0011\u0010J\u001a\u00020K\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008L\u0010M\u00a8\u0006S"
    }
    d2 = {
        "Ldev/nino/squareglass/material/DampedDragAnimation;",
        "",
        "animationScope",
        "Lkotlinx/coroutines/CoroutineScope;",
        "initialValue",
        "",
        "valueRange",
        "Ldev/nino/squareglass/material/FloatBounds;",
        "visibilityThreshold",
        "initialScale",
        "pressedScale",
        "onDragStarted",
        "Lkotlin/Function2;",
        "Landroidx/compose/ui/geometry/Offset;",
        "Lkotlin/ParameterName;",
        "name",
        "position",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "onDragStopped",
        "Lkotlin/Function1;",
        "onDragCancelled",
        "onDrag",
        "Lkotlin/Function3;",
        "Landroidx/compose/ui/unit/IntSize;",
        "size",
        "dragAmount",
        "<init>",
        "(Lkotlinx/coroutines/CoroutineScope;FLdev/nino/squareglass/material/FloatBounds;FFFLam0/p;Lam0/l;Lam0/l;Lkotlin/jvm/functions/Function3;)V",
        "getInitialValue",
        "()F",
        "getValueRange",
        "()Ldev/nino/squareglass/material/FloatBounds;",
        "getVisibilityThreshold",
        "getInitialScale",
        "getPressedScale",
        "getOnDragStarted",
        "()Lam0/p;",
        "getOnDragStopped",
        "()Lam0/l;",
        "getOnDragCancelled",
        "getOnDrag",
        "()Lkotlin/jvm/functions/Function3;",
        "valueAnimationSpec",
        "Landroidx/compose/animation/core/SpringSpec;",
        "velocityAnimationSpec",
        "pressProgressAnimationSpec",
        "scaleXAnimationSpec",
        "scaleYAnimationSpec",
        "valueAnimation",
        "Landroidx/compose/animation/core/Animatable;",
        "Landroidx/compose/animation/core/AnimationVector1D;",
        "velocityAnimation",
        "pressProgressAnimation",
        "scaleXAnimation",
        "scaleYAnimation",
        "mutatorMutex",
        "Landroidx/compose/foundation/MutatorMutex;",
        "velocityTracker",
        "Landroidx/compose/ui/input/pointer/util/VelocityTracker;",
        "value",
        "getValue",
        "progress",
        "getProgress",
        "targetValue",
        "getTargetValue",
        "pressProgress",
        "getPressProgress",
        "scaleX",
        "getScaleX",
        "scaleY",
        "getScaleY",
        "velocity",
        "getVelocity",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "getModifier",
        "()Landroidx/compose/ui/Modifier;",
        "press",
        "release",
        "updateValue",
        "animateToValue",
        "updateVelocity",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final animationScope:Lkotlinx/coroutines/CoroutineScope;

.field private final initialScale:F

.field private final initialValue:F

.field private final modifier:Landroidx/compose/ui/Modifier;

.field private final mutatorMutex:Landroidx/compose/foundation/MutatorMutex;

.field private final onDrag:Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function3<",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Landroidx/compose/ui/unit/IntSize;",
            "Landroidx/compose/ui/geometry/Offset;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final onDragCancelled:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final onDragStarted:Lam0/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Landroidx/compose/ui/geometry/Offset;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final onDragStopped:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field private final pressProgressAnimation:Landroidx/compose/animation/core/Animatable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/Animatable<",
            "Ljava/lang/Float;",
            "Landroidx/compose/animation/core/AnimationVector1D;",
            ">;"
        }
    .end annotation
.end field

.field private final pressProgressAnimationSpec:Landroidx/compose/animation/core/SpringSpec;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/SpringSpec<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field private final pressedScale:F

.field private final scaleXAnimation:Landroidx/compose/animation/core/Animatable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/Animatable<",
            "Ljava/lang/Float;",
            "Landroidx/compose/animation/core/AnimationVector1D;",
            ">;"
        }
    .end annotation
.end field

.field private final scaleXAnimationSpec:Landroidx/compose/animation/core/SpringSpec;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/SpringSpec<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field private final scaleYAnimation:Landroidx/compose/animation/core/Animatable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/Animatable<",
            "Ljava/lang/Float;",
            "Landroidx/compose/animation/core/AnimationVector1D;",
            ">;"
        }
    .end annotation
.end field

.field private final scaleYAnimationSpec:Landroidx/compose/animation/core/SpringSpec;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/SpringSpec<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field private final valueAnimation:Landroidx/compose/animation/core/Animatable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/Animatable<",
            "Ljava/lang/Float;",
            "Landroidx/compose/animation/core/AnimationVector1D;",
            ">;"
        }
    .end annotation
.end field

.field private final valueAnimationSpec:Landroidx/compose/animation/core/SpringSpec;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/SpringSpec<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field private final valueRange:Ldev/nino/squareglass/material/FloatBounds;

.field private final velocityAnimation:Landroidx/compose/animation/core/Animatable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/Animatable<",
            "Ljava/lang/Float;",
            "Landroidx/compose/animation/core/AnimationVector1D;",
            ">;"
        }
    .end annotation
.end field

.field private final velocityAnimationSpec:Landroidx/compose/animation/core/SpringSpec;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/SpringSpec<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field private final velocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker;

.field private final visibilityThreshold:F


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Lkotlinx/coroutines/CoroutineScope;FLdev/nino/squareglass/material/FloatBounds;FFFLam0/p;Lam0/l;Lam0/l;Lkotlin/jvm/functions/Function3;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "F",
            "Ldev/nino/squareglass/material/FloatBounds;",
            "FFF",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "-",
            "Landroidx/compose/ui/geometry/Offset;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Lkotlin/u;",
            ">;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "-",
            "Landroidx/compose/ui/unit/IntSize;",
            "-",
            "Landroidx/compose/ui/geometry/Offset;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "animationScope"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "valueRange"

    invoke-static {p3, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDragStarted"

    invoke-static {p7, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDragStopped"

    invoke-static {p8, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDragCancelled"

    invoke-static {p9, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDrag"

    invoke-static {p10, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->animationScope:Lkotlinx/coroutines/CoroutineScope;

    .line 34
    iput p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->initialValue:F

    .line 35
    iput-object p3, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    .line 36
    iput p4, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->visibilityThreshold:F

    .line 37
    iput p5, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->initialScale:F

    .line 38
    iput p6, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->pressedScale:F

    .line 39
    iput-object p7, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->onDragStarted:Lam0/p;

    .line 40
    iput-object p8, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->onDragStopped:Lam0/l;

    .line 41
    iput-object p9, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->onDragCancelled:Lam0/l;

    .line 42
    iput-object p10, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->onDrag:Lkotlin/jvm/functions/Function3;

    .line 46
    invoke-static {p4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/high16 p3, 0x3f800000    # 1.0f

    const/high16 p6, 0x447a0000    # 1000.0f

    invoke-static {p3, p6, p1}, Landroidx/compose/animation/core/AnimationSpecKt;->spring(FFLjava/lang/Object;)Landroidx/compose/animation/core/SpringSpec;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    const/high16 p1, 0x41200000    # 10.0f

    mul-float/2addr p1, p4

    .line 48
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/high16 p7, 0x3f000000    # 0.5f

    const/high16 p8, 0x43960000    # 300.0f

    invoke-static {p7, p8, p1}, Landroidx/compose/animation/core/AnimationSpecKt;->spring(FFLjava/lang/Object;)Landroidx/compose/animation/core/SpringSpec;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    const p1, 0x3a83126f    # 0.001f

    .line 50
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p7

    invoke-static {p3, p6, p7}, Landroidx/compose/animation/core/AnimationSpecKt;->spring(FFLjava/lang/Object;)Landroidx/compose/animation/core/SpringSpec;

    move-result-object p3

    iput-object p3, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->pressProgressAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    const p3, 0x3f19999a    # 0.6f

    const/high16 p6, 0x437a0000    # 250.0f

    .line 52
    invoke-static {p3, p6, p7}, Landroidx/compose/animation/core/AnimationSpecKt;->spring(FFLjava/lang/Object;)Landroidx/compose/animation/core/SpringSpec;

    move-result-object p3

    iput-object p3, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleXAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    const p3, 0x3f333333    # 0.7f

    .line 54
    invoke-static {p3, p6, p7}, Landroidx/compose/animation/core/AnimationSpecKt;->spring(FFLjava/lang/Object;)Landroidx/compose/animation/core/SpringSpec;

    move-result-object p3

    iput-object p3, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleYAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    .line 57
    invoke-static {p2, p4}, Landroidx/compose/animation/core/AnimatableKt;->Animatable(FF)Landroidx/compose/animation/core/Animatable;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueAnimation:Landroidx/compose/animation/core/Animatable;

    const/high16 p2, 0x40a00000    # 5.0f

    const/4 p3, 0x0

    .line 59
    invoke-static {p3, p2}, Landroidx/compose/animation/core/AnimatableKt;->Animatable(FF)Landroidx/compose/animation/core/Animatable;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityAnimation:Landroidx/compose/animation/core/Animatable;

    .line 61
    invoke-static {p3, p1}, Landroidx/compose/animation/core/AnimatableKt;->Animatable(FF)Landroidx/compose/animation/core/Animatable;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->pressProgressAnimation:Landroidx/compose/animation/core/Animatable;

    .line 63
    invoke-static {p5, p1}, Landroidx/compose/animation/core/AnimatableKt;->Animatable(FF)Landroidx/compose/animation/core/Animatable;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleXAnimation:Landroidx/compose/animation/core/Animatable;

    .line 65
    invoke-static {p5, p1}, Landroidx/compose/animation/core/AnimatableKt;->Animatable(FF)Landroidx/compose/animation/core/Animatable;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleYAnimation:Landroidx/compose/animation/core/Animatable;

    .line 67
    new-instance p1, Landroidx/compose/foundation/MutatorMutex;

    invoke-direct {p1}, Landroidx/compose/foundation/MutatorMutex;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->mutatorMutex:Landroidx/compose/foundation/MutatorMutex;

    .line 69
    new-instance p1, Landroidx/compose/ui/input/pointer/util/VelocityTracker;

    invoke-direct {p1}, Landroidx/compose/ui/input/pointer/util/VelocityTracker;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker;

    .line 79
    sget-object p1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast p1, Landroidx/compose/ui/Modifier;

    sget-object p2, Lkotlin/u;->a:Lkotlin/u;

    new-instance p3, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;

    invoke-direct {p3, p0}, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;)V

    check-cast p3, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    invoke-static {p1, p2, p3}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Landroidx/compose/ui/Modifier;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->modifier:Landroidx/compose/ui/Modifier;

    return-void
.end method

.method public static final synthetic access$getMutatorMutex$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/foundation/MutatorMutex;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->mutatorMutex:Landroidx/compose/foundation/MutatorMutex;

    return-object p0
.end method

.method public static final synthetic access$getPressProgressAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->pressProgressAnimation:Landroidx/compose/animation/core/Animatable;

    return-object p0
.end method

.method public static final synthetic access$getPressProgressAnimationSpec$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/SpringSpec;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->pressProgressAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    return-object p0
.end method

.method public static final synthetic access$getScaleXAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleXAnimation:Landroidx/compose/animation/core/Animatable;

    return-object p0
.end method

.method public static final synthetic access$getScaleXAnimationSpec$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/SpringSpec;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleXAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    return-object p0
.end method

.method public static final synthetic access$getScaleYAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleYAnimation:Landroidx/compose/animation/core/Animatable;

    return-object p0
.end method

.method public static final synthetic access$getScaleYAnimationSpec$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/SpringSpec;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleYAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    return-object p0
.end method

.method public static final synthetic access$getValueAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueAnimation:Landroidx/compose/animation/core/Animatable;

    return-object p0
.end method

.method public static final synthetic access$getValueAnimationSpec$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/SpringSpec;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    return-object p0
.end method

.method public static final synthetic access$getVelocityAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityAnimation:Landroidx/compose/animation/core/Animatable;

    return-object p0
.end method

.method public static final synthetic access$getVelocityAnimationSpec$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/SpringSpec;
    .locals 0

    .line 32
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    return-object p0
.end method

.method public static final synthetic access$updateVelocity(Ldev/nino/squareglass/material/DampedDragAnimation;)V
    .locals 0

    .line 32
    invoke-direct {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->updateVelocity()V

    return-void
.end method

.method private final updateVelocity()V
    .locals 9

    .line 156
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker;

    .line 157
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    .line 158
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValue()F

    move-result v3

    .line 166
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v3

    int-to-long v3, v3

    const/4 v5, 0x0

    .line 167
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v5

    int-to-long v5, v5

    const/16 v7, 0x20

    shl-long/2addr v3, v7

    const-wide v7, 0xffffffffL

    and-long/2addr v5, v7

    or-long/2addr v3, v5

    .line 165
    invoke-static {v3, v4}, Landroidx/compose/ui/geometry/Offset;->constructor-impl(J)J

    move-result-wide v3

    .line 156
    invoke-virtual {v0, v1, v2, v3, v4}, Landroidx/compose/ui/input/pointer/util/VelocityTracker;->addPosition-Uv8p0NA(JJ)V

    .line 160
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker;

    invoke-virtual {v0}, Landroidx/compose/ui/input/pointer/util/VelocityTracker;->calculateVelocity-9UxMQ8M()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/unit/Velocity;->getX-impl(J)F

    move-result v0

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    invoke-virtual {v1}, Ldev/nino/squareglass/material/FloatBounds;->getEndInclusive()F

    move-result v1

    iget-object v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    invoke-virtual {v2}, Ldev/nino/squareglass/material/FloatBounds;->getStart()F

    move-result v2

    sub-float/2addr v1, v2

    div-float/2addr v0, v1

    .line 161
    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->animationScope:Lkotlinx/coroutines/CoroutineScope;

    new-instance v2, Ldev/nino/squareglass/material/DampedDragAnimation$updateVelocity$1;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v0, v3}, Ldev/nino/squareglass/material/DampedDragAnimation$updateVelocity$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V

    move-object v4, v2

    check-cast v4, Lam0/p;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    return-void
.end method


# virtual methods
.method public final animateToValue(F)V
    .locals 6

    .line 136
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->animationScope:Lkotlinx/coroutines/CoroutineScope;

    new-instance v1, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;

    const/4 v2, 0x0

    invoke-direct {v1, p0, p1, v2}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V

    move-object v3, v1

    check-cast v3, Lam0/p;

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x0

    invoke-static/range {v0 .. v5}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    return-void
.end method

.method public final getInitialScale()F
    .locals 0

    .line 37
    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->initialScale:F

    return p0
.end method

.method public final getInitialValue()F
    .locals 0

    .line 34
    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->initialValue:F

    return p0
.end method

.method public final getModifier()Landroidx/compose/ui/Modifier;
    .locals 0

    .line 79
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->modifier:Landroidx/compose/ui/Modifier;

    return-object p0
.end method

.method public final getOnDrag()Lkotlin/jvm/functions/Function3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function3<",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Landroidx/compose/ui/unit/IntSize;",
            "Landroidx/compose/ui/geometry/Offset;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 42
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->onDrag:Lkotlin/jvm/functions/Function3;

    return-object p0
.end method

.method public final getOnDragCancelled()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 41
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->onDragCancelled:Lam0/l;

    return-object p0
.end method

.method public final getOnDragStarted()Lam0/p;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Landroidx/compose/ui/geometry/Offset;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 39
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->onDragStarted:Lam0/p;

    return-object p0
.end method

.method public final getOnDragStopped()Lam0/l;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 40
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->onDragStopped:Lam0/l;

    return-object p0
.end method

.method public final getPressProgress()F
    .locals 1

    .line 74
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->pressProgressAnimation:Landroidx/compose/animation/core/Animatable;

    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final getPressedScale()F
    .locals 0

    .line 38
    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->pressedScale:F

    return p0
.end method

.method public final getProgress()F
    .locals 2

    .line 72
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValue()F

    move-result v0

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    invoke-virtual {v1}, Ldev/nino/squareglass/material/FloatBounds;->getStart()F

    move-result v1

    sub-float/2addr v0, v1

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    invoke-virtual {v1}, Ldev/nino/squareglass/material/FloatBounds;->getEndInclusive()F

    move-result v1

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    invoke-virtual {p0}, Ldev/nino/squareglass/material/FloatBounds;->getStart()F

    move-result p0

    sub-float/2addr v1, p0

    div-float/2addr v0, v1

    return v0
.end method

.method public final getScaleX()F
    .locals 1

    .line 75
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleXAnimation:Landroidx/compose/animation/core/Animatable;

    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0

    :cond_0
    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->initialScale:F

    return p0
.end method

.method public final getScaleY()F
    .locals 1

    .line 76
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->scaleYAnimation:Landroidx/compose/animation/core/Animatable;

    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0

    :cond_0
    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->initialScale:F

    return p0
.end method

.method public final getTargetValue()F
    .locals 0

    .line 73
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueAnimation:Landroidx/compose/animation/core/Animatable;

    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getTargetValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0
.end method

.method public final getValue()F
    .locals 0

    .line 71
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueAnimation:Landroidx/compose/animation/core/Animatable;

    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0
.end method

.method public final getValueRange()Ldev/nino/squareglass/material/FloatBounds;
    .locals 0

    .line 35
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    return-object p0
.end method

.method public final getVelocity()F
    .locals 1

    .line 77
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityAnimation:Landroidx/compose/animation/core/Animatable;

    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final getVisibilityThreshold()F
    .locals 0

    .line 36
    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->visibilityThreshold:F

    return p0
.end method

.method public final press()V
    .locals 7

    .line 101
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 102
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->velocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker;

    invoke-virtual {v0}, Landroidx/compose/ui/input/pointer/util/VelocityTracker;->resetTracking()V

    .line 103
    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->animationScope:Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Ldev/nino/squareglass/material/DampedDragAnimation$press$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V

    move-object v4, v0

    check-cast v4, Lam0/p;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    return-void
.end method

.method public final release()V
    .locals 7

    .line 111
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 112
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->animationScope:Lkotlinx/coroutines/CoroutineScope;

    new-instance v0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V

    move-object v4, v0

    check-cast v4, Lam0/p;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    return-void
.end method

.method public final updateValue(F)V
    .locals 6

    .line 127
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    invoke-virtual {v0}, Ldev/nino/squareglass/material/FloatBounds;->getStart()F

    move-result v0

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->valueRange:Ldev/nino/squareglass/material/FloatBounds;

    invoke-virtual {v1}, Ldev/nino/squareglass/material/FloatBounds;->getEndInclusive()F

    move-result v1

    invoke-static {p1, v0, v1}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result p1

    .line 128
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation;->animationScope:Lkotlinx/coroutines/CoroutineScope;

    new-instance v1, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;

    const/4 v2, 0x0

    invoke-direct {v1, p0, p1, v2}, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V

    move-object v3, v1

    check-cast v3, Lam0/p;

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x0

    invoke-static/range {v0 .. v5}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    return-void
.end method
