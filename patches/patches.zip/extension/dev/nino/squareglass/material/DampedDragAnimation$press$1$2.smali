.class final Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "DampedDragAnimation.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/material/DampedDragAnimation$press$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field label:I

.field final synthetic this$0:Ldev/nino/squareglass/material/DampedDragAnimation;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance p1, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-direct {p1, p0, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V

    check-cast p1, Lkotlin/coroutines/e;

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 105
    iget v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->label:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getScaleXAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;

    move-result-object v3

    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->getPressedScale()F

    move-result p1

    invoke-static {p1}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v4

    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getScaleXAnimationSpec$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/SpringSpec;

    move-result-object p1

    move-object v5, p1

    check-cast v5, Landroidx/compose/animation/core/AnimationSpec;

    move-object v8, p0

    check-cast v8, Lkotlin/coroutines/e;

    iput v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$press$1$2;->label:I

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/16 v9, 0xc

    const/4 v10, 0x0

    invoke-static/range {v3 .. v10}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Ljava/lang/Object;Lam0/l;Lkotlin/coroutines/e;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_2

    return-object v0

    :cond_2
    :goto_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
