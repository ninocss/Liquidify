.class final Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "DampedDragAnimation.kt"

# interfaces
.implements Lam0/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function1<",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"
    }
    d2 = {
        "<anonymous>",
        ""
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $$this$launch:Lkotlinx/coroutines/CoroutineScope;

.field final synthetic $value:F

.field label:I

.field final synthetic this$0:Ldev/nino/squareglass/material/DampedDragAnimation;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "F",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iput p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->$value:F

    iput-object p3, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->$$this$launch:Lkotlinx/coroutines/CoroutineScope;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iget v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->$value:F

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->$$this$launch:Lkotlinx/coroutines/CoroutineScope;

    invoke-direct {v0, v1, v2, p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)V

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->invoke(Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->create(Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 137
    iget v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->label:I

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v1, :cond_5

    if-eq v1, v6, :cond_4

    if-eq v1, v5, :cond_3

    if-eq v1, v4, :cond_2

    if-eq v1, v3, :cond_1

    if-ne v1, v2, :cond_0

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto/16 :goto_5

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto/16 :goto_3

    :cond_2
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto/16 :goto_2

    :cond_3
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_1

    :cond_4
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_0

    :cond_5
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 138
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p1

    .line 144
    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    if-nez p1, :cond_b

    .line 139
    invoke-static {v1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getValueAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;

    move-result-object p1

    iget v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->$value:F

    iget-object v8, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {v8}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValueRange()Ldev/nino/squareglass/material/FloatBounds;

    move-result-object v8

    invoke-virtual {v8}, Ldev/nino/squareglass/material/FloatBounds;->getStart()F

    move-result v8

    iget-object v9, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {v9}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValueRange()Ldev/nino/squareglass/material/FloatBounds;

    move-result-object v9

    invoke-virtual {v9}, Ldev/nino/squareglass/material/FloatBounds;->getEndInclusive()F

    move-result v9

    invoke-static {v1, v8, v9}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v1

    move-object v8, p0

    check-cast v8, Lkotlin/coroutines/e;

    iput v6, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->label:I

    invoke-virtual {p1, v1, v8}, Landroidx/compose/animation/core/Animatable;->snapTo(Ljava/lang/Object;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_6

    goto :goto_4

    .line 140
    :cond_6
    :goto_0
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getPressProgressAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;

    move-result-object p1

    invoke-static {v7}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v1

    move-object v6, p0

    check-cast v6, Lkotlin/coroutines/e;

    iput v5, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->label:I

    invoke-virtual {p1, v1, v6}, Landroidx/compose/animation/core/Animatable;->snapTo(Ljava/lang/Object;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_7

    goto :goto_4

    :cond_7
    :goto_1
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getScaleXAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;

    move-result-object p1

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {v1}, Ldev/nino/squareglass/material/DampedDragAnimation;->getInitialScale()F

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v1

    move-object v5, p0

    check-cast v5, Lkotlin/coroutines/e;

    iput v4, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->label:I

    invoke-virtual {p1, v1, v5}, Landroidx/compose/animation/core/Animatable;->snapTo(Ljava/lang/Object;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_8

    goto :goto_4

    :cond_8
    :goto_2
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getScaleYAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;

    move-result-object p1

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {v1}, Ldev/nino/squareglass/material/DampedDragAnimation;->getInitialScale()F

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v1

    move-object v4, p0

    check-cast v4, Lkotlin/coroutines/e;

    iput v3, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->label:I

    invoke-virtual {p1, v1, v4}, Landroidx/compose/animation/core/Animatable;->snapTo(Ljava/lang/Object;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_9

    goto :goto_4

    .line 141
    :cond_9
    :goto_3
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getVelocityAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;

    move-result-object p1

    invoke-static {v7}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v1

    move-object v3, p0

    check-cast v3, Lkotlin/coroutines/e;

    iput v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->label:I

    invoke-virtual {p1, v1, v3}, Landroidx/compose/animation/core/Animatable;->snapTo(Ljava/lang/Object;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_a

    :goto_4
    return-object v0

    .line 142
    :cond_a
    :goto_5
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0

    .line 144
    :cond_b
    invoke-virtual {v1}, Ldev/nino/squareglass/material/DampedDragAnimation;->press()V

    .line 145
    iget p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->$value:F

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {v0}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValueRange()Ldev/nino/squareglass/material/FloatBounds;

    move-result-object v0

    invoke-virtual {v0}, Ldev/nino/squareglass/material/FloatBounds;->getStart()F

    move-result v0

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {v1}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValueRange()Ldev/nino/squareglass/material/FloatBounds;

    move-result-object v1

    invoke-virtual {v1}, Ldev/nino/squareglass/material/FloatBounds;->getEndInclusive()F

    move-result v1

    invoke-static {p1, v0, v1}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result p1

    .line 146
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->$$this$launch:Lkotlinx/coroutines/CoroutineScope;

    new-instance v1, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1$1;

    iget-object v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    const/4 v6, 0x0

    invoke-direct {v1, v2, p1, v6}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V

    move-object v3, v1

    check-cast v3, Lam0/p;

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static/range {v0 .. v5}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 147
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->getVelocity()F

    move-result p1

    cmpg-float p1, p1, v7

    if-nez p1, :cond_c

    goto :goto_6

    .line 148
    :cond_c
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->$$this$launch:Lkotlinx/coroutines/CoroutineScope;

    new-instance p1, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1$2;

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-direct {p1, v1, v6}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1$2;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V

    move-object v3, p1

    check-cast v3, Lam0/p;

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static/range {v0 .. v5}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 150
    :goto_6
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->release()V

    .line 151
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
