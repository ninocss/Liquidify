.class public final synthetic Ldev/nino/squareglass/material/DampedDragAnimation$release$1$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/DampedDragAnimation;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$0;->f$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$0;->f$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p0}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->invokeSuspend$lambda$0(Ldev/nino/squareglass/material/DampedDragAnimation;)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    return-object p0
.end method
