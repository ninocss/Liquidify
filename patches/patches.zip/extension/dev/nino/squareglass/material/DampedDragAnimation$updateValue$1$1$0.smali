.class public final synthetic Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1$1$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/DampedDragAnimation;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1$1$0;->f$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1$1$0;->f$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    check-cast p1, Landroidx/compose/animation/core/Animatable;

    invoke-static {p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1$1;->invokeSuspend$lambda$0(Ldev/nino/squareglass/material/DampedDragAnimation;Landroidx/compose/animation/core/Animatable;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
