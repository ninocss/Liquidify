.class final Ldev/nino/squareglass/material/DampedDragAnimation$release$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "DampedDragAnimation.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/material/DampedDragAnimation;->release()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDampedDragAnimation.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DampedDragAnimation.kt\ndev/nino/squareglass/material/DampedDragAnimation$release$1\n+ 2 Transform.kt\nkotlinx/coroutines/flow/FlowKt__TransformKt\n+ 3 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n+ 4 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt\n*L\n1#1,164:1\n17#2:165\n19#2:169\n46#3:166\n51#3:168\n105#4:167\n*S KotlinDebug\n*F\n+ 1 DampedDragAnimation.kt\ndev/nino/squareglass/material/DampedDragAnimation$release$1\n*L\n117#1:165\n117#1:169\n117#1:166\n117#1:168\n117#1:167\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field F$0:F

.field private synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Ldev/nino/squareglass/material/DampedDragAnimation;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation$release$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method

.method static final invokeSuspend$lambda$0(Ldev/nino/squareglass/material/DampedDragAnimation;)F
    .locals 0

    .line 116
    invoke-static {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getValueAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;

    move-result-object p0

    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-direct {v0, p0, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V

    iput-object p1, v0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->L$0:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 112
    iget v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->label:I

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v2, :cond_2

    if-eq v2, v4, :cond_1

    if-ne v2, v3, :cond_0

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_2

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_0

    :cond_2
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 113
    move-object p1, p0

    check-cast p1, Lkotlin/coroutines/e;

    iput-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->L$0:Ljava/lang/Object;

    iput v4, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->label:I

    invoke-static {p1}, Ldev/nino/squareglass/material/CoroutinesKt;->awaitFrame(Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3

    goto :goto_1

    .line 114
    :cond_3
    :goto_0
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValue()F

    move-result p1

    iget-object v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {v2}, Ldev/nino/squareglass/material/DampedDragAnimation;->getTargetValue()F

    move-result v2

    cmpg-float p1, p1, v2

    if-nez p1, :cond_4

    goto :goto_2

    .line 115
    :cond_4
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValueRange()Ldev/nino/squareglass/material/FloatBounds;

    move-result-object p1

    invoke-virtual {p1}, Ldev/nino/squareglass/material/FloatBounds;->getEndInclusive()F

    move-result p1

    iget-object v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-virtual {v2}, Ldev/nino/squareglass/material/DampedDragAnimation;->getValueRange()Ldev/nino/squareglass/material/FloatBounds;

    move-result-object v2

    invoke-virtual {v2}, Ldev/nino/squareglass/material/FloatBounds;->getStart()F

    move-result v2

    sub-float/2addr p1, v2

    const v2, 0x3ccccccd    # 0.025f

    mul-float/2addr p1, v2

    .line 116
    iget-object v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    new-instance v4, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$0;

    invoke-direct {v4, v2}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$0;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;)V

    invoke-static {v4}, Landroidx/compose/runtime/SnapshotStateKt;->snapshotFlow(Lam0/a;)Lkotlinx/coroutines/flow/Flow;

    move-result-object v2

    iget-object v4, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    .line 167
    new-instance v5, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$invokeSuspend$$inlined$filter$1;

    invoke-direct {v5, v2, v4, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$invokeSuspend$$inlined$filter$1;-><init>(Lkotlinx/coroutines/flow/Flow;Ldev/nino/squareglass/material/DampedDragAnimation;F)V

    check-cast v5, Lkotlinx/coroutines/flow/Flow;

    .line 169
    move-object v2, p0

    check-cast v2, Lkotlin/coroutines/e;

    .line 118
    iput-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->L$0:Ljava/lang/Object;

    iput p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->F$0:F

    iput v3, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->label:I

    invoke-static {v5, v2}, Lkotlinx/coroutines/flow/FlowKt;->first(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_5

    :goto_1
    return-object v0

    .line 120
    :cond_5
    :goto_2
    new-instance p1, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$3;

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    const/4 v7, 0x0

    invoke-direct {p1, v0, v7}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$3;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V

    move-object v4, p1

    check-cast v4, Lam0/p;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 121
    new-instance p1, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$4;

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-direct {p1, v0, v7}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$4;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V

    move-object v4, p1

    check-cast v4, Lam0/p;

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 122
    new-instance p1, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$5;

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$release$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-direct {p1, p0, v7}, Ldev/nino/squareglass/material/DampedDragAnimation$release$1$5;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Lkotlin/coroutines/e;)V

    move-object v4, p1

    check-cast v4, Lam0/p;

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 123
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
