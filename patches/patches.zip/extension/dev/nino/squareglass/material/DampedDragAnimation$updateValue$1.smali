.class final Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "DampedDragAnimation.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/material/DampedDragAnimation;->updateValue(F)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $targetValue:F

.field private synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Ldev/nino/squareglass/material/DampedDragAnimation;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "F",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iput p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->$targetValue:F

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->$targetValue:F

    invoke-direct {v0, v1, p0, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V

    iput-object p1, v0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->L$0:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 128
    iget v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->label:I

    const/4 v3, 0x1

    if-eqz v2, :cond_1

    if-ne v2, v3, :cond_0

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 129
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p1

    if-eqz p1, :cond_2

    .line 130
    new-instance p1, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1$1;

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->$targetValue:F

    const/4 v2, 0x0

    invoke-direct {p1, v0, p0, v2}, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V

    move-object v4, p1

    check-cast v4, Lam0/p;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    goto :goto_0

    .line 131
    :cond_2
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getValueAnimation$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/animation/core/Animatable;

    move-result-object p1

    iget v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->$targetValue:F

    invoke-static {v2}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v2

    move-object v4, p0

    check-cast v4, Lkotlin/coroutines/e;

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->L$0:Ljava/lang/Object;

    iput v3, p0, Ldev/nino/squareglass/material/DampedDragAnimation$updateValue$1;->label:I

    invoke-virtual {p1, v2, v4}, Landroidx/compose/animation/core/Animatable;->snapTo(Ljava/lang/Object;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_3

    return-object v0

    .line 132
    :cond_3
    :goto_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
