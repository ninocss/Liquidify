.class final Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;
.super Ljava/lang/Object;
.source "DampedDragAnimation.kt"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/material/DampedDragAnimation;-><init>(Lkotlinx/coroutines/CoroutineScope;FLdev/nino/squareglass/material/FloatBounds;FFFLam0/p;Lam0/l;Lam0/l;Lkotlin/jvm/functions/Function3;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Ldev/nino/squareglass/material/DampedDragAnimation;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;)V
    .locals 0

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static final invoke$lambda$0(Ldev/nino/squareglass/material/DampedDragAnimation;Landroidx/compose/ui/input/pointer/PointerInputChange;)Lkotlin/u;
    .locals 3

    const-string v0, "down"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->getOnDragStarted()Lam0/p;

    move-result-object v0

    invoke-virtual {p1}, Landroidx/compose/ui/input/pointer/PointerInputChange;->getPosition-F1C5BW0()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/compose/ui/geometry/Offset;->box-impl(J)Landroidx/compose/ui/geometry/Offset;

    move-result-object p1

    invoke-interface {v0, p0, p1}, Lam0/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->press()V

    .line 84
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final invoke$lambda$1(Ldev/nino/squareglass/material/DampedDragAnimation;Landroidx/compose/ui/input/pointer/PointerInputChange;)Lkotlin/u;
    .locals 1

    const-string v0, "it"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->getOnDragStopped()Lam0/l;

    move-result-object p1

    invoke-interface {p1, p0}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->release()V

    .line 88
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final invoke$lambda$2(Ldev/nino/squareglass/material/DampedDragAnimation;)Lkotlin/u;
    .locals 1

    .line 92
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->getOnDragCancelled()Lam0/l;

    move-result-object v0

    invoke-interface {v0, p0}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->release()V

    .line 94
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method static final invoke$lambda$3(Ldev/nino/squareglass/material/DampedDragAnimation;Landroidx/compose/ui/input/pointer/PointerInputScope;Landroidx/compose/ui/input/pointer/PointerInputChange;Landroidx/compose/ui/geometry/Offset;)Lkotlin/u;
    .locals 2

    const-string v0, "change"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    invoke-virtual {p0}, Ldev/nino/squareglass/material/DampedDragAnimation;->getOnDrag()Lkotlin/jvm/functions/Function3;

    move-result-object p2

    invoke-interface {p1}, Landroidx/compose/ui/input/pointer/PointerInputScope;->getSize-YbymL2g()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/unit/IntSize;->box-impl(J)Landroidx/compose/ui/unit/IntSize;

    move-result-object p1

    invoke-interface {p2, p0, p1, p3}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final invoke(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/input/pointer/PointerInputScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 80
    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    new-instance v2, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$0;

    invoke-direct {v2, v0}, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$0;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;)V

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    new-instance v3, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$1;

    invoke-direct {v3, v0}, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;)V

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    new-instance v4, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$2;

    invoke-direct {v4, v0}, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$2;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;)V

    iget-object p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    new-instance v5, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$3;

    invoke-direct {v5, p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$modifier$1$3;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;Landroidx/compose/ui/input/pointer/PointerInputScope;)V

    move-object v1, p1

    move-object v6, p2

    invoke-static/range {v1 .. v6}, Ldev/nino/squareglass/material/DragGestureInspectorKt;->inspectDragGestures(Landroidx/compose/ui/input/pointer/PointerInputScope;Lam0/l;Lam0/l;Lam0/a;Lam0/p;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object p1

    if-ne p0, p1, :cond_0

    return-object p0

    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
