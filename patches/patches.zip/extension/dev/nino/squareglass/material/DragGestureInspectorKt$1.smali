.class public final synthetic Ldev/nino/squareglass/material/DragGestureInspectorKt$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Landroidx/compose/ui/input/pointer/PointerInputChange;

    invoke-static {p1}, Ldev/nino/squareglass/material/DragGestureInspectorKt;->inspectDragGestures$lambda$1(Landroidx/compose/ui/input/pointer/PointerInputChange;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
