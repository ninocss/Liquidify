.class final Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "DampedDragAnimation.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/material/DampedDragAnimation;->animateToValue(F)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $value:F

.field private synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Ldev/nino/squareglass/material/DampedDragAnimation;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/nino/squareglass/material/DampedDragAnimation;",
            "F",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iput p2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->$value:F

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;

    iget-object v1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iget p0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->$value:F

    invoke-direct {v0, v1, p0, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlin/coroutines/e;)V

    iput-object p1, v0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    iget-object v0, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlinx/coroutines/CoroutineScope;

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 136
    iget v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->label:I

    const/4 v3, 0x1

    if-eqz v2, :cond_1

    if-ne v2, v3, :cond_0

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 137
    iget-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    invoke-static {p1}, Ldev/nino/squareglass/material/DampedDragAnimation;->access$getMutatorMutex$p(Ldev/nino/squareglass/material/DampedDragAnimation;)Landroidx/compose/foundation/MutatorMutex;

    move-result-object v4

    new-instance p1, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;

    iget-object v2, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->this$0:Ldev/nino/squareglass/material/DampedDragAnimation;

    iget v5, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->$value:F

    const/4 v6, 0x0

    invoke-direct {p1, v2, v5, v0, v6}, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1$1;-><init>(Ldev/nino/squareglass/material/DampedDragAnimation;FLkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)V

    move-object v6, p1

    check-cast v6, Lam0/l;

    move-object v7, p0

    check-cast v7, Lkotlin/coroutines/e;

    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->L$0:Ljava/lang/Object;

    iput v3, p0, Ldev/nino/squareglass/material/DampedDragAnimation$animateToValue$1;->label:I

    const/4 v5, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static/range {v4 .. v9}, Landroidx/compose/foundation/MutatorMutex;->mutate$default(Landroidx/compose/foundation/MutatorMutex;Landroidx/compose/foundation/MutatePriority;Lam0/l;Lkotlin/coroutines/e;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v1, :cond_2

    return-object v1

    .line 152
    :cond_2
    :goto_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
