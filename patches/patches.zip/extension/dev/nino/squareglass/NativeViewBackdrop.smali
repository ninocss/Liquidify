.class public final Ldev/nino/squareglass/NativeViewBackdrop;
.super Ljava/lang/Object;
.source "NativeViewBackdrop.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/Backdrop;
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/NativeViewBackdrop$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeViewBackdrop.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeViewBackdrop.kt\ndev/nino/squareglass/NativeViewBackdrop\n+ 2 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n+ 5 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 6 Offset.kt\nandroidx/compose/ui/geometry/Offset\n+ 7 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 8 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,186:1\n78#2:187\n111#2,2:188\n1807#3,3:190\n1642#3,10:213\n1915#3:223\n1916#3:225\n1652#3:226\n249#4,8:193\n257#4:207\n233#4:208\n259#4,4:209\n1#5:201\n1#5:224\n65#6:202\n69#6:205\n60#7:203\n70#7:206\n22#8:204\n*S KotlinDebug\n*F\n+ 1 NativeViewBackdrop.kt\ndev/nino/squareglass/NativeViewBackdrop\n*L\n36#1:187\n36#1:188,2\n118#1:190,3\n109#1:213,10\n109#1:223\n109#1:225\n109#1:226\n149#1:193,8\n149#1:207\n156#1:208\n149#1:209,4\n109#1:224\n154#1:202\n154#1:205\n154#1:203\n154#1:206\n154#1:204\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0007\u0008\u0007\u0018\u0000 82\u00020\u00012\u00020\u00022\u00020\u0003:\u00018B\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0006\u0010\"\u001a\u00020#J\u0006\u0010$\u001a\u00020#J\u0008\u0010%\u001a\u00020#H\u0002J\u0008\u0010&\u001a\u00020\u0011H\u0016J\u0010\u0010\'\u001a\u00020\u00112\u0006\u0010(\u001a\u00020\u0005H\u0002J9\u0010)\u001a\u00020#*\u00020*2\u0006\u0010+\u001a\u00020,2\u0008\u0010-\u001a\u0004\u0018\u00010.2\u0019\u0010/\u001a\u0015\u0012\u0004\u0012\u000201\u0012\u0004\u0012\u00020#\u0018\u000100\u00a2\u0006\u0002\u00082H\u0016J\u000e\u00103\u001a\u00020\u00112\u0006\u0010(\u001a\u00020\u0005J\u0006\u00104\u001a\u00020#J\u0010\u00105\u001a\u00020#2\u0006\u00106\u001a\u00020\u0005H\u0016J\u0010\u00107\u001a\u00020#2\u0006\u00106\u001a\u00020\u0005H\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R+\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0013\u001a\u00020\u00148F@BX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u001a\u0010\u001b\u001a\u0004\u0008\u0016\u0010\u0017\"\u0004\u0008\u0018\u0010\u0019R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u001e\u001a\u00020\u00118F\u00a2\u0006\u0006\u001a\u0004\u0008\u001f\u0010 R\u0014\u0010!\u001a\u00020\u0011X\u0096D\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008!\u0010 \u00a8\u00069"
    }
    d2 = {
        "Ldev/nino/squareglass/NativeViewBackdrop;",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "Landroid/view/ViewTreeObserver$OnPreDrawListener;",
        "Landroid/view/View$OnAttachStateChangeListener;",
        "source",
        "Landroid/view/View;",
        "<init>",
        "(Landroid/view/View;)V",
        "node",
        "Landroid/graphics/RenderNode;",
        "location",
        "",
        "inverse",
        "Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;",
        "capturePolicy",
        "Ldev/nino/squareglass/BackdropCapturePolicy;",
        "notifyNextCapture",
        "",
        "ready",
        "<set-?>",
        "",
        "handoverVersion",
        "getHandoverVersion",
        "()I",
        "setHandoverVersion",
        "(I)V",
        "handoverVersion$delegate",
        "Landroidx/compose/runtime/MutableIntState;",
        "resume",
        "Ljava/lang/Runnable;",
        "hasSample",
        "getHasSample",
        "()Z",
        "isCoordinatesDependent",
        "transition",
        "",
        "requestCapture",
        "retryNextFrame",
        "onPreDraw",
        "transitioning",
        "view",
        "drawBackdrop",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layerBlock",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "Lkotlin/ExtensionFunctionType;",
        "matches",
        "release",
        "onViewAttachedToWindow",
        "v",
        "onViewDetachedFromWindow",
        "Companion",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field private static final Companion:Ldev/nino/squareglass/NativeViewBackdrop$Companion;

.field private static final fragmentTransitionFields:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/reflect/Field;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final capturePolicy:Ldev/nino/squareglass/BackdropCapturePolicy;

.field private final handoverVersion$delegate:Landroidx/compose/runtime/MutableIntState;

.field private final inverse:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

.field private final isCoordinatesDependent:Z

.field private final location:[I

.field private final node:Landroid/graphics/RenderNode;

.field private notifyNextCapture:Z

.field private ready:Z

.field private final resume:Ljava/lang/Runnable;

.field private final source:Landroid/view/View;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    new-instance v0, Ldev/nino/squareglass/NativeViewBackdrop$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ldev/nino/squareglass/NativeViewBackdrop$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Ldev/nino/squareglass/NativeViewBackdrop;->Companion:Ldev/nino/squareglass/NativeViewBackdrop$Companion;

    const/16 v0, 0x8

    sput v0, Ldev/nino/squareglass/NativeViewBackdrop;->$stable:I

    .line 109
    const-string v0, "transitioningFragmentViews"

    const-string v2, "disappearingFragmentChildren"

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 213
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .line 223
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .line 222
    check-cast v3, Ljava/lang/String;

    .line 110
    :try_start_0
    const-class v4, Landroidx/fragment/app/FragmentContainerView;

    invoke-virtual {v4, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/reflect/Field;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-object v3, v1

    :goto_1
    if-eqz v3, :cond_0

    .line 222
    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 226
    :cond_1
    check-cast v2, Ljava/util/List;

    .line 109
    sput-object v2, Ldev/nino/squareglass/NativeViewBackdrop;->fragmentTransitionFields:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 2

    const-string v0, "source"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    .line 30
    new-instance v0, Landroid/graphics/RenderNode;

    const-string v1, "SquareGlass native TIDAL page"

    invoke-direct {v0, v1}, Landroid/graphics/RenderNode;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    const/4 v0, 0x2

    .line 31
    new-array v0, v0, [I

    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    .line 32
    new-instance v0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->inverse:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    .line 33
    new-instance v0, Ldev/nino/squareglass/BackdropCapturePolicy;

    invoke-direct {v0}, Ldev/nino/squareglass/BackdropCapturePolicy;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->capturePolicy:Ldev/nino/squareglass/BackdropCapturePolicy;

    const/4 v0, 0x1

    .line 34
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->notifyNextCapture:Z

    const/4 v1, 0x0

    .line 36
    invoke-static {v1}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->handoverVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    .line 38
    new-instance v1, Ldev/nino/squareglass/NativeViewBackdrop$0;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/NativeViewBackdrop$0;-><init>(Ldev/nino/squareglass/NativeViewBackdrop;)V

    iput-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    .line 40
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->isCoordinatesDependent:Z

    .line 61
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    move-object v1, p0

    check-cast v1, Landroid/view/ViewTreeObserver$OnPreDrawListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 62
    move-object v0, p0

    check-cast v0, Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {p1, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 63
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->requestCapture()V

    return-void
.end method

.method public static final synthetic access$getFragmentTransitionFields$cp()Ljava/util/List;
    .locals 1

    .line 28
    sget-object v0, Ldev/nino/squareglass/NativeViewBackdrop;->fragmentTransitionFields:Ljava/util/List;

    return-object v0
.end method

.method static final resume$lambda$0(Ldev/nino/squareglass/NativeViewBackdrop;)V
    .locals 0

    .line 38
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method private final retryNextFrame()V
    .locals 2

    .line 56
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 57
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    return-void
.end method

.method private final setHandoverVersion(I)V
    .locals 0

    .line 36
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->handoverVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    .line 188
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method private final transitioning(Landroid/view/View;)Z
    .locals 6

    .line 118
    instance-of v0, p1, Landroidx/fragment/app/FragmentContainerView;

    const/4 v1, 0x1

    if-eqz v0, :cond_3

    sget-object v2, Ldev/nino/squareglass/NativeViewBackdrop;->fragmentTransitionFields:Ljava/util/List;

    check-cast v2, Ljava/lang/Iterable;

    .line 190
    instance-of v3, v2, Ljava/util/Collection;

    if-eqz v3, :cond_0

    move-object v3, v2

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    goto :goto_1

    .line 191
    :cond_0
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/reflect/Field;

    .line 119
    invoke-virtual {v3, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Ljava/util/Collection;

    if-eqz v4, :cond_2

    check-cast v3, Ljava/util/Collection;

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    :goto_0
    if-eqz v3, :cond_1

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    xor-int/2addr v3, v1

    if-ne v3, v1, :cond_1

    return v1

    .line 121
    :cond_3
    :goto_1
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_4

    return v3

    .line 122
    :cond_4
    invoke-virtual {p1}, Landroid/view/View;->hasTransientState()Z

    move-result v2

    if-eqz v2, :cond_5

    return v1

    .line 123
    :cond_5
    invoke-virtual {p1}, Landroid/view/View;->getAnimation()Landroid/view/animation/Animation;

    move-result-object v2

    if-eqz v2, :cond_6

    .line 126
    invoke-virtual {v2}, Landroid/view/animation/Animation;->getRepeatCount()I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_6

    invoke-virtual {v2}, Landroid/view/animation/Animation;->hasEnded()Z

    move-result v2

    if-nez v2, :cond_6

    return v1

    .line 127
    :cond_6
    instance-of v2, p1, Landroid/view/ViewGroup;

    if-eqz v2, :cond_c

    .line 128
    check-cast p1, Landroid/view/ViewGroup;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getLayoutTransition()Landroid/animation/LayoutTransition;

    move-result-object v2

    if-eqz v2, :cond_7

    invoke-virtual {v2}, Landroid/animation/LayoutTransition;->isRunning()Z

    move-result v2

    if-ne v2, v1, :cond_7

    return v1

    :cond_7
    if-eqz v0, :cond_a

    .line 134
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    move v2, v3

    move v4, v2

    :goto_2
    if-ge v2, v0, :cond_9

    invoke-virtual {p1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v5

    if-nez v5, :cond_8

    add-int/lit8 v4, v4, 0x1

    :cond_8
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_9
    if-le v4, v1, :cond_a

    return v1

    .line 137
    :cond_a
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    move v2, v3

    :goto_3
    if-ge v2, v0, :cond_c

    invoke-virtual {p1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const-string v5, "getChildAt(...)"

    invoke-static {v4, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v4}, Ldev/nino/squareglass/NativeViewBackdrop;->transitioning(Landroid/view/View;)Z

    move-result v4

    if-eqz v4, :cond_b

    return v1

    :cond_b
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_c
    return v3
.end method


# virtual methods
.method public drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroidx/compose/ui/unit/Density;",
            "Landroidx/compose/ui/layout/LayoutCoordinates;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "density"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 145
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    if-eqz p3, :cond_4

    .line 146
    invoke-interface {p3}, Landroidx/compose/ui/layout/LayoutCoordinates;->isAttached()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->hasDisplayList()Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_0

    .line 147
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationInWindow([I)V

    .line 148
    :cond_1
    invoke-static {p3}, Landroidx/compose/ui/layout/LayoutCoordinatesKt;->positionInWindow(Landroidx/compose/ui/layout/LayoutCoordinates;)J

    move-result-wide v0

    .line 193
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p3

    .line 197
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getSize-NH-jbRc()J

    move-result-wide v2

    .line 198
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v4

    invoke-interface {v4}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 200
    :try_start_0
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v4

    if-eqz p4, :cond_2

    .line 151
    iget-object v5, p0, Ldev/nino/squareglass/NativeViewBackdrop;->inverse:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    invoke-virtual {v5}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->reset()V

    .line 152
    iget-object v5, p0, Ldev/nino/squareglass/NativeViewBackdrop;->inverse:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    invoke-virtual {v5, v4, p2, p4}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->inverseTransform(Landroidx/compose/ui/graphics/drawscope/DrawTransform;Landroidx/compose/ui/unit/Density;Lam0/l;)V

    .line 154
    :cond_2
    iget-object p2, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    const/4 p4, 0x0

    aget p2, p2, p4

    int-to-float p2, p2

    const/16 p4, 0x20

    shr-long v5, v0, p4

    long-to-int p4, v5

    .line 204
    invoke-static {p4}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p4

    sub-float/2addr p2, p4

    .line 154
    iget-object p4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    const/4 v5, 0x1

    aget p4, p4, v5

    int-to-float p4, p4

    const-wide v5, 0xffffffffL

    and-long/2addr v0, v5

    long-to-int v0, v0

    .line 204
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    sub-float/2addr p4, v0

    .line 154
    invoke-interface {v4, p2, p4}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 208
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p1

    .line 157
    invoke-static {p1}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object p2

    invoke-virtual {p2}, Landroid/graphics/Canvas;->isHardwareAccelerated()Z

    move-result p2

    if-eqz p2, :cond_3

    .line 158
    invoke-static {p1}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object p1

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p1, p0}, Landroid/graphics/Canvas;->drawRenderNode(Landroid/graphics/RenderNode;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 209
    :cond_3
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 210
    invoke-interface {p3, v2, v3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    return-void

    :catchall_0
    move-exception p0

    .line 209
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 210
    invoke-interface {p3, v2, v3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    throw p0

    :cond_4
    :goto_0
    return-void
.end method

.method public final getHandoverVersion()I
    .locals 0

    .line 36
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->handoverVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 187
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method public final getHasSample()Z
    .locals 0

    .line 39
    iget-boolean p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    return p0
.end method

.method public isCoordinatesDependent()Z
    .locals 0

    .line 40
    iget-boolean p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->isCoordinatesDependent:Z

    return p0
.end method

.method public final matches(Landroid/view/View;)Z
    .locals 1

    const-string v0, "view"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public onPreDraw()Z
    .locals 6

    .line 67
    sget v0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    .line 68
    const-string v0, "nav"

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const-string v0, "mini"

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 69
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->hasDisplayList()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->discardDisplayList()V

    .line 70
    :cond_0
    iget-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    if-eqz v0, :cond_1

    .line 71
    iput-boolean v2, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    .line 72
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    move-result v0

    add-int/2addr v0, v1

    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeViewBackdrop;->setHandoverVersion(I)V

    :cond_1
    return v1

    .line 80
    :cond_2
    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeBackdrop;->getActive()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v0

    if-ne v0, p0, :cond_7

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_7

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    if-lez v0, :cond_7

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    if-lez v0, :cond_7

    .line 81
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->capturePolicy:Ldev/nino/squareglass/BackdropCapturePolicy;

    iget-object v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-direct {p0, v3}, Ldev/nino/squareglass/NativeViewBackdrop;->transitioning(Landroid/view/View;)Z

    move-result v3

    invoke-virtual {v0, v3}, Ldev/nino/squareglass/BackdropCapturePolicy;->allowCapture(Z)Z

    move-result v0

    if-nez v0, :cond_3

    .line 82
    invoke-direct {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->retryNextFrame()V

    return v1

    .line 85
    :cond_3
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, v3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 86
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    iget-object v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v3

    iget-object v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v4

    invoke-virtual {v0, v2, v2, v3, v4}, Landroid/graphics/RenderNode;->setPosition(IIII)Z

    .line 87
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    iget-object v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v3

    iget-object v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v4

    invoke-virtual {v0, v3, v4}, Landroid/graphics/RenderNode;->beginRecording(II)Landroid/graphics/RecordingCanvas;

    move-result-object v0

    const-string v3, "beginRecording(...)"

    invoke-static {v0, v3}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    :try_start_0
    iget-object v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    check-cast v0, Landroid/graphics/Canvas;

    invoke-virtual {v3, v0}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->endRecording()V

    .line 89
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationInWindow([I)V

    .line 90
    iget-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    if-eqz v0, :cond_5

    iget-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->notifyNextCapture:Z

    if-eqz v0, :cond_4

    goto :goto_0

    :cond_4
    move v0, v2

    goto :goto_1

    :cond_5
    :goto_0
    move v0, v1

    .line 91
    :goto_1
    iput-boolean v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    .line 92
    iput-boolean v2, p0, Ldev/nino/squareglass/NativeViewBackdrop;->notifyNextCapture:Z

    if-eqz v0, :cond_6

    .line 94
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    move-result v0

    add-int/2addr v0, v1

    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeViewBackdrop;->setHandoverVersion(I)V

    .line 95
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryHandovers:I

    add-int/2addr p0, v1

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryHandovers:I

    .line 96
    sget-wide v2, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryFirstCaptureUptime:J

    const-wide/16 v4, 0x0

    cmp-long p0, v2, v4

    if-nez p0, :cond_6

    .line 97
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    sput-wide v2, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryFirstCaptureUptime:J

    .line 98
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryFirstCaptureTraversal:I

    .line 101
    :cond_6
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeCaptures:I

    add-int/2addr p0, v1

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeCaptures:I

    goto :goto_2

    :catchall_0
    move-exception v0

    .line 88
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p0}, Landroid/graphics/RenderNode;->endRecording()V

    throw v0

    :cond_7
    :goto_2
    return v1
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 1

    const-string v0, "v"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 175
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    move-object v0, p0

    check-cast v0, Landroid/view/ViewTreeObserver$OnPreDrawListener;

    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 176
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 177
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->capturePolicy:Ldev/nino/squareglass/BackdropCapturePolicy;

    invoke-virtual {p1}, Ldev/nino/squareglass/BackdropCapturePolicy;->transition()V

    .line 178
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->requestCapture()V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    const-string v0, "v"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 181
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    move-object v0, p0

    check-cast v0, Landroid/view/ViewTreeObserver$OnPreDrawListener;

    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 182
    :cond_0
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {p1, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final release()V
    .locals 2

    .line 167
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 168
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    move-object v1, p0

    check-cast v1, Landroid/view/ViewTreeObserver$OnPreDrawListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 169
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    move-object v1, p0

    check-cast v1, Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 170
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->discardDisplayList()V

    const/4 v0, 0x0

    .line 171
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    return-void
.end method

.method public final requestCapture()V
    .locals 2

    const/4 v0, 0x1

    .line 50
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->notifyNextCapture:Z

    .line 51
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 52
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final transition()V
    .locals 1

    .line 45
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->capturePolicy:Ldev/nino/squareglass/BackdropCapturePolicy;

    invoke-virtual {v0}, Ldev/nino/squareglass/BackdropCapturePolicy;->transition()V

    .line 46
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->requestCapture()V

    return-void
.end method
