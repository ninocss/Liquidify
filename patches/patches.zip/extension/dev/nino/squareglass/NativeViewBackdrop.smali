.class public final Ldev/nino/squareglass/NativeViewBackdrop;
.super Ljava/lang/Object;
.source "NativeViewBackdrop.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/Backdrop;
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeViewBackdrop.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeViewBackdrop.kt\ndev/nino/squareglass/NativeViewBackdrop\n+ 2 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n+ 5 Offset.kt\nandroidx/compose/ui/geometry/Offset\n+ 6 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 7 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,233:1\n78#2:234\n111#2,2:235\n1#3:237\n249#4,8:238\n257#4:251\n233#4:252\n259#4,4:253\n65#5:246\n69#5:249\n60#6:247\n70#6:250\n22#7:248\n*S KotlinDebug\n*F\n+ 1 NativeViewBackdrop.kt\ndev/nino/squareglass/NativeViewBackdrop\n*L\n44#1:234\n44#1:235,2\n194#1:238,8\n194#1:251\n201#1:252\n194#1:253,4\n199#1:246\n199#1:249\n199#1:247\n199#1:250\n199#1:248\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\t\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0006\u0008\u0007\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003B\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0006\u0010$\u001a\u00020%J\u0006\u0010&\u001a\u00020%J\u0008\u0010\'\u001a\u00020%H\u0002J\u0008\u0010(\u001a\u00020%H\u0002J\u0008\u0010)\u001a\u00020\u000fH\u0016J\u0010\u0010*\u001a\u00020\u000f2\u0006\u0010+\u001a\u00020\u0005H\u0002J9\u0010,\u001a\u00020%*\u00020-2\u0006\u0010.\u001a\u00020/2\u0008\u00100\u001a\u0004\u0018\u0001012\u0019\u00102\u001a\u0015\u0012\u0004\u0012\u000204\u0012\u0004\u0012\u00020%\u0018\u000103\u00a2\u0006\u0002\u00085H\u0016J\u000e\u00106\u001a\u00020\u000f2\u0006\u0010+\u001a\u00020\u0005J\u0006\u00107\u001a\u00020%J\u0010\u00108\u001a\u00020%2\u0006\u00109\u001a\u00020\u0005H\u0016J\u0010\u0010:\u001a\u00020%2\u0006\u00109\u001a\u00020\u0005H\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000R+\u0010\u0017\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00158F@BX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u001c\u0010\u001d\u001a\u0004\u0008\u0018\u0010\u0019\"\u0004\u0008\u001a\u0010\u001bR\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010 \u001a\u00020\u000f8F\u00a2\u0006\u0006\u001a\u0004\u0008!\u0010\"R\u0014\u0010#\u001a\u00020\u000fX\u0096D\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008#\u0010\"\u00a8\u0006;"
    }
    d2 = {
        "Ldev/nino/squareglass/NativeViewBackdrop;",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "Landroid/view/ViewTreeObserver$OnPreDrawListener;",
        "Landroid/view/View$OnAttachStateChangeListener;",
        "source",
        "Landroid/view/View;",
        "<init>",
        "(Landroid/view/View;)V",
        "node",
        "Landroid/graphics/RenderNode;",
        "location",
        "",
        "inverse",
        "Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;",
        "transitionPending",
        "",
        "notifyNextCapture",
        "ready",
        "frozen",
        "Landroid/graphics/Bitmap;",
        "frozenTop",
        "",
        "<set-?>",
        "handoverVersion",
        "getHandoverVersion",
        "()I",
        "setHandoverVersion",
        "(I)V",
        "handoverVersion$delegate",
        "Landroidx/compose/runtime/MutableIntState;",
        "resume",
        "Ljava/lang/Runnable;",
        "hasSample",
        "getHasSample",
        "()Z",
        "isCoordinatesDependent",
        "transition",
        "",
        "requestCapture",
        "retryNextFrame",
        "freeze",
        "onPreDraw",
        "transitioning",
        "view",
        "drawBackdrop",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layerBlock",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "Lkotlin/ExtensionFunctionType;",
        "matches",
        "release",
        "onViewAttachedToWindow",
        "v",
        "onViewDetachedFromWindow",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private frozen:Landroid/graphics/Bitmap;

.field private frozenTop:I

.field private final handoverVersion$delegate:Landroidx/compose/runtime/MutableIntState;

.field private final inverse:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

.field private final isCoordinatesDependent:Z

.field private final location:[I

.field private final node:Landroid/graphics/RenderNode;

.field private notifyNextCapture:Z

.field private ready:Z

.field private final resume:Ljava/lang/Runnable;

.field private final source:Landroid/view/View;

.field private transitionPending:Z


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 2

    const-string v0, "source"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    .line 36
    new-instance v0, Landroid/graphics/RenderNode;

    const-string v1, "SquareGlass native TIDAL page"

    invoke-direct {v0, v1}, Landroid/graphics/RenderNode;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    const/4 v0, 0x2

    .line 37
    new-array v0, v0, [I

    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    .line 38
    new-instance v0, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    invoke-direct {v0}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->inverse:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    const/4 v0, 0x1

    .line 40
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->notifyNextCapture:Z

    const/4 v1, 0x0

    .line 44
    invoke-static {v1}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->handoverVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    .line 46
    new-instance v1, Ldev/nino/squareglass/NativeViewBackdrop$0;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/NativeViewBackdrop$0;-><init>(Ldev/nino/squareglass/NativeViewBackdrop;)V

    iput-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    .line 48
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->isCoordinatesDependent:Z

    .line 114
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    move-object v1, p0

    check-cast v1, Landroid/view/ViewTreeObserver$OnPreDrawListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 115
    move-object v0, p0

    check-cast v0, Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {p1, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 116
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->requestCapture()V

    return-void
.end method

.method private final freeze()V
    .locals 12

    .line 74
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    .line 75
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    iget-object v2, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    const/high16 v3, 0x43960000    # 300.0f

    mul-float/2addr v3, v2

    float-to-int v2, v3

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    if-lez v1, :cond_b

    if-gtz v2, :cond_0

    goto/16 :goto_4

    .line 77
    :cond_0
    new-instance v7, Landroid/graphics/RenderNode;

    const-string v0, "SquareGlass stable accessory sample"

    invoke-direct {v7, v0}, Landroid/graphics/RenderNode;-><init>(Ljava/lang/String;)V

    .line 78
    new-instance v8, Landroid/graphics/HardwareRenderer;

    invoke-direct {v8}, Landroid/graphics/HardwareRenderer;-><init>()V

    const/4 v9, 0x0

    const/4 v10, 0x1

    .line 81
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    sub-int/2addr v0, v2

    iput v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozenTop:I

    const/4 v0, 0x0

    .line 82
    invoke-virtual {v7, v0, v0, v1, v2}, Landroid/graphics/RenderNode;->setPosition(IIII)Z

    .line 83
    invoke-virtual {v7, v1, v2}, Landroid/graphics/RenderNode;->beginRecording(II)Landroid/graphics/RecordingCanvas;

    move-result-object v3

    const-string v4, "beginRecording(...)"

    invoke-static {v3, v4}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 84
    :try_start_1
    iget v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozenTop:I

    int-to-float v4, v4

    neg-float v4, v4

    const/4 v5, 0x0

    invoke-virtual {v3, v5, v4}, Landroid/graphics/RecordingCanvas;->translate(FF)V

    iget-object v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v3, v4}, Landroid/graphics/RecordingCanvas;->drawRenderNode(Landroid/graphics/RenderNode;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    invoke-virtual {v7}, Landroid/graphics/RenderNode;->endRecording()V

    const/4 v4, 0x2

    const-wide/16 v5, 0x300

    const/4 v3, 0x1

    .line 85
    invoke-static/range {v1 .. v6}, Landroid/media/ImageReader;->newInstance(IIIIJ)Landroid/media/ImageReader;

    move-result-object v3
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 87
    :try_start_3
    invoke-virtual {v3}, Landroid/media/ImageReader;->getSurface()Landroid/view/Surface;

    move-result-object v4

    invoke-virtual {v8, v4}, Landroid/graphics/HardwareRenderer;->setSurface(Landroid/view/Surface;)V

    .line 88
    invoke-virtual {v8, v7}, Landroid/graphics/HardwareRenderer;->setContentRoot(Landroid/graphics/RenderNode;)V

    .line 89
    invoke-virtual {v8, v0}, Landroid/graphics/HardwareRenderer;->setOpaque(Z)V

    .line 90
    invoke-virtual {v8}, Landroid/graphics/HardwareRenderer;->start()V

    .line 91
    invoke-virtual {v8}, Landroid/graphics/HardwareRenderer;->createRenderRequest()Landroid/graphics/HardwareRenderer$FrameRenderRequest;

    move-result-object v4

    invoke-virtual {v4, v10}, Landroid/graphics/HardwareRenderer$FrameRenderRequest;->setWaitForPresent(Z)Landroid/graphics/HardwareRenderer$FrameRenderRequest;

    move-result-object v4

    invoke-virtual {v4}, Landroid/graphics/HardwareRenderer$FrameRenderRequest;->syncAndDraw()I

    move-result v4

    sput v4, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryRenderStatus:I

    .line 92
    invoke-virtual {v3}, Landroid/media/ImageReader;->acquireLatestImage()Landroid/media/Image;

    move-result-object v4
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    if-eqz v4, :cond_5

    .line 94
    :try_start_4
    invoke-virtual {v4}, Landroid/media/Image;->getHardwareBuffer()Landroid/hardware/HardwareBuffer;

    move-result-object v5
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    if-eqz v5, :cond_4

    .line 96
    :try_start_5
    sget-object v6, Landroid/graphics/ColorSpace$Named;->SRGB:Landroid/graphics/ColorSpace$Named;

    invoke-static {v6}, Landroid/graphics/ColorSpace;->get(Landroid/graphics/ColorSpace$Named;)Landroid/graphics/ColorSpace;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/graphics/Bitmap;->wrapHardwareBuffer(Landroid/hardware/HardwareBuffer;Landroid/graphics/ColorSpace;)Landroid/graphics/Bitmap;

    move-result-object v6

    if-eqz v6, :cond_1

    .line 100
    sget-object v11, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-virtual {v6, v11, v0}, Landroid/graphics/Bitmap;->copy(Landroid/graphics/Bitmap$Config;Z)Landroid/graphics/Bitmap;

    move-result-object v0

    goto :goto_0

    :cond_1
    move-object v0, v9

    :goto_0
    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-eqz v6, :cond_2

    .line 101
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->recycle()V

    .line 102
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_3

    div-int/lit8 v1, v1, 0x2

    div-int/lit8 v2, v2, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Bitmap;->getPixel(II)I

    move-result v0

    invoke-static {v0}, Landroid/graphics/Color;->alpha(I)I

    move-result v0

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->accessorySampleAlpha:I
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 103
    :cond_3
    :try_start_6
    invoke-virtual {v5}, Landroid/hardware/HardwareBuffer;->close()V

    goto :goto_1

    :catchall_0
    move-exception v0

    invoke-virtual {v5}, Landroid/hardware/HardwareBuffer;->close()V

    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 104
    :cond_4
    :goto_1
    :try_start_7
    invoke-virtual {v4}, Landroid/media/Image;->close()V

    goto :goto_2

    :catchall_1
    move-exception v0

    invoke-virtual {v4}, Landroid/media/Image;->close()V

    throw v0

    .line 105
    :cond_5
    :goto_2
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_6

    sget v0, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryFreezes:I

    add-int/2addr v0, v10

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryFreezes:I

    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    move-result v0

    add-int/2addr v0, v10

    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeViewBackdrop;->setHandoverVersion(I)V
    :try_end_7
    .catch Ljava/lang/RuntimeException; {:try_start_7 .. :try_end_7} :catch_1
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 110
    :cond_6
    invoke-virtual {v8}, Landroid/graphics/HardwareRenderer;->destroy()V

    if-eqz v3, :cond_7

    invoke-virtual {v3}, Landroid/media/ImageReader;->close()V

    :cond_7
    invoke-virtual {v7}, Landroid/graphics/RenderNode;->discardDisplayList()V

    return-void

    :catchall_2
    move-exception v0

    .line 84
    :try_start_8
    invoke-virtual {v7}, Landroid/graphics/RenderNode;->endRecording()V

    throw v0
    :try_end_8
    .catch Ljava/lang/RuntimeException; {:try_start_8 .. :try_end_8} :catch_0
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    :catchall_3
    move-exception v0

    move-object p0, v0

    goto :goto_3

    :catch_0
    move-object v3, v9

    .line 109
    :catch_1
    :try_start_9
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_8

    iput-object v9, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    move-result v0

    add-int/2addr v0, v10

    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeViewBackdrop;->setHandoverVersion(I)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 110
    :cond_8
    invoke-virtual {v8}, Landroid/graphics/HardwareRenderer;->destroy()V

    if-eqz v3, :cond_9

    invoke-virtual {v3}, Landroid/media/ImageReader;->close()V

    :cond_9
    invoke-virtual {v7}, Landroid/graphics/RenderNode;->discardDisplayList()V

    return-void

    :catchall_4
    move-exception v0

    move-object p0, v0

    move-object v9, v3

    :goto_3
    invoke-virtual {v8}, Landroid/graphics/HardwareRenderer;->destroy()V

    if-eqz v9, :cond_a

    invoke-virtual {v9}, Landroid/media/ImageReader;->close()V

    :cond_a
    invoke-virtual {v7}, Landroid/graphics/RenderNode;->discardDisplayList()V

    throw p0

    :cond_b
    :goto_4
    return-void
.end method

.method static final resume$lambda$0(Ldev/nino/squareglass/NativeViewBackdrop;)V
    .locals 0

    .line 46
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method private final retryNextFrame()V
    .locals 2

    .line 69
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 70
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    return-void
.end method

.method private final setHandoverVersion(I)V
    .locals 0

    .line 44
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->handoverVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    .line 235
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method private final transitioning(Landroid/view/View;)Z
    .locals 6

    .line 167
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 168
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getAnimation()Landroid/view/animation/Animation;

    move-result-object v0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    .line 171
    invoke-virtual {v0}, Landroid/view/animation/Animation;->getRepeatCount()I

    move-result v3

    const/4 v4, -0x1

    if-eq v3, v4, :cond_1

    invoke-virtual {v0}, Landroid/view/animation/Animation;->hasEnded()Z

    move-result v0

    if-nez v0, :cond_1

    return v2

    .line 172
    :cond_1
    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_7

    .line 173
    move-object v0, p1

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getLayoutTransition()Landroid/animation/LayoutTransition;

    move-result-object v3

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Landroid/animation/LayoutTransition;->isRunning()Z

    move-result v3

    if-ne v3, v2, :cond_2

    return v2

    .line 176
    :cond_2
    instance-of p1, p1, Landroidx/fragment/app/FragmentContainerView;

    if-eqz p1, :cond_5

    .line 179
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    move v3, v1

    move v4, v3

    :goto_0
    if-ge v3, p1, :cond_4

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v5

    if-nez v5, :cond_3

    add-int/lit8 v4, v4, 0x1

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_4
    if-le v4, v2, :cond_5

    return v2

    .line 182
    :cond_5
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    move v3, v1

    :goto_1
    if-ge v3, p1, :cond_7

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const-string v5, "getChildAt(...)"

    invoke-static {v4, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v4}, Ldev/nino/squareglass/NativeViewBackdrop;->transitioning(Landroid/view/View;)Z

    move-result v4

    if-eqz v4, :cond_6

    return v2

    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_7
    return v1
.end method


# virtual methods
.method public drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroidx/compose/ui/unit/Density;",
            "Landroidx/compose/ui/layout/LayoutCoordinates;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "density"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    if-eqz p3, :cond_5

    .line 191
    invoke-interface {p3}, Landroidx/compose/ui/layout/LayoutCoordinates;->isAttached()Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->hasDisplayList()Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_1

    .line 192
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationInWindow([I)V

    .line 193
    :cond_1
    invoke-static {p3}, Landroidx/compose/ui/layout/LayoutCoordinatesKt;->positionInWindow(Landroidx/compose/ui/layout/LayoutCoordinates;)J

    move-result-wide v0

    .line 238
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p3

    .line 242
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getSize-NH-jbRc()J

    move-result-wide v2

    .line 243
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v4

    invoke-interface {v4}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 245
    :try_start_0
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object v4

    if-eqz p4, :cond_2

    .line 196
    iget-object v5, p0, Ldev/nino/squareglass/NativeViewBackdrop;->inverse:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    invoke-virtual {v5}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->reset()V

    .line 197
    iget-object v5, p0, Ldev/nino/squareglass/NativeViewBackdrop;->inverse:Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;

    invoke-virtual {v5, v4, p2, p4}, Ldev/nino/squareglass/backdrop/internal/InverseLayerScope;->inverseTransform(Landroidx/compose/ui/graphics/drawscope/DrawTransform;Landroidx/compose/ui/unit/Density;Lam0/l;)V

    .line 199
    :cond_2
    iget-object p2, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    const/4 p4, 0x0

    aget p2, p2, p4

    int-to-float p2, p2

    const/16 p4, 0x20

    shr-long v5, v0, p4

    long-to-int p4, v5

    .line 248
    invoke-static {p4}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p4

    sub-float/2addr p2, p4

    .line 199
    iget-object p4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    const/4 v5, 0x1

    aget p4, p4, v5

    int-to-float p4, p4

    const-wide v5, 0xffffffffL

    and-long/2addr v0, v5

    long-to-int v0, v0

    .line 248
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    sub-float/2addr p4, v0

    .line 199
    invoke-interface {v4, p2, p4}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 252
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p1

    .line 202
    invoke-static {p1}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object p2

    invoke-virtual {p2}, Landroid/graphics/Canvas;->isHardwareAccelerated()Z

    move-result p2

    if-eqz p2, :cond_4

    .line 203
    iget-object p2, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-eqz p2, :cond_3

    .line 204
    invoke-static {p1}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object p1

    iget p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozenTop:I

    int-to-float p0, p0

    const/4 p4, 0x0

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0, p0, p4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    goto :goto_0

    .line 205
    :cond_3
    invoke-static {p1}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object p1

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p1, p0}, Landroid/graphics/Canvas;->drawRenderNode(Landroid/graphics/RenderNode;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 253
    :cond_4
    :goto_0
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 254
    invoke-interface {p3, v2, v3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    return-void

    :catchall_0
    move-exception p0

    .line 253
    invoke-interface {p3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/Canvas;->restore()V

    .line 254
    invoke-interface {p3, v2, v3}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->setSize-uvyYCjk(J)V

    throw p0

    :cond_5
    :goto_1
    return-void
.end method

.method public final getHandoverVersion()I
    .locals 0

    .line 44
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->handoverVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 234
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method public final getHasSample()Z
    .locals 1

    .line 47
    iget-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    if-nez v0, :cond_1

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x1

    return p0
.end method

.method public isCoordinatesDependent()Z
    .locals 0

    .line 48
    iget-boolean p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->isCoordinatesDependent:Z

    return p0
.end method

.method public final matches(Landroid/view/View;)Z
    .locals 1

    const-string v0, "view"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 211
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public onPreDraw()Z
    .locals 6

    .line 120
    sget v0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    .line 121
    const-string v0, "nav"

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_3

    const-string v0, "mini"

    invoke-static {v0}, Ldev/nino/squareglass/SquareSettings;->glass(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_3

    .line 122
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->hasDisplayList()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->discardDisplayList()V

    .line 123
    :cond_0
    iget-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_2

    .line 124
    :cond_1
    iput-boolean v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    .line 125
    iput-object v2, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    .line 126
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    move-result v0

    add-int/2addr v0, v1

    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeViewBackdrop;->setHandoverVersion(I)V

    :cond_2
    return v1

    .line 134
    :cond_3
    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeBackdrop;->getActive()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v0

    if-ne v0, p0, :cond_9

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_9

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    if-lez v0, :cond_9

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    if-lez v0, :cond_9

    .line 135
    iget-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->transitionPending:Z

    if-eqz v0, :cond_4

    .line 136
    iput-boolean v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->transitionPending:Z

    .line 137
    invoke-direct {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->retryNextFrame()V

    return v1

    .line 140
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeViewBackdrop;->transitioning(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 141
    invoke-direct {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->retryNextFrame()V

    return v1

    .line 144
    :cond_5
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, v4}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 145
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    iget-object v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    move-result v4

    iget-object v5, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result v5

    invoke-virtual {v0, v3, v3, v4, v5}, Landroid/graphics/RenderNode;->setPosition(IIII)Z

    .line 146
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    iget-object v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    move-result v4

    iget-object v5, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result v5

    invoke-virtual {v0, v4, v5}, Landroid/graphics/RenderNode;->beginRecording(II)Landroid/graphics/RecordingCanvas;

    move-result-object v0

    const-string v4, "beginRecording(...)"

    invoke-static {v0, v4}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 147
    :try_start_0
    iget-object v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    check-cast v0, Landroid/graphics/Canvas;

    invoke-virtual {v4, v0}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->endRecording()V

    .line 148
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v4, p0, Ldev/nino/squareglass/NativeViewBackdrop;->location:[I

    invoke-virtual {v0, v4}, Landroid/view/View;->getLocationInWindow([I)V

    .line 149
    iget-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    if-eqz v0, :cond_7

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-nez v0, :cond_7

    iget-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->notifyNextCapture:Z

    if-eqz v0, :cond_6

    goto :goto_0

    :cond_6
    move v0, v3

    goto :goto_1

    :cond_7
    :goto_0
    move v0, v1

    .line 150
    :goto_1
    iput-boolean v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    .line 151
    iput-object v2, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    .line 152
    iput-boolean v3, p0, Ldev/nino/squareglass/NativeViewBackdrop;->notifyNextCapture:Z

    if-eqz v0, :cond_8

    .line 154
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    move-result v0

    add-int/2addr v0, v1

    invoke-direct {p0, v0}, Ldev/nino/squareglass/NativeViewBackdrop;->setHandoverVersion(I)V

    .line 155
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryHandovers:I

    add-int/2addr p0, v1

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryHandovers:I

    .line 156
    sget-wide v2, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryFirstCaptureUptime:J

    const-wide/16 v4, 0x0

    cmp-long p0, v2, v4

    if-nez p0, :cond_8

    .line 157
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    sput-wide v2, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryFirstCaptureUptime:J

    .line 158
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->accessoryFirstCaptureTraversal:I

    .line 161
    :cond_8
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeCaptures:I

    add-int/2addr p0, v1

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeCaptures:I

    goto :goto_2

    :catchall_0
    move-exception v0

    .line 147
    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p0}, Landroid/graphics/RenderNode;->endRecording()V

    throw v0

    :cond_9
    :goto_2
    return v1
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 1

    const-string v0, "v"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 223
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    move-object v0, p0

    check-cast v0, Landroid/view/ViewTreeObserver$OnPreDrawListener;

    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 224
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 225
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->requestCapture()V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    const-string v0, "v"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 228
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    move-object v0, p0

    check-cast v0, Landroid/view/ViewTreeObserver$OnPreDrawListener;

    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 229
    :cond_0
    iget-object p1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {p1, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final release()V
    .locals 2

    .line 214
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 215
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    move-object v1, p0

    check-cast v1, Landroid/view/ViewTreeObserver$OnPreDrawListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 216
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    move-object v1, p0

    check-cast v1, Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 217
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->discardDisplayList()V

    const/4 v0, 0x0

    .line 218
    iput-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    const/4 v0, 0x0

    .line 219
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->ready:Z

    return-void
.end method

.method public final requestCapture()V
    .locals 2

    const/4 v0, 0x1

    .line 63
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->notifyNextCapture:Z

    .line 64
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 65
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->resume:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final transition()V
    .locals 1

    .line 55
    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->frozen:Landroid/graphics/Bitmap;

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->hasDisplayList()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->source:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->freeze()V

    :cond_0
    const/4 v0, 0x1

    .line 58
    iput-boolean v0, p0, Ldev/nino/squareglass/NativeViewBackdrop;->transitionPending:Z

    .line 59
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeViewBackdrop;->requestCapture()V

    return-void
.end method
