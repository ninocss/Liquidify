.class public final Ldev/nino/squareglass/LinnPlayer;
.super Ljava/lang/Object;
.source "LinnPlayer.java"

# interfaces
.implements Lcom/aspiro/wamp/player/k0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnPlayer$Action;
    }
.end annotation


# instance fields
.field volatile closed:Z

.field volatile device:Ldev/nino/squareglass/LinnProvider$Device;

.field volatile duration:I

.field final eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

.field events:Ldev/nino/squareglass/LinnEvents;

.field failedObservations:I

.field generation:I

.field index:I

.field final nativeIndices:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field nextRecovery:J

.field poll:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field volatile position:I

.field final previous:Lcom/aspiro/wamp/player/k0;

.field final provider:Ldev/nino/squareglass/LinnProvider;

.field final queue:Lcom/aspiro/wamp/playqueue/y;

.field volatile ready:Z

.field final remote:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field repeat:Lcom/aspiro/wamp/enums/RepeatMode;

.field shuffled:Z

.field signature:Ljava/lang/String;

.field volatile state:Lcom/aspiro/wamp/enums/MusicServiceState;

.field syncing:Z

.field token:Ljava/lang/String;

.field final tracks:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/aspiro/wamp/model/MediaItem;",
            ">;"
        }
    .end annotation
.end field

.field volume:Landroidx/media/VolumeProviderCompat;

.field wasPlaying:Z


# direct methods
.method public static synthetic $r8$lambda$3EVJFE5eAxNeckTlyXjDtrpGUnM(Ldev/nino/squareglass/LinnPlayer;IZ)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer;->lambda$select$0(IZ)V

    return-void
.end method

.method public static synthetic $r8$lambda$59Gv1qLWi8l-Z1l0soaVLH97oKg(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$observe$1(Ldev/nino/squareglass/OpenHome;)V

    return-void
.end method

.method public static synthetic $r8$lambda$5hIf8FY9WMRN4AgZBuVy_kReqYE(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionPlay$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$7PicGHndXZcdeFB-7Jo-M7sM2sU(Ldev/nino/squareglass/LinnPlayer;ILjava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$2(ILjava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Br1Hq9dv5kxtwVHHGBUS-kISeuk(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionPause$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$Iia6Oct-_GT5ocOZG5kOr0yWwoU(Ldev/nino/squareglass/LinnPlayer;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionSeekTo$0(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$KcPPpCtRTHOrP6spGDVHDDsIoqw(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$eventChanged$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$MhGCgF-1Os4P1cg2J5wmbCyRpwA(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$0(Ldev/nino/squareglass/LinnPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$TNWXaqRX9fgCtjRrfHFrmvaFDpg(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionStop$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$WwwhXSjzJgS0ppt_k6zAUCEb6qE(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;II)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->lambda$observe$0(Ldev/nino/squareglass/OpenHome;II)V

    return-void
.end method

.method public static synthetic $r8$lambda$YLk1UqFwthJYQXCFYNKGLSEpQLo(Ldev/nino/squareglass/LinnPlayer;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$skip$0(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$a2yszlRI_hLyocI33hJLXtDJdAI(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$optimistic$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$hy7zbM2Z4EE4hoBx_jzdGTM-ovQ(Ldev/nino/squareglass/LinnPlayer;JLdev/nino/squareglass/LinnPlayer$Action;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->lambda$command$0(JLdev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method public static synthetic $r8$lambda$k-HtG2Jm2UuPv0OmnqLuXewsqqQ(Ldev/nino/squareglass/LinnPlayer;ILdev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$1(ILdev/nino/squareglass/LinnPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$nMZ86Y3NyM-gB50ArR_Y7Hp3m4I(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;Ljava/util/List;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->lambda$adoptRemote$0(Ljava/util/List;Ljava/util/List;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$xG5ZdQ2JmtJ2AhtnvEHH5khC0z4(Ldev/nino/squareglass/LinnPlayer;)Ljava/lang/Void;
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$0()Ljava/lang/Void;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V
    .locals 1

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    .line 25
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    .line 27
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 35
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 37
    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 38
    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    .line 43
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {p3}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    .line 44
    iget p1, p1, Ldev/nino/squareglass/LinnProvider;->generation:I

    iput p1, p0, Ldev/nino/squareglass/LinnPlayer;->generation:I

    return-void
.end method

.method private synthetic lambda$adoptRemote$0(Ljava/util/List;Ljava/util/List;I)V
    .locals 2

    .line 273
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-eqz v0, :cond_0

    goto :goto_1

    .line 274
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1, p2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    const/4 p1, 0x0

    move p2, p1

    .line 275
    :goto_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p2, v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_1
    invoke-static {p1, p3}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 276
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->persist()V

    :cond_2
    :goto_1
    return-void
.end method

.method private synthetic lambda$command$0(JLdev/nino/squareglass/LinnPlayer$Action;)V
    .locals 4

    .line 283
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 284
    :cond_0
    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "control_queue_ms="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v2, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sub-long/2addr v2, p1

    const-wide/32 p1, 0xf4240

    div-long/2addr v2, p1

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    .line 285
    :try_start_0
    invoke-interface {p3}, Ldev/nino/squareglass/LinnPlayer$Action;->run()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    .line 286
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method private synthetic lambda$eventChanged$0()V
    .locals 2

    const/4 v0, 0x0

    .line 177
    :try_start_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->observe()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void

    :catchall_0
    move-exception v1

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    throw v1
.end method

.method private synthetic lambda$observe$0(Ldev/nino/squareglass/OpenHome;II)V
    .locals 2

    .line 206
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 207
    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_3

    .line 208
    iget-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p2}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_1

    .line 209
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    new-instance p2, Ldev/nino/squareglass/LinnPlayer$20;

    invoke-direct {p2, p0, p1}, Ldev/nino/squareglass/LinnPlayer$20;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;)V

    invoke-virtual {p0, p2}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void

    .line 217
    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p1}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result p1

    iget-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object p3, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne p2, p3, :cond_2

    const/4 v1, 0x1

    :cond_2
    iget p2, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    invoke-virtual {p0, p1, v1, p2}, Ldev/nino/squareglass/LinnPlayer;->synchronize(IZI)V

    return-void

    :cond_3
    if-ltz p2, :cond_4

    .line 220
    iget p1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-eq p2, p1, :cond_4

    iput p2, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p1, p2, v1}, Lcom/aspiro/wamp/playqueue/y;->goTo(IZ)Lcom/aspiro/wamp/playqueue/u0;

    .line 221
    :cond_4
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget p2, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {p1, p2, v0}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    invoke-virtual {p1, p3}, Landroidx/media/VolumeProviderCompat;->setCurrentVolume(I)V

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    invoke-virtual {p0, p3}, Ldev/nino/squareglass/LinnNativeVolume;->changed(I)V

    :cond_5
    :goto_0
    return-void
.end method

.method private synthetic lambda$observe$1(Ldev/nino/squareglass/OpenHome;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 210
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 211
    invoke-virtual {p1}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v2, "Queue changed in another controller"

    if-eqz v1, :cond_2

    const/4 v1, 0x0

    .line 212
    new-array v1, v1, [Ljava/lang/String;

    const-string v3, "Playlist"

    const-string v4, "Stop"

    invoke-virtual {p1, v3, v4, v1}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 213
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Long;

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-virtual {p1}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v7

    invoke-interface {v7, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    invoke-static {v5, v6}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v5}, [Ljava/lang/String;

    move-result-object v5

    const-string v6, "DeleteId"

    invoke-virtual {p1, v3, v6, v5}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    invoke-interface {v0, v4}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/io/IOException;

    invoke-direct {p0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 214
    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    const/4 p1, 0x1

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    .line 215
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object p1, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v0, "Bereit \u2013 Musik ausw\u00e4hlen"

    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    return-void

    .line 211
    :cond_2
    new-instance p0, Ljava/io/IOException;

    invoke-direct {p0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private synthetic lambda$onActionPause$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 372
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Pause"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$onActionPlay$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 370
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Play"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$onActionSeekTo$0(I)V
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 377
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-static {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->seekConfirmed(Ldev/nino/squareglass/OpenHome;I)V

    return-void
.end method

.method private synthetic lambda$onActionStop$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 378
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Stop"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$optimistic$0()V
    .locals 2

    .line 290
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$select$0(IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 314
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    const/4 v1, 0x0

    invoke-virtual {v0, p0, p1, v1, p2}, Ldev/nino/squareglass/OpenHome;->selectTrack(JIZ)V

    return-void
.end method

.method private synthetic lambda$skip$0(Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 373
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v0, "TransportState"

    const-string v1, "Playlist"

    invoke-virtual {p0, v1, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "Playing"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/String;

    invoke-virtual {p0, v1, p1, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    if-nez v0, :cond_0

    const-string p1, "Pause"

    new-array v0, v2, [Ljava/lang/String;

    invoke-virtual {p0, v1, p1, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    :cond_0
    return-void
.end method

.method private synthetic lambda$synchronize$0(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 3

    .line 298
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v0, v0, Ldev/nino/squareglass/LinnProvider;->generation:I

    .line 300
    :try_start_0
    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->transfer()V

    .line 301
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$5;

    invoke-direct {v2, p0, v0, p1}, Ldev/nino/squareglass/LinnPlayer$5;-><init>(Ldev/nino/squareglass/LinnPlayer;ILdev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    .line 307
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$6;

    invoke-direct {v2, p0, v0, p1}, Ldev/nino/squareglass/LinnPlayer$6;-><init>(Ldev/nino/squareglass/LinnPlayer;ILjava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic lambda$synchronize$1(ILdev/nino/squareglass/LinnPlayer;)V
    .locals 1

    .line 302
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v0, v0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    goto :goto_1

    .line 303
    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->close()V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iput-object p2, p1, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    invoke-static {p2}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->start()V

    .line 304
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object p2, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v0, ""

    invoke-virtual {p1, p2, v0}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 305
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p1}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_1
    return-void

    .line 302
    :cond_2
    :goto_1
    invoke-virtual {p2}, Ldev/nino/squareglass/LinnPlayer;->close()V

    return-void
.end method

.method private synthetic lambda$synchronize$2(ILjava/lang/Exception;)V
    .locals 1

    .line 307
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v0, v0, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-eq p1, v0, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez p1, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    :cond_1
    const/4 p1, 0x0

    iput-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    invoke-static {p2}, Ldev/nino/squareglass/LinnProvider;->explain(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_2
    :goto_0
    return-void
.end method

.method private synthetic lambda$transfer$0()Ljava/lang/Void;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 100
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getCurrentMediaPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {p0}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    const/4 p0, 0x0

    return-object p0
.end method

.method static seekConfirmed(Ldev/nino/squareglass/OpenHome;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 151
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/OpenHome;->seekConfirmed(I)V

    return-void
.end method


# virtual methods
.method adoptExisting()V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 164
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->playlistSource()Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_2

    .line 165
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    goto/16 :goto_2

    .line 167
    :cond_1
    :try_start_0
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->readRemoteTracks(Ljava/util/List;)Ljava/util/List;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 168
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v3, "Id"

    const-string v4, "Playlist"

    invoke-virtual {v2, v4, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v2

    if-ltz v2, :cond_5

    .line 169
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v3, v3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v3}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    goto :goto_2

    .line 170
    :cond_2
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v3, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v1, 0x0

    move v3, v1

    :goto_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    if-ge v3, v5, :cond_3

    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 171
    :cond_3
    iput v2, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iput-boolean v1, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    .line 172
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Shuffle"

    invoke-virtual {v0, v4, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    .line 173
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v2, "Repeat"

    invoke-virtual {v0, v4, v2}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->ALL:Lcom/aspiro/wamp/enums/RepeatMode;

    goto :goto_1

    :cond_4
    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    :goto_1
    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    :catch_0
    :cond_5
    :goto_2
    return-void
.end method

.method adoptRemote(Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 269
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->readRemoteTracks(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    .line 270
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v1}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, p1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    return-void

    .line 271
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v2, "Playlist"

    const-string v3, "Id"

    invoke-virtual {v1, v2, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v1

    .line 272
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v3, Ldev/nino/squareglass/LinnPlayer$14;

    invoke-direct {v3, p0, v0, p1, v1}, Ldev/nino/squareglass/LinnPlayer$14;-><init>(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;Ljava/util/List;I)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method capture()V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 47
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_7

    .line 48
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 49
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/aspiro/wamp/playqueue/u0;

    .line 50
    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v1

    .line 51
    instance-of v3, v1, Lcom/aspiro/wamp/model/Track;

    if-eqz v3, :cond_1

    move-object v4, v1

    check-cast v4, Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v4}, Lcom/aspiro/wamp/model/Track;->isUpload()Z

    move-result v4

    if-nez v4, :cond_1

    invoke-virtual {v1}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v4

    if-gtz v4, :cond_0

    goto :goto_1

    .line 55
    :cond_0
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    :goto_1
    if-eqz v3, :cond_3

    .line 52
    check-cast v1, Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v1}, Lcom/aspiro/wamp/model/Track;->isUpload()Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "Upload"

    goto :goto_2

    :cond_2
    const-string v0, "keine g\u00fcltige TIDAL-ID"

    goto :goto_2

    :cond_3
    const-string v0, "kein Online-Musiktitel"

    .line 53
    :goto_2
    new-instance v1, Ljava/lang/Exception;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Linn: Titel "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    add-int/2addr p0, v2

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " der Warteschlange ist nicht unterst\u00fctzt ("

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "). Bitte eine reine Online-Musikqueue w\u00e4hlen."

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1

    .line 57
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-ltz v0, :cond_6

    .line 58
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_6

    .line 59
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getCurrentMediaPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getState()Lcom/aspiro/wamp/enums/MusicServiceState;

    move-result-object v0

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_5

    goto :goto_3

    :cond_5
    const/4 v2, 0x0

    :goto_3
    iput-boolean v2, p0, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    .line 60
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->isShuffled()Z

    move-result v0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getRepeatMode()Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 61
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    return-void

    .line 58
    :cond_6
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "Current queue position is unavailable."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    .line 47
    :cond_7
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "Open an online TIDAL track first."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method close()V
    .locals 2

    const/4 v0, 0x1

    .line 178
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnEvents;->close()V

    :cond_1
    return-void
.end method

.method command(Ldev/nino/squareglass/LinnPlayer$Action;)V
    .locals 4

    .line 280
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 281
    :cond_0
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .line 282
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider;->controls:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Ldev/nino/squareglass/LinnPlayer$19;

    invoke-direct {v3, p0, v0, v1, p1}, Ldev/nino/squareglass/LinnPlayer$19;-><init>(Ldev/nino/squareglass/LinnPlayer;JLdev/nino/squareglass/LinnPlayer$Action;)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    :cond_1
    :goto_0
    return-void
.end method

.method eventChanged()V
    .locals 3

    .line 177
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->observations:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$8;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnPlayer$8;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method

.method public getCurrentBitDepth()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentBitRate()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentCodec()Ljava/lang/String;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentMediaDuration()I
    .locals 0

    .line 389
    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    return p0
.end method

.method public getCurrentMediaPosition()I
    .locals 0

    .line 390
    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    return p0
.end method

.method public getCurrentSampleRate()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getPlayQueue()Lcom/aspiro/wamp/playqueue/y;
    .locals 0

    .line 387
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    return-object p0
.end method

.method public getState()Lcom/aspiro/wamp/enums/MusicServiceState;
    .locals 0

    .line 388
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    return-object p0
.end method

.method public getVideoPlayerController()Lli/a;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getVolumeProvider()Landroidx/media/VolumeProviderCompat;
    .locals 0

    .line 391
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    return-object p0
.end method

.method public isCurrentStreamAudioOnly()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isCurrentStreamDolbyAtmos()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamHiResLosslessQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamHighQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamLossless()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamLowQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamMasterQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamOnline()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isCurrentStreamPaygatedPreview()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamPreview()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isLocal()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isRepeatSupported()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isSeekingSupported()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method metadata(Lcom/aspiro/wamp/model/MediaItem;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 64
    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getDisplayTitle()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getArtistNames()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getArtistNames()Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 65
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\"><item id=\""

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "\" parentID=\"0\" restricted=\"1\"><dc:title>"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</dc:title><upnp:artist>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</upnp:artist><upnp:class>object.item.audioItem.musicTrack</upnp:class><res>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</res></item></DIDL-Lite>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method observe()V
    .locals 11

    .line 187
    const-string v0, "Volume"

    const-string v1, "Time"

    .line 0
    const-string v2, "observation_failed count="

    .line 187
    iget-boolean v3, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v3, :cond_a

    iget-boolean v3, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-eqz v3, :cond_0

    goto/16 :goto_3

    .line 188
    :cond_0
    iget v3, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    const/4 v4, 0x3

    if-lt v3, v4, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->recover()V

    return-void

    .line 189
    :cond_1
    sget-object v3, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v6, 0x165a0bc00L

    add-long/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v3, 0x1

    .line 191
    :try_start_0
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v4, v4, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    .line 192
    iget-boolean v5, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-string v6, "TransportState"

    const/4 v7, 0x0

    const-string v8, "Playlist"

    if-eqz v5, :cond_3

    :try_start_1
    invoke-virtual {v4, v8, v6}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    iput v7, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v1, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v1, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v4, "Bereit \u2013 Musik ausw\u00e4hlen"

    invoke-virtual {v0, v1, v4}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 227
    :cond_2
    :goto_0
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    .line 193
    :cond_3
    :try_start_2
    invoke-virtual {v4}, Ldev/nino/squareglass/OpenHome;->playlistSource()Z

    move-result v5

    if-nez v5, :cond_4

    iput-boolean v3, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v1, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v4, "Andere Quelle aktiv \u2013 Musik ausw\u00e4hlen"

    invoke-virtual {v0, v1, v4}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    goto :goto_0

    .line 194
    :cond_4
    invoke-virtual {v4}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v5

    .line 195
    iget-object v9, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v5, v9}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_5

    iget-boolean v9, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v9, :cond_5

    invoke-virtual {p0, v5}, Ldev/nino/squareglass/LinnPlayer;->adoptRemote(Ljava/util/List;)V

    goto :goto_0

    .line 196
    :cond_5
    const-string v5, "Id"

    invoke-virtual {v4, v8, v5}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v9

    .line 197
    new-array v5, v7, [Ljava/lang/String;

    invoke-virtual {v4, v1, v1, v5}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v1

    .line 198
    const-string v5, "Seconds"

    invoke-interface {v1, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    mul-int/lit16 v5, v5, 0x3e8

    iput v5, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    const-string v5, "Duration"

    invoke-interface {v1, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    mul-int/lit16 v1, v1, 0x3e8

    iput v1, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    .line 199
    invoke-virtual {v4, v8, v6}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 200
    const-string v5, "Playing"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_1

    :cond_6
    const-string v5, "Paused"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_1

    :cond_7
    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->STOPPED:Lcom/aspiro/wamp/enums/MusicServiceState;

    :goto_1
    iput-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 201
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v1, v9, v10}, Ldev/nino/squareglass/LinnQueuePlan;->confirmedIndex(Ljava/util/List;J)I

    move-result v1

    if-gez v1, :cond_8

    const/4 v1, -0x1

    goto :goto_2

    :cond_8
    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 202
    :goto_2
    invoke-virtual {v4, v0, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 203
    iput v7, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    .line 204
    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v5, v5, Ldev/nino/squareglass/LinnProvider;->phase:Ldev/nino/squareglass/LinnProvider$Phase;

    sget-object v6, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    if-ne v5, v6, :cond_9

    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v6, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v7, ""

    invoke-virtual {v5, v6, v7}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 205
    :cond_9
    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v5, v5, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v6, Ldev/nino/squareglass/LinnPlayer$13;

    invoke-direct {v6, p0, v4, v1, v0}, Ldev/nino/squareglass/LinnPlayer$13;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;II)V

    invoke-virtual {v5, v6}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto/16 :goto_0

    :catch_0
    move-exception v0

    .line 224
    :try_start_3
    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    add-int/2addr v1, v3

    iput v1, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    .line 225
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v3, Ldev/nino/squareglass/LinnProvider$Phase;->RECONNECTING:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v4, "Verbindung unterbrochen \u2013 erneut verbinden\u2026"

    invoke-virtual {v1, v3, v4}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    .line 226
    sget-object v1, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " type="

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v1, p0}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto/16 :goto_0

    :catchall_0
    move-exception p0

    .line 227
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->remove()V

    throw p0

    :cond_a
    :goto_3
    return-void
.end method

.method public onActionNext()V
    .locals 2

    .line 375
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v1, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-ne v0, v1, :cond_1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->singleSkip(Z)V

    return-void

    :cond_1
    const-string v0, "Next"

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->skip(Ljava/lang/String;)V

    return-void
.end method

.method public onActionPause()V
    .locals 1

    .line 372
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v0, :cond_0

    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->optimistic(Lcom/aspiro/wamp/enums/MusicServiceState;)V

    new-instance v0, Ldev/nino/squareglass/LinnPlayer$15;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnPlayer$15;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    :cond_0
    return-void
.end method

.method public onActionPlay()V
    .locals 2

    .line 369
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result v0

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/LinnPlayer;->select(IZ)V

    return-void

    .line 370
    :cond_0
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->optimistic(Lcom/aspiro/wamp/enums/MusicServiceState;)V

    new-instance v0, Ldev/nino/squareglass/LinnPlayer$4;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnPlayer$4;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method public onActionPlayPosition(IZZ)V
    .locals 0

    .line 380
    invoke-virtual {p0, p1, p3}, Ldev/nino/squareglass/LinnPlayer;->select(IZ)V

    return-void
.end method

.method public onActionPrevious(Z)V
    .locals 1

    .line 376
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    if-nez p1, :cond_1

    iget p1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    const/16 v0, 0x1388

    if-le p1, v0, :cond_1

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->onActionSeekTo(I)V

    return-void

    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-ne p1, v0, :cond_2

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->singleSkip(Z)V

    return-void

    :cond_2
    const-string p1, "Previous"

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->skip(Ljava/lang/String;)V

    return-void
.end method

.method public onActionSeekTo(I)V
    .locals 1

    .line 377
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v0, :cond_0

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    new-instance v0, Ldev/nino/squareglass/LinnPlayer$9;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/LinnPlayer$9;-><init>(Ldev/nino/squareglass/LinnPlayer;I)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    :cond_0
    return-void
.end method

.method public onActionStop(Lcom/aspiro/wamp/player/PlaybackEndReason;)V
    .locals 0

    .line 378
    iget-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez p1, :cond_0

    new-instance p1, Ldev/nino/squareglass/LinnPlayer$16;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/LinnPlayer$16;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    :cond_0
    return-void
.end method

.method public onActionTogglePlayback()V
    .locals 2

    .line 379
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->onActionPause()V

    return-void

    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->onActionPlay()V

    return-void
.end method

.method public onActionWifiQualityChanged()V
    .locals 0

    return-void
.end method

.method public onActivated(ILcom/aspiro/wamp/player/k0;)V
    .locals 0

    return-void
.end method

.method public onDeactivated()V
    .locals 0

    return-void
.end method

.method public onServicePreEnterForeground()V
    .locals 0

    return-void
.end method

.method public onServicePreLeaveForeground()V
    .locals 0

    return-void
.end method

.method public onTaskRemoved()V
    .locals 0

    return-void
.end method

.method optimistic(Lcom/aspiro/wamp/enums/MusicServiceState;)V
    .locals 1

    .line 290
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p1, p1, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v0, Ldev/nino/squareglass/LinnPlayer$12;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnPlayer$12;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method persist()V
    .locals 5

    .line 318
    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/model/MediaItem;

    new-instance v3, Lcom/aspiro/wamp/model/Track;

    check-cast v2, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v3, v2}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    const/4 v2, 0x0

    invoke-virtual {v3, v2}, Lcom/aspiro/wamp/model/Track;->setSource(Lcom/aspiro/wamp/playqueue/source/model/Source;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 319
    :cond_0
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v2, Ljava/io/ObjectOutputStream;

    invoke-direct {v2, v1}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {v2, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V

    .line 320
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v0

    const/high16 v2, 0x400000

    if-gt v0, v2, :cond_2

    .line 321
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    :goto_1
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_1

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v4, 0x3a

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v4, 0x2c

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 322
    :cond_1
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v3, v3, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v4, "squareglass_linn"

    invoke-virtual {v3, v4, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "sessionUuid"

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v4, v4, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v4, v4, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "queue"

    .line 323
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    const/4 v4, 0x2

    invoke-static {v1, v4}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "mapping"

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "shuffled"

    iget-boolean v2, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    .line 324
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "repeat"

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    invoke-virtual {v2}, Lcom/aspiro/wamp/enums/RepeatMode;->name()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    .line 320
    :cond_2
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Queue snapshot too large"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catchall_0
    move-exception v0

    .line 319
    :try_start_3
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v1

    :try_start_4
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 325
    :catch_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    const-string v0, "Linn is connected; saving its reconnect state failed."

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method prepareReady()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, 0x1

    .line 155
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    .line 156
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Volume"

    invoke-virtual {v0, v1, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 157
    new-instance v1, Ldev/nino/squareglass/LinnPlayer$2;

    const/4 v2, 0x2

    const/16 v3, 0x64

    invoke-direct {v1, p0, v2, v3, v0}, Ldev/nino/squareglass/LinnPlayer$2;-><init>(Ldev/nino/squareglass/LinnPlayer;III)V

    iput-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    .line 161
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v0, "squareglass_linn"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "sessionUuid"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "queue"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "mapping"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method readRemoteTracks(Ljava/util/List;)Ljava/util/List;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/aspiro/wamp/model/MediaItem;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 247
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 248
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v1, p1}, Ldev/nino/squareglass/OpenHome;->readTracks(Ljava/util/List;)Ljava/util/Map;

    move-result-object v1

    .line 249
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 250
    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    .line 251
    new-instance v3, Ljava/net/URI;

    const-string v4, "Uri"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-direct {v3, v4}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 252
    const-string v4, "tidal"

    invoke-virtual {v3}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    .line 253
    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v3}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v3

    const-string v5, "&"

    invoke-virtual {v3, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v5, v3

    const/4 v6, 0x0

    move v7, v6

    :goto_1
    const/4 v8, 0x1

    if-ge v7, v5, :cond_1

    aget-object v9, v3, v7

    .line 254
    const-string v10, "="

    const/4 v11, 0x2

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v9

    array-length v10, v9

    if-ne v10, v11, :cond_0

    aget-object v10, v9, v6

    aget-object v8, v9, v8

    const-string v9, "UTF-8"

    invoke-static {v8, v9}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v4, v10, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 256
    :cond_1
    const-string v3, "trackId"

    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    .line 257
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/aspiro/wamp/model/MediaItem;

    invoke-virtual {v5}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v6

    if-ne v6, v3, :cond_2

    new-instance v4, Lcom/aspiro/wamp/model/Track;

    check-cast v5, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v4, v5}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    goto :goto_2

    :cond_3
    const/4 v4, 0x0

    :goto_2
    if-nez v4, :cond_4

    .line 259
    const-string v4, "Metadata"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v2, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v2

    invoke-static {v2}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object v2

    invoke-interface {v2}, Lorg/w3c/dom/Document;->getDocumentElement()Lorg/w3c/dom/Element;

    move-result-object v2

    .line 260
    new-instance v4, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v4}, Lcom/aspiro/wamp/model/Track;-><init>()V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setId(I)V

    const-string v3, "title"

    invoke-static {v2, v3}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setTitle(Ljava/lang/String;)V

    .line 261
    new-instance v3, Lcom/aspiro/wamp/model/Artist;

    invoke-direct {v3}, Lcom/aspiro/wamp/model/Artist;-><init>()V

    const-string v5, "artist"

    invoke-static {v2, v5}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/aspiro/wamp/model/Artist;->setName(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setArtist(Lcom/aspiro/wamp/model/Artist;)V

    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setArtists(Ljava/util/List;)V

    .line 262
    new-instance v3, Lcom/aspiro/wamp/model/Album;

    invoke-direct {v3}, Lcom/aspiro/wamp/model/Album;-><init>()V

    const-string v5, "album"

    invoke-static {v2, v5}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/aspiro/wamp/model/Album;->setTitle(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setAlbum(Lcom/aspiro/wamp/model/Album;)V

    invoke-virtual {v4, v8}, Lcom/aspiro/wamp/model/Track;->setAllowStreaming(Z)V

    invoke-virtual {v4, v8}, Lcom/aspiro/wamp/model/Track;->setStreamReady(Z)V

    .line 264
    :cond_4
    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 252
    :cond_5
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Linn queue now contains non-TIDAL content; its playback was left untouched."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_6
    return-object v0
.end method

.method readdress(Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 8

    .line 180
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eq v0, p0, :cond_0

    return-void

    .line 181
    :cond_0
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnEvents;->close()V

    .line 182
    :cond_1
    new-instance p1, Ldev/nino/squareglass/LinnEvents;

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$11;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnPlayer$11;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {p1, v0, v1}, Ldev/nino/squareglass/LinnEvents;-><init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;)V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnEvents;->start()V

    .line 183
    iget-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    const/4 v0, 0x0

    if-eqz p1, :cond_2

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, p1, Ldev/nino/squareglass/LinnProvider;->observations:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$10;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$10;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    const-wide/16 v5, 0x2

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x0

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    .line 184
    :cond_2
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p1, p1, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    invoke-virtual {p1, v1, v0}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object p0, p0, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    const-string v0, "location"

    invoke-interface {p1, v0, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method reattach()V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 329
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->playlistSource()Z

    move-result v0

    if-eqz v0, :cond_a

    .line 330
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 331
    const-string v1, "shuffled"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    const-string v1, "repeat"

    const-string v3, "OFF"

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/aspiro/wamp/enums/RepeatMode;->valueOf(Ljava/lang/String;)Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 332
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, v1, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    const-string v3, "sessionUuid"

    const-string v4, ""

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    .line 333
    const-string v1, "queue"

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    invoke-static {v1, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    .line 334
    array-length v5, v1

    const/high16 v6, 0x400000

    if-gt v5, v6, :cond_8

    .line 335
    new-instance v5, Ljava/io/ObjectInputStream;

    new-instance v6, Ljava/io/ByteArrayInputStream;

    invoke-direct {v6, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v5, v6}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    :try_start_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-virtual {v5}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/List;

    invoke-interface {v1, v6}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v5}, Ljava/io/ObjectInputStream;->close()V

    .line 336
    const-string v1, "mapping"

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ","

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v1, v0

    move v4, v2

    :goto_0
    if-ge v4, v1, :cond_2

    aget-object v5, v0, v4

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_1

    .line 337
    const-string v6, ":"

    invoke-virtual {v5, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    aget-object v7, v5, v2

    invoke-static {v7}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    aget-object v5, v5, v6

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    if-ltz v5, :cond_0

    .line 338
    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge v5, v6, :cond_0

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v6, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid queue mapping"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 340
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    .line 341
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    .line 342
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->readRemoteTracks(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    .line 343
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v4, v4, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v4}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 344
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->clear()V

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v4, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 345
    :goto_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge v2, v0, :cond_4

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    .line 343
    :cond_3
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Linn queue is changing. Retry reconnecting."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 347
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Shuffle"

    const-string v2, "Playlist"

    invoke-virtual {v0, v2, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    .line 348
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v4, "Repeat"

    invoke-virtual {v0, v2, v4}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    goto :goto_3

    .line 349
    :cond_5
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v1, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-eq v0, v1, :cond_6

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->ALL:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 350
    :cond_6
    :goto_3
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Id"

    invoke-virtual {v0, v2, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    if-ltz v0, :cond_7

    .line 351
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 352
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Volume"

    invoke-virtual {v0, v1, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 353
    new-instance v1, Ldev/nino/squareglass/LinnPlayer$3;

    const/16 v2, 0x64

    invoke-direct {v1, p0, v3, v2, v0}, Ldev/nino/squareglass/LinnPlayer$3;-><init>(Ldev/nino/squareglass/LinnPlayer;III)V

    iput-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    return-void

    .line 351
    :cond_7
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Linn current track is unavailable"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :catchall_0
    move-exception p0

    .line 335
    :try_start_1
    invoke-virtual {v5}, Ljava/io/ObjectInputStream;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_4

    :catchall_1
    move-exception v0

    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw p0

    .line 334
    :cond_8
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid queue snapshot"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 332
    :cond_9
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Different Linn session"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 329
    :cond_a
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Another Linn source is active"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method recover()V
    .locals 7

    .line 230
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iget-wide v2, p0, Ldev/nino/squareglass/LinnPlayer;->nextRecovery:J

    cmp-long v2, v0, v2

    if-gez v2, :cond_0

    goto/16 :goto_3

    .line 231
    :cond_0
    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    iget v3, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    add-int/lit8 v3, v3, -0x3

    const/4 v4, 0x5

    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    const-wide/16 v4, 0x1

    shl-long v3, v4, v3

    const-wide/16 v5, 0x1e

    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v2

    add-long/2addr v0, v2

    iput-wide v0, p0, Ldev/nino/squareglass/LinnPlayer;->nextRecovery:J

    .line 233
    :try_start_0
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, v1, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/16 v1, 0x5dc

    invoke-static {v1}, Ldev/nino/squareglass/OpenHome;->discover(I)Ljava/util/Set;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 234
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 235
    :try_start_1
    new-instance v2, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    .line 236
    iget-object v1, v2, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v3, v3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v3, v3, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_0

    .line 237
    :cond_1
    const-string v1, "Playlist"

    const-string v3, "TransportState"

    invoke-virtual {v2, v1, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 238
    new-instance v1, Ldev/nino/squareglass/LinnProvider$Device;

    invoke-direct {v1, v2}, Ldev/nino/squareglass/LinnProvider$Device;-><init>(Ldev/nino/squareglass/OpenHome;)V

    .line 239
    invoke-virtual {p0, v1}, Ldev/nino/squareglass/LinnPlayer;->readdress(Ldev/nino/squareglass/LinnProvider$Device;)V

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iput-object v1, v2, Ldev/nino/squareglass/LinnProvider;->connected:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider;->devices:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v3, v1, Ldev/nino/squareglass/LinnProvider$Device;->a:Ljava/lang/String;

    invoke-virtual {v2, v3, v1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x0

    .line 240
    iput v1, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-boolean v2, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz v2, :cond_2

    sget-object v2, Ldev/nino/squareglass/LinnProvider$Phase;->READY:Ldev/nino/squareglass/LinnProvider$Phase;

    goto :goto_1

    :cond_2
    sget-object v2, Ldev/nino/squareglass/LinnProvider$Phase;->ACTIVE:Ldev/nino/squareglass/LinnProvider$Phase;

    :goto_1
    iget-boolean v3, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-eqz v3, :cond_3

    const-string v3, "Bereit \u2013 Musik ausw\u00e4hlen"

    goto :goto_2

    :cond_3
    const-string v3, ""

    :goto_2
    invoke-virtual {v1, v2, v3}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :goto_3
    return-void

    .line 243
    :catch_1
    :cond_4
    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->failedObservations:I

    return-void
.end method

.method restoreNativeQueue()V
    .locals 9

    .line 359
    new-instance v0, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;

    sget-object v1, Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType$None;->INSTANCE:Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType$None;

    const/4 v2, 0x0

    const-string v3, "squareglass-linn"

    const-string v4, "Linn queue"

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType;Lcom/tidal/android/navigation/NavigationInfo$Node;)V

    .line 360
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/model/MediaItem;

    new-instance v3, Lcom/aspiro/wamp/model/Track;

    check-cast v2, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v3, v2}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    invoke-virtual {v0, v3}, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;->addSourceItem(Lcom/aspiro/wamp/model/MediaItem;)V

    goto :goto_0

    .line 363
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    new-instance v2, Lcom/aspiro/wamp/playqueue/w0;

    iget v3, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    sget-object v5, Lcom/aspiro/wamp/enums/ShuffleMode;->TURN_OFF:Lcom/aspiro/wamp/enums/ShuffleMode;

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v4, 0x0

    invoke-direct/range {v2 .. v8}, Lcom/aspiro/wamp/playqueue/w0;-><init>(IZLcom/aspiro/wamp/enums/ShuffleMode;Lcom/aspiro/wamp/enums/RepeatMode;ZZ)V

    invoke-interface {v1, v0, v2}, Lcom/aspiro/wamp/playqueue/y;->prepare(Lcom/aspiro/wamp/playqueue/source/model/Source;Lcom/aspiro/wamp/playqueue/w0;)V

    .line 364
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    iget-boolean v1, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    invoke-static {v0, v1}, Ldev/nino/squareglass/NativeLinnBridge;->restoreShuffle(Lcom/aspiro/wamp/playqueue/y;Z)V

    .line 365
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Lcom/aspiro/wamp/playqueue/y;->goTo(IZ)Lcom/aspiro/wamp/playqueue/u0;

    .line 366
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    return-void
.end method

.method select(IZ)V
    .locals 2

    if-ltz p1, :cond_3

    .line 311
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lt p1, v0, :cond_0

    goto :goto_1

    .line 312
    :cond_0
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v0, :cond_2

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 313
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {v0, p1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result p1

    .line 314
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$17;

    invoke-direct {v0, p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer$17;-><init>(Ldev/nino/squareglass/LinnPlayer;IZ)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void

    :cond_2
    :goto_0
    const/4 v0, 0x0

    .line 312
    invoke-virtual {p0, p1, p2, v0}, Ldev/nino/squareglass/LinnPlayer;->synchronize(IZI)V

    :cond_3
    :goto_1
    return-void
.end method

.method singleSkip(Z)V
    .locals 2

    .line 374
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-static {v0, p1}, Ldev/nino/squareglass/NativeLinnBridge;->skip(Lcom/aspiro/wamp/playqueue/y;Z)I

    move-result p1

    if-ltz p1, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnPlayer;->select(IZ)V

    :cond_1
    return-void
.end method

.method skip(Ljava/lang/String;)V
    .locals 1

    .line 373
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$7;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/LinnPlayer$7;-><init>(Ldev/nino/squareglass/LinnPlayer;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method snapshotSignature()Ljava/lang/String;
    .locals 5

    .line 153
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/16 v3, 0x3a

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/playqueue/u0;

    invoke-interface {v2}, Lcom/aspiro/wamp/playqueue/u0;->getUid()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-interface {v2}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v2

    invoke-virtual {v2}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v2, 0x2c

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/y;->isShuffled()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p0}, Lcom/aspiro/wamp/playqueue/y;->getRepeatMode()Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method start()V
    .locals 8

    .line 175
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->ready:Z

    if-nez v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->persist()V

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->observations:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$10;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$10;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    const-wide/16 v5, 0x2

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x0

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    .line 176
    new-instance v0, Ldev/nino/squareglass/LinnEvents;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$11;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$11;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnEvents;-><init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnEvents;->start()V

    return-void
.end method

.method synchronize(IZI)V
    .locals 4

    .line 293
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    .line 294
    new-instance v0, Ldev/nino/squareglass/LinnPlayer;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-direct {v0, v1, v2, v3}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    .line 295
    :try_start_0
    invoke-virtual {v0}, Ldev/nino/squareglass/LinnPlayer;->capture()V

    iput p1, v0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iput-boolean p2, v0, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    iput p3, v0, Ldev/nino/squareglass/LinnPlayer;->position:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 297
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p1, p1, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance p2, Ldev/nino/squareglass/LinnPlayer$18;

    invoke-direct {p2, p0, v0}, Ldev/nino/squareglass/LinnPlayer$18;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V

    invoke-interface {p1, p2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :catch_0
    move-exception p1

    const/4 p2, 0x0

    .line 296
    iput-boolean p2, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method transfer()V
    .locals 43
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v1, p0

    .line 68
    const-string v2, "SetSourceIndex"

    const-string v3, "SetShuffle"

    const-string v4, "Pause"

    const-string v5, "DeleteId"

    const-string v6, "SetRepeat"

    const-string v7, "0"

    const-string v0, "Preparing Linn queue\u2026"

    invoke-static {v0}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V

    .line 69
    iget-object v8, v1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v9, v8, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v8, "TracksMax"

    const-string v15, "Playlist"

    invoke-virtual {v9, v15, v8}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    .line 70
    const-string v10, "Queue capacity read"

    const-string v11, "SquareLinn"

    invoke-static {v11, v10}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 71
    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v10

    .line 72
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v13, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    const/16 v16, 0x1

    if-ne v12, v13, :cond_0

    move/from16 v12, v16

    goto :goto_0

    :cond_0
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v12}, Ljava/util/List;->size()I

    move-result v12

    .line 73
    :goto_0
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v13

    invoke-static {v13, v12, v8}, Ldev/nino/squareglass/LinnQueuePlan;->capacity(III)V

    .line 74
    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->preflight()V

    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->tidalTokenId()Ljava/lang/String;

    move-result-object v8

    iput-object v8, v1, Ldev/nino/squareglass/LinnPlayer;->token:Ljava/lang/String;

    const-string v8, "SourceIndex"

    const-string v13, "Product"

    invoke-virtual {v9, v13, v8}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 75
    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->playlistIndex()I

    move-result v17

    .line 76
    const-string v14, "Device TIDAL login verified"

    invoke-static {v11, v14}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 77
    const-string v14, "TransportState"

    invoke-virtual {v9, v15, v14}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v18, v0

    const-string v0, "Id"

    invoke-virtual {v9, v15, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    .line 79
    const-string v0, "Repeat"

    invoke-virtual {v9, v15, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    const-string v0, "Shuffle"

    invoke-virtual {v9, v15, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    move-object/from16 v22, v8

    .line 80
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8, v10}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    move-object/from16 v23, v7

    .line 81
    invoke-virtual {v9, v10}, Ldev/nino/squareglass/OpenHome;->readTracks(Ljava/util/List;)Ljava/util/Map;

    move-result-object v7

    .line 82
    invoke-static/range {v18 .. v18}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V

    move-object/from16 v18, v7

    const/4 v7, 0x0

    .line 83
    new-array v0, v7, [Ljava/lang/String;

    const-string v7, "Time"

    invoke-virtual {v9, v7, v7, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    const-string v7, "Seconds"

    invoke-interface {v0, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    .line 84
    const-string v0, "Volume"

    invoke-virtual {v9, v0, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const-wide/16 v24, 0x0

    .line 86
    :try_start_0
    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v26

    if-eqz v26, :cond_1

    move/from16 v27, v7

    move-wide/from16 v28, v24

    goto :goto_1

    :cond_1
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v26
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_b

    move/from16 v27, v7

    add-int/lit8 v7, v26, -0x1

    :try_start_1
    invoke-interface {v10, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Long;

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v28
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_a

    :goto_1
    const/4 v7, 0x0

    :goto_2
    move-object/from16 v26, v9

    .line 87
    :try_start_2
    iget-object v9, v1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_9

    move-object/from16 v30, v11

    const-string v11, "Linn handoff was cancelled"

    if-ge v7, v9, :cond_4

    .line 88
    :try_start_3
    iget v9, v1, Ldev/nino/squareglass/LinnPlayer;->generation:I

    move/from16 v31, v12

    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v12, v12, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne v9, v12, :cond_3

    .line 89
    iget-object v9, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v11, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    if-ne v9, v11, :cond_2

    :try_start_4
    iget v9, v1, Ldev/nino/squareglass/LinnPlayer;->index:I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    if-eq v7, v9, :cond_2

    move/from16 v32, v7

    move-object v7, v10

    move-object/from16 v33, v14

    move-object/from16 v9, v26

    move-object/from16 v34, v30

    move/from16 v26, v0

    move-wide/from16 v29, v28

    move/from16 v0, v31

    move-object/from16 v28, v5

    move-object v5, v13

    goto/16 :goto_3

    :catch_0
    move-exception v0

    move-object v12, v5

    move-object v7, v10

    move-object v5, v13

    move-object/from16 v33, v14

    move-object/from16 v9, v26

    const/4 v11, 0x0

    const/4 v13, 0x0

    move-object v10, v0

    const/4 v0, 0x0

    goto/16 :goto_e

    .line 90
    :cond_2
    :try_start_5
    iget-object v9, v1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/aspiro/wamp/model/MediaItem;

    .line 91
    invoke-virtual {v9}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v11

    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->token:Ljava/lang/String;

    invoke-static {v11, v12}, Ldev/nino/squareglass/OpenHome;->tidalUri(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 92
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v10, v12}, Ldev/nino/squareglass/LinnQueuePlan;->expected(Ljava/util/List;Ljava/util/List;)Ljava/util/List;

    move-result-object v12

    invoke-virtual {v1, v9, v11}, Ldev/nino/squareglass/LinnPlayer;->metadata(Lcom/aspiro/wamp/model/MediaItem;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    move/from16 v32, v7

    move-object v7, v10

    move-object v10, v12

    move-object/from16 v33, v14

    move-object/from16 v34, v30

    move-object v14, v9

    move-object/from16 v9, v26

    move/from16 v26, v0

    move/from16 v0, v31

    move-wide/from16 v41, v28

    move-object/from16 v28, v5

    move-object v5, v13

    move-object v13, v11

    move-wide/from16 v11, v41

    :try_start_6
    invoke-virtual/range {v9 .. v14}, Ldev/nino/squareglass/OpenHome;->insertConfirmed(Ljava/util/List;JLjava/lang/String;Ljava/lang/String;)J

    move-result-wide v10

    .line 93
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v13

    invoke-interface {v12, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 94
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static/range {v32 .. v32}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-interface {v12, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 95
    iget-object v12, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v13, Ldev/nino/squareglass/LinnProvider$Phase;->TRANSFERRING:Ldev/nino/squareglass/LinnProvider$Phase;

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    move-wide/from16 v29, v10

    const-string v10, "Warteschlange "

    invoke-virtual {v14, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    invoke-virtual {v14, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v10, "/"

    invoke-virtual {v14, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v12, v13, v10}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V

    :goto_3
    add-int/lit8 v10, v32, 0x1

    move v11, v10

    move-object v10, v7

    move v7, v11

    move v12, v0

    move-object v13, v5

    move/from16 v0, v26

    move-object/from16 v5, v28

    move-wide/from16 v28, v29

    move-object/from16 v14, v33

    move-object/from16 v11, v34

    goto/16 :goto_2

    :cond_3
    move-object/from16 v28, v5

    move-object v7, v10

    move-object v5, v13

    move-object/from16 v33, v14

    move-object/from16 v9, v26

    .line 88
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v11}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    :catch_1
    move-exception v0

    goto :goto_4

    :catch_2
    move-exception v0

    move-object/from16 v28, v5

    move-object v7, v10

    move-object v5, v13

    move-object/from16 v33, v14

    move-object/from16 v9, v26

    :goto_4
    move-object v10, v0

    move-object/from16 v12, v28

    goto/16 :goto_b

    :cond_4
    move-object/from16 v28, v5

    move-object v7, v10

    move-object v5, v13

    move-object/from16 v33, v14

    move-object/from16 v9, v26

    move-object/from16 v34, v30

    move/from16 v26, v0

    .line 98
    :try_start_7
    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v7, v10}, Ldev/nino/squareglass/LinnQueuePlan;->expected(Ljava/util/List;Ljava/util/List;)Ljava/util/List;

    move-result-object v10

    invoke-interface {v0, v10}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 99
    iget v0, v1, Ldev/nino/squareglass/LinnPlayer;->generation:I

    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget v10, v10, Ldev/nino/squareglass/LinnProvider;->generation:I

    if-ne v0, v10, :cond_9

    .line 100
    new-instance v0, Ljava/util/concurrent/FutureTask;

    new-instance v10, Ldev/nino/squareglass/LinnPlayer$0;

    invoke-direct {v10, v1}, Ldev/nino/squareglass/LinnPlayer$0;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {v0, v10}, Ljava/util/concurrent/FutureTask;-><init>(Ljava/util/concurrent/Callable;)V

    .line 101
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v10, v10, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    invoke-virtual {v10, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    sget-object v10, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v11, 0x5

    invoke-virtual {v0, v11, v12, v10}, Ljava/util/concurrent/FutureTask;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 102
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    sget-object v10, Ldev/nino/squareglass/LinnProvider$Phase;->CONFIRMING:Ldev/nino/squareglass/LinnProvider$Phase;

    const-string v11, "Wiedergabe startet\u2026"

    invoke-virtual {v0, v10, v11}, Ldev/nino/squareglass/LinnProvider;->phase(Ldev/nino/squareglass/LinnProvider$Phase;Ljava/lang/String;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_8

    const/4 v10, 0x0

    .line 104
    :try_start_8
    new-array v0, v10, [Ljava/lang/String;

    invoke-virtual {v9, v15, v4, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 105
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v5, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 106
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    iget v10, v1, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v0, v10}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    .line 107
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v11, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_5

    const-string v12, "1"

    if-ne v10, v11, :cond_5

    move-object/from16 v10, v23

    goto :goto_5

    :cond_5
    move-object v10, v12

    :goto_5
    :try_start_9
    filled-new-array {v10}, [Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v15, v6, v10}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 108
    iget-boolean v10, v1, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    if-eqz v10, :cond_6

    goto :goto_6

    :cond_6
    move-object/from16 v12, v23

    :goto_6
    filled-new-array {v12}, [Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v15, v3, v10}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 109
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v10, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    iget v0, v1, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget-boolean v12, v1, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    invoke-virtual {v9, v10, v11, v0, v12}, Ldev/nino/squareglass/OpenHome;->selectTrack(JIZ)V

    .line 110
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Long;

    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    move-result-wide v11

    .line 111
    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v13

    iget-object v14, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v8, v14}, Ldev/nino/squareglass/LinnQueuePlan;->expected(Ljava/util/List;Ljava/util/List;)Ljava/util/List;

    move-result-object v14

    invoke-interface {v13, v14}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_7

    .line 112
    invoke-static {v11, v12}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v11

    filled-new-array {v11}, [Ljava/lang/String;

    move-result-object v11
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_5

    move-object/from16 v12, v28

    :try_start_a
    invoke-virtual {v9, v15, v12, v11}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    invoke-interface {v8, v10}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 113
    const-string v10, "Finishing Linn connection\u2026"

    invoke-static {v10}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V

    move-object/from16 v28, v12

    goto :goto_7

    :cond_7
    move-object/from16 v12, v28

    .line 111
    new-instance v34, Ldev/nino/squareglass/OpenHome$Fault;

    sget-object v35, Ldev/nino/squareglass/OpenHome$Failure;->CONFLICT:Ldev/nino/squareglass/OpenHome$Failure;

    const-string v36, "Queue commit"

    const-string v38, ""

    const-string v39, "Linn queue changed in another controller"

    const/16 v40, 0x0

    const/16 v37, 0x0

    invoke-direct/range {v34 .. v40}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v34
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_3

    :catch_3
    move-exception v0

    goto :goto_8

    :cond_8
    move-object/from16 v12, v28

    .line 116
    :try_start_b
    const-string v0, "Device queue committed; creating remote volume adapter"

    move-object/from16 v10, v34

    invoke-static {v10, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 117
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$1;

    const/4 v11, 0x2

    const/16 v13, 0x64

    move/from16 v14, v26

    invoke-direct {v0, v1, v11, v13, v14}, Ldev/nino/squareglass/LinnPlayer$1;-><init>(Ldev/nino/squareglass/LinnPlayer;III)V

    iput-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    .line 121
    const-string v0, "Queue transfer complete"

    invoke-static {v10, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_4

    return-void

    :catch_4
    move-exception v0

    move-object v10, v0

    move/from16 v0, v16

    move v11, v0

    goto :goto_d

    :catch_5
    move-exception v0

    move-object/from16 v12, v28

    :goto_8
    move-object v10, v0

    move/from16 v0, v16

    goto :goto_c

    :cond_9
    move-object/from16 v12, v28

    .line 99
    :try_start_c
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v11}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_6

    :catch_6
    move-exception v0

    goto :goto_a

    :cond_a
    move-object/from16 v12, v28

    .line 98
    :try_start_d
    new-instance v0, Ljava/lang/Exception;

    const-string v10, "Linn queue changed during transfer. Retry."

    invoke-direct {v0, v10}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_7

    :catch_7
    move-exception v0

    move-object v10, v0

    move/from16 v13, v16

    const/4 v0, 0x0

    const/4 v11, 0x0

    goto :goto_e

    :catch_8
    move-exception v0

    move-object/from16 v12, v28

    goto :goto_a

    :catch_9
    move-exception v0

    move-object v12, v5

    move-object v7, v10

    move-object v5, v13

    move-object/from16 v33, v14

    move-object/from16 v9, v26

    goto :goto_a

    :catch_a
    move-exception v0

    move-object v12, v5

    goto :goto_9

    :catch_b
    move-exception v0

    move-object v12, v5

    move/from16 v27, v7

    :goto_9
    move-object v7, v10

    move-object v5, v13

    move-object/from16 v33, v14

    :goto_a
    move-object v10, v0

    :goto_b
    const/4 v0, 0x0

    :goto_c
    const/4 v11, 0x0

    :goto_d
    const/4 v13, 0x0

    :goto_e
    if-nez v11, :cond_18

    .line 125
    :try_start_e
    instance-of v11, v10, Ldev/nino/squareglass/OpenHome$Fault;

    if-eqz v11, :cond_b

    move-object v11, v10

    check-cast v11, Ldev/nino/squareglass/OpenHome$Fault;

    iget-object v11, v11, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v14, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    if-ne v11, v14, :cond_b

    move/from16 v11, v16

    goto :goto_f

    :cond_b
    const/4 v11, 0x0

    :goto_f
    if-nez v13, :cond_17

    if-nez v11, :cond_17

    .line 126
    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v11

    iget-object v13, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v8, v13}, Ldev/nino/squareglass/LinnQueuePlan;->expected(Ljava/util/List;Ljava/util/List;)Ljava/util/List;

    move-result-object v13

    invoke-interface {v11, v13}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v11
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_d

    if-eqz v11, :cond_17

    .line 127
    const-string v11, "Stop"

    if-eqz v0, :cond_c

    const/4 v13, 0x0

    :try_start_f
    new-array v14, v13, [Ljava/lang/String;

    invoke-virtual {v9, v15, v11, v14}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 128
    :cond_c
    iget-object v13, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v8, v13}, Ldev/nino/squareglass/LinnQueuePlan;->expected(Ljava/util/List;Ljava/util/List;)Ljava/util/List;

    move-result-object v8

    .line 129
    iget-object v1, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_10
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v13
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_d

    const-string v14, "Queue changed during recovery"

    if-eqz v13, :cond_e

    :try_start_10
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Long;

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v28

    move/from16 v17, v0

    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v8}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    invoke-static/range {v28 .. v29}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v15, v12, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    invoke-interface {v8, v13}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move/from16 v0, v17

    goto :goto_10

    :cond_d
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v14}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e
    move/from16 v17, v0

    .line 131
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move-object v7, v11

    move-object/from16 v1, v19

    move-wide/from16 v11, v24

    :goto_11
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_13

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Long;

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v28

    move-object/from16 p0, v0

    .line 132
    invoke-virtual {v9}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v8}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12

    .line 133
    invoke-interface {v8, v13}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    move-object/from16 v0, p0

    move-wide/from16 v11, v28

    goto :goto_11

    :cond_f
    move-object/from16 v19, v4

    move-object/from16 v4, v18

    .line 134
    invoke-interface {v4, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    .line 135
    const-string v13, "Uri"

    invoke-interface {v0, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    move-object/from16 v18, v4

    const-string v4, "Metadata"

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_d

    move-object v4, v14

    move-object v14, v0

    move-object v0, v4

    move-object v4, v10

    move-object v10, v8

    :try_start_11
    invoke-virtual/range {v9 .. v14}, Ldev/nino/squareglass/OpenHome;->insertConfirmed(Ljava/util/List;JLjava/lang/String;Ljava/lang/String;)J

    move-result-wide v13

    cmp-long v8, v11, v24

    if-nez v8, :cond_10

    const/4 v8, 0x0

    goto :goto_12

    .line 136
    :cond_10
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    invoke-interface {v10, v8}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v8

    add-int/lit8 v8, v8, 0x1

    :goto_12
    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    invoke-interface {v10, v8, v11}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 137
    invoke-static/range {v28 .. v29}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_11

    invoke-static {v13, v14}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v1

    :cond_11
    move-object v8, v10

    move-wide v11, v13

    move-object v14, v0

    move-object v10, v4

    move-object/from16 v4, v19

    move-object/from16 v0, p0

    goto :goto_11

    :cond_12
    move-object v4, v10

    move-object v0, v14

    .line 132
    new-instance v1, Ljava/io/IOException;

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_13
    move-object/from16 v19, v4

    move-object v4, v10

    if-eqz v17, :cond_19

    .line 140
    filled-new-array/range {v20 .. v20}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v15, v6, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    filled-new-array/range {v21 .. v21}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v15, v3, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-object/from16 v3, v23

    .line 141
    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_14

    const-string v0, "SeekId"

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v15, v0, v1}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    const-string v0, "SeekSecondAbsolute"

    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v15, v0, v1}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 142
    :cond_14
    filled-new-array/range {v22 .. v22}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v5, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 143
    const-string v0, "Playing"

    move-object/from16 v1, v33

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_16

    const-string v0, "Stopped"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    move-object v0, v7

    goto :goto_13

    :cond_15
    move-object/from16 v0, v19

    goto :goto_13

    :cond_16
    const-string v0, "Play"

    :goto_13
    const/4 v10, 0x0

    new-array v1, v10, [Ljava/lang/String;

    invoke-virtual {v9, v15, v0, v1}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    goto :goto_15

    :cond_17
    move-object v4, v10

    .line 126
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Recovery paused: device state must be checked before retrying"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_c

    :catch_c
    move-exception v0

    goto :goto_14

    :catch_d
    move-exception v0

    move-object v4, v10

    .line 146
    :goto_14
    invoke-virtual {v4, v0}, Ljava/lang/Exception;->addSuppressed(Ljava/lang/Throwable;)V

    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "recovery=unconfirmed original="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    goto :goto_15

    :cond_18
    move-object v4, v10

    .line 147
    :cond_19
    :goto_15
    throw v4
.end method
