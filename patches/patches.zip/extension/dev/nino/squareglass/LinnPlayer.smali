.class public final Ldev/nino/squareglass/LinnPlayer;
.super Ljava/lang/Object;
.source "LinnPlayer.java"

# interfaces
.implements Lcom/aspiro/wamp/player/k0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnPlayer$Action;
    }
.end annotation


# instance fields
.field volatile closed:Z

.field volatile device:Ldev/nino/squareglass/LinnProvider$Device;

.field volatile duration:I

.field final eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

.field events:Ldev/nino/squareglass/LinnEvents;

.field index:I

.field final nativeIndices:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field poll:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field volatile position:I

.field final previous:Lcom/aspiro/wamp/player/k0;

.field final provider:Ldev/nino/squareglass/LinnProvider;

.field final queue:Lcom/aspiro/wamp/playqueue/y;

.field final remote:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field repeat:Lcom/aspiro/wamp/enums/RepeatMode;

.field shuffled:Z

.field signature:Ljava/lang/String;

.field volatile state:Lcom/aspiro/wamp/enums/MusicServiceState;

.field syncing:Z

.field token:Ljava/lang/String;

.field final tracks:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/aspiro/wamp/model/MediaItem;",
            ">;"
        }
    .end annotation
.end field

.field volume:Landroidx/media/VolumeProviderCompat;

.field wasPlaying:Z


# direct methods
.method public static synthetic $r8$lambda$06ygxR2prpIA3SQ_YaOtcOdzbhk(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$1(Ldev/nino/squareglass/LinnPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$3EVJFE5eAxNeckTlyXjDtrpGUnM(Ldev/nino/squareglass/LinnPlayer;IZ)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer;->lambda$select$0(IZ)V

    return-void
.end method

.method public static synthetic $r8$lambda$59Gv1qLWi8l-Z1l0soaVLH97oKg(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$observe$1(Ldev/nino/squareglass/OpenHome;)V

    return-void
.end method

.method public static synthetic $r8$lambda$5hIf8FY9WMRN4AgZBuVy_kReqYE(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionPlay$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$Br1Hq9dv5kxtwVHHGBUS-kISeuk(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionPause$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$Iia6Oct-_GT5ocOZG5kOr0yWwoU(Ldev/nino/squareglass/LinnPlayer;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionSeekTo$0(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$KcPPpCtRTHOrP6spGDVHDDsIoqw(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$eventChanged$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$MhGCgF-1Os4P1cg2J5wmbCyRpwA(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$0(Ldev/nino/squareglass/LinnPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$QJCOtlWMsH5dcJTl0nD78UtF2xQ(Ldev/nino/squareglass/LinnPlayer;Ljava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$synchronize$2(Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$TNWXaqRX9fgCtjRrfHFrmvaFDpg(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$onActionStop$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$WwwhXSjzJgS0ppt_k6zAUCEb6qE(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;II)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->lambda$observe$0(Ldev/nino/squareglass/OpenHome;II)V

    return-void
.end method

.method public static synthetic $r8$lambda$YLk1UqFwthJYQXCFYNKGLSEpQLo(Ldev/nino/squareglass/LinnPlayer;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$skip$0(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ZvPwEXnUKDd_uAXdPGD6e-AoNUY(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$k_IUIeTL_UJHZSkK8TWBSYa7lQg(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer$Action;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->lambda$command$0(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method public static synthetic $r8$lambda$nMZ86Y3NyM-gB50ArR_Y7Hp3m4I(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;Ljava/util/List;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Ldev/nino/squareglass/LinnPlayer;->lambda$adoptRemote$0(Ljava/util/List;Ljava/util/List;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$q3wYKb7jgTqQ0_rwS6zA1R3CbF4(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$xG5ZdQ2JmtJ2AhtnvEHH5khC0z4(Ldev/nino/squareglass/LinnPlayer;)Ljava/lang/Void;
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnPlayer;->lambda$transfer$0()Ljava/lang/Void;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V
    .locals 1

    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    .line 25
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    .line 27
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 31
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 33
    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 34
    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    .line 39
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {p3}, Lcom/aspiro/wamp/player/k0;->getPlayQueue()Lcom/aspiro/wamp/playqueue/y;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    return-void
.end method

.method private synthetic lambda$adoptRemote$0(Ljava/util/List;Ljava/util/List;I)V
    .locals 2

    .line 216
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-eqz v0, :cond_0

    goto :goto_1

    .line 217
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1, p2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    const/4 p1, 0x0

    move p2, p1

    .line 218
    :goto_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p2, v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_1
    invoke-static {p1, p3}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 219
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->persist()V

    :cond_2
    :goto_1
    return-void
.end method

.method private synthetic lambda$command$0(Ldev/nino/squareglass/LinnPlayer$Action;)V
    .locals 0

    .line 222
    :try_start_0
    invoke-interface {p1}, Ldev/nino/squareglass/LinnPlayer$Action;->run()V

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->observe()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    const-string p1, "Linn command failed. Check the connection and retry."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$eventChanged$0()V
    .locals 2

    const/4 v0, 0x0

    .line 154
    :try_start_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->observe()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void

    :catchall_0
    move-exception v1

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    throw v1
.end method

.method private synthetic lambda$observe$0(Ldev/nino/squareglass/OpenHome;II)V
    .locals 2

    .line 176
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-eqz v0, :cond_0

    return-void

    .line 177
    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_3

    .line 178
    iget-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p2}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_1

    .line 179
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    new-instance p2, Ldev/nino/squareglass/LinnPlayer$20;

    invoke-direct {p2, p0, p1}, Ldev/nino/squareglass/LinnPlayer$20;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;)V

    invoke-virtual {p0, p2}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void

    .line 180
    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p1}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result p1

    iget-object p2, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object p3, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne p2, p3, :cond_2

    const/4 v1, 0x1

    :cond_2
    iget p2, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    invoke-virtual {p0, p1, v1, p2}, Ldev/nino/squareglass/LinnPlayer;->synchronize(IZI)V

    return-void

    :cond_3
    if-ltz p2, :cond_4

    .line 183
    iget p1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-eq p2, p1, :cond_4

    iput p2, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p1, p2, v1}, Lcom/aspiro/wamp/playqueue/y;->goTo(IZ)Lcom/aspiro/wamp/playqueue/u0;

    .line 184
    :cond_4
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget p2, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget v0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    invoke-static {p1, p2, v0}, Ldev/nino/squareglass/NativeLinnBridge;->publish(Lcom/aspiro/wamp/enums/MusicServiceState;II)V

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    invoke-virtual {p1, p3}, Landroidx/media/VolumeProviderCompat;->setCurrentVolume(I)V

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->nativeVolume:Ldev/nino/squareglass/LinnNativeVolume;

    invoke-virtual {p0, p3}, Ldev/nino/squareglass/LinnNativeVolume;->changed(I)V

    return-void
.end method

.method private synthetic lambda$observe$1(Ldev/nino/squareglass/OpenHome;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, 0x0

    .line 179
    new-array v1, v0, [Ljava/lang/String;

    const-string v2, "Playlist"

    const-string v3, "Stop"

    invoke-virtual {p1, v2, v3, v1}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    const-string v1, "DeleteAll"

    new-array v0, v0, [Ljava/lang/String;

    invoke-virtual {p1, v2, v1, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->clear()V

    return-void
.end method

.method private synthetic lambda$onActionPause$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 296
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Pause"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$onActionPlay$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 295
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Play"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$onActionSeekTo$0(I)V
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 301
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-static {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->seekConfirmed(Ldev/nino/squareglass/OpenHome;I)V

    return-void
.end method

.method private synthetic lambda$onActionStop$0()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 302
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "Stop"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$select$0(IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 242
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const-string v1, "Playlist"

    const-string v2, "SeekId"

    invoke-virtual {v0, v1, v2, p1}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    if-eqz p2, :cond_0

    const-string p1, "Play"

    goto :goto_0

    :cond_0
    const-string p1, "Pause"

    :goto_0
    const/4 p2, 0x0

    new-array p2, p2, [Ljava/lang/String;

    invoke-virtual {p0, v1, p1, p2}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    return-void
.end method

.method private synthetic lambda$skip$0(Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 297
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v0, "TransportState"

    const-string v1, "Playlist"

    invoke-virtual {p0, v1, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "Playing"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/String;

    invoke-virtual {p0, v1, p1, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    if-nez v0, :cond_0

    const-string p1, "Pause"

    new-array v0, v2, [Ljava/lang/String;

    invoke-virtual {p0, v1, p1, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    :cond_0
    return-void
.end method

.method private synthetic lambda$synchronize$0(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 2

    .line 230
    :try_start_0
    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->transfer()V

    .line 231
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$6;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnPlayer$6;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    .line 235
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$7;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnPlayer$7;-><init>(Ldev/nino/squareglass/LinnPlayer;Ljava/lang/Exception;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic lambda$synchronize$1(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 1

    .line 232
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->close()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iput-object p1, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    invoke-static {p1}, Ldev/nino/squareglass/NativeLinnBridge;->activate(Lcom/aspiro/wamp/player/k0;)V

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnPlayer;->start()V

    .line 233
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/aspiro/wamp/broadcast/l;

    invoke-interface {p1}, Lcom/aspiro/wamp/broadcast/l;->c()V

    goto :goto_0

    :cond_0
    return-void
.end method

.method private synthetic lambda$synchronize$2(Ljava/lang/Exception;)V
    .locals 1

    .line 235
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->restoreNativeQueue()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$transfer$0()Ljava/lang/Void;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 80
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getCurrentMediaPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {p0}, Lcom/aspiro/wamp/player/k0;->onActionPause()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private synthetic lambda$transfer$1()V
    .locals 1

    .line 120
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {p0}, Lcom/aspiro/wamp/player/k0;->onActionPlay()V

    :cond_0
    return-void
.end method

.method private synthetic lambda$transfer$2()V
    .locals 1

    .line 136
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {p0}, Lcom/aspiro/wamp/player/k0;->onActionPlay()V

    :cond_0
    return-void
.end method

.method static seekConfirmed(Ldev/nino/squareglass/OpenHome;I)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 142
    div-int/lit16 p1, p1, 0x3e8

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    move v1, v0

    :goto_0
    const/16 v2, 0x8

    if-ge v1, v2, :cond_1

    .line 144
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v2

    const-string v3, "Playlist"

    const-string v4, "SeekSecondAbsolute"

    invoke-virtual {p0, v3, v4, v2}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 145
    new-array v2, v0, [Ljava/lang/String;

    const-string v3, "Time"

    invoke-virtual {p0, v3, v3, v2}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v2

    const-string v3, "Seconds"

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    sub-int/2addr v2, p1

    .line 146
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v2

    const/4 v3, 0x2

    if-gt v2, v3, :cond_0

    return-void

    :cond_0
    const-wide/16 v2, 0x12c

    .line 147
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 149
    :cond_1
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Linn did not confirm the playback position."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method adoptRemote(Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 212
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->readRemoteTracks(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    .line 213
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v1}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, p1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    return-void

    .line 214
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v2, "Playlist"

    const-string v3, "Id"

    invoke-virtual {v1, v2, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v1

    .line 215
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v3, Ldev/nino/squareglass/LinnPlayer$14;

    invoke-direct {v3, p0, v0, p1, v1}, Ldev/nino/squareglass/LinnPlayer$14;-><init>(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;Ljava/util/List;I)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method capture()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 42
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    if-eqz v0, :cond_4

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4

    .line 43
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 44
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/aspiro/wamp/playqueue/u0;

    .line 45
    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v1

    .line 46
    instance-of v2, v1, Lcom/aspiro/wamp/model/Track;

    if-eqz v2, :cond_0

    move-object v2, v1

    check-cast v2, Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v2}, Lcom/aspiro/wamp/model/Track;->isUpload()Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {v1}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v2

    if-lez v2, :cond_0

    .line 48
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 47
    :cond_0
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "Linn supports online TIDAL music; this queue contains an unsupported item."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    .line 50
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getCurrentItemPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-ltz v0, :cond_3

    .line 51
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    .line 52
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getCurrentMediaPosition()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-interface {v0}, Lcom/aspiro/wamp/player/k0;->getState()Lcom/aspiro/wamp/enums/MusicServiceState;

    move-result-object v0

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_2

    const/4 v0, 0x1

    goto :goto_1

    :cond_2
    const/4 v0, 0x0

    :goto_1
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    .line 53
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->isShuffled()Z

    move-result v0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getRepeatMode()Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 54
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    return-void

    .line 51
    :cond_3
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "Current queue position is unavailable."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    .line 42
    :cond_4
    new-instance p0, Ljava/lang/Exception;

    const-string v0, "Open an online TIDAL track first."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method close()V
    .locals 2

    const/4 v0, 0x1

    .line 155
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledFuture;->cancel(Z)Z

    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnEvents;->close()V

    :cond_1
    return-void
.end method

.method command(Ldev/nino/squareglass/LinnPlayer$Action;)V
    .locals 2

    .line 222
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$19;

    invoke-direct {v1, p0, p1}, Ldev/nino/squareglass/LinnPlayer$19;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer$Action;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method eventChanged()V
    .locals 3

    .line 154
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->eventQueued:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$9;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnPlayer$9;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method

.method public getCurrentBitDepth()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentBitRate()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentCodec()Ljava/lang/String;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getCurrentMediaDuration()I
    .locals 0

    .line 313
    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    return p0
.end method

.method public getCurrentMediaPosition()I
    .locals 0

    .line 314
    iget p0, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    return p0
.end method

.method public getCurrentSampleRate()Ljava/lang/Integer;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getPlayQueue()Lcom/aspiro/wamp/playqueue/y;
    .locals 0

    .line 311
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    return-object p0
.end method

.method public getState()Lcom/aspiro/wamp/enums/MusicServiceState;
    .locals 0

    .line 312
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    return-object p0
.end method

.method public getVideoPlayerController()Lli/a;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public getVolumeProvider()Landroidx/media/VolumeProviderCompat;
    .locals 0

    .line 315
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    return-object p0
.end method

.method public isCurrentStreamAudioOnly()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isCurrentStreamDolbyAtmos()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamHiResLosslessQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamHighQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamLossless()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamLowQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamMasterQuality()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamOnline()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isCurrentStreamPaygatedPreview()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isCurrentStreamPreview()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isLocal()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public isRepeatSupported()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public isSeekingSupported()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method metadata(Lcom/aspiro/wamp/model/MediaItem;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 57
    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getDisplayTitle()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getArtistNames()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getArtistNames()Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 58
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\"><item id=\""

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "\" parentID=\"0\" restricted=\"1\"><dc:title>"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</dc:title><upnp:artist>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</upnp:artist><upnp:class>object.item.audioItem.musicTrack</upnp:class><res>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "</res></item></DIDL-Lite>"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method observe()V
    .locals 7

    .line 163
    const-string v0, "Volume"

    const-string v1, "Time"

    const-string v2, "Playlist"

    iget-boolean v3, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-eqz v3, :cond_0

    return-void

    .line 165
    :cond_0
    :try_start_0
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v3, v3, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    .line 166
    invoke-virtual {v3}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v4

    .line 167
    iget-object v5, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v4, v5}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    iget-boolean v5, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v5, :cond_1

    invoke-virtual {p0, v4}, Ldev/nino/squareglass/LinnPlayer;->adoptRemote(Ljava/util/List;)V

    return-void

    .line 168
    :cond_1
    const-string v4, "Id"

    invoke-virtual {v3, v2, v4}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    const/4 v6, 0x0

    .line 169
    new-array v6, v6, [Ljava/lang/String;

    invoke-virtual {v3, v1, v1, v6}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v1

    .line 170
    const-string v6, "Seconds"

    invoke-interface {v1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    mul-int/lit16 v6, v6, 0x3e8

    iput v6, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    const-string v6, "Duration"

    invoke-interface {v1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    mul-int/lit16 v1, v1, 0x3e8

    iput v1, p0, Ldev/nino/squareglass/LinnPlayer;->duration:I

    .line 171
    const-string v1, "TransportState"

    invoke-virtual {v3, v2, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 172
    const-string v2, "Playing"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_0

    :cond_2
    const-string v2, "Paused"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    goto :goto_0

    :cond_3
    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->STOPPED:Lcom/aspiro/wamp/enums/MusicServiceState;

    :goto_0
    iput-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    .line 173
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v1, v4, v5}, Ldev/nino/squareglass/LinnQueuePlan;->confirmedIndex(Ljava/util/List;J)I

    move-result v1

    if-gez v1, :cond_4

    const/4 v1, -0x1

    goto :goto_1

    :cond_4
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 174
    :goto_1
    invoke-virtual {v3, v0, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 175
    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, v2, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v4, Ldev/nino/squareglass/LinnPlayer$13;

    invoke-direct {v4, p0, v3, v1, v0}, Ldev/nino/squareglass/LinnPlayer$13;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/OpenHome;II)V

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 186
    :catch_0
    sget-object v0, Lcom/aspiro/wamp/enums/MusicServiceState;->PAUSED:Lcom/aspiro/wamp/enums/MusicServiceState;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    const-string v1, "Linn connection lost. Local playback remains paused. Retry the output connection."

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->close()V

    return-void
.end method

.method public onActionNext()V
    .locals 2

    .line 299
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v1, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->singleSkip(Z)V

    return-void

    :cond_0
    const-string v0, "Next"

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->skip(Ljava/lang/String;)V

    return-void
.end method

.method public onActionPause()V
    .locals 1

    .line 296
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$15;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnPlayer$15;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method public onActionPlay()V
    .locals 1

    .line 295
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$5;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/LinnPlayer$5;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method public onActionPlayPosition(IZZ)V
    .locals 0

    .line 304
    invoke-virtual {p0, p1, p3}, Ldev/nino/squareglass/LinnPlayer;->select(IZ)V

    return-void
.end method

.method public onActionPrevious(Z)V
    .locals 1

    if-nez p1, :cond_0

    .line 300
    iget p1, p0, Ldev/nino/squareglass/LinnPlayer;->position:I

    const/16 v0, 0x1388

    if-le p1, v0, :cond_0

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->onActionSeekTo(I)V

    return-void

    :cond_0
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-ne p1, v0, :cond_1

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->singleSkip(Z)V

    return-void

    :cond_1
    const-string p1, "Previous"

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->skip(Ljava/lang/String;)V

    return-void
.end method

.method public onActionSeekTo(I)V
    .locals 1

    .line 301
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$10;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/LinnPlayer$10;-><init>(Ldev/nino/squareglass/LinnPlayer;I)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method public onActionStop(Lcom/aspiro/wamp/player/PlaybackEndReason;)V
    .locals 0

    .line 302
    new-instance p1, Ldev/nino/squareglass/LinnPlayer$16;

    invoke-direct {p1, p0}, Ldev/nino/squareglass/LinnPlayer$16;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method public onActionTogglePlayback()V
    .locals 2

    .line 303
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->onActionPause()V

    return-void

    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->onActionPlay()V

    return-void
.end method

.method public onActionWifiQualityChanged()V
    .locals 0

    return-void
.end method

.method public onActivated(ILcom/aspiro/wamp/player/k0;)V
    .locals 0

    return-void
.end method

.method public onDeactivated()V
    .locals 0

    return-void
.end method

.method public onServicePreEnterForeground()V
    .locals 0

    return-void
.end method

.method public onServicePreLeaveForeground()V
    .locals 0

    return-void
.end method

.method public onTaskRemoved()V
    .locals 0

    return-void
.end method

.method persist()V
    .locals 5

    .line 246
    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/model/MediaItem;

    new-instance v3, Lcom/aspiro/wamp/model/Track;

    check-cast v2, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v3, v2}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    const/4 v2, 0x0

    invoke-virtual {v3, v2}, Lcom/aspiro/wamp/model/Track;->setSource(Lcom/aspiro/wamp/playqueue/source/model/Source;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 247
    :cond_0
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v2, Ljava/io/ObjectOutputStream;

    invoke-direct {v2, v1}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {v2, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V

    .line 248
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v0

    const/high16 v2, 0x400000

    if-gt v0, v2, :cond_2

    .line 249
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    :goto_1
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_1

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v4, 0x3a

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v4, 0x2c

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 250
    :cond_1
    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v3, v3, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v4, "squareglass_linn"

    invoke-virtual {v3, v4, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "sessionUuid"

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v4, v4, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v4, v4, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "queue"

    .line 251
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    const/4 v4, 0x2

    invoke-static {v1, v4}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "mapping"

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "shuffled"

    iget-boolean v2, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    .line 252
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "repeat"

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    invoke-virtual {v2}, Lcom/aspiro/wamp/enums/RepeatMode;->name()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    .line 248
    :cond_2
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Queue snapshot too large"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catchall_0
    move-exception v0

    .line 247
    :try_start_3
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v1

    :try_start_4
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 253
    :catch_0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    const-string v0, "Linn is connected; saving its reconnect state failed."

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    return-void
.end method

.method readRemoteTracks(Ljava/util/List;)Ljava/util/List;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/aspiro/wamp/model/MediaItem;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 190
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 191
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v1, p1}, Ldev/nino/squareglass/OpenHome;->readTracks(Ljava/util/List;)Ljava/util/Map;

    move-result-object v1

    .line 192
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 193
    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    .line 194
    new-instance v3, Ljava/net/URI;

    const-string v4, "Uri"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-direct {v3, v4}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 195
    const-string v4, "tidal"

    invoke-virtual {v3}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    .line 196
    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v3}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v3

    const-string v5, "&"

    invoke-virtual {v3, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v5, v3

    const/4 v6, 0x0

    move v7, v6

    :goto_1
    const/4 v8, 0x1

    if-ge v7, v5, :cond_1

    aget-object v9, v3, v7

    .line 197
    const-string v10, "="

    const/4 v11, 0x2

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v9

    array-length v10, v9

    if-ne v10, v11, :cond_0

    aget-object v10, v9, v6

    aget-object v8, v9, v8

    const-string v9, "UTF-8"

    invoke-static {v8, v9}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v4, v10, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 199
    :cond_1
    const-string v3, "trackId"

    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    .line 200
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/aspiro/wamp/model/MediaItem;

    invoke-virtual {v5}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v6

    if-ne v6, v3, :cond_2

    new-instance v4, Lcom/aspiro/wamp/model/Track;

    check-cast v5, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v4, v5}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    goto :goto_2

    :cond_3
    const/4 v4, 0x0

    :goto_2
    if-nez v4, :cond_4

    .line 202
    const-string v4, "Metadata"

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v2, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v2

    invoke-static {v2}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object v2

    invoke-interface {v2}, Lorg/w3c/dom/Document;->getDocumentElement()Lorg/w3c/dom/Element;

    move-result-object v2

    .line 203
    new-instance v4, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v4}, Lcom/aspiro/wamp/model/Track;-><init>()V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setId(I)V

    const-string v3, "title"

    invoke-static {v2, v3}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setTitle(Ljava/lang/String;)V

    .line 204
    new-instance v3, Lcom/aspiro/wamp/model/Artist;

    invoke-direct {v3}, Lcom/aspiro/wamp/model/Artist;-><init>()V

    const-string v5, "artist"

    invoke-static {v2, v5}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/aspiro/wamp/model/Artist;->setName(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setArtist(Lcom/aspiro/wamp/model/Artist;)V

    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setArtists(Ljava/util/List;)V

    .line 205
    new-instance v3, Lcom/aspiro/wamp/model/Album;

    invoke-direct {v3}, Lcom/aspiro/wamp/model/Album;-><init>()V

    const-string v5, "album"

    invoke-static {v2, v5}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/aspiro/wamp/model/Album;->setTitle(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Lcom/aspiro/wamp/model/Track;->setAlbum(Lcom/aspiro/wamp/model/Album;)V

    invoke-virtual {v4, v8}, Lcom/aspiro/wamp/model/Track;->setAllowStreaming(Z)V

    invoke-virtual {v4, v8}, Lcom/aspiro/wamp/model/Track;->setStreamReady(Z)V

    .line 207
    :cond_4
    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 195
    :cond_5
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Linn queue now contains non-TIDAL content; its playback was left untouched."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_6
    return-object v0
.end method

.method readdress(Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 8

    .line 157
    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnEvents;->close()V

    .line 158
    :cond_0
    new-instance p1, Ldev/nino/squareglass/LinnEvents;

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-instance v1, Ldev/nino/squareglass/LinnPlayer$12;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnPlayer$12;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {p1, v0, v1}, Ldev/nino/squareglass/LinnEvents;-><init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;)V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    invoke-virtual {p1}, Ldev/nino/squareglass/LinnEvents;->start()V

    .line 159
    iget-boolean p1, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    const/4 v0, 0x0

    if-eqz p1, :cond_1

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, p1, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$11;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$11;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    const-wide/16 v5, 0x1

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x0

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    .line 160
    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p1, p1, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    invoke-virtual {p1, v1, v0}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object p0, p0, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    const-string v0, "location"

    invoke-interface {p1, v0, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method reattach()V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 257
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->app:Landroid/app/Application;

    const-string v1, "squareglass_linn"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 258
    const-string v1, "shuffled"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    const-string v1, "repeat"

    const-string v3, "OFF"

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/aspiro/wamp/enums/RepeatMode;->valueOf(Ljava/lang/String;)Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 259
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    iget-object v1, v1, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    const-string v3, "sessionUuid"

    const-string v4, ""

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    .line 260
    const-string v1, "queue"

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    invoke-static {v1, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    .line 261
    array-length v5, v1

    const/high16 v6, 0x400000

    if-gt v5, v6, :cond_8

    .line 262
    new-instance v5, Ljava/io/ObjectInputStream;

    new-instance v6, Ljava/io/ByteArrayInputStream;

    invoke-direct {v6, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v5, v6}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    :try_start_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-virtual {v5}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/List;

    invoke-interface {v1, v6}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v5}, Ljava/io/ObjectInputStream;->close()V

    .line 263
    const-string v1, "mapping"

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ","

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v1, v0

    move v4, v2

    :goto_0
    if-ge v4, v1, :cond_2

    aget-object v5, v0, v4

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_1

    .line 264
    const-string v6, ":"

    invoke-virtual {v5, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    aget-object v7, v5, v2

    invoke-static {v7}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    aget-object v5, v5, v6

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    if-ltz v5, :cond_0

    .line 265
    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge v5, v6, :cond_0

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v6, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid queue mapping"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 267
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v0}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    .line 268
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    .line 269
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->readRemoteTracks(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    .line 270
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v4, v4, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    invoke-virtual {v4}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, v0}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 271
    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->clear()V

    iget-object v4, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v4, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 272
    :goto_2
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge v2, v0, :cond_4

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    .line 270
    :cond_3
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Linn queue is changing. Retry reconnecting."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 274
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Shuffle"

    const-string v2, "Playlist"

    invoke-virtual {v0, v2, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    .line 275
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v4, "Repeat"

    invoke-virtual {v0, v2, v4}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    goto :goto_3

    .line 276
    :cond_5
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v1, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-eq v0, v1, :cond_6

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->ALL:Lcom/aspiro/wamp/enums/RepeatMode;

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    .line 277
    :cond_6
    :goto_3
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Id"

    invoke-virtual {v0, v2, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    if-ltz v0, :cond_7

    .line 278
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    .line 279
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v1, "Volume"

    invoke-virtual {v0, v1, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 280
    new-instance v1, Ldev/nino/squareglass/LinnPlayer$2;

    const/16 v2, 0x64

    invoke-direct {v1, p0, v3, v2, v0}, Ldev/nino/squareglass/LinnPlayer$2;-><init>(Ldev/nino/squareglass/LinnPlayer;III)V

    iput-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    return-void

    .line 278
    :cond_7
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Linn current track is unavailable"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :catchall_0
    move-exception p0

    .line 262
    :try_start_1
    invoke-virtual {v5}, Ljava/io/ObjectInputStream;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_4

    :catchall_1
    move-exception v0

    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw p0

    .line 261
    :cond_8
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid queue snapshot"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 259
    :cond_9
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Different Linn session"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method restoreNativeQueue()V
    .locals 9

    .line 286
    new-instance v0, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;

    sget-object v1, Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType$None;->INSTANCE:Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType$None;

    const/4 v2, 0x0

    const-string v3, "squareglass-linn"

    const-string v4, "Linn queue"

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/aspiro/wamp/playqueue/source/model/ItemSource$NavigationType;Lcom/tidal/android/navigation/NavigationInfo$Node;)V

    .line 287
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/model/MediaItem;

    new-instance v3, Lcom/aspiro/wamp/model/Track;

    check-cast v2, Lcom/aspiro/wamp/model/Track;

    invoke-direct {v3, v2}, Lcom/aspiro/wamp/model/Track;-><init>(Lcom/aspiro/wamp/model/Track;)V

    invoke-virtual {v0, v3}, Lcom/aspiro/wamp/playqueue/source/model/ItemSource;->addSourceItem(Lcom/aspiro/wamp/model/MediaItem;)V

    goto :goto_0

    .line 290
    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    new-instance v2, Lcom/aspiro/wamp/playqueue/w0;

    iget v3, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    sget-object v5, Lcom/aspiro/wamp/enums/ShuffleMode;->TURN_OFF:Lcom/aspiro/wamp/enums/ShuffleMode;

    iget-object v6, p0, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v4, 0x0

    invoke-direct/range {v2 .. v8}, Lcom/aspiro/wamp/playqueue/w0;-><init>(IZLcom/aspiro/wamp/enums/ShuffleMode;Lcom/aspiro/wamp/enums/RepeatMode;ZZ)V

    invoke-interface {v1, v0, v2}, Lcom/aspiro/wamp/playqueue/y;->prepare(Lcom/aspiro/wamp/playqueue/source/model/Source;Lcom/aspiro/wamp/playqueue/w0;)V

    .line 291
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    iget-boolean v1, p0, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    invoke-static {v0, v1}, Ldev/nino/squareglass/NativeLinnBridge;->restoreShuffle(Lcom/aspiro/wamp/playqueue/y;Z)V

    .line 292
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer;->index:I

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Lcom/aspiro/wamp/playqueue/y;->goTo(IZ)Lcom/aspiro/wamp/playqueue/u0;

    .line 293
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    return-void
.end method

.method select(IZ)V
    .locals 2

    if-ltz p1, :cond_3

    .line 239
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v0}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lt p1, v0, :cond_0

    goto :goto_1

    .line 240
    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->snapshotSignature()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->signature:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 241
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {v0, p1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result p1

    .line 242
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$17;

    invoke-direct {v0, p0, p1, p2}, Ldev/nino/squareglass/LinnPlayer$17;-><init>(Ldev/nino/squareglass/LinnPlayer;IZ)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void

    :cond_2
    :goto_0
    const/4 v0, 0x0

    .line 240
    invoke-virtual {p0, p1, p2, v0}, Ldev/nino/squareglass/LinnPlayer;->synchronize(IZI)V

    :cond_3
    :goto_1
    return-void
.end method

.method singleSkip(Z)V
    .locals 2

    .line 298
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-static {v0, p1}, Ldev/nino/squareglass/NativeLinnBridge;->skip(Lcom/aspiro/wamp/playqueue/y;Z)I

    move-result p1

    if-ltz p1, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->state:Lcom/aspiro/wamp/enums/MusicServiceState;

    sget-object v1, Lcom/aspiro/wamp/enums/MusicServiceState;->PLAYING:Lcom/aspiro/wamp/enums/MusicServiceState;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, p1, v0}, Ldev/nino/squareglass/LinnPlayer;->select(IZ)V

    :cond_1
    return-void
.end method

.method skip(Ljava/lang/String;)V
    .locals 1

    .line 297
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$8;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/LinnPlayer$8;-><init>(Ldev/nino/squareglass/LinnPlayer;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/LinnPlayer;->command(Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method

.method snapshotSignature()Ljava/lang/String;
    .locals 5

    .line 151
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/y;->getItems()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/16 v3, 0x3a

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/aspiro/wamp/playqueue/u0;

    invoke-interface {v2}, Lcom/aspiro/wamp/playqueue/u0;->getUid()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-interface {v2}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v2

    invoke-virtual {v2}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v2, 0x2c

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {v1}, Lcom/aspiro/wamp/playqueue/y;->isShuffled()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->queue:Lcom/aspiro/wamp/playqueue/y;

    invoke-interface {p0}, Lcom/aspiro/wamp/playqueue/y;->getRepeatMode()Lcom/aspiro/wamp/enums/RepeatMode;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method start()V
    .locals 8

    .line 152
    invoke-virtual {p0}, Ldev/nino/squareglass/LinnPlayer;->persist()V

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, v0, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$11;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$11;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    const-wide/16 v5, 0x1

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x0

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->poll:Ljava/util/concurrent/ScheduledFuture;

    .line 153
    new-instance v0, Ldev/nino/squareglass/LinnEvents;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v1, v1, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$12;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/LinnPlayer$12;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/LinnEvents;-><init>(Ldev/nino/squareglass/OpenHome;Ljava/lang/Runnable;)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->events:Ldev/nino/squareglass/LinnEvents;

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnEvents;->start()V

    return-void
.end method

.method synchronize(IZI)V
    .locals 4

    .line 224
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->closed:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    .line 225
    new-instance v0, Ldev/nino/squareglass/LinnPlayer;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v3, p0, Ldev/nino/squareglass/LinnPlayer;->previous:Lcom/aspiro/wamp/player/k0;

    invoke-direct {v0, v1, v2, v3}, Ldev/nino/squareglass/LinnPlayer;-><init>(Ldev/nino/squareglass/LinnProvider;Ldev/nino/squareglass/LinnProvider$Device;Lcom/aspiro/wamp/player/k0;)V

    .line 226
    :try_start_0
    invoke-virtual {v0}, Ldev/nino/squareglass/LinnPlayer;->capture()V

    iput p1, v0, Ldev/nino/squareglass/LinnPlayer;->index:I

    iput-boolean p2, v0, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    iput p3, v0, Ldev/nino/squareglass/LinnPlayer;->position:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 228
    iget-object p1, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p1, p1, Ldev/nino/squareglass/LinnProvider;->io:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance p2, Ldev/nino/squareglass/LinnPlayer$18;

    invoke-direct {p2, p0, v0}, Ldev/nino/squareglass/LinnPlayer$18;-><init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V

    invoke-interface {p1, p2}, Ljava/util/concurrent/ScheduledExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    :catch_0
    move-exception p1

    const/4 p2, 0x0

    .line 227
    iput-boolean p2, p0, Ldev/nino/squareglass/LinnPlayer;->syncing:Z

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnProvider;->fail(Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method transfer()V
    .locals 31
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v1, p0

    .line 61
    const-string v2, "NewId"

    const-string v3, "Insert"

    const-string v4, "Play"

    const-string v5, "SeekId"

    const-string v6, "Playing"

    const-string v7, "DeleteId"

    const-string v8, "0"

    const-string v9, "Pause"

    const-string v0, "Preparing Linn queue\u2026"

    invoke-static {v0}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V

    .line 62
    iget-object v10, v1, Ldev/nino/squareglass/LinnPlayer;->device:Ldev/nino/squareglass/LinnProvider$Device;

    iget-object v10, v10, Ldev/nino/squareglass/LinnProvider$Device;->transport:Ldev/nino/squareglass/OpenHome;

    const-string v11, "TracksMax"

    const-string v12, "Playlist"

    invoke-virtual {v10, v12, v11}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    .line 63
    const-string v13, "Queue capacity read"

    const-string v14, "SquareLinn"

    invoke-static {v14, v13}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 64
    invoke-virtual {v10}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v13

    .line 65
    iget-object v15, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    move-object/from16 v16, v0

    sget-object v0, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    const/16 v17, 0x1

    if-ne v15, v0, :cond_0

    move/from16 v0, v17

    goto :goto_0

    :cond_0
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 66
    :goto_0
    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v15

    invoke-static {v15, v0, v11}, Ldev/nino/squareglass/LinnQueuePlan;->capacity(III)V

    .line 67
    invoke-virtual {v10}, Ldev/nino/squareglass/OpenHome;->tidalTokenId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->token:Ljava/lang/String;

    const-string v0, "SourceIndex"

    const-string v11, "Product"

    invoke-virtual {v10, v11, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 68
    const-string v0, "Device TIDAL login verified"

    invoke-static {v14, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 69
    const-string v0, "TransportState"

    move-object/from16 v18, v15

    invoke-virtual {v10, v12, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v19, v6

    const-string v6, "Id"

    move-object/from16 v20, v15

    invoke-virtual {v10, v12, v6}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 71
    invoke-virtual {v10, v13}, Ldev/nino/squareglass/OpenHome;->readTracks(Ljava/util/List;)Ljava/util/Map;

    move-result-object v21

    .line 72
    invoke-static/range {v16 .. v16}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V

    move-object/from16 v16, v8

    const/4 v8, 0x0

    move-object/from16 v22, v15

    .line 73
    new-array v15, v8, [Ljava/lang/String;

    const-string v8, "Time"

    invoke-virtual {v10, v8, v8, v15}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v15

    move-object/from16 v23, v14

    const-string v14, "Seconds"

    invoke-interface {v15, v14}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    invoke-static {v15}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v15

    move/from16 v24, v15

    .line 74
    const-string v15, "Volume"

    invoke-virtual {v10, v15, v15}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v15

    const-wide/16 v25, 0x0

    move/from16 v27, v15

    .line 76
    :try_start_0
    iget-object v15, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v15, v15, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    if-eqz v15, :cond_1

    move-object/from16 v28, v7

    const/4 v15, 0x0

    .line 77
    :try_start_1
    new-array v7, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v9, v7}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 78
    iget v7, v1, Ldev/nino/squareglass/LinnPlayer;->position:I

    if-lez v7, :cond_2

    new-array v7, v15, [Ljava/lang/String;

    invoke-virtual {v10, v8, v8, v7}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v7

    invoke-interface {v7, v14}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    mul-int/lit16 v7, v7, 0x3e8

    iput v7, v1, Ldev/nino/squareglass/LinnPlayer;->position:I

    goto :goto_1

    :cond_1
    move-object/from16 v28, v7

    .line 80
    :cond_2
    :goto_1
    new-instance v7, Ljava/util/concurrent/FutureTask;

    new-instance v8, Ldev/nino/squareglass/LinnPlayer$0;

    invoke-direct {v8, v1}, Ldev/nino/squareglass/LinnPlayer$0;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-direct {v7, v8}, Ljava/util/concurrent/FutureTask;-><init>(Ljava/util/concurrent/Callable;)V

    .line 81
    iget-object v8, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v8, v8, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    invoke-virtual {v8, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    sget-object v8, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v14, 0x5

    invoke-virtual {v7, v14, v15, v8}, Ljava/util/concurrent/FutureTask;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 82
    invoke-interface {v13}, Ljava/util/List;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_3

    move-wide/from16 v7, v25

    goto :goto_2

    :cond_3
    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v7

    add-int/lit8 v7, v7, -0x1

    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Long;

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    :goto_2
    const/4 v14, 0x0

    .line 83
    :goto_3
    iget-object v15, v1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v15}, Ljava/util/List;->size()I

    move-result v15

    if-ge v14, v15, :cond_5

    .line 84
    iget-object v15, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    move-wide/from16 v29, v7

    sget-object v7, Lcom/aspiro/wamp/enums/RepeatMode;->SINGLE:Lcom/aspiro/wamp/enums/RepeatMode;

    if-ne v15, v7, :cond_4

    iget v7, v1, Ldev/nino/squareglass/LinnPlayer;->index:I

    if-eq v14, v7, :cond_4

    :goto_4
    move-wide/from16 v7, v29

    goto :goto_5

    .line 85
    :cond_4
    iget-object v7, v1, Ldev/nino/squareglass/LinnPlayer;->tracks:Ljava/util/List;

    invoke-interface {v7, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/aspiro/wamp/model/MediaItem;

    .line 86
    invoke-virtual {v7}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v8

    iget-object v15, v1, Ldev/nino/squareglass/LinnPlayer;->token:Ljava/lang/String;

    invoke-static {v8, v15}, Ldev/nino/squareglass/OpenHome;->tidalUri(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 87
    invoke-static/range {v29 .. v30}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v1, v7, v8}, Ldev/nino/squareglass/LinnPlayer;->metadata(Lcom/aspiro/wamp/model/MediaItem;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    filled-new-array {v15, v8, v7}, [Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v10, v12, v3, v7}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v7

    invoke-interface {v7, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-static {v7}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    .line 88
    iget-object v15, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    move-wide/from16 v29, v7

    invoke-static/range {v29 .. v30}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-interface {v15, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 89
    iget-object v7, v1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 90
    const-string v7, "Transferring queue to Linn\u2026"

    invoke-static {v7}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V

    goto :goto_4

    :goto_5
    add-int/lit8 v14, v14, 0x1

    goto :goto_3

    .line 93
    :cond_5
    invoke-virtual {v10}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v7

    iget-object v8, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-static {v13, v8}, Ldev/nino/squareglass/LinnQueuePlan;->expected(Ljava/util/List;Ljava/util/List;)Ljava/util/List;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_d

    const/4 v15, 0x0

    .line 94
    new-array v7, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v9, v7}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 95
    const-string v7, "SetSourceIndexByName"

    filled-new-array {v12}, [Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v11, v7, v8}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 96
    iget-object v7, v1, Ldev/nino/squareglass/LinnPlayer;->nativeIndices:Ljava/util/List;

    iget v8, v1, Ldev/nino/squareglass/LinnPlayer;->index:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v7

    .line 97
    const-string v8, "SetRepeat"

    iget-object v14, v1, Ldev/nino/squareglass/LinnPlayer;->repeat:Lcom/aspiro/wamp/enums/RepeatMode;

    sget-object v15, Lcom/aspiro/wamp/enums/RepeatMode;->OFF:Lcom/aspiro/wamp/enums/RepeatMode;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3

    const-string v29, "1"

    if-ne v14, v15, :cond_6

    move-object/from16 v14, v16

    goto :goto_6

    :cond_6
    move-object/from16 v14, v29

    :goto_6
    :try_start_2
    filled-new-array {v14}, [Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v10, v12, v8, v14}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 98
    const-string v8, "SetShuffle"

    iget-boolean v14, v1, Ldev/nino/squareglass/LinnPlayer;->shuffled:Z

    if-eqz v14, :cond_7

    goto :goto_7

    :cond_7
    move-object/from16 v29, v16

    :goto_7
    filled-new-array/range {v29 .. v29}, [Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v10, v12, v8, v14}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 99
    iget-object v8, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Long;

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v8

    filled-new-array {v8}, [Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v12, v5, v8}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    const/4 v15, 0x0

    .line 100
    new-array v8, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v9, v8}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 101
    iget v8, v1, Ldev/nino/squareglass/LinnPlayer;->position:I

    invoke-static {v10, v8}, Ldev/nino/squareglass/LinnPlayer;->seekConfirmed(Ldev/nino/squareglass/OpenHome;I)V

    .line 102
    iget-boolean v8, v1, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3

    if-eqz v8, :cond_8

    :try_start_3
    new-array v8, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v4, v8}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_8

    :catch_0
    move-exception v0

    move/from16 v17, v15

    move-object/from16 v7, v28

    goto/16 :goto_d

    .line 103
    :cond_8
    :try_start_4
    new-array v8, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v9, v8}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 104
    :goto_8
    invoke-virtual {v10, v12, v6}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 105
    iget-object v8, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Long;

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_c

    .line 106
    invoke-virtual {v10, v12, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-boolean v6, v1, Ldev/nino/squareglass/LinnPlayer;->wasPlaying:Z

    if-eqz v6, :cond_9

    move-object/from16 v6, v19

    goto :goto_9

    :cond_9
    const-string v6, "Paused"

    :goto_9
    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 107
    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Long;

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v6

    filled-new-array {v6}, [Ljava/lang/String;

    move-result-object v6
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    move-object/from16 v7, v28

    :try_start_5
    invoke-virtual {v10, v12, v7, v6}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    const-string v6, "Finishing Linn connection\u2026"

    invoke-static {v6}, Ldev/nino/squareglass/SquareOutput;->linnProgress(Ljava/lang/String;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_4

    move-object/from16 v28, v7

    goto :goto_a

    :cond_a
    move-object/from16 v7, v28

    .line 109
    :try_start_6
    const-string v0, "Device queue committed; creating remote volume adapter"

    move-object/from16 v6, v23

    invoke-static {v6, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 110
    new-instance v0, Ldev/nino/squareglass/LinnPlayer$1;

    const/4 v8, 0x2

    const/16 v14, 0x64

    move/from16 v15, v27

    invoke-direct {v0, v1, v8, v14, v15}, Ldev/nino/squareglass/LinnPlayer$1;-><init>(Ldev/nino/squareglass/LinnPlayer;III)V

    iput-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    .line 114
    const-string v0, "Queue transfer complete"

    invoke-static {v6, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    return-void

    :catch_1
    move-exception v0

    const/4 v15, 0x0

    goto :goto_d

    :cond_b
    move-object/from16 v7, v28

    .line 106
    :try_start_7
    new-instance v0, Ljava/lang/Exception;

    const-string v6, "Linn did not confirm the playback state."

    invoke-direct {v0, v6}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_c
    move-object/from16 v7, v28

    .line 105
    new-instance v0, Ljava/lang/Exception;

    const-string v6, "Linn did not confirm the selected track."

    invoke-direct {v0, v6}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_4

    :cond_d
    move-object/from16 v7, v28

    .line 93
    :try_start_8
    new-instance v0, Ljava/lang/Exception;

    const-string v6, "Linn queue changed during transfer. Retry."

    invoke-direct {v0, v6}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_2

    :catch_2
    move-exception v0

    move/from16 v15, v17

    goto :goto_c

    :catch_3
    move-exception v0

    move-object/from16 v7, v28

    goto :goto_b

    :catch_4
    move-exception v0

    :goto_b
    const/4 v15, 0x0

    :goto_c
    const/16 v17, 0x0

    :goto_d
    if-nez v17, :cond_18

    .line 117
    const-string v6, "Stop"

    if-nez v15, :cond_e

    const/4 v8, 0x0

    new-array v14, v8, [Ljava/lang/String;

    invoke-virtual {v10, v12, v6, v14}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 118
    :cond_e
    invoke-virtual {v10}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v8

    .line 119
    iget-object v14, v1, Ldev/nino/squareglass/LinnPlayer;->remote:Ljava/util/List;

    invoke-interface {v14}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_e
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_10

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v23, v0

    move-object/from16 v0, v17

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v27

    invoke-interface {v8, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-static/range {v27 .. v28}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v10, v12, v7, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    :cond_f
    move-object/from16 v0, v23

    goto :goto_e

    :cond_10
    move-object/from16 v23, v0

    if-nez v15, :cond_17

    if-nez v15, :cond_13

    .line 121
    invoke-virtual {v10}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v13}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_13

    .line 123
    const-string v0, "DeleteAll"

    const/4 v15, 0x0

    new-array v7, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v0, v7}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 124
    invoke-interface/range {v21 .. v21}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move-object/from16 v7, v16

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_12

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/Map$Entry;

    .line 125
    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/util/Map;

    .line 126
    invoke-static/range {v25 .. v26}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v14

    const-string v15, "Uri"

    invoke-interface {v13, v15}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    move-object/from16 v17, v0

    const-string v0, "Metadata"

    invoke-interface {v13, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    filled-new-array {v14, v15, v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v10, v12, v3, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v25

    .line 127
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->toString()Ljava/lang/String;

    move-result-object v0

    move-object/from16 v8, v22

    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    invoke-static/range {v25 .. v26}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v7

    :cond_11
    move-object/from16 v22, v8

    move-object/from16 v0, v17

    goto :goto_f

    :cond_12
    move-object v15, v7

    goto :goto_10

    :cond_13
    move-object/from16 v8, v22

    move-object v15, v8

    :goto_10
    move-object/from16 v2, v16

    .line 131
    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_14

    filled-new-array {v15}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v10, v12, v5, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const-string v2, "SeekSecondAbsolute"

    invoke-virtual {v10, v12, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 132
    :cond_14
    const-string v0, "SetSourceIndex"

    filled-new-array/range {v18 .. v18}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v11, v0, v2}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-object/from16 v3, v19

    move-object/from16 v2, v20

    .line 133
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_16

    .line 134
    const-string v0, "Stopped"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    const/4 v15, 0x0

    new-array v0, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v6, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    goto :goto_11

    :cond_15
    const/4 v15, 0x0

    .line 135
    new-array v0, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v9, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    goto :goto_11

    :cond_16
    const/4 v15, 0x0

    .line 133
    new-array v0, v15, [Ljava/lang/String;

    invoke-virtual {v10, v12, v4, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 136
    :goto_11
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$4;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/LinnPlayer$4;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_12

    .line 120
    :cond_17
    iget-object v0, v1, Ldev/nino/squareglass/LinnPlayer;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v2, Ldev/nino/squareglass/LinnPlayer$3;

    invoke-direct {v2, v1}, Ldev/nino/squareglass/LinnPlayer$3;-><init>(Ldev/nino/squareglass/LinnPlayer;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    throw v23

    :cond_18
    move-object/from16 v23, v0

    .line 138
    :goto_12
    throw v23
.end method
