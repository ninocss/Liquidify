.class public final synthetic Ldev/nino/squareglass/NativeGlass$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/graphics/Shape;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/graphics/Shape;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeGlass$$ExternalSyntheticLambda0;->f$0:Landroidx/compose/ui/graphics/Shape;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/NativeGlass$$ExternalSyntheticLambda0;->f$0:Landroidx/compose/ui/graphics/Shape;

    invoke-static {p0}, Ldev/nino/squareglass/NativeGlass;->$r8$lambda$ZCIpaH-rNi_qW6xlxuy_zsjbUlY(Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    return-object p0
.end method
