.class public final synthetic Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Lam0/a;

.field public final synthetic f$1:Lam0/p;

.field public final synthetic f$2:I


# direct methods
.method public synthetic constructor <init>(Lam0/a;Lam0/p;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda6;->f$0:Lam0/a;

    iput-object p2, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda6;->f$1:Lam0/p;

    iput p3, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda6;->f$2:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda6;->f$0:Lam0/a;

    iget-object v1, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda6;->f$1:Lam0/p;

    iget p0, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda6;->f$2:I

    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {v0, v1, p0, p1, p2}, Ldev/nino/squareglass/GlassProbe;->$r8$lambda$PWxt8AAUX8PlD927cVWVfA9Wip0(Lam0/a;Lam0/p;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
