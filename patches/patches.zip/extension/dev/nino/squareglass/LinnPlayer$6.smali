.class public final synthetic Ldev/nino/squareglass/LinnPlayer$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:Ldev/nino/squareglass/LinnPlayer;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$1:Ldev/nino/squareglass/LinnPlayer;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$6;->f$1:Ldev/nino/squareglass/LinnPlayer;

    invoke-static {v0, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$06ygxR2prpIA3SQ_YaOtcOdzbhk(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer;)V

    return-void
.end method
