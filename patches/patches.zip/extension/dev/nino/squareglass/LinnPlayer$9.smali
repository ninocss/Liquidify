.class public final synthetic Ldev/nino/squareglass/LinnPlayer$9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ldev/nino/squareglass/LinnPlayer$Action;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$9;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput p2, p0, Ldev/nino/squareglass/LinnPlayer$9;->f$1:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$9;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget p0, p0, Ldev/nino/squareglass/LinnPlayer$9;->f$1:I

    invoke-static {v0, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$Iia6Oct-_GT5ocOZG5kOr0yWwoU(Ldev/nino/squareglass/LinnPlayer;I)V

    return-void
.end method
