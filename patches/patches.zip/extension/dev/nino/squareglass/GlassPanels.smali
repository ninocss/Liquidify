.class public final Ldev/nino/squareglass/GlassPanels;
.super Ljava/lang/Object;
.source "GlassPanels.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nGlassPanels.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GlassPanels.kt\ndev/nino/squareglass/GlassPanels\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 4 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 5 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n*L\n1#1,46:1\n123#2:47\n123#2:53\n113#2:54\n57#3:48\n61#3:51\n60#4:49\n70#4:52\n22#5:50\n*S KotlinDebug\n*F\n+ 1 GlassPanels.kt\ndev/nino/squareglass/GlassPanels\n*L\n26#1:47\n38#1:53\n40#1:54\n37#1:48\n37#1:51\n37#1:49\n37#1:52\n37#1:50\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0000\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005H\u0007J \u0010\u0007\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0008\u001a\u00020\t2\u0008\u0008\u0002\u0010\n\u001a\u00020\u000b\u00a8\u0006\u000c"
    }
    d2 = {
        "Ldev/nino/squareglass/GlassPanels;",
        "",
        "<init>",
        "()V",
        "field",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "panel",
        "radius",
        "",
        "emphasized",
        "",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/GlassPanels;


# direct methods
.method public static synthetic $r8$lambda$2rWKAtZBD0Ppy5VrI5OdT44UeXY(ZZLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/GlassPanels;->panel$lambda$4(ZZLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$FhRiG2QQX925nLIVaE_9PtebqKY()Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/GlassPanels;->panel$lambda$3()Ldev/nino/squareglass/backdrop/shadow/Shadow;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$UM7cwjYBVZUymzLe9qKShkYqHl8(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/GlassPanels;->panel$lambda$1(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pMKjr6GvXuufsaP-l2bzpSJN5Wo()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/GlassPanels;->panel$lambda$2()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$zgHlcngF4yMXZc7vwJmkiQSvvKs(Landroidx/compose/foundation/shape/RoundedCornerShape;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/GlassPanels;->panel$lambda$0(Landroidx/compose/foundation/shape/RoundedCornerShape;)Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/GlassPanels;

    invoke-direct {v0}, Ldev/nino/squareglass/GlassPanels;-><init>()V

    sput-object v0, Ldev/nino/squareglass/GlassPanels;->INSTANCE:Ldev/nino/squareglass/GlassPanels;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final field(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;
    .locals 7

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    sget-object v1, Ldev/nino/squareglass/GlassPanels;->INSTANCE:Ldev/nino/squareglass/GlassPanels;

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/high16 v3, 0x41e00000    # 28.0f

    const/4 v4, 0x0

    move-object v2, p0

    invoke-static/range {v1 .. v6}, Ldev/nino/squareglass/GlassPanels;->panel$default(Ldev/nino/squareglass/GlassPanels;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic panel$default(Ldev/nino/squareglass/GlassPanels;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;
    .locals 0

    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_0

    const/4 p3, 0x0

    .line 23
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Ldev/nino/squareglass/GlassPanels;->panel(Landroidx/compose/ui/Modifier;FZ)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method

.method private static final panel$lambda$0(Landroidx/compose/foundation/shape/RoundedCornerShape;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 35
    check-cast p0, Landroidx/compose/ui/graphics/Shape;

    return-object p0
.end method

.method private static final panel$lambda$1(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 9

    const-string v0, "$this$drawBackdrop"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 37
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v0

    const/16 v2, 0x20

    shr-long/2addr v0, v2

    long-to-int v0, v0

    .line 50
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    .line 37
    invoke-interface {p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v1

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    long-to-int v1, v1

    .line 50
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    .line 37
    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const v1, 0x3e4ccccd    # 0.2f

    mul-float/2addr v0, v1

    const/16 v1, 0xc

    int-to-float v1, v1

    .line 38
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v2

    mul-float/2addr v1, v2

    .line 53
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 38
    invoke-interface {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v1

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->coerceAtMost(FF)F

    move-result v3

    const/16 v1, 0x12

    int-to-float v1, v1

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v2

    mul-float/2addr v1, v2

    .line 53
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 38
    invoke-interface {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v1

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->coerceAtMost(FF)F

    move-result v4

    const/16 v7, 0xc

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p0

    invoke-static/range {v2 .. v8}, Ldev/nino/squareglass/backdrop/effects/LensKt;->lens$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZILjava/lang/Object;)V

    .line 40
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final panel$lambda$2()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    .line 40
    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Companion:Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;->getDefault()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method private static final panel$lambda$3()Ldev/nino/squareglass/backdrop/shadow/Shadow;
    .locals 10

    .line 40
    new-instance v0, Ldev/nino/squareglass/backdrop/shadow/Shadow;

    const/4 v1, 0x6

    int-to-float v1, v1

    .line 54
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 40
    invoke-direct/range {v0 .. v9}, Ldev/nino/squareglass/backdrop/shadow/Shadow;-><init>(FJJFIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private static final panel$lambda$4(ZZLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 14

    const-string v0, "$this$drawBackdrop"

    move-object/from16 v1, p2

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    sget-object v0, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v2

    if-eqz p0, :cond_0

    const v0, 0x3da3d70a    # 0.08f

    goto :goto_0

    :cond_0
    const v0, 0x3f051eb8    # 0.52f

    :goto_0
    move v4, v0

    const/16 v8, 0xe

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v2 .. v9}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v2

    const/16 v12, 0x7e

    const/4 v13, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v1 .. v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    if-eqz p1, :cond_1

    .line 42
    invoke-static {p0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p0

    invoke-static {p0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    const/16 v6, 0xe

    const/4 v7, 0x0

    const v2, 0x3dcccccd    # 0.1f

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v2

    const/16 v12, 0x7e

    const/4 v13, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object/from16 v1, p2

    invoke-static/range {v1 .. v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 43
    :cond_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final panel(Landroidx/compose/ui/Modifier;FZ)Landroidx/compose/ui/Modifier;
    .locals 20

    move-object/from16 v1, p1

    const-string v0, "original"

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    return-object v1

    .line 25
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    .line 47
    invoke-static/range {p2 .. p2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 26
    invoke-static {v2}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    .line 27
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_1

    check-cast v2, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v2}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    return-object v0

    .line 30
    :cond_1
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v3

    invoke-static {v3}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v3

    .line 31
    new-instance v5, Ldev/nino/squareglass/GlassPanels$panel$source$1;

    invoke-direct {v5, v3, v4}, Ldev/nino/squareglass/GlassPanels$panel$source$1;-><init>(J)V

    .line 35
    check-cast v5, Ldev/nino/squareglass/backdrop/Backdrop;

    new-instance v3, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda0;

    invoke-direct {v3, v2}, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/foundation/shape/RoundedCornerShape;)V

    new-instance v4, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda1;

    invoke-direct {v4}, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda1;-><init>()V

    move-object v2, v5

    new-instance v5, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda2;

    invoke-direct {v5}, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda2;-><init>()V

    new-instance v6, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda3;

    invoke-direct {v6}, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda3;-><init>()V

    new-instance v12, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda4;

    move/from16 v7, p3

    invoke-direct {v12, v0, v7}, Ldev/nino/squareglass/GlassPanels$$ExternalSyntheticLambda4;-><init>(ZZ)V

    const v18, 0xfbe0

    const/16 v19, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-static/range {v1 .. v19}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->drawBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    return-object v0
.end method
