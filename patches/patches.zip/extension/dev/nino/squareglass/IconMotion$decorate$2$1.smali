.class final Ldev/nino/squareglass/IconMotion$decorate$2$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "IconMotion.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $fire:Lam0/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $previousPulse$delegate:Landroidx/compose/runtime/MutableIntState;

.field final synthetic $pulse:I

.field label:I


# direct methods
.method constructor <init>(ILam0/l;Landroidx/compose/runtime/MutableIntState;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/MutableIntState;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/IconMotion$decorate$2$1;",
            ">;)V"
        }
    .end annotation

    iput p1, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$pulse:I

    iput-object p2, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$fire:Lam0/l;

    iput-object p3, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$previousPulse$delegate:Landroidx/compose/runtime/MutableIntState;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance p1, Ldev/nino/squareglass/IconMotion$decorate$2$1;

    iget v0, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$pulse:I

    iget-object v1, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$fire:Lam0/l;

    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$previousPulse$delegate:Landroidx/compose/runtime/MutableIntState;

    invoke-direct {p1, v0, v1, p0, p2}, Ldev/nino/squareglass/IconMotion$decorate$2$1;-><init>(ILam0/l;Landroidx/compose/runtime/MutableIntState;Lkotlin/coroutines/e;)V

    check-cast p1, Lkotlin/coroutines/e;

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$2$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$2$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/IconMotion$decorate$2$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 117
    iget v0, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->label:I

    if-nez v0, :cond_1

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 118
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$previousPulse$delegate:Landroidx/compose/runtime/MutableIntState;

    invoke-static {p1}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$17(Landroidx/compose/runtime/MutableIntState;)I

    move-result p1

    iget v0, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$pulse:I

    if-eq p1, v0, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$previousPulse$delegate:Landroidx/compose/runtime/MutableIntState;

    invoke-static {p1, v0}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$18(Landroidx/compose/runtime/MutableIntState;I)V

    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$decorate$2$1;->$fire:Lam0/l;

    const/4 p1, 0x1

    invoke-static {p1}, Ldev/nino/squareglass/HostCompat;->boxInt(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0

    .line 117
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
