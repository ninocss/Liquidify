.class public final synthetic Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareSongMenu;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareSongMenu;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda3;->f$0:Ldev/nino/squareglass/SquareSongMenu;

    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda3;->f$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/SquareSongMenu;->$r8$lambda$56-dIAQoyh55z077KIeXRKINWQo(Ldev/nino/squareglass/SquareSongMenu;Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    move-result-object p0

    return-object p0
.end method
