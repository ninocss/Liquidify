.class final Ldev/nino/squareglass/SquareOutput$Session;
.super Ljava/lang/Object;
.source "SquareOutput.java"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareOutput;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Session"
.end annotation


# instance fields
.field activeBox:Landroid/widget/LinearLayout;

.field final activity:Landroid/app/Activity;

.field final anchor:Landroid/graphics/Rect;

.field closed:Z

.field content:Landroid/widget/LinearLayout;

.field final devices:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final dialog:Landroid/app/Dialog;

.field drawn:Ljava/lang/String;

.field fetching:Z

.field glass:Ldev/nino/squareglass/LiquidMenuSurface;

.field listener:Ljava/lang/Object;

.field maxHeight:I

.field message:Ljava/lang/String;

.field final parent:Landroid/view/View;

.field final poll:Ljava/lang/Runnable;

.field popup:Landroid/widget/PopupWindow;

.field refreshButton:Landroid/widget/TextView;

.field request:Ljava/lang/Object;

.field retryDevice:Ljava/lang/Object;

.field rows:Landroid/widget/LinearLayout;

.field scroll:Landroid/widget/ScrollView;

.field searching:Z

.field final selection:Ldev/nino/squareglass/OutputSelection;

.field shell:Landroid/widget/FrameLayout;

.field snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

.field status:Landroid/widget/TextView;

.field final timeout:Ljava/lang/Runnable;

.field width:I


# direct methods
.method public static synthetic $r8$lambda$-7Kq55RmcJCsXkBhfMz9buibKCk(Ldev/nino/squareglass/SquareOutput$Session;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->lambda$open$0(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$4AzZBlxHprpflrqNip8BuVB_20M(Ldev/nino/squareglass/SquareOutput$Session;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/SquareOutput$Session;->lambda$new$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$KbQqKWpzE6H_NYNs7uzz0xPMsm4(Ldev/nino/squareglass/SquareOutput$Session;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->lambda$open$1(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ULNuPX_H6jeLwUH7RAPBCrFQvKM(Ldev/nino/squareglass/SquareOutput$Session;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->lambda$draw$0(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$cMoUvCYy9ANICtSCahnZuxjb9FI(Ldev/nino/squareglass/SquareOutput$Session;Ljava/lang/Object;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/SquareOutput$Session;->lambda$row$0(Ljava/lang/Object;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$v5as-jEvEU5yefTmfgIX03Z_FKA(Ldev/nino/squareglass/SquareOutput$Session;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/SquareOutput$Session;->lambda$new$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$wl_RpvF6bU4MD_peeum831ELiLQ(Ldev/nino/squareglass/SquareOutput$Session;I)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->lambda$draw$2(I)V

    return-void
.end method

.method constructor <init>(Landroid/app/Dialog;Landroid/app/Activity;Landroid/graphics/Rect;Landroid/view/View;)V
    .locals 1

    .line 78
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 68
    new-instance v0, Ldev/nino/squareglass/OutputSelection;

    invoke-direct {v0}, Ldev/nino/squareglass/OutputSelection;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    .line 69
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->devices:Ljava/util/ArrayList;

    .line 70
    new-instance v0, Ldev/nino/squareglass/SquareOutput$Session$6;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SquareOutput$Session$6;-><init>(Ldev/nino/squareglass/SquareOutput$Session;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->poll:Ljava/lang/Runnable;

    .line 71
    new-instance v0, Ldev/nino/squareglass/SquareOutput$Session$7;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SquareOutput$Session$7;-><init>(Ldev/nino/squareglass/SquareOutput$Session;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->timeout:Ljava/lang/Runnable;

    const/4 v0, 0x1

    .line 74
    iput-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->searching:Z

    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    .line 77
    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->drawn:Ljava/lang/String;

    .line 78
    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->dialog:Landroid/app/Dialog;

    iput-object p2, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    iput-object p3, p0, Ldev/nino/squareglass/SquareOutput$Session;->anchor:Landroid/graphics/Rect;

    iput-object p4, p0, Ldev/nino/squareglass/SquareOutput$Session;->parent:Landroid/view/View;

    return-void
.end method

.method private synthetic lambda$draw$0(Landroid/view/View;)V
    .locals 2

    .line 193
    new-instance p1, Landroid/widget/EditText;

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {p1, v0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setSingleLine(Z)V

    const-string v0, "Local IP or device description URL"

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    const-string v0, "Linn local network address"

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 194
    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string p0, "Add Linn device"

    invoke-virtual {v0, p0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    const-string v0, "Cancel"

    const/4 v1, 0x0

    .line 195
    invoke-virtual {p0, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    new-instance v0, Ldev/nino/squareglass/SquareOutput$Session$5;

    invoke-direct {v0, p1}, Ldev/nino/squareglass/SquareOutput$Session$5;-><init>(Landroid/widget/EditText;)V

    const-string p1, "Find"

    invoke-virtual {p0, p1, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method static synthetic lambda$draw$1(Landroid/widget/EditText;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 195
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/LinnProvider;->addAddress(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$draw$2(I)V
    .locals 1

    .line 201
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->closed:Z

    if-nez v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1}, Landroid/widget/ScrollView;->scrollTo(II)V

    :cond_0
    return-void
.end method

.method private synthetic lambda$new$0()V
    .locals 1

    const/4 v0, 0x0

    .line 70
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/SquareOutput$Session;->request(Z)V

    return-void
.end method

.method private synthetic lambda$new$1()V
    .locals 1

    .line 71
    const-string v0, "Device search timed out. Tap Refresh to retry."

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/SquareOutput$Session;->fetchFailed(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$open$0(Landroid/view/View;)V
    .locals 0

    .line 101
    const-string p1, ""

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    invoke-static {}, Ldev/nino/squareglass/NativeOutputBridge;->scan()V

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->refresh()V

    return-void
.end method

.method private synthetic lambda$open$1(Landroid/view/View;)V
    .locals 0

    .line 104
    iget-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->retryDevice:Ljava/lang/Object;

    if-eqz p1, :cond_0

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->choose(Ljava/lang/Object;)V

    return-void

    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->refresh()V

    return-void
.end method

.method private synthetic lambda$row$0(Ljava/lang/Object;Landroid/view/View;)V
    .locals 0

    .line 175
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->choose(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method choose(Ljava/lang/Object;)V
    .locals 4

    .line 154
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->closed:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/OutputSelection;->target()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 155
    :cond_0
    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->retryDevice:Ljava/lang/Object;

    const-string v0, ""

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Ldev/nino/squareglass/OutputSelection;->begin(Ljava/lang/String;J)V

    .line 156
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    .line 157
    :try_start_0
    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->select(Ljava/lang/Object;)V

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->schedule()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    .line 158
    :catch_0
    iget-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {p1}, Ldev/nino/squareglass/OutputSelection;->failed()V

    const-string p1, "Connection failed. Tap here to retry."

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    :cond_1
    :goto_0
    return-void
.end method

.method close()V
    .locals 3

    .line 224
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->closed:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->closed:Z

    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetcurrent()Ldev/nino/squareglass/SquareOutput$Session;

    move-result-object v0

    const/4 v1, 0x0

    if-ne v0, p0, :cond_1

    invoke-static {v1}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfputcurrent(Ldev/nino/squareglass/SquareOutput$Session;)V

    .line 225
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/OutputSelection;->invalidate()V

    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session;->poll:Ljava/lang/Runnable;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session;->timeout:Ljava/lang/Runnable;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 226
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->request:Ljava/lang/Object;

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->cancel(Ljava/lang/Object;)V

    iput-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->request:Ljava/lang/Object;

    .line 227
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->listener:Ljava/lang/Object;

    if-eqz v0, :cond_2

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->close(Ljava/lang/Object;)V

    iput-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->listener:Ljava/lang/Object;

    .line 228
    :cond_2
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 229
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    if-eqz v0, :cond_3

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    .line 230
    :cond_3
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ldev/nino/squareglass/LiquidMenuSurface;->release()V

    .line 231
    :cond_4
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->release()V

    iput-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    :cond_5
    :goto_0
    return-void
.end method

.method dp(F)I
    .locals 0

    .line 79
    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method draw()V
    .locals 10

    .line 178
    invoke-static {}, Ldev/nino/squareglass/NativeOutputBridge;->active()Ljava/lang/Object;

    move-result-object v0

    .line 179
    new-instance v1, Ljava/lang/StringBuilder;

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x7c

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-boolean v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->searching:Z

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v3}, Ldev/nino/squareglass/OutputSelection;->target()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 180
    const-string v3, ""

    if-nez v0, :cond_0

    move-object v4, v3

    goto :goto_0

    :cond_0
    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    :goto_0
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->devices:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/16 v6, 0x3a

    if-eqz v5, :cond_1

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {v5}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v5}, Ldev/nino/squareglass/SquareOutput$Session;->name(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v5}, Ldev/nino/squareglass/SquareOutput$Session;->type(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_1
    if-eqz v0, :cond_2

    .line 182
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/SquareOutput$Session;->name(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ldev/nino/squareglass/SquareOutput$Session;->type(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 184
    :cond_2
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->drawn:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    goto/16 :goto_5

    :cond_3
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->drawn:Ljava/lang/String;

    .line 185
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v1}, Landroid/widget/ScrollView;->getScrollY()I

    move-result v1

    .line 186
    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session;->activeBox:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->removeAllViews()V

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session;->rows:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->removeAllViews()V

    const/4 v2, 0x1

    if-eqz v0, :cond_4

    .line 187
    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->activeBox:Landroid/widget/LinearLayout;

    const-string v5, "ACTIVE DEVICE"

    invoke-virtual {p0, v4, v5}, Ldev/nino/squareglass/SquareOutput$Session;->heading(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->activeBox:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v4, v0, v2}, Ldev/nino/squareglass/SquareOutput$Session;->row(Landroid/widget/LinearLayout;Ljava/lang/Object;Z)V

    .line 188
    :cond_4
    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->rows:Landroid/widget/LinearLayout;

    const-string v5, "AVAILABLE DEVICES"

    invoke-virtual {p0, v4, v5}, Ldev/nino/squareglass/SquareOutput$Session;->heading(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 189
    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->devices:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    const/4 v5, 0x0

    move v6, v5

    :cond_5
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_7

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    if-eqz v0, :cond_6

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v7}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_5

    :cond_6
    iget-object v8, p0, Ldev/nino/squareglass/SquareOutput$Session;->rows:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v8, v7, v5}, Ldev/nino/squareglass/SquareOutput$Session;->row(Landroid/widget/LinearLayout;Ljava/lang/Object;Z)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    .line 190
    :cond_7
    const-string v0, "Searching\u2026"

    const/16 v4, 0xe

    if-nez v6, :cond_9

    iget-object v6, p0, Ldev/nino/squareglass/SquareOutput$Session;->rows:Landroid/widget/LinearLayout;

    iget-boolean v7, p0, Ldev/nino/squareglass/SquareOutput$Session;->searching:Z

    if-eqz v7, :cond_8

    move-object v7, v0

    goto :goto_3

    :cond_8
    const-string v7, "No other devices found"

    :goto_3
    invoke-virtual {p0, v7, v4}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 191
    :cond_9
    const-string v6, "Linn not found? Add by address"

    invoke-virtual {p0, v6, v4}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v4

    const/high16 v6, 0x42400000    # 48.0f

    invoke-virtual {p0, v6}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setFocusable(Z)V

    .line 192
    new-instance v6, Ldev/nino/squareglass/SquareOutput$Session$3;

    invoke-direct {v6, p0}, Ldev/nino/squareglass/SquareOutput$Session$3;-><init>(Ldev/nino/squareglass/SquareOutput$Session;)V

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 196
    iget-object v6, p0, Ldev/nino/squareglass/SquareOutput$Session;->rows:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 197
    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v4}, Ldev/nino/squareglass/OutputSelection;->target()Ljava/lang/String;

    move-result-object v4

    .line 198
    iget-object v6, p0, Ldev/nino/squareglass/SquareOutput$Session;->status:Landroid/widget/TextView;

    iget-object v7, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_a

    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    goto :goto_4

    :cond_a
    if-eqz v4, :cond_b

    const-string v3, "Connecting\u2026"

    goto :goto_4

    :cond_b
    iget-boolean v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->searching:Z

    if-eqz v4, :cond_c

    move-object v3, v0

    :cond_c
    :goto_4
    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 199
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->status:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-nez v3, :cond_d

    const/16 v5, 0x8

    :cond_d
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 200
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->status:Landroid/widget/TextView;

    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    xor-int/2addr v2, v3

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setFocusable(Z)V

    .line 201
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->rows:Landroid/widget/LinearLayout;

    new-instance v2, Ldev/nino/squareglass/SquareOutput$Session$4;

    invoke-direct {v2, p0, v1}, Ldev/nino/squareglass/SquareOutput$Session$4;-><init>(Ldev/nino/squareglass/SquareOutput$Session;I)V

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->post(Ljava/lang/Runnable;)Z

    .line 202
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    :cond_e
    :goto_5
    return-void
.end method

.method fetchFailed(Ljava/lang/String;)V
    .locals 2

    .line 148
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->closed:Z

    if-eqz v0, :cond_0

    return-void

    .line 149
    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/OutputSelection;->invalidate()V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/OutputSelection;->failed()V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->request:Ljava/lang/Object;

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->cancel(Ljava/lang/Object;)V

    const/4 v0, 0x0

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->request:Ljava/lang/Object;

    .line 150
    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->timeout:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->fetching:Z

    iput-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->searching:Z

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const-string v1, "\u21bb"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 151
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const-string v1, "Refresh output devices"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    return-void
.end method

.method fit()V
    .locals 8

    .line 205
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 206
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v1

    const/high16 v2, 0x41c00000    # 24.0f

    invoke-virtual {p0, v2}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v2

    sub-int/2addr v1, v2

    const/4 v2, 0x1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->maxHeight:I

    .line 207
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v1}, Landroid/widget/ScrollView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v3, -0x2

    iput v3, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 210
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    iget v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->width:I

    const/high16 v4, 0x40000000    # 2.0f

    invoke-static {v3, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    iget v5, p0, Ldev/nino/squareglass/SquareOutput$Session;->maxHeight:I

    const/high16 v6, -0x80000000

    invoke-static {v5, v6}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    invoke-virtual {v1, v3, v5}, Landroid/widget/LinearLayout;->measure(II)V

    .line 211
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getMeasuredHeight()I

    move-result v1

    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v3}, Landroid/widget/ScrollView;->getMeasuredHeight()I

    move-result v3

    sub-int/2addr v1, v3

    .line 212
    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v3}, Landroid/widget/ScrollView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    iget-object v5, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v5}, Landroid/widget/ScrollView;->getMeasuredHeight()I

    move-result v5

    iget v7, p0, Ldev/nino/squareglass/SquareOutput$Session;->maxHeight:I

    sub-int/2addr v7, v1

    invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v3, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 213
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v1}, Landroid/widget/ScrollView;->requestLayout()V

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    iget v2, p0, Ldev/nino/squareglass/SquareOutput$Session;->width:I

    invoke-static {v2, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    iget v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->maxHeight:I

    invoke-static {v3, v6}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Landroid/widget/LinearLayout;->measure(II)V

    .line 214
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getMeasuredHeight()I

    move-result v1

    .line 215
    iget v2, v0, Landroid/graphics/Rect;->left:I

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v4

    add-int/2addr v2, v4

    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->anchor:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->right:I

    iget v5, p0, Ldev/nino/squareglass/SquareOutput$Session;->width:I

    sub-int/2addr v4, v5

    iget v5, v0, Landroid/graphics/Rect;->right:I

    iget v6, p0, Ldev/nino/squareglass/SquareOutput$Session;->width:I

    sub-int/2addr v5, v6

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v6

    sub-int/2addr v5, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 216
    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->anchor:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->bottom:I

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v5

    add-int/2addr v4, v5

    add-int v5, v4, v1

    iget v6, v0, Landroid/graphics/Rect;->bottom:I

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v7

    sub-int/2addr v6, v7

    if-le v5, v6, :cond_0

    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->anchor:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->top:I

    sub-int/2addr v4, v1

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v5

    sub-int/2addr v4, v5

    .line 217
    :cond_0
    iget v5, v0, Landroid/graphics/Rect;->top:I

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v6

    add-int/2addr v5, v6

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr v0, v1

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v3

    sub-int/2addr v0, v3

    invoke-static {v4, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v5, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 218
    iget-object v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v3}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v3

    .line 221
    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    if-eqz v3, :cond_1

    .line 218
    iget p0, p0, Ldev/nino/squareglass/SquareOutput$Session;->width:I

    invoke-virtual {v4, v2, v0, p0, v1}, Landroid/widget/PopupWindow;->update(IIII)V

    return-void

    .line 221
    :cond_1
    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session;->parent:Landroid/view/View;

    const/16 v1, 0x33

    invoke-virtual {v4, p0, v1, v2, v0}, Landroid/widget/PopupWindow;->showAtLocation(Landroid/view/View;III)V

    return-void
.end method

.method heading(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .locals 1

    const/16 v0, 0xb

    .line 160
    invoke-virtual {p0, p2, v0}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object p0

    const/4 p2, 0x1

    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setAccessibilityHeading(Z)V

    invoke-virtual {p1, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method name(Ljava/lang/Object;)Ljava/lang/String;
    .locals 0

    .line 161
    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->local(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const-string p0, "This phone"

    return-object p0

    :cond_0
    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->name(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 1

    .line 234
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    if-ne p1, v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->close()V

    :cond_0
    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 1

    .line 233
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    if-ne p1, v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->close()V

    :cond_0
    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method open()V
    .locals 9

    .line 87
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->dialog:Landroid/app/Dialog;

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->discard(Ljava/lang/Object;)V

    .line 88
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    const/high16 v1, 0x43a00000    # 320.0f

    .line 89
    invoke-virtual {p0, v1}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v1

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v2

    const/high16 v3, 0x41c00000    # 24.0f

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v4

    sub-int/2addr v2, v4

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v2, 0x1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->width:I

    .line 90
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v1

    sub-int/2addr v0, v1

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->maxHeight:I

    .line 91
    new-instance v0, Landroid/widget/FrameLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->shell:Landroid/widget/FrameLayout;

    invoke-static {}, Ldev/nino/squareglass/PlayerWindow;->take()Ldev/nino/squareglass/PlayerWindow$Snapshot;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    new-instance v0, Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    invoke-direct {v0, v1, v4}, Ldev/nino/squareglass/LiquidMenuSurface;-><init>(Landroid/app/Activity;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    .line 92
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->shell:Landroid/widget/FrameLayout;

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v3, v4}, Ldev/nino/squareglass/LiquidMenuSurface;->paint(Landroid/widget/FrameLayout;FZ)V

    .line 93
    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 94
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->shell:Landroid/widget/FrameLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v3, v5, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 95
    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 96
    const-string v1, "Output"

    const/16 v3, 0x14

    invoke-virtual {p0, v1, v3}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setAccessibilityHeading(Z)V

    .line 97
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v3, v4, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 98
    const-string v1, "\u21bb"

    const/16 v3, 0x1a

    invoke-virtual {p0, v1, v3}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v1

    iput-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const/16 v3, 0x11

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setGravity(I)V

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const/high16 v3, 0x42400000    # 48.0f

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v7

    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setMinHeight(I)V

    .line 99
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const-string v7, "Refresh output devices"

    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setFocusable(Z)V

    .line 100
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x42600000    # 56.0f

    invoke-virtual {p0, v8}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v8

    invoke-direct {v7, v8, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 101
    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    new-instance v7, Ldev/nino/squareglass/SquareOutput$Session$0;

    invoke-direct {v7, p0}, Ldev/nino/squareglass/SquareOutput$Session$0;-><init>(Ldev/nino/squareglass/SquareOutput$Session;)V

    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 102
    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activeBox:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activeBox:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 103
    const-string v0, "Searching\u2026"

    const/16 v1, 0xe

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->status:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setAccessibilityLiveRegion(I)V

    .line 104
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->status:Landroid/widget/TextView;

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMinHeight(I)V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->status:Landroid/widget/TextView;

    new-instance v1, Ldev/nino/squareglass/SquareOutput$Session$1;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareOutput$Session$1;-><init>(Ldev/nino/squareglass/SquareOutput$Session;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 105
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->status:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 106
    new-instance v0, Landroid/widget/ScrollView;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v0, v4}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 107
    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->rows:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->rows:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 108
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->content:Landroid/widget/LinearLayout;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->scroll:Landroid/widget/ScrollView;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 109
    new-instance v0, Landroid/widget/PopupWindow;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->shell:Landroid/widget/FrameLayout;

    iget v3, p0, Ldev/nino/squareglass/SquareOutput$Session;->width:I

    invoke-direct {v0, v1, v3, v6, v2}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;IIZ)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v0, v2}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    .line 110
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v1, v4}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    const/high16 v1, 0x41200000    # 10.0f

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setElevation(F)V

    .line 111
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    invoke-virtual {v0, v2}, Landroid/widget/PopupWindow;->setClippingEnabled(Z)V

    .line 112
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->popup:Landroid/widget/PopupWindow;

    new-instance v1, Ldev/nino/squareglass/SquareOutput$Session$2;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareOutput$Session$2;-><init>(Ldev/nino/squareglass/SquareOutput$Session;)V

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 113
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 114
    invoke-static {}, Ldev/nino/squareglass/NativeOutputBridge;->open()Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->listener:Ljava/lang/Object;

    invoke-static {}, Ldev/nino/squareglass/NativeOutputBridge;->scan()V

    .line 115
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->fit()V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->shell:Landroid/widget/FrameLayout;

    invoke-static {v0, v2, v4}, Ldev/nino/squareglass/SurfaceMotion;->enter(Landroid/view/View;ZZ)V

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->refresh()V

    return-void
.end method

.method received(ILjava/lang/Object;Z)V
    .locals 3

    .line 130
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->closed:Z

    if-nez v0, :cond_9

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0, p1}, Ldev/nino/squareglass/OutputSelection;->accepts(I)Z

    move-result p1

    if-nez p1, :cond_0

    goto/16 :goto_3

    :cond_0
    if-nez p3, :cond_8

    .line 131
    instance-of p1, p2, Ljava/util/List;

    if-nez p1, :cond_1

    goto/16 :goto_2

    .line 132
    :cond_1
    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object p1

    iget-object p3, p0, Ldev/nino/squareglass/SquareOutput$Session;->timeout:Ljava/lang/Runnable;

    invoke-virtual {p1, p3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->fetching:Z

    iput-boolean p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->searching:Z

    iget-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const-string p3, "\u21bb"

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 133
    iget-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const-string p3, "Refresh output devices"

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 134
    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 135
    check-cast p2, Ljava/util/List;

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_2
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_3

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    if-eqz p3, :cond_2

    invoke-static {p3}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, p3}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 136
    :cond_3
    iget-object p2, p0, Ldev/nino/squareglass/SquareOutput$Session;->devices:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->clear()V

    iget-object p2, p0, Ldev/nino/squareglass/SquareOutput$Session;->devices:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 137
    invoke-static {}, Ldev/nino/squareglass/NativeOutputBridge;->active()Ljava/lang/Object;

    move-result-object p1

    .line 138
    iget-object p2, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    const/4 p3, 0x0

    if-nez p1, :cond_4

    move-object v0, p3

    goto :goto_1

    :cond_4
    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    :goto_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    invoke-virtual {p2, v0, v1, v2}, Ldev/nino/squareglass/OutputSelection;->observe(Ljava/lang/String;J)I

    move-result p2

    const/4 v0, 0x1

    .line 139
    const-string v1, ""

    if-ne p2, v0, :cond_5

    iput-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/SquareOutput$Session;->retryDevice:Ljava/lang/Object;

    :cond_5
    const/4 v0, -0x1

    if-ne p2, v0, :cond_6

    .line 140
    const-string p2, "Connection was not confirmed. Tap here to retry."

    iput-object p2, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    :cond_6
    if-eqz p1, :cond_7

    .line 142
    iget-object p2, p0, Ldev/nino/squareglass/SquareOutput$Session;->retryDevice:Ljava/lang/Object;

    if-eqz p2, :cond_7

    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Ldev/nino/squareglass/SquareOutput$Session;->retryDevice:Ljava/lang/Object;

    invoke-static {p2}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    .line 143
    iput-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->message:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/SquareOutput$Session;->retryDevice:Ljava/lang/Object;

    .line 145
    :cond_7
    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object p1

    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session;->poll:Ljava/lang/Runnable;

    const-wide/16 p2, 0x3e8

    invoke-virtual {p1, p0, p2, p3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 131
    :cond_8
    :goto_2
    const-string p1, "Device search failed. Tap Refresh to retry."

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->fetchFailed(Ljava/lang/String;)V

    :cond_9
    :goto_3
    return-void
.end method

.method refresh()V
    .locals 1

    const/4 v0, 0x1

    .line 118
    invoke-virtual {p0, v0}, Ldev/nino/squareglass/SquareOutput$Session;->request(Z)V

    return-void
.end method

.method request(Z)V
    .locals 4

    .line 120
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->closed:Z

    if-eqz v0, :cond_0

    return-void

    .line 121
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->poll:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->timeout:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 122
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->request:Ljava/lang/Object;

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->cancel(Ljava/lang/Object;)V

    const/4 v0, 0x0

    iput-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->request:Ljava/lang/Object;

    const/4 v0, 0x1

    .line 123
    iput-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->fetching:Z

    if-eqz p1, :cond_1

    .line 124
    iput-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->searching:Z

    iget-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const-string v0, "\u2026"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->refreshButton:Landroid/widget/TextView;

    const-string v0, "Searching output devices. Refresh again"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Ldev/nino/squareglass/SquareOutput$Session;->draw()V

    .line 125
    :cond_1
    iget-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {p1}, Ldev/nino/squareglass/OutputSelection;->nextRequest()I

    move-result p1

    .line 126
    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->timeout:Ljava/lang/Runnable;

    const-wide/16 v2, 0x1f40

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 127
    new-instance v0, Ldev/nino/squareglass/SquareOutput$Request;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/SquareOutput$Request;-><init>(Ldev/nino/squareglass/SquareOutput$Session;I)V

    invoke-static {v0}, Ldev/nino/squareglass/NativeOutputBridge;->request(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->request:Ljava/lang/Object;

    return-void
.end method

.method row(Landroid/widget/LinearLayout;Ljava/lang/Object;Z)V
    .locals 9

    .line 164
    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/OutputSelection;->target()Ljava/lang/String;

    move-result-object v0

    invoke-static {p2}, Ldev/nino/squareglass/NativeOutputBridge;->id(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    .line 165
    new-instance v1, Landroid/widget/LinearLayout;

    iget-object v2, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v2, 0x10

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v3, 0x42800000    # 64.0f

    invoke-virtual {p0, v3}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setMinimumHeight(I)V

    .line 166
    invoke-static {p2}, Ldev/nino/squareglass/NativeOutputBridge;->local(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const-string v3, "\u25af"

    goto :goto_0

    :cond_0
    const-string v3, "\u25a3"

    :goto_0
    const/16 v4, 0x16

    invoke-virtual {p0, v3, v4}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x42400000    # 48.0f

    invoke-virtual {p0, v5}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v5

    const/4 v6, -0x2

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 167
    new-instance v3, Landroid/widget/LinearLayout;

    iget-object v4, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 168
    invoke-virtual {p0, p2}, Ldev/nino/squareglass/SquareOutput$Session;->name(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v5, v2}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v2

    const/high16 v5, 0x41000000    # 8.0f

    invoke-virtual {p0, v5}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v7

    const/4 v8, 0x0

    invoke-virtual {v2, v8, v7, v8, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    if-eqz v0, :cond_1

    .line 169
    const-string v2, "Connecting\u2026"

    goto :goto_1

    :cond_1
    invoke-virtual {p0, p2}, Ldev/nino/squareglass/SquareOutput$Session;->type(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    :goto_1
    const/16 v7, 0xc

    invoke-virtual {p0, v2, v7}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {p0, v5}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v5

    invoke-virtual {v2, v8, v8, v8, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 170
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v2, v8, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz p3, :cond_2

    .line 171
    const-string v2, "\u2713"

    const/16 v3, 0x14

    invoke-virtual {p0, v2, v3}, Ldev/nino/squareglass/SquareOutput$Session;->text(Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 172
    :cond_2
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v2

    invoke-static {v2}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v2

    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v5, -0x1

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v5, 0x41400000    # 12.0f

    invoke-virtual {p0, v5}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 173
    new-instance v5, Landroid/graphics/drawable/RippleDrawable;

    const v6, 0xffffff

    and-int/2addr v2, v6

    const/high16 v6, 0x18000000

    or-int/2addr v2, v6

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    const/4 v6, 0x0

    invoke-direct {v5, v2, v6, v3}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v1, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 174
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, p2}, Ldev/nino/squareglass/SquareOutput$Session;->name(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ", "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p2}, Ldev/nino/squareglass/SquareOutput$Session;->type(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p3, :cond_3

    const-string v0, ", active"

    goto :goto_2

    :cond_3
    if-eqz v0, :cond_4

    const-string v0, ", connecting"

    goto :goto_2

    :cond_4
    const-string v0, ""

    :goto_2
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 175
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    iget-object v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->selection:Ldev/nino/squareglass/OutputSelection;

    invoke-virtual {v0}, Ldev/nino/squareglass/OutputSelection;->target()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_5

    if-nez p3, :cond_5

    goto :goto_3

    :cond_5
    move v4, v8

    :goto_3
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setEnabled(Z)V

    new-instance p3, Ldev/nino/squareglass/SquareOutput$Session$8;

    invoke-direct {p3, p0, p2}, Ldev/nino/squareglass/SquareOutput$Session$8;-><init>(Ldev/nino/squareglass/SquareOutput$Session;Ljava/lang/Object;)V

    invoke-virtual {v1, p3}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method schedule()V
    .locals 3

    .line 117
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareOutput$Session;->closed:Z

    if-nez v0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->poll:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-static {}, Ldev/nino/squareglass/SquareOutput;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session;->poll:Ljava/lang/Runnable;

    const-wide/16 v1, 0x64

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void
.end method

.method text(Ljava/lang/String;I)Landroid/widget/TextView;
    .locals 3

    .line 81
    new-instance v0, Landroid/widget/TextView;

    iget-object v1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    int-to-float p1, p2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 82
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p1

    invoke-static {p1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 83
    iget-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-virtual {p1}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const p2, 0x7f090005

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getFont(I)Landroid/graphics/Typeface;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/high16 p1, 0x41800000    # 16.0f

    .line 84
    invoke-virtual {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result p2

    const/high16 v1, 0x41000000    # 8.0f

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result v2

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result p1

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/SquareOutput$Session;->dp(F)I

    move-result p0

    invoke-virtual {v0, p2, v2, p1, p0}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object v0
.end method

.method type(Ljava/lang/Object;)Ljava/lang/String;
    .locals 1

    .line 162
    invoke-static {p1}, Ldev/nino/squareglass/LinnProvider;->label(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    invoke-static {p1}, Ldev/nino/squareglass/NativeOutputBridge;->type(Ljava/lang/Object;)I

    move-result p1

    if-lez p1, :cond_1

    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session;->activity:Landroid/app/Activity;

    invoke-virtual {p0, p1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    const-string p0, ""

    return-object p0
.end method
