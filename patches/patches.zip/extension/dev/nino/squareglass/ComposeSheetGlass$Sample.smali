.class final Ldev/nino/squareglass/ComposeSheetGlass$Sample;
.super Ljava/lang/Object;
.source "ComposeSheetGlass.kt"

# interfaces
.implements Ldev/nino/squareglass/backdrop/Backdrop;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/ComposeSheetGlass;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Sample"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nComposeSheetGlass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ComposeSheetGlass.kt\ndev/nino/squareglass/ComposeSheetGlass$Sample\n+ 2 Offset.kt\nandroidx/compose/ui/geometry/Offset\n+ 3 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 4 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n+ 5 DrawScope.kt\nandroidx/compose/ui/graphics/drawscope/DrawScopeKt\n*L\n1#1,93:1\n65#2:94\n69#2:97\n60#3:95\n70#3:98\n22#4:96\n120#5,3:99\n233#5:102\n124#5,3:103\n*S KotlinDebug\n*F\n+ 1 ComposeSheetGlass.kt\ndev/nino/squareglass/ComposeSheetGlass$Sample\n*L\n86#1:94\n86#1:97\n86#1:95\n86#1:98\n86#1:96\n86#1:99,3\n87#1:102\n86#1:103,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0015\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J9\u0010\u0013\u001a\u00020\u0014*\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\u0008\u0010\u0018\u001a\u0004\u0018\u00010\u00192\u0019\u0010\u001a\u001a\u0015\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u001b\u00a2\u0006\u0002\u0008\u001dH\u0016J\u0006\u0010\u001e\u001a\u00020\u0014R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0008\u001a\n \n*\u0004\u0018\u00010\t0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u000cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\u00020\u0011X\u0096D\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u0012\u00a8\u0006\u001f"
    }
    d2 = {
        "Ldev/nino/squareglass/ComposeSheetGlass$Sample;",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "activity",
        "Landroid/app/Activity;",
        "target",
        "Landroid/view/View;",
        "<init>",
        "(Landroid/app/Activity;Landroid/view/View;)V",
        "snapshot",
        "Ldev/nino/squareglass/PlayerWindow$Snapshot;",
        "kotlin.jvm.PlatformType",
        "node",
        "Landroid/graphics/RenderNode;",
        "origin",
        "",
        "screen",
        "isCoordinatesDependent",
        "",
        "()Z",
        "drawBackdrop",
        "",
        "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
        "density",
        "Landroidx/compose/ui/unit/Density;",
        "coordinates",
        "Landroidx/compose/ui/layout/LayoutCoordinates;",
        "layerBlock",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "Lkotlin/ExtensionFunctionType;",
        "release",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final isCoordinatesDependent:Z

.field private final node:Landroid/graphics/RenderNode;

.field private final origin:[I

.field private final screen:[I

.field private final snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

.field private final target:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Landroid/view/View;)V
    .locals 7

    const-string v0, "activity"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "target"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->target:Landroid/view/View;

    .line 61
    invoke-static {}, Ldev/nino/squareglass/PlayerWindow;->take()Ldev/nino/squareglass/PlayerWindow$Snapshot;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    .line 62
    new-instance v1, Landroid/graphics/RenderNode;

    const-string v2, "Liquidify Compose sheet source"

    invoke-direct {v1, v2}, Landroid/graphics/RenderNode;-><init>(Ljava/lang/String;)V

    iput-object v1, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->node:Landroid/graphics/RenderNode;

    const/4 v2, 0x2

    .line 63
    new-array v3, v2, [I

    iput-object v3, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->origin:[I

    .line 64
    new-array v2, v2, [I

    iput-object v2, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->screen:[I

    const/4 v2, 0x1

    .line 65
    iput-boolean v2, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->isCoordinatesDependent:Z

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    .line 71
    move-object v5, p1

    check-cast v5, Landroid/content/Context;

    invoke-virtual {v0, v5, v4}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->view(Landroid/content/Context;Z)Landroid/view/View;

    move-result-object v5

    if-nez v5, :cond_1

    :cond_0
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v5

    const-string p1, "getDecorView(...)"

    invoke-static {v5, p1}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1
    if-eqz v0, :cond_2

    .line 73
    iget p1, v0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->width:I

    iget v6, v0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->height:I

    invoke-virtual {v5, v4, v4, p1, v6}, Landroid/view/View;->layout(IIII)V

    .line 74
    iget p1, v0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->x:I

    aput p1, v3, v4

    iget p1, v0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->y:I

    aput p1, v3, v2

    goto :goto_0

    .line 75
    :cond_2
    invoke-virtual {v5, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 76
    :goto_0
    invoke-virtual {v5}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p2}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object p2

    if-eq p1, p2, :cond_3

    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result p1

    if-lez p1, :cond_3

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result p1

    if-lez p1, :cond_3

    .line 77
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result p1

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result p2

    invoke-virtual {v1, v4, v4, p1, p2}, Landroid/graphics/RenderNode;->setPosition(IIII)Z

    .line 78
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result p1

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result p2

    invoke-virtual {v1, p1, p2}, Landroid/graphics/RenderNode;->beginRecording(II)Landroid/graphics/RecordingCanvas;

    move-result-object p1

    const-string p2, "beginRecording(...)"

    invoke-static {p1, p2}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    :try_start_0
    check-cast p1, Landroid/graphics/Canvas;

    invoke-virtual {v5, p1}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v1}, Landroid/graphics/RenderNode;->endRecording()V

    return-void

    :catchall_0
    move-exception p1

    iget-object p0, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p0}, Landroid/graphics/RenderNode;->endRecording()V

    throw p1

    :cond_3
    return-void
.end method


# virtual methods
.method public drawBackdrop(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/unit/Density;Landroidx/compose/ui/layout/LayoutCoordinates;Lam0/l;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroidx/compose/ui/unit/Density;",
            "Landroidx/compose/ui/layout/LayoutCoordinates;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;)V"
        }
    .end annotation

    const-string p4, "<this>"

    invoke-static {p1, p4}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p4, "density"

    invoke-static {p2, p4}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p3, :cond_2

    .line 83
    invoke-interface {p3}, Landroidx/compose/ui/layout/LayoutCoordinates;->isAttached()Z

    move-result p2

    if-eqz p2, :cond_2

    iget-object p2, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p2}, Landroid/graphics/RenderNode;->hasDisplayList()Z

    move-result p2

    if-nez p2, :cond_0

    goto/16 :goto_0

    .line 84
    :cond_0
    iget-object p2, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->target:Landroid/view/View;

    invoke-virtual {p2}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object p2

    iget-object p4, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->screen:[I

    invoke-virtual {p2, p4}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 85
    invoke-static {p3}, Landroidx/compose/ui/layout/LayoutCoordinatesKt;->positionInWindow(Landroidx/compose/ui/layout/LayoutCoordinates;)J

    move-result-wide p2

    .line 86
    iget-object p4, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->origin:[I

    const/4 v0, 0x0

    aget p4, p4, v0

    iget-object v1, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->screen:[I

    aget v0, v1, v0

    sub-int/2addr p4, v0

    int-to-float p4, p4

    const/16 v0, 0x20

    shr-long v0, p2, v0

    long-to-int v0, v0

    .line 96
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    sub-float/2addr p4, v0

    .line 86
    iget-object v0, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->origin:[I

    const/4 v1, 0x1

    aget v0, v0, v1

    iget-object v2, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->screen:[I

    aget v1, v2, v1

    sub-int/2addr v0, v1

    int-to-float v0, v0

    const-wide v1, 0xffffffffL

    and-long/2addr p2, v1

    long-to-int p2, p2

    .line 96
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p2

    sub-float/2addr v0, p2

    .line 99
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p2

    invoke-interface {p2}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p2

    invoke-interface {p2, p4, v0}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    .line 102
    :try_start_0
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p2

    invoke-interface {p2}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object p2

    .line 87
    invoke-static {p2}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object p3

    invoke-virtual {p3}, Landroid/graphics/Canvas;->isHardwareAccelerated()Z

    move-result p3

    if-eqz p3, :cond_1

    invoke-static {p2}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object p2

    iget-object p0, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->node:Landroid/graphics/RenderNode;

    invoke-virtual {p2, p0}, Landroid/graphics/Canvas;->drawRenderNode(Landroid/graphics/RenderNode;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 103
    :cond_1
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p0

    neg-float p1, p4

    neg-float p2, v0

    invoke-interface {p0, p1, p2}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    return-void

    :catchall_0
    move-exception p0

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object p1

    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getTransform()Landroidx/compose/ui/graphics/drawscope/DrawTransform;

    move-result-object p1

    neg-float p2, p4

    neg-float p3, v0

    invoke-interface {p1, p2, p3}, Landroidx/compose/ui/graphics/drawscope/DrawTransform;->translate(FF)V

    throw p0

    :cond_2
    :goto_0
    return-void
.end method

.method public isCoordinatesDependent()Z
    .locals 0

    .line 65
    iget-boolean p0, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->isCoordinatesDependent:Z

    return p0
.end method

.method public final release()V
    .locals 1

    .line 90
    iget-object v0, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->node:Landroid/graphics/RenderNode;

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->discardDisplayList()V

    iget-object p0, p0, Ldev/nino/squareglass/ComposeSheetGlass$Sample;->snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->release()V

    :cond_0
    return-void
.end method
