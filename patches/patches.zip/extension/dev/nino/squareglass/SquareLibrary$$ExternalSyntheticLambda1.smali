.class public final synthetic Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Lkotlinx/coroutines/CoroutineScope;

.field public final synthetic f$2:Lam0/l;

.field public final synthetic f$3:Z

.field public final synthetic f$4:Lam0/a;

.field public final synthetic f$5:I


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lkotlinx/coroutines/CoroutineScope;Lam0/l;ZLam0/a;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$0:Ljava/util/List;

    iput-object p2, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$1:Lkotlinx/coroutines/CoroutineScope;

    iput-object p3, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$2:Lam0/l;

    iput-boolean p4, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$3:Z

    iput-object p5, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$4:Lam0/a;

    iput p6, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$5:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$0:Ljava/util/List;

    iget-object v1, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$1:Lkotlinx/coroutines/CoroutineScope;

    iget-object v2, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$2:Lam0/l;

    iget-boolean v3, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$3:Z

    iget-object v4, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$4:Lam0/a;

    iget v5, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda1;->f$5:I

    move-object v6, p1

    check-cast v6, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/SquareLibrary;->$r8$lambda$VfN3FB2nHH8_3XwPerJ31EEt0CE(Ljava/util/List;Lkotlinx/coroutines/CoroutineScope;Lam0/l;ZLam0/a;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
