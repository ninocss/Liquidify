.class public final synthetic Ldev/nino/squareglass/SquareOutput$Session$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareOutput$Session;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareOutput$Session;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareOutput$Session$3;->f$0:Ldev/nino/squareglass/SquareOutput$Session;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SquareOutput$Session$3;->f$0:Ldev/nino/squareglass/SquareOutput$Session;

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquareOutput$Session;->$r8$lambda$ULNuPX_H6jeLwUH7RAPBCrFQvKM(Ldev/nino/squareglass/SquareOutput$Session;Landroid/view/View;)V

    return-void
.end method
