.class public final synthetic Ldev/nino/squareglass/LinnPlayer$12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:I

.field public final synthetic f$2:Ldev/nino/squareglass/LinnPlayer;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;ILdev/nino/squareglass/LinnPlayer;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$12;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput p2, p0, Ldev/nino/squareglass/LinnPlayer$12;->f$1:I

    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer$12;->f$2:Ldev/nino/squareglass/LinnPlayer;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$12;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget v1, p0, Ldev/nino/squareglass/LinnPlayer$12;->f$1:I

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$12;->f$2:Ldev/nino/squareglass/LinnPlayer;

    invoke-static {v0, v1, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$k-HtG2Jm2UuPv0OmnqLuXewsqqQ(Ldev/nino/squareglass/LinnPlayer;ILdev/nino/squareglass/LinnPlayer;)V

    return-void
.end method
