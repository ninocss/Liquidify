.class public final Ldev/nino/squareglass/SleepDeadline;
.super Ljava/lang/Object;
.source "SleepDeadline.java"


# instance fields
.field private deadline:J

.field private revision:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public active()Z
    .locals 4

    .line 25
    iget-wide v0, p0, Ldev/nino/squareglass/SleepDeadline;->deadline:J

    const-wide/16 v2, 0x0

    cmp-long p0, v0, v2

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public cancel()V
    .locals 2

    const-wide/16 v0, 0x0

    .line 19
    iput-wide v0, p0, Ldev/nino/squareglass/SleepDeadline;->deadline:J

    iget v0, p0, Ldev/nino/squareglass/SleepDeadline;->revision:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ldev/nino/squareglass/SleepDeadline;->revision:I

    return-void
.end method

.method public consume(IJ)Z
    .locals 2

    .line 29
    iget v0, p0, Ldev/nino/squareglass/SleepDeadline;->revision:I

    if-ne p1, v0, :cond_1

    invoke-virtual {p0}, Ldev/nino/squareglass/SleepDeadline;->active()Z

    move-result p1

    if-eqz p1, :cond_1

    iget-wide v0, p0, Ldev/nino/squareglass/SleepDeadline;->deadline:J

    cmp-long p1, p2, v0

    if-gez p1, :cond_0

    goto :goto_0

    .line 31
    :cond_0
    invoke-virtual {p0}, Ldev/nino/squareglass/SleepDeadline;->cancel()V

    const/4 p0, 0x1

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return p0
.end method

.method public deadline()J
    .locals 2

    .line 23
    iget-wide v0, p0, Ldev/nino/squareglass/SleepDeadline;->deadline:J

    return-wide v0
.end method

.method public remaining(J)J
    .locals 4

    .line 21
    iget-wide v0, p0, Ldev/nino/squareglass/SleepDeadline;->deadline:J

    const-wide/16 v2, 0x0

    cmp-long p0, v0, v2

    if-nez p0, :cond_0

    return-wide v2

    :cond_0
    sub-long/2addr v0, p1

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p0

    return-wide p0
.end method

.method public start(JJ)I
    .locals 2

    const-wide/16 v0, 0x0

    cmp-long v0, p3, v0

    if-lez v0, :cond_0

    const-wide/32 v0, 0xa4cb80

    cmp-long v0, p3, v0

    if-gtz v0, :cond_0

    .line 15
    invoke-static {p1, p2, p3, p4}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p1

    iput-wide p1, p0, Ldev/nino/squareglass/SleepDeadline;->deadline:J

    iget p1, p0, Ldev/nino/squareglass/SleepDeadline;->revision:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Ldev/nino/squareglass/SleepDeadline;->revision:I

    return p1

    .line 13
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Duration must be 1 to 180 minutes"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
