.class public final Ldev/nino/squareglass/NativeIconGlass;
.super Ljava/lang/Object;
.source "NativeIconGlass.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/NativeIconGlass$State;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeIconGlass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeIconGlass.kt\ndev/nino/squareglass/NativeIconGlass\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Effects.kt\nandroidx/compose/runtime/EffectsKt\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 5 Effects.kt\nandroidx/compose/runtime/EffectsKt$rememberCoroutineScope$1\n*L\n1#1,87:1\n1#2:88\n599#3:89\n596#3,6:90\n1128#4,3:96\n1131#4,3:100\n1128#4,6:103\n1128#4,6:109\n597#5:99\n*S KotlinDebug\n*F\n+ 1 NativeIconGlass.kt\ndev/nino/squareglass/NativeIconGlass\n*L\n44#1:89\n44#1:90,6\n44#1:96,3\n44#1:100,3\n45#1:103,6\n49#1:109,6\n44#1:99\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0008\u00c7\u0002\u0018\u00002\u00020\u0001:\u0001\u0011B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0006H\u0007J\u0010\u0010\u000b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0006H\u0007J\u0018\u0010\u000c\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u000eH\u0007J\u0018\u0010\u000f\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u0006H\u0007R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0012"
    }
    d2 = {
        "Ldev/nino/squareglass/NativeIconGlass;",
        "",
        "<init>",
        "()V",
        "states",
        "Ljava/util/WeakHashMap;",
        "Landroid/view/View;",
        "Ldev/nino/squareglass/NativeIconGlass$State;",
        "attach",
        "",
        "view",
        "detach",
        "touch",
        "event",
        "Landroid/view/MotionEvent;",
        "observe",
        "child",
        "State",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/NativeIconGlass;

.field private static final states:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ldev/nino/squareglass/NativeIconGlass$State;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$FeLJmf0IFrd4dJjDZCq8gG09PhQ(Ldev/nino/squareglass/NativeIconGlass$State;Landroidx/compose/ui/platform/ComposeView;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/NativeIconGlass;->attach$lambda$1(Ldev/nino/squareglass/NativeIconGlass$State;Landroidx/compose/ui/platform/ComposeView;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$RizWUs0HSPXiKQyV9pVZqNB458w(Ldev/nino/squareglass/NativeIconGlass$State;I)V
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeIconGlass;->attach$lambda$0(Ldev/nino/squareglass/NativeIconGlass$State;I)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/NativeIconGlass;

    invoke-direct {v0}, Ldev/nino/squareglass/NativeIconGlass;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativeIconGlass;->INSTANCE:Ldev/nino/squareglass/NativeIconGlass;

    .line 31
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    const/16 v0, 0x8

    sput v0, Ldev/nino/squareglass/NativeIconGlass;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final attach(Landroid/view/View;)V
    .locals 8

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0b02c6

    if-ne v0, v1, :cond_1

    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_1

    sget-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 35
    :cond_0
    new-instance v2, Landroidx/compose/ui/platform/ComposeView;

    move-object v1, p0

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v4, "getContext(...)"

    invoke-static {v3, v4}, Ldev/nino/squareglass/HostCompat;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v7}, Landroidx/compose/ui/platform/ComposeView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 36
    sget-object v3, Landroidx/compose/ui/platform/ViewCompositionStrategy$DisposeOnDetachedFromWindow;->INSTANCE:Landroidx/compose/ui/platform/ViewCompositionStrategy$DisposeOnDetachedFromWindow;

    check-cast v3, Landroidx/compose/ui/platform/ViewCompositionStrategy;

    invoke-virtual {v2, v3}, Landroidx/compose/ui/platform/ComposeView;->setViewCompositionStrategy(Landroidx/compose/ui/platform/ViewCompositionStrategy;)V

    .line 37
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    const/4 v4, 0x4

    invoke-virtual {v3, v4}, Landroid/view/View;->setImportantForAccessibility(I)V

    const/4 v4, 0x0

    .line 38
    invoke-virtual {v3, v4}, Landroid/view/View;->setClickable(Z)V

    .line 39
    invoke-virtual {v3, v4}, Landroid/view/View;->setFocusable(Z)V

    .line 40
    new-instance v5, Ldev/nino/squareglass/NativeIconGlass$State;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->isSelected()Z

    move-result v6

    invoke-direct {v5, v2, v6}, Ldev/nino/squareglass/NativeIconGlass$State;-><init>(Landroidx/compose/ui/platform/ComposeView;Z)V

    .line 41
    check-cast v0, Ljava/util/Map;

    invoke-interface {v0, p0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    new-instance v0, Ldev/nino/squareglass/NativeIconGlass$$ExternalSyntheticLambda0;

    invoke-direct {v0, v5}, Ldev/nino/squareglass/NativeIconGlass$$ExternalSyntheticLambda0;-><init>(Ldev/nino/squareglass/NativeIconGlass$State;)V

    invoke-static {p0, v0}, Ldev/nino/squareglass/IconMotion;->registerNative(Landroid/view/View;Ljava/util/function/IntConsumer;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {v5, p0}, Ldev/nino/squareglass/NativeIconGlass$State;->setToken(Ljava/lang/Object;)V

    .line 43
    new-instance p0, Ldev/nino/squareglass/NativeIconGlass$$ExternalSyntheticLambda1;

    invoke-direct {p0, v5, v2}, Ldev/nino/squareglass/NativeIconGlass$$ExternalSyntheticLambda1;-><init>(Ldev/nino/squareglass/NativeIconGlass$State;Landroidx/compose/ui/platform/ComposeView;)V

    const v0, -0x7cdabd34

    const/4 v5, 0x1

    invoke-static {v0, v5, p0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object p0

    check-cast p0, Lam0/p;

    invoke-virtual {v2, p0}, Landroidx/compose/ui/platform/ComposeView;->setContent(Lam0/p;)V

    .line 55
    new-instance p0, Landroid/view/ViewGroup$LayoutParams;

    const/4 v0, -0x1

    invoke-direct {p0, v0, v0}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v3, v4, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    :cond_1
    :goto_0
    return-void
.end method

.method private static final attach$lambda$0(Ldev/nino/squareglass/NativeIconGlass$State;I)V
    .locals 0

    .line 42
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/NativeIconGlass$State;->getEvent()I

    move-result p1

    add-int/lit8 p1, p1, 0x1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/NativeIconGlass$State;->setEvent(I)V

    :cond_0
    return-void
.end method

.method private static final attach$lambda$1(Ldev/nino/squareglass/NativeIconGlass$State;Landroidx/compose/ui/platform/ComposeView;Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 15

    move-object/from16 v4, p2

    move/from16 v0, p3

    const-string v1, "C43@1804L24,44@1857L47,48@2065L176,48@2035L206,52@2270L43,52@2254L60:NativeIconGlass.kt#vqphja"

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x3

    const/4 v2, 0x1

    const/4 v7, 0x0

    const/4 v3, 0x2

    if-eq v1, v3, :cond_0

    move v1, v2

    goto :goto_0

    :cond_0
    move v1, v7

    :goto_0
    and-int/lit8 v5, v0, 0x1

    invoke-interface {v4, v1, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, -0x1

    const-string v5, "dev.nino.squareglass.NativeIconGlass.attach.<anonymous> (NativeIconGlass.kt:43)"

    const v6, -0x7cdabd34

    invoke-static {v6, v0, v1, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_1
    const v0, 0x2e20b340

    .line 44
    const-string v1, "CC(rememberCoroutineScope)N(getContext)600@27430L68:Effects.kt#9igjgp"

    .line 89
    invoke-static {v4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v0, 0x28c0fdc4

    .line 94
    const-string v1, "CC(remember):Effects.kt#9igjgp"

    .line 95
    invoke-static {v4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 96
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .line 97
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_2

    .line 99
    sget-object v0, Lkotlin/coroutines/EmptyCoroutineContext;->INSTANCE:Lkotlin/coroutines/EmptyCoroutineContext;

    .line 95
    check-cast v0, Lkotlin/coroutines/h;

    invoke-static {v0, v4}, Landroidx/compose/runtime/EffectsKt;->createCompositionCoroutineScope(Lkotlin/coroutines/h;Landroidx/compose/runtime/Composer;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v0

    .line 100
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 95
    :cond_2
    check-cast v0, Lkotlinx/coroutines/CoroutineScope;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 89
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v1, 0x4edfc9db

    .line 45
    const-string v5, "CC(remember):NativeIconGlass.kt#9igjgp"

    invoke-static {v4, v1, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .line 103
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    const/4 v8, 0x0

    if-nez v1, :cond_3

    .line 104
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v6, v1, :cond_4

    .line 45
    :cond_3
    new-instance v6, Ldev/nino/squareglass/material/InteractiveHighlight;

    invoke-direct {v6, v0, v8, v3, v8}, Ldev/nino/squareglass/material/InteractiveHighlight;-><init>(Lkotlinx/coroutines/CoroutineScope;Lam0/p;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 106
    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 45
    :cond_4
    move-object v12, v6

    check-cast v12, Ldev/nino/squareglass/material/InteractiveHighlight;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 46
    sget-object v0, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v0}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 47
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v11

    .line 48
    invoke-virtual {p0}, Ldev/nino/squareglass/NativeIconGlass$State;->getEvent()I

    move-result v10

    .line 49
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const v1, 0x4edfe45c

    invoke-static {v4, v1, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v4, v10}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v1

    invoke-interface {v4, v11}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v3

    or-int/2addr v1, v3

    invoke-interface {v4, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    move-object/from16 v13, p1

    invoke-interface {v4, v13}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    .line 109
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    if-nez v1, :cond_5

    .line 110
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v3, v1, :cond_6

    .line 49
    :cond_5
    new-instance v9, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;

    const/4 v14, 0x0

    invoke-direct/range {v9 .. v14}, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;-><init>(IZLdev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/platform/ComposeView;Lkotlin/coroutines/e;)V

    move-object v3, v9

    check-cast v3, Lam0/p;

    .line 112
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 49
    :cond_6
    check-cast v3, Lam0/p;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {p0, v0, v3, v4, v7}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Lam0/p;Landroidx/compose/runtime/Composer;I)V

    .line 53
    sget-object v0, Ldev/nino/squareglass/GlassMotion;->INSTANCE:Ldev/nino/squareglass/GlassMotion;

    sget-object p0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast p0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    invoke-static {p0, v1, v2, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v5, 0xc06

    const/4 v6, 0x4

    const/4 v3, 0x0

    move-object v2, v12

    invoke-virtual/range {v0 .. v6}, Ldev/nino/squareglass/GlassMotion;->feedback(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/material/InteractiveHighlight;Ldev/nino/squareglass/backdrop/Backdrop;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {p0, v4, v7}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    .line 43
    :cond_7
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 54
    :cond_8
    :goto_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final detach(Landroid/view/View;)V
    .locals 2

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    sget-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconGlass$State;

    if-nez v0, :cond_0

    goto :goto_1

    .line 59
    :cond_0
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getToken()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-static {v1}, Ldev/nino/squareglass/IconMotion;->unregisterNative(Ljava/lang/Object;)V

    .line 60
    :cond_1
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getPaint()Landroidx/compose/ui/platform/ComposeView;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/ui/platform/ComposeView;->disposeComposition()V

    .line 61
    instance-of v1, p0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_2

    check-cast p0, Landroid/view/ViewGroup;

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    :goto_0
    if-eqz p0, :cond_3

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getPaint()Landroidx/compose/ui/platform/ComposeView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_3
    :goto_1
    return-void
.end method

.method public static final observe(Landroid/view/View;Landroid/view/View;)V
    .locals 3

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "child"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    sget-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconGlass$State;

    if-nez v0, :cond_0

    goto :goto_0

    .line 78
    :cond_0
    instance-of p1, p1, Landroid/widget/ImageView;

    if-eqz p1, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->isSelected()Z

    move-result p1

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getSelected()Z

    move-result v1

    if-ne p1, v1, :cond_1

    goto :goto_0

    .line 79
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->isSelected()Z

    move-result p0

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/NativeIconGlass$State;->setSelected(Z)V

    .line 80
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide p0

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getTap()J

    move-result-wide v1

    sub-long/2addr p0, v1

    const-wide/16 v1, 0x2710

    cmp-long p0, p0, v1

    if-gez p0, :cond_2

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p0

    if-eqz p0, :cond_2

    .line 81
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getEvent()I

    move-result p0

    add-int/lit8 p0, p0, 0x1

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/NativeIconGlass$State;->setEvent(I)V

    .line 82
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getSelected()Z

    move-result p0

    if-eqz p0, :cond_2

    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->likeAnimations:I

    add-int/lit8 p0, p0, 0x1

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->likeAnimations:I

    :cond_2
    const-wide/16 p0, -0x4e20

    .line 84
    invoke-virtual {v0, p0, p1}, Ldev/nino/squareglass/NativeIconGlass$State;->setTap(J)V

    :cond_3
    :goto_0
    return-void
.end method

.method public static final touch(Landroid/view/View;Landroid/view/MotionEvent;)V
    .locals 7

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "event"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    sget-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconGlass$State;

    if-nez v0, :cond_0

    goto/16 :goto_0

    .line 65
    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_4

    if-eq v1, v2, :cond_3

    const/4 v3, 0x2

    if-eq v1, v3, :cond_2

    const/4 p0, 0x3

    if-eq v1, p0, :cond_1

    const/4 p0, 0x5

    if-eq v1, p0, :cond_1

    goto :goto_0

    .line 72
    :cond_1
    invoke-virtual {v0, v2}, Ldev/nino/squareglass/NativeIconGlass$State;->setMoved(Z)V

    return-void

    .line 70
    :cond_2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getX()F

    move-result v3

    sub-float/2addr v1, v3

    float-to-double v3, v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getY()F

    move-result v1

    sub-float/2addr p1, v1

    float-to-double v5, p1

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v3

    double-to-float p1, v3

    .line 71
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result p0

    int-to-float p0, p0

    cmpl-float p0, p1, p0

    if-lez p0, :cond_5

    invoke-virtual {v0, v2}, Ldev/nino/squareglass/NativeIconGlass$State;->setMoved(Z)V

    return-void

    .line 73
    :cond_3
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getMoved()Z

    move-result p0

    if-nez p0, :cond_5

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide p0

    invoke-virtual {v0, p0, p1}, Ldev/nino/squareglass/NativeIconGlass$State;->setTap(J)V

    return-void

    .line 67
    :cond_4
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result p0

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/NativeIconGlass$State;->setX(F)V

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p0

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/NativeIconGlass$State;->setY(F)V

    const/4 p0, 0x0

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/NativeIconGlass$State;->setMoved(Z)V

    .line 68
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p0

    if-eqz p0, :cond_5

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getEvent()I

    move-result p0

    add-int/2addr p0, v2

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/NativeIconGlass$State;->setEvent(I)V

    :cond_5
    :goto_0
    return-void
.end method
