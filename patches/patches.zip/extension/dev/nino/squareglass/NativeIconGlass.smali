.class public final Ldev/nino/squareglass/NativeIconGlass;
.super Ljava/lang/Object;
.source "NativeIconGlass.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/NativeIconGlass$State;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeIconGlass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeIconGlass.kt\ndev/nino/squareglass/NativeIconGlass\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,80:1\n1#2:81\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u00c7\u0002\u0018\u00002\u00020\u0001:\u0001\u0016B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\u0007H\u0002J\u0010\u0010\u000c\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0006H\u0007J\u0010\u0010\r\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0006H\u0007J\u0018\u0010\u000e\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u0010H\u0007J \u0010\u0011\u001a\u00020\u00122\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\u0014\u001a\u00020\u0015H\u0007R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0017"
    }
    d2 = {
        "Ldev/nino/squareglass/NativeIconGlass;",
        "",
        "<init>",
        "()V",
        "states",
        "Ljava/util/WeakHashMap;",
        "Landroid/view/View;",
        "Ldev/nino/squareglass/NativeIconGlass$State;",
        "pulse",
        "",
        "view",
        "state",
        "attach",
        "detach",
        "touch",
        "event",
        "Landroid/view/MotionEvent;",
        "before",
        "",
        "child",
        "canvas",
        "Landroid/graphics/Canvas;",
        "State",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/NativeIconGlass;

.field private static final states:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ldev/nino/squareglass/NativeIconGlass$State;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/NativeIconGlass;

    invoke-direct {v0}, Ldev/nino/squareglass/NativeIconGlass;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativeIconGlass;->INSTANCE:Ldev/nino/squareglass/NativeIconGlass;

    .line 24
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    const/16 v0, 0x8

    sput v0, Ldev/nino/squareglass/NativeIconGlass;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final attach(Landroid/view/View;)V
    .locals 3

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0b02c6

    if-ne v0, v1, :cond_1

    sget-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 36
    :cond_0
    new-instance v1, Ldev/nino/squareglass/NativeIconGlass$State;

    invoke-virtual {p0}, Landroid/view/View;->isSelected()Z

    move-result v2

    invoke-direct {v1, v2}, Ldev/nino/squareglass/NativeIconGlass$State;-><init>(Z)V

    .line 37
    check-cast v0, Ljava/util/Map;

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    new-instance v0, Ldev/nino/squareglass/NativeIconGlass$1;

    invoke-direct {v0, p0, v1}, Ldev/nino/squareglass/NativeIconGlass$1;-><init>(Landroid/view/View;Ldev/nino/squareglass/NativeIconGlass$State;)V

    invoke-static {p0, v0}, Ldev/nino/squareglass/IconMotion;->registerNative(Landroid/view/View;Ljava/util/function/IntConsumer;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {v1, p0}, Ldev/nino/squareglass/NativeIconGlass$State;->setToken(Ljava/lang/Object;)V

    :cond_1
    :goto_0
    return-void
.end method

.method static final attach$lambda$0(Landroid/view/View;Ldev/nino/squareglass/NativeIconGlass$State;I)V
    .locals 0

    .line 38
    sget-object p2, Ldev/nino/squareglass/NativeIconGlass;->INSTANCE:Ldev/nino/squareglass/NativeIconGlass;

    invoke-direct {p2, p0, p1}, Ldev/nino/squareglass/NativeIconGlass;->pulse(Landroid/view/View;Ldev/nino/squareglass/NativeIconGlass$State;)V

    return-void
.end method

.method public static final before(Landroid/view/View;Landroid/view/View;Landroid/graphics/Canvas;)I
    .locals 6

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "child"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "canvas"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    sget-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconGlass$State;

    const/4 v1, -0x1

    if-nez v0, :cond_0

    return v1

    .line 64
    :cond_0
    instance-of v2, p1, Landroid/widget/ImageView;

    if-nez v2, :cond_1

    return v1

    .line 65
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->isSelected()Z

    move-result v2

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getSelected()Z

    move-result v3

    if-eq v2, v3, :cond_3

    .line 66
    invoke-virtual {p0}, Landroid/view/View;->isSelected()Z

    move-result v2

    invoke-virtual {v0, v2}, Ldev/nino/squareglass/NativeIconGlass$State;->setSelected(Z)V

    .line 67
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getTap()J

    move-result-wide v4

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x2710

    cmp-long v2, v2, v4

    if-gez v2, :cond_2

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v2

    if-eqz v2, :cond_2

    .line 68
    sget-object v2, Ldev/nino/squareglass/NativeIconGlass;->INSTANCE:Ldev/nino/squareglass/NativeIconGlass;

    invoke-direct {v2, p0, v0}, Ldev/nino/squareglass/NativeIconGlass;->pulse(Landroid/view/View;Ldev/nino/squareglass/NativeIconGlass$State;)V

    .line 69
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getSelected()Z

    move-result p0

    if-eqz p0, :cond_2

    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->likeAnimations:I

    add-int/lit8 p0, p0, 0x1

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->likeAnimations:I

    :cond_2
    const-wide/16 v2, -0x4e20

    .line 71
    invoke-virtual {v0, v2, v3}, Ldev/nino/squareglass/NativeIconGlass$State;->setTap(J)V

    .line 73
    :cond_3
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p0

    if-eqz p0, :cond_5

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getProgress()F

    move-result p0

    const/high16 v2, 0x3f800000    # 1.0f

    cmpl-float p0, p0, v2

    if-ltz p0, :cond_4

    goto :goto_0

    .line 74
    :cond_4
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getProgress()F

    move-result p0

    const/4 v0, 0x0

    invoke-static {p0, v0, v2}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result p0

    const v0, 0x40490fdb    # (float)Math.PI

    mul-float/2addr p0, v0

    float-to-double v0, p0

    invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D

    move-result-wide v0

    double-to-float p0, v0

    const v0, 0x3d75c28f    # 0.06f

    mul-float/2addr p0, v0

    add-float/2addr p0, v2

    .line 75
    invoke-virtual {p2}, Landroid/graphics/Canvas;->save()I

    move-result v0

    .line 76
    check-cast p1, Landroid/widget/ImageView;

    invoke-virtual {p1}, Landroid/widget/ImageView;->getLeft()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p1}, Landroid/widget/ImageView;->getWidth()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    add-float/2addr v1, v2

    invoke-virtual {p1}, Landroid/widget/ImageView;->getTop()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {p1}, Landroid/widget/ImageView;->getHeight()I

    move-result p1

    int-to-float p1, p1

    div-float/2addr p1, v3

    add-float/2addr v2, p1

    invoke-virtual {p2, p0, p0, v1, v2}, Landroid/graphics/Canvas;->scale(FFFF)V

    return v0

    :cond_5
    :goto_0
    return v1
.end method

.method public static final detach(Landroid/view/View;)V
    .locals 1

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    sget-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconGlass$State;

    if-nez v0, :cond_0

    return-void

    .line 43
    :cond_0
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getToken()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-static {v0}, Ldev/nino/squareglass/IconMotion;->unregisterNative(Ljava/lang/Object;)V

    .line 44
    :cond_1
    const-string v0, "icon"

    invoke-static {p0, v0}, Ldev/nino/squareglass/LiquidViewMotion;->cancel(Landroid/view/View;Ljava/lang/String;)V

    .line 45
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method private final pulse(Landroid/view/View;Ldev/nino/squareglass/NativeIconGlass$State;)V
    .locals 7

    .line 27
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p0

    if-nez p0, :cond_0

    return-void

    .line 28
    :cond_0
    new-instance v5, Ldev/nino/squareglass/NativeIconGlass$0;

    invoke-direct {v5, p2, p1}, Ldev/nino/squareglass/NativeIconGlass$0;-><init>(Ldev/nino/squareglass/NativeIconGlass$State;Landroid/view/View;)V

    const/4 v6, 0x0

    const-string v1, "icon"

    const/4 v2, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    move-object v0, p1

    invoke-static/range {v0 .. v6}, Ldev/nino/squareglass/LiquidViewMotion;->animate(Landroid/view/View;Ljava/lang/String;FFZLjava/util/function/Consumer;Ljava/lang/Runnable;)V

    return-void
.end method

.method static final pulse$lambda$0(Ldev/nino/squareglass/NativeIconGlass$State;Landroid/view/View;Ljava/lang/Float;)V
    .locals 1

    const-string v0, "it"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    move-result p2

    invoke-virtual {p0, p2}, Ldev/nino/squareglass/NativeIconGlass$State;->setProgress(F)V

    .line 30
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public static final touch(Landroid/view/View;Landroid/view/MotionEvent;)V
    .locals 7

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "event"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    sget-object v0, Ldev/nino/squareglass/NativeIconGlass;->states:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/NativeIconGlass$State;

    if-nez v0, :cond_0

    goto :goto_0

    .line 50
    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-eqz v1, :cond_5

    const/4 v2, 0x1

    if-eq v1, v2, :cond_3

    const/4 v3, 0x2

    if-eq v1, v3, :cond_2

    const/4 p0, 0x3

    if-eq v1, p0, :cond_1

    const/4 p0, 0x5

    if-eq v1, p0, :cond_1

    goto :goto_0

    .line 57
    :cond_1
    invoke-virtual {v0, v2}, Ldev/nino/squareglass/NativeIconGlass$State;->setMoved(Z)V

    return-void

    .line 55
    :cond_2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getX()F

    move-result v3

    sub-float/2addr v1, v3

    float-to-double v3, v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getY()F

    move-result v1

    sub-float/2addr p1, v1

    float-to-double v5, p1

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v3

    double-to-float p1, v3

    .line 56
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result p0

    int-to-float p0, p0

    cmpl-float p0, p1, p0

    if-lez p0, :cond_4

    invoke-virtual {v0, v2}, Ldev/nino/squareglass/NativeIconGlass$State;->setMoved(Z)V

    return-void

    .line 58
    :cond_3
    invoke-virtual {v0}, Ldev/nino/squareglass/NativeIconGlass$State;->getMoved()Z

    move-result p0

    if-nez p0, :cond_4

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide p0

    invoke-virtual {v0, p0, p1}, Ldev/nino/squareglass/NativeIconGlass$State;->setTap(J)V

    :cond_4
    :goto_0
    return-void

    .line 52
    :cond_5
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {v0, v1}, Ldev/nino/squareglass/NativeIconGlass$State;->setX(F)V

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    invoke-virtual {v0, p1}, Ldev/nino/squareglass/NativeIconGlass$State;->setY(F)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Ldev/nino/squareglass/NativeIconGlass$State;->setMoved(Z)V

    .line 53
    sget-object p1, Ldev/nino/squareglass/NativeIconGlass;->INSTANCE:Ldev/nino/squareglass/NativeIconGlass;

    invoke-direct {p1, p0, v0}, Ldev/nino/squareglass/NativeIconGlass;->pulse(Landroid/view/View;Ldev/nino/squareglass/NativeIconGlass$State;)V

    return-void
.end method
