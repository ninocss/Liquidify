.class public final synthetic Ldev/nino/squareglass/SquareOutput$Session$4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-static {p1}, Ldev/nino/squareglass/SquareOutput$Session;->lambda$draw$8(Landroid/view/View;)V

    return-void
.end method
