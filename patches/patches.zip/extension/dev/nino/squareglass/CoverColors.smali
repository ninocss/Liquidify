.class public final Ldev/nino/squareglass/CoverColors;
.super Ljava/lang/Object;
.source "CoverColors.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static blend(IIF)I
    .locals 4

    ushr-int/lit8 v0, p0, 0x10

    and-int/lit16 v0, v0, 0xff

    int-to-float v0, v0

    const/high16 v1, 0x3f800000    # 1.0f

    sub-float/2addr v1, p2

    mul-float/2addr v0, v1

    ushr-int/lit8 v2, p1, 0x10

    and-int/lit16 v2, v2, 0xff

    int-to-float v2, v2

    mul-float/2addr v2, p2

    add-float/2addr v0, v2

    .line 7
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    ushr-int/lit8 v2, p0, 0x8

    and-int/lit16 v2, v2, 0xff

    int-to-float v2, v2

    mul-float/2addr v2, v1

    ushr-int/lit8 v3, p1, 0x8

    and-int/lit16 v3, v3, 0xff

    int-to-float v3, v3

    mul-float/2addr v3, p2

    add-float/2addr v2, v3

    .line 8
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    and-int/lit16 p0, p0, 0xff

    int-to-float p0, p0

    mul-float/2addr p0, v1

    and-int/lit16 p1, p1, 0xff

    int-to-float p1, p1

    mul-float/2addr p1, p2

    add-float/2addr p0, p1

    .line 9
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    const/high16 p1, -0x1000000

    shl-int/lit8 p2, v0, 0x10

    or-int/2addr p1, p2

    shl-int/lit8 p2, v2, 0x8

    or-int/2addr p1, p2

    or-int/2addr p0, p1

    return p0
.end method

.method private static channel(I)D
    .locals 4

    int-to-double v0, p0

    const-wide v2, 0x406fe00000000000L    # 255.0

    div-double/2addr v0, v2

    const-wide v2, 0x3fa4b5dcc63f1412L    # 0.04045

    cmpg-double p0, v0, v2

    if-gtz p0, :cond_0

    const-wide v2, 0x4029d70a3d70a3d7L    # 12.92

    div-double/2addr v0, v2

    return-wide v0

    :cond_0
    const-wide v2, 0x3fac28f5c28f5c29L    # 0.055

    add-double/2addr v0, v2

    const-wide v2, 0x3ff0e147ae147ae1L    # 1.055

    div-double/2addr v0, v2

    const-wide v2, 0x4003333333333333L    # 2.4

    .line 56
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    return-wide v0
.end method

.method public static contrast(II)D
    .locals 6

    .line 62
    invoke-static {p0}, Ldev/nino/squareglass/CoverColors;->luminance(I)D

    move-result-wide v0

    invoke-static {p1}, Ldev/nino/squareglass/CoverColors;->luminance(I)D

    move-result-wide p0

    .line 63
    invoke-static {v0, v1, p0, p1}, Ljava/lang/Math;->max(DD)D

    move-result-wide v2

    const-wide v4, 0x3fa999999999999aL    # 0.05

    add-double/2addr v2, v4

    invoke-static {v0, v1, p0, p1}, Ljava/lang/Math;->min(DD)D

    move-result-wide p0

    add-double/2addr p0, v4

    div-double/2addr v2, p0

    return-wide v2
.end method

.method private static luminance(I)D
    .locals 6

    ushr-int/lit8 v0, p0, 0x10

    and-int/lit16 v0, v0, 0xff

    .line 59
    invoke-static {v0}, Ldev/nino/squareglass/CoverColors;->channel(I)D

    move-result-wide v0

    const-wide v2, 0x3fcb367a0f9096bcL    # 0.2126

    mul-double/2addr v0, v2

    ushr-int/lit8 v2, p0, 0x8

    and-int/lit16 v2, v2, 0xff

    invoke-static {v2}, Ldev/nino/squareglass/CoverColors;->channel(I)D

    move-result-wide v2

    const-wide v4, 0x3fe6e2eb1c432ca5L    # 0.7152

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    and-int/lit16 p0, p0, 0xff

    invoke-static {p0}, Ldev/nino/squareglass/CoverColors;->channel(I)D

    move-result-wide v2

    const-wide v4, 0x3fb27bb2fec56d5dL    # 0.0722

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    return-wide v0
.end method

.method public static playerSurface(IZ)I
    .locals 6

    if-nez p1, :cond_0

    const/4 p1, 0x0

    .line 25
    invoke-static {p0, p1}, Ldev/nino/squareglass/CoverColors;->surface(IZ)I

    move-result p0

    return p0

    :cond_0
    const p1, -0xdbdbda

    const v0, 0x3f147ae1    # 0.58f

    .line 27
    invoke-static {p0, p1, v0}, Ldev/nino/squareglass/CoverColors;->blend(IIF)I

    move-result v1

    :goto_0
    const/4 v2, -0x1

    .line 28
    invoke-static {v1, v2}, Ldev/nino/squareglass/CoverColors;->contrast(II)D

    move-result-wide v2

    const-wide/high16 v4, 0x4016000000000000L    # 5.5

    cmpg-double v2, v2, v4

    if-gez v2, :cond_1

    const/high16 v2, 0x3f800000    # 1.0f

    cmpg-float v3, v0, v2

    if-gez v3, :cond_1

    const v1, 0x3ca3d70a    # 0.02f

    add-float/2addr v0, v1

    .line 29
    invoke-static {v2, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-static {p0, p1, v0}, Ldev/nino/squareglass/CoverColors;->blend(IIF)I

    move-result v1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public static seed([I)I
    .locals 21

    move-object/from16 v0, p0

    const/16 v1, 0xd

    .line 34
    new-array v2, v1, [D

    new-array v3, v1, [D

    new-array v4, v1, [D

    new-array v5, v1, [D

    .line 35
    array-length v6, v0

    const/4 v8, 0x0

    :goto_0
    if-ge v8, v6, :cond_6

    aget v11, v0, v8

    ushr-int/lit8 v12, v11, 0x18

    const/16 v13, 0x80

    if-ge v12, v13, :cond_0

    move-object/from16 v20, v2

    goto/16 :goto_4

    :cond_0
    ushr-int/lit8 v12, v11, 0x10

    and-int/lit16 v12, v12, 0xff

    ushr-int/lit8 v13, v11, 0x8

    and-int/lit16 v13, v13, 0xff

    and-int/lit16 v11, v11, 0xff

    .line 38
    invoke-static {v13, v11}, Ljava/lang/Math;->max(II)I

    move-result v14

    invoke-static {v12, v14}, Ljava/lang/Math;->max(II)I

    move-result v14

    invoke-static {v13, v11}, Ljava/lang/Math;->min(II)I

    move-result v15

    invoke-static {v12, v15}, Ljava/lang/Math;->min(II)I

    move-result v15

    sub-int v15, v14, v15

    const/16 v7, 0xc

    const-wide/16 v16, 0x0

    const/16 v9, 0x18

    if-lt v15, v9, :cond_4

    if-ne v14, v12, :cond_1

    sub-int v14, v13, v11

    const-wide/high16 v18, 0x4000000000000000L    # 2.0

    int-to-double v9, v14

    move-object/from16 v20, v2

    int-to-double v1, v15

    div-double/2addr v9, v1

    goto :goto_1

    :cond_1
    move-object/from16 v20, v2

    const-wide/high16 v18, 0x4000000000000000L    # 2.0

    if-ne v14, v13, :cond_2

    sub-int v1, v11, v12

    int-to-double v1, v1

    int-to-double v9, v15

    div-double/2addr v1, v9

    add-double v9, v1, v18

    goto :goto_1

    :cond_2
    sub-int v1, v12, v13

    int-to-double v1, v1

    int-to-double v9, v15

    div-double/2addr v1, v9

    const-wide/high16 v9, 0x4010000000000000L    # 4.0

    add-double/2addr v9, v1

    :goto_1
    cmpg-double v1, v9, v16

    if-gez v1, :cond_3

    const-wide/high16 v1, 0x4018000000000000L    # 6.0

    add-double/2addr v9, v1

    :cond_3
    mul-double v9, v9, v18

    double-to-int v1, v9

    const/16 v2, 0xb

    .line 43
    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_2

    :cond_4
    move-object/from16 v20, v2

    move v1, v7

    :goto_2
    if-ne v1, v7, :cond_5

    const-wide/high16 v9, 0x3fd0000000000000L    # 0.25

    goto :goto_3

    :cond_5
    int-to-double v9, v15

    const-wide/high16 v14, 0x4060000000000000L    # 128.0

    div-double/2addr v9, v14

    const-wide/high16 v14, 0x3ff0000000000000L    # 1.0

    add-double/2addr v9, v14

    .line 46
    :goto_3
    aget-wide v14, v20, v1

    move v2, v1

    int-to-double v0, v12

    mul-double/2addr v0, v9

    add-double/2addr v14, v0

    aput-wide v14, v20, v2

    aget-wide v0, v3, v2

    int-to-double v12, v13

    mul-double/2addr v12, v9

    add-double/2addr v0, v12

    aput-wide v0, v3, v2

    aget-wide v0, v4, v2

    int-to-double v11, v11

    mul-double/2addr v11, v9

    add-double/2addr v0, v11

    aput-wide v0, v4, v2

    aget-wide v0, v5, v2

    add-double/2addr v0, v9

    aput-wide v0, v5, v2

    :goto_4
    add-int/lit8 v8, v8, 0x1

    move-object/from16 v0, p0

    move-object/from16 v2, v20

    const/16 v1, 0xd

    goto/16 :goto_0

    :cond_6
    move-object/from16 v20, v2

    const-wide/16 v16, 0x0

    const/4 v0, 0x1

    const/16 v1, 0xd

    const/4 v7, 0x0

    :goto_5
    if-ge v0, v1, :cond_8

    .line 49
    aget-wide v8, v5, v0

    aget-wide v10, v5, v7

    cmpl-double v2, v8, v10

    if-lez v2, :cond_7

    move v7, v0

    :cond_7
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 50
    :cond_8
    aget-wide v0, v5, v7

    cmpl-double v2, v0, v16

    if-nez v2, :cond_9

    const v0, -0x7f7f80

    return v0

    .line 52
    :cond_9
    aget-wide v5, v20, v7

    div-double/2addr v5, v0

    .line 51
    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v5

    long-to-int v2, v5

    shl-int/lit8 v2, v2, 0x10

    const/high16 v5, -0x1000000

    or-int/2addr v2, v5

    aget-wide v5, v3, v7

    div-double/2addr v5, v0

    .line 52
    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v5

    long-to-int v3, v5

    shl-int/lit8 v3, v3, 0x8

    or-int/2addr v2, v3

    aget-wide v3, v4, v7

    div-double/2addr v3, v0

    invoke-static {v3, v4}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    or-int/2addr v0, v2

    return v0
.end method

.method public static surface(IZ)I
    .locals 7

    if-eqz p1, :cond_0

    const v0, -0xf2f1ef

    goto :goto_0

    :cond_0
    const v0, -0xe0d0a

    :goto_0
    if-eqz p1, :cond_1

    const v1, -0x4b473c

    goto :goto_1

    :cond_1
    const v1, -0xa29d93

    :goto_1
    if-eqz p1, :cond_2

    const p1, 0x3f051eb8    # 0.52f

    goto :goto_2

    :cond_2
    const p1, 0x3eb33333    # 0.35f

    .line 16
    :goto_2
    invoke-static {p0, v0, p1}, Ldev/nino/squareglass/CoverColors;->blend(IIF)I

    move-result v2

    .line 18
    :goto_3
    invoke-static {v2, v1}, Ldev/nino/squareglass/CoverColors;->contrast(II)D

    move-result-wide v3

    const-wide/high16 v5, 0x4012000000000000L    # 4.5

    cmpg-double v3, v3, v5

    if-gez v3, :cond_3

    const/high16 v3, 0x3f800000    # 1.0f

    cmpg-float v4, p1, v3

    if-gez v4, :cond_3

    const v2, 0x3ca3d70a    # 0.02f

    add-float/2addr p1, v2

    .line 19
    invoke-static {v3, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    .line 20
    invoke-static {p0, v0, p1}, Ldev/nino/squareglass/CoverColors;->blend(IIF)I

    move-result v2

    goto :goto_3

    :cond_3
    return v2
.end method
