.class public final synthetic Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareSongMenu;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareSongMenu;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/SquareSongMenu;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-static {p0}, Ldev/nino/squareglass/SquareSongMenu;->$r8$lambda$G-Q5Y2C59aVX9t3WU0eJ755Q0BM(Ldev/nino/squareglass/SquareSongMenu;)V

    return-void
.end method
