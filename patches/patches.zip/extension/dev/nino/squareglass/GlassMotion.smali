.class public final Ldev/nino/squareglass/GlassMotion;
.super Ljava/lang/Object;
.source "GlassMotion.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nGlassMotion.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GlassMotion.kt\ndev/nino/squareglass/GlassMotion\n+ 2 Effects.kt\nandroidx/compose/runtime/EffectsKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Effects.kt\nandroidx/compose/runtime/EffectsKt$rememberCoroutineScope$1\n+ 5 Dp.kt\nandroidx/compose/ui/unit/DpKt\n*L\n1#1,70:1\n599#2:71\n596#2,6:72\n1128#3,3:78\n1131#3,3:82\n1128#3,6:85\n1128#3,6:91\n1128#3,6:97\n1128#3,6:103\n1128#3,6:109\n1128#3,6:115\n1128#3,6:121\n597#4:81\n113#5:127\n*S KotlinDebug\n*F\n+ 1 GlassMotion.kt\ndev/nino/squareglass/GlassMotion\n*L\n26#1:71\n26#1:72,6\n26#1:78,3\n26#1:82,3\n27#1:85,6\n38#1:91,6\n39#1:97,6\n50#1:103,6\n55#1:109,6\n60#1:115,6\n63#1:121,6\n26#1:81\n43#1:127\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005H\u0007J\u0015\u0010\u0007\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005H\u0007\u00a2\u0006\u0002\u0010\u0008J\'\u0010\t\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u000b2\u0008\u0008\u0002\u0010\u000c\u001a\u00020\rH\u0007\u00a2\u0006\u0002\u0010\u000e\u00a8\u0006\u000f"
    }
    d2 = {
        "Ldev/nino/squareglass/GlassMotion;",
        "",
        "<init>",
        "()V",
        "bounce",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "control",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "feedback",
        "highlight",
        "Ldev/nino/squareglass/material/InteractiveHighlight;",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/material/InteractiveHighlight;Ldev/nino/squareglass/backdrop/Backdrop;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/GlassMotion;


# direct methods
.method public static synthetic $r8$lambda$9G0VtuNC9i2Hx-QqyXYhO6fHA0A(Ldev/nino/squareglass/material/InteractiveHighlight;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/GlassMotion;->feedback$lambda$5$0(Ldev/nino/squareglass/material/InteractiveHighlight;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$BPtAUCYTxzAHROT6zQteE22wvno(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/GlassMotion;->bounce$lambda$0(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JF3huwdLfv04DnoE1gD5GX69y0g(Ldev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/graphics/GraphicsLayerScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/GlassMotion;->feedback$lambda$3$0(Ldev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/graphics/GraphicsLayerScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JX-ANoXePWXlnKSY4hdANqSKRFI(Ldev/nino/squareglass/material/InteractiveHighlight;)Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/GlassMotion;->feedback$lambda$2$0(Ldev/nino/squareglass/material/InteractiveHighlight;)Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$VE1bnizU_udWyID96Uv10vy1C2s(Ldev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/graphics/drawscope/DrawScope;Lam0/l;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/GlassMotion;->feedback$lambda$4$0(Ldev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/graphics/drawscope/DrawScope;Lam0/l;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$edjisbuDzrIgZkv6ynG7FCFijvY(Ldev/nino/squareglass/material/InteractiveHighlight;Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/GlassMotion;->feedback$lambda$1$0(Ldev/nino/squareglass/material/InteractiveHighlight;Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vrPM9t154nN-N82A2JoeeEqCtpg()Landroidx/compose/ui/graphics/Shape;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/GlassMotion;->feedback$lambda$0$0()Landroidx/compose/ui/graphics/Shape;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/GlassMotion;

    invoke-direct {v0}, Ldev/nino/squareglass/GlassMotion;-><init>()V

    sput-object v0, Ldev/nino/squareglass/GlassMotion;->INSTANCE:Ldev/nino/squareglass/GlassMotion;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final bounce(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;
    .locals 3

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    new-instance v0, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda0;-><init>()V

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1, v2}, Landroidx/compose/ui/ComposedModifierKt;->composed$default(Landroidx/compose/ui/Modifier;Lam0/l;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method

.method private static final bounce$lambda$0(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 2

    const-string v0, "$this$composed"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const p0, -0x482f9fd0

    .line 23
    invoke-interface {p1, p0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "C22@1047L17:GlassMotion.kt#vqphja"

    invoke-static {p1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v1, "dev.nino.squareglass.GlassMotion.bounce.<anonymous> (GlassMotion.kt:22)"

    invoke-static {p0, p2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    sget-object p0, Ldev/nino/squareglass/GlassMotion;->INSTANCE:Ldev/nino/squareglass/GlassMotion;

    sget-object p2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast p2, Landroidx/compose/ui/Modifier;

    const/16 v0, 0x36

    invoke-virtual {p0, p2, p1, v0}, Ldev/nino/squareglass/GlassMotion;->control(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object p0
.end method

.method private static final feedback$lambda$0$0()Landroidx/compose/ui/graphics/Shape;
    .locals 1

    .line 38
    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/Shape;

    return-object v0
.end method

.method private static final feedback$lambda$1$0(Ldev/nino/squareglass/material/InteractiveHighlight;Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 8

    const-string v0, "$this$drawBackdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/material/InteractiveHighlight;->getPressProgress()F

    move-result p0

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {p0, v1, v0}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result v1

    :cond_0
    const p0, 0x3a83126f    # 0.001f

    cmpl-float p0, v1, p0

    if-lez p0, :cond_1

    .line 41
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result p0

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1

    .line 42
    invoke-static {p1}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->vibrancy(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)V

    int-to-float p0, v0

    .line 127
    invoke-static {p0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result p0

    .line 43
    invoke-interface {p1, p0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result p0

    mul-float/2addr p0, v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1, p0, v2, v0, v3}, Ldev/nino/squareglass/backdrop/effects/BlurKt;->blur-3YTHUZs$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FIILjava/lang/Object;)V

    .line 44
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result p0

    if-nez p0, :cond_1

    .line 45
    invoke-interface {p1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->getSize-NH-jbRc()J

    move-result-wide v2

    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Size;->getMinDimension-impl(J)F

    move-result p0

    const v0, 0x3e4ccccd    # 0.2f

    mul-float/2addr p0, v0

    mul-float/2addr p0, v1

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v0

    mul-float v2, p0, v0

    const p0, 0x3fb33333    # 1.4f

    mul-float v3, v2, p0

    const/16 v6, 0xc

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v1, p1

    .line 46
    invoke-static/range {v1 .. v7}, Ldev/nino/squareglass/backdrop/effects/LensKt;->lens$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZILjava/lang/Object;)V

    .line 49
    :cond_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final feedback$lambda$2$0(Ldev/nino/squareglass/material/InteractiveHighlight;)Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 8

    .line 51
    sget-object v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;->Companion:Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;

    invoke-virtual {v0}, Ldev/nino/squareglass/backdrop/highlight/Highlight$Companion;->getDefault()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v1

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    const/4 v3, 0x2

    if-eq v0, v3, :cond_0

    .line 52
    invoke-virtual {p0}, Ldev/nino/squareglass/material/InteractiveHighlight;->getPressProgress()F

    move-result p0

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {p0, v2, v0}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result v2

    :cond_0
    move v4, v2

    const/16 v6, 0xb

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x0

    .line 51
    invoke-static/range {v1 .. v7}, Ldev/nino/squareglass/backdrop/highlight/Highlight;->copy-i1RSzL4$default(Ldev/nino/squareglass/backdrop/highlight/Highlight;FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;ILjava/lang/Object;)Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object p0

    return-object p0
.end method

.method private static final feedback$lambda$3$0(Ldev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/graphics/GraphicsLayerScope;)Lkotlin/u;
    .locals 2

    const-string v0, "$this$drawBackdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/material/InteractiveHighlight;->getPressProgress()F

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    const v0, 0x3da3d70a    # 0.08f

    mul-float/2addr v0, p0

    const/high16 v1, 0x3f800000    # 1.0f

    add-float/2addr v0, v1

    .line 57
    invoke-interface {p1, v0}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->setScaleX(F)V

    const v0, 0x3d23d70a    # 0.04f

    mul-float/2addr p0, v0

    sub-float/2addr v1, p0

    .line 58
    invoke-interface {p1, v1}, Landroidx/compose/ui/graphics/GraphicsLayerScope;->setScaleY(F)V

    .line 59
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final feedback$lambda$4$0(Ldev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/graphics/drawscope/DrawScope;Lam0/l;)Lkotlin/u;
    .locals 1

    const-string v0, "$this$drawBackdrop"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "drawContent"

    invoke-static {p2, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/material/InteractiveHighlight;->getPressProgress()F

    move-result p0

    const v0, 0x3a83126f    # 0.001f

    cmpl-float p0, p0, v0

    if-lez p0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result p0

    const/4 v0, 0x2

    if-eq p0, v0, :cond_0

    invoke-interface {p2, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final feedback$lambda$5$0(Ldev/nino/squareglass/material/InteractiveHighlight;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 14

    const-string v0, "$this$drawBackdrop"

    move-object/from16 v1, p3

    invoke-static {v1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/material/InteractiveHighlight;->getPressProgress()F

    move-result p0

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {p0, v2, v0}, Ldev/nino/squareglass/HostCompat;->coerceIn(FFF)F

    move-result v2

    :cond_0
    const p0, 0x3d75c28f    # 0.06f

    mul-float v5, v2, p0

    const/16 v9, 0xe

    const/4 v10, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-wide v3, p1

    .line 65
    invoke-static/range {v3 .. v10}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v2

    const/16 v12, 0x7e

    const/4 v13, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x0

    const/4 v11, 0x0

    invoke-static/range {v1 .. v13}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 66
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final control(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 10

    const-string v0, "original"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(control)N(original)25@1148L24,26@1197L47,27@1260L52:GlassMotion.kt#vqphja"

    const v1, 0x4ea6b39f

    .line 25
    invoke-static {p2, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.GlassMotion.control (GlassMotion.kt:24)"

    invoke-static {v1, p3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    const v0, 0x2e20b340

    .line 26
    const-string v1, "CC(rememberCoroutineScope)N(getContext)600@27430L68:Effects.kt#9igjgp"

    .line 71
    invoke-static {p2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v0, 0x28c0fdc4

    .line 76
    const-string v1, "CC(remember):Effects.kt#9igjgp"

    .line 77
    invoke-static {p2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 78
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .line 79
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_1

    .line 81
    sget-object v0, Lkotlin/coroutines/EmptyCoroutineContext;->INSTANCE:Lkotlin/coroutines/EmptyCoroutineContext;

    .line 77
    check-cast v0, Lkotlin/coroutines/h;

    invoke-static {v0, p2}, Landroidx/compose/runtime/EffectsKt;->createCompositionCoroutineScope(Lkotlin/coroutines/h;Landroidx/compose/runtime/Composer;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v0

    .line 82
    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 77
    :cond_1
    check-cast v0, Lkotlinx/coroutines/CoroutineScope;

    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 71
    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v1, 0x3fc8562e    # 1.56513f

    .line 26
    const-string v2, "CC(remember):GlassMotion.kt#9igjgp"

    .line 27
    invoke-static {p2, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .line 85
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v1, :cond_2

    .line 86
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v2, v1, :cond_3

    .line 27
    :cond_2
    new-instance v2, Ldev/nino/squareglass/material/InteractiveHighlight;

    const/4 v1, 0x2

    const/4 v3, 0x0

    invoke-direct {v2, v0, v3, v1, v3}, Ldev/nino/squareglass/material/InteractiveHighlight;-><init>(Lkotlinx/coroutines/CoroutineScope;Lam0/p;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 88
    invoke-interface {p2, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 27
    :cond_3
    move-object v5, v2

    check-cast v5, Ldev/nino/squareglass/material/InteractiveHighlight;

    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 28
    sget-object v0, Ldev/nino/squareglass/NativeBackdrop;->INSTANCE:Ldev/nino/squareglass/NativeBackdrop;

    invoke-virtual {v0}, Ldev/nino/squareglass/NativeBackdrop;->getActive()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v6

    and-int/lit8 v0, p3, 0xe

    shl-int/lit8 p3, p3, 0x6

    and-int/lit16 p3, p3, 0x1c00

    or-int v8, v0, p3

    const/4 v9, 0x0

    move-object v3, p0

    move-object v4, p1

    move-object v7, p2

    invoke-virtual/range {v3 .. v9}, Ldev/nino/squareglass/GlassMotion;->feedback(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/material/InteractiveHighlight;Ldev/nino/squareglass/backdrop/Backdrop;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-virtual {v5}, Ldev/nino/squareglass/material/InteractiveHighlight;->getGestureModifier()Landroidx/compose/ui/Modifier;

    move-result-object p1

    invoke-interface {p0, p1}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 25
    :cond_4
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method public final feedback(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/material/InteractiveHighlight;Ldev/nino/squareglass/backdrop/Backdrop;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;
    .locals 22

    move-object/from16 v0, p2

    move-object/from16 v1, p4

    const-string v2, "original"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "highlight"

    invoke-static {v0, v2}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C(feedback)N(original,highlight,backdrop)33@1548L4,37@1693L15,38@1732L523,49@2281L193,54@2528L199,59@2758L156,62@2944L184:GlassMotion.kt#vqphja"

    const v4, 0x6cc05e3f

    .line 32
    invoke-static {v1, v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v2, p6, 0x4

    if-eqz v2, :cond_0

    invoke-static {}, Ldev/nino/squareglass/backdrop/backdrops/EmptyBackdropKt;->emptyBackdrop()Ldev/nino/squareglass/backdrop/Backdrop;

    move-result-object v2

    goto :goto_0

    :cond_0
    move-object/from16 v2, p3

    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_1

    const/4 v5, -0x1

    const-string v6, "dev.nino.squareglass.GlassMotion.feedback (GlassMotion.kt:31)"

    move/from16 v7, p5

    invoke-static {v4, v7, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 33
    :cond_1
    sget-object v4, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v4}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 34
    sget-object v4, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v5, 0x6

    invoke-virtual {v4, v1, v5}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v4

    .line 35
    invoke-static {v4}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v4

    invoke-static {v4}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v4

    const v6, 0x3e21f2ae

    .line 38
    const-string v7, "CC(remember):GlassMotion.kt#9igjgp"

    invoke-static {v1, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 91
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .line 92
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_2

    .line 93
    new-instance v6, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda1;

    invoke-direct {v6}, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda1;-><init>()V

    .line 94
    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 38
    :cond_2
    check-cast v6, Lam0/a;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, 0x3e21f98a

    .line 39
    invoke-static {v1, v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 97
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    if-nez v8, :cond_3

    .line 98
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v9, v8, :cond_4

    .line 39
    :cond_3
    new-instance v9, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda2;

    invoke-direct {v9, v0}, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda2;-><init>(Ldev/nino/squareglass/material/InteractiveHighlight;)V

    .line 100
    invoke-interface {v1, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 39
    :cond_4
    check-cast v9, Lam0/l;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, 0x3e223ce0

    .line 50
    invoke-static {v1, v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 103
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    if-nez v8, :cond_5

    .line 104
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v10, v8, :cond_6

    .line 50
    :cond_5
    new-instance v10, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda3;

    invoke-direct {v10, v0}, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda3;-><init>(Ldev/nino/squareglass/material/InteractiveHighlight;)V

    .line 106
    invoke-interface {v1, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 50
    :cond_6
    check-cast v10, Lam0/a;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, 0x3e225bc6

    .line 55
    invoke-static {v1, v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 109
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    if-nez v8, :cond_7

    .line 110
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v11, v8, :cond_8

    .line 55
    :cond_7
    new-instance v11, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda4;

    invoke-direct {v11, v0}, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda4;-><init>(Ldev/nino/squareglass/material/InteractiveHighlight;)V

    .line 112
    invoke-interface {v1, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 55
    :cond_8
    check-cast v11, Lam0/l;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, 0x3e22785b

    .line 60
    invoke-static {v1, v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 115
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    if-nez v8, :cond_9

    .line 116
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v12, v8, :cond_a

    .line 60
    :cond_9
    new-instance v12, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda5;

    invoke-direct {v12, v0}, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda5;-><init>(Ldev/nino/squareglass/material/InteractiveHighlight;)V

    .line 118
    invoke-interface {v1, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 60
    :cond_a
    move-object v13, v12

    check-cast v13, Lam0/p;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, 0x3e228fb7

    .line 63
    invoke-static {v1, v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    invoke-interface {v1, v4, v5}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v8

    or-int/2addr v7, v8

    .line 121
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    if-nez v7, :cond_b

    .line 122
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v8, v7, :cond_c

    .line 63
    :cond_b
    new-instance v8, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda6;

    invoke-direct {v8, v0, v4, v5}, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda6;-><init>(Ldev/nino/squareglass/material/InteractiveHighlight;J)V

    .line 124
    invoke-interface {v1, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 63
    :cond_c
    move-object v14, v8

    check-cast v14, Lam0/l;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v20, 0xf9a0

    const/16 v21, 0x0

    const/4 v8, 0x0

    move-object v5, v6

    move-object v6, v9

    const/4 v9, 0x0

    move-object v7, v10

    move-object v10, v11

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object v4, v2

    .line 36
    invoke-static/range {v3 .. v21}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->drawBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 67
    invoke-virtual {v0}, Ldev/nino/squareglass/material/InteractiveHighlight;->getModifier()Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-interface {v2, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 32
    :cond_d
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object v0
.end method
