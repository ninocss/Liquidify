.class final Ldev/nino/squareglass/IconMotion$decorate$4$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "IconMotion.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nIconMotion.kt\nKotlin\n*S Kotlin\n*F\n+ 1 IconMotion.kt\ndev/nino/squareglass/IconMotion$decorate$4$1\n+ 2 Rect.kt\nandroidx/compose/ui/geometry/Rect\n+ 3 Offset.kt\nandroidx/compose/ui/geometry/OffsetKt\n+ 4 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n*L\n1#1,154:1\n57#2,6:155\n30#3:161\n53#4,3:162\n*S KotlinDebug\n*F\n+ 1 IconMotion.kt\ndev/nino/squareglass/IconMotion$decorate$4$1\n*L\n125#1:155,6\n125#1:161\n125#1:162,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $bounds$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Landroidx/compose/ui/geometry/Rect;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $event$delegate:Landroidx/compose/runtime/MutableIntState;

.field final synthetic $highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

.field final synthetic $motion:Z

.field label:I


# direct methods
.method constructor <init>(ZLdev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ldev/nino/squareglass/material/InteractiveHighlight;",
            "Landroidx/compose/runtime/MutableIntState;",
            "Landroidx/compose/runtime/MutableState<",
            "Landroidx/compose/ui/geometry/Rect;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/IconMotion$decorate$4$1;",
            ">;)V"
        }
    .end annotation

    iput-boolean p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$motion:Z

    iput-object p2, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

    iput-object p3, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$event$delegate:Landroidx/compose/runtime/MutableIntState;

    iput-object p4, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$bounds$delegate:Landroidx/compose/runtime/MutableState;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/IconMotion$decorate$4$1;

    iget-boolean v1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$motion:Z

    iget-object v2, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

    iget-object v3, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$event$delegate:Landroidx/compose/runtime/MutableIntState;

    iget-object v4, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$bounds$delegate:Landroidx/compose/runtime/MutableState;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/IconMotion$decorate$4$1;-><init>(ZLdev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$4$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$4$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/IconMotion$decorate$4$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 124
    iget v0, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->label:I

    if-nez v0, :cond_1

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 125
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$event$delegate:Landroidx/compose/runtime/MutableIntState;

    invoke-static {p1}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I

    move-result p1

    if-lez p1, :cond_0

    iget-boolean p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$motion:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

    iget-object v0, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$bounds$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {v0}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$5(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/geometry/Rect;

    move-result-object v0

    .line 155
    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Rect;->getRight()F

    move-result v1

    invoke-virtual {v0}, Landroidx/compose/ui/geometry/Rect;->getLeft()F

    move-result v0

    sub-float/2addr v1, v0

    const/high16 v0, 0x40000000    # 2.0f

    div-float/2addr v1, v0

    .line 125
    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$bounds$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$5(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/geometry/Rect;

    move-result-object p0

    .line 160
    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getBottom()F

    move-result v2

    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getTop()F

    move-result p0

    sub-float/2addr v2, p0

    div-float/2addr v2, v0

    .line 162
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    int-to-long v0, p0

    .line 163
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    int-to-long v2, p0

    const/16 p0, 0x20

    shl-long/2addr v0, p0

    const-wide v4, 0xffffffffL

    and-long/2addr v2, v4

    or-long/2addr v0, v2

    .line 161
    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Offset;->constructor-impl(J)J

    move-result-wide v0

    .line 125
    invoke-virtual {p1, v0, v1}, Ldev/nino/squareglass/material/InteractiveHighlight;->pulse-k-4lQ0M(J)V

    goto :goto_0

    .line 126
    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

    invoke-virtual {p0}, Ldev/nino/squareglass/material/InteractiveHighlight;->reset()V

    .line 127
    :goto_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0

    .line 124
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
