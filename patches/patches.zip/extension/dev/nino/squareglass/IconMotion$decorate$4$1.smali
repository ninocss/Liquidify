.class final Ldev/nino/squareglass/IconMotion$decorate$4$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "IconMotion.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $event$delegate:Landroidx/compose/runtime/MutableIntState;

.field final synthetic $kind$delegate:Landroidx/compose/runtime/MutableIntState;

.field final synthetic $motion:Z

.field final synthetic $progress:Landroidx/compose/animation/core/Animatable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/animation/core/Animatable<",
            "Ljava/lang/Float;",
            "Landroidx/compose/animation/core/AnimationVector1D;",
            ">;"
        }
    .end annotation
.end field

.field label:I


# direct methods
.method constructor <init>(ZLandroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Landroidx/compose/animation/core/Animatable<",
            "Ljava/lang/Float;",
            "Landroidx/compose/animation/core/AnimationVector1D;",
            ">;",
            "Landroidx/compose/runtime/MutableIntState;",
            "Landroidx/compose/runtime/MutableIntState;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/IconMotion$decorate$4$1;",
            ">;)V"
        }
    .end annotation

    iput-boolean p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$motion:Z

    iput-object p2, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$progress:Landroidx/compose/animation/core/Animatable;

    iput-object p3, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$event$delegate:Landroidx/compose/runtime/MutableIntState;

    iput-object p4, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$kind$delegate:Landroidx/compose/runtime/MutableIntState;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/IconMotion$decorate$4$1;

    iget-boolean v1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$motion:Z

    iget-object v2, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$progress:Landroidx/compose/animation/core/Animatable;

    iget-object v3, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$event$delegate:Landroidx/compose/runtime/MutableIntState;

    iget-object v4, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$kind$delegate:Landroidx/compose/runtime/MutableIntState;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/IconMotion$decorate$4$1;-><init>(ZLandroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;Lkotlin/coroutines/e;)V

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$4$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/IconMotion$decorate$4$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/IconMotion$decorate$4$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 130
    iget v1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->label:I

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v1, :cond_3

    if-eq v1, v4, :cond_2

    if-eq v1, v5, :cond_1

    if-ne v1, v3, :cond_0

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto/16 :goto_3

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_4

    :cond_2
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    goto :goto_0

    :cond_3
    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 131
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$event$delegate:Landroidx/compose/runtime/MutableIntState;

    invoke-static {p1}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I

    move-result p1

    if-lez p1, :cond_6

    iget-boolean p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$motion:Z

    if-eqz p1, :cond_6

    .line 132
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$progress:Landroidx/compose/animation/core/Animatable;

    const/4 v1, 0x0

    invoke-static {v1}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v1

    move-object v3, p0

    check-cast v3, Lkotlin/coroutines/e;

    iput v4, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->label:I

    invoke-virtual {p1, v1, v3}, Landroidx/compose/animation/core/Animatable;->snapTo(Ljava/lang/Object;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_4

    goto :goto_2

    .line 133
    :cond_4
    :goto_0
    iget-object v6, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$progress:Landroidx/compose/animation/core/Animatable;

    invoke-static {v2}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v7

    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$kind$delegate:Landroidx/compose/runtime/MutableIntState;

    invoke-static {p1}, Ldev/nino/squareglass/IconMotion;->access$decorate$lambda$5(Landroidx/compose/runtime/MutableIntState;)I

    move-result p1

    if-ne p1, v5, :cond_5

    const/16 p1, 0x26c

    goto :goto_1

    :cond_5
    const/16 p1, 0x1cc

    :goto_1
    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1, v1, v3, v2, v3}, Landroidx/compose/animation/core/AnimationSpecKt;->tween$default(IILandroidx/compose/animation/core/Easing;ILjava/lang/Object;)Landroidx/compose/animation/core/TweenSpec;

    move-result-object p1

    move-object v8, p1

    check-cast v8, Landroidx/compose/animation/core/AnimationSpec;

    move-object v11, p0

    check-cast v11, Lkotlin/coroutines/e;

    iput v5, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->label:I

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v12, 0xc

    const/4 v13, 0x0

    invoke-static/range {v6 .. v13}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Ljava/lang/Object;Lam0/l;Lkotlin/coroutines/e;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_8

    goto :goto_2

    .line 134
    :cond_6
    iget-object p1, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->$progress:Landroidx/compose/animation/core/Animatable;

    invoke-static {v2}, Ldev/nino/squareglass/HostCompat;->boxFloat(F)Ljava/lang/Float;

    move-result-object v1

    move-object v2, p0

    check-cast v2, Lkotlin/coroutines/e;

    iput v3, p0, Ldev/nino/squareglass/IconMotion$decorate$4$1;->label:I

    invoke-virtual {p1, v1, v2}, Landroidx/compose/animation/core/Animatable;->snapTo(Ljava/lang/Object;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_7

    :goto_2
    return-object v0

    .line 135
    :cond_7
    :goto_3
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    :cond_8
    :goto_4
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method
