.class final enum Ldev/nino/squareglass/OpenHome$Failure;
.super Ljava/lang/Enum;
.source "OpenHome.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/OpenHome;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "Failure"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Ldev/nino/squareglass/OpenHome$Failure;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Ldev/nino/squareglass/OpenHome$Failure;

.field public static final enum AUTH:Ldev/nino/squareglass/OpenHome$Failure;

.field public static final enum CONFLICT:Ldev/nino/squareglass/OpenHome$Failure;

.field public static final enum REJECTED:Ldev/nino/squareglass/OpenHome$Failure;

.field public static final enum TIMEOUT:Ldev/nino/squareglass/OpenHome$Failure;

.field public static final enum UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

.field public static final enum UNREACHABLE:Ldev/nino/squareglass/OpenHome$Failure;


# direct methods
.method private static synthetic $values()[Ldev/nino/squareglass/OpenHome$Failure;
    .locals 6

    .line 37
    sget-object v0, Ldev/nino/squareglass/OpenHome$Failure;->UNREACHABLE:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v1, Ldev/nino/squareglass/OpenHome$Failure;->TIMEOUT:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v2, Ldev/nino/squareglass/OpenHome$Failure;->REJECTED:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v3, Ldev/nino/squareglass/OpenHome$Failure;->AUTH:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v4, Ldev/nino/squareglass/OpenHome$Failure;->CONFLICT:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v5, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    filled-new-array/range {v0 .. v5}, [Ldev/nino/squareglass/OpenHome$Failure;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 37
    new-instance v0, Ldev/nino/squareglass/OpenHome$Failure;

    const-string v1, "UNREACHABLE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/OpenHome$Failure;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/OpenHome$Failure;->UNREACHABLE:Ldev/nino/squareglass/OpenHome$Failure;

    new-instance v0, Ldev/nino/squareglass/OpenHome$Failure;

    const-string v1, "TIMEOUT"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/OpenHome$Failure;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/OpenHome$Failure;->TIMEOUT:Ldev/nino/squareglass/OpenHome$Failure;

    new-instance v0, Ldev/nino/squareglass/OpenHome$Failure;

    const-string v1, "REJECTED"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/OpenHome$Failure;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/OpenHome$Failure;->REJECTED:Ldev/nino/squareglass/OpenHome$Failure;

    new-instance v0, Ldev/nino/squareglass/OpenHome$Failure;

    const-string v1, "AUTH"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/OpenHome$Failure;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/OpenHome$Failure;->AUTH:Ldev/nino/squareglass/OpenHome$Failure;

    new-instance v0, Ldev/nino/squareglass/OpenHome$Failure;

    const-string v1, "CONFLICT"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/OpenHome$Failure;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/OpenHome$Failure;->CONFLICT:Ldev/nino/squareglass/OpenHome$Failure;

    new-instance v0, Ldev/nino/squareglass/OpenHome$Failure;

    const-string v1, "UNCERTAIN"

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/OpenHome$Failure;-><init>(Ljava/lang/String;I)V

    sput-object v0, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    invoke-static {}, Ldev/nino/squareglass/OpenHome$Failure;->$values()[Ldev/nino/squareglass/OpenHome$Failure;

    move-result-object v0

    sput-object v0, Ldev/nino/squareglass/OpenHome$Failure;->$VALUES:[Ldev/nino/squareglass/OpenHome$Failure;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 37
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Ldev/nino/squareglass/OpenHome$Failure;
    .locals 1
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            null
        }
    .end annotation

    .line 37
    const-class v0, Ldev/nino/squareglass/OpenHome$Failure;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/OpenHome$Failure;

    return-object p0
.end method

.method public static values()[Ldev/nino/squareglass/OpenHome$Failure;
    .locals 1

    .line 37
    sget-object v0, Ldev/nino/squareglass/OpenHome$Failure;->$VALUES:[Ldev/nino/squareglass/OpenHome$Failure;

    invoke-virtual {v0}, [Ldev/nino/squareglass/OpenHome$Failure;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ldev/nino/squareglass/OpenHome$Failure;

    return-object v0
.end method
