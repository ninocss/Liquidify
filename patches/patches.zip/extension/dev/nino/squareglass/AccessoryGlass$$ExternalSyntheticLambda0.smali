.class public final synthetic Ldev/nino/squareglass/AccessoryGlass$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/AccessoryGlass$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/AccessoryGlass$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;

    invoke-static {p0}, Ldev/nino/squareglass/AccessoryGlass;->$r8$lambda$fH3dRO46yz4Thcuovx-GrfCzGkg(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    return-object p0
.end method
