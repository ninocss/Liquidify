.class public final synthetic Ldev/nino/squareglass/SurfaceMotion$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Landroid/view/View;

.field public final synthetic f$1:Z

.field public final synthetic f$2:Z

.field public final synthetic f$3:F


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;ZZF)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SurfaceMotion$0;->f$0:Landroid/view/View;

    iput-boolean p2, p0, Ldev/nino/squareglass/SurfaceMotion$0;->f$1:Z

    iput-boolean p3, p0, Ldev/nino/squareglass/SurfaceMotion$0;->f$2:Z

    iput p4, p0, Ldev/nino/squareglass/SurfaceMotion$0;->f$3:F

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SurfaceMotion$0;->f$0:Landroid/view/View;

    iget-boolean v1, p0, Ldev/nino/squareglass/SurfaceMotion$0;->f$1:Z

    iget-boolean v2, p0, Ldev/nino/squareglass/SurfaceMotion$0;->f$2:Z

    iget p0, p0, Ldev/nino/squareglass/SurfaceMotion$0;->f$3:F

    check-cast p1, Ljava/lang/Float;

    invoke-static {v0, v1, v2, p0, p1}, Ldev/nino/squareglass/SurfaceMotion;->lambda$enter$0(Landroid/view/View;ZZFLjava/lang/Float;)V

    return-void
.end method
