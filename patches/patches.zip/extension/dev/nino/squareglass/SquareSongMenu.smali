.class final Ldev/nino/squareglass/SquareSongMenu;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "SquareSongMenu.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/SquareSongMenu$NativeHolder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
        "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;",
        ">;"
    }
.end annotation


# instance fields
.field final fit:Ljava/lang/Runnable;

.field final fitListener:Landroid/view/View$OnLayoutChangeListener;

.field final footer:Landroid/widget/ScrollView;

.field final glass:Ldev/nino/squareglass/LiquidMenuSurface;

.field final layout:Landroid/widget/LinearLayout;

.field final list:Landroidx/recyclerview/widget/RecyclerView;

.field final listView:Landroid/view/View;

.field final mapping:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field final observer:Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;

.field final panel:Landroid/view/View;

.field final quick:Landroid/widget/GridLayout;

.field final rebuild:Ljava/lang/Runnable;

.field released:Z

.field final source:Landroidx/recyclerview/widget/RecyclerView$Adapter;


# direct methods
.method public static synthetic $r8$lambda$56-dIAQoyh55z077KIeXRKINWQo(Ldev/nino/squareglass/SquareSongMenu;Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/SquareSongMenu;->lambda$new$1(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$80pJa4hI_YuTeLoms6oH3BrxJWY(Ldev/nino/squareglass/SquareSongMenu;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/SquareSongMenu;->rebuild()V

    return-void
.end method

.method public static synthetic $r8$lambda$G-Q5Y2C59aVX9t3WU0eJ755Q0BM(Ldev/nino/squareglass/SquareSongMenu;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/SquareSongMenu;->fit()V

    return-void
.end method

.method public static synthetic $r8$lambda$_FlMTZRsj7jE5PVD5W8JQ34smzs(Ldev/nino/squareglass/SquareSongMenu;Landroid/view/View;IIIIIIII)V
    .locals 0

    invoke-direct/range {p0 .. p9}, Ldev/nino/squareglass/SquareSongMenu;->lambda$new$0(Landroid/view/View;IIIIIIII)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mdp(Ldev/nino/squareglass/SquareSongMenu;I)I
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$mschedule(Ldev/nino/squareglass/SquareSongMenu;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/SquareSongMenu;->schedule()V

    return-void
.end method

.method private constructor <init>(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Adapter;Ldev/nino/squareglass/LiquidMenuSurface;Z)V
    .locals 11

    .line 84
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    .line 27
    new-instance v0, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda0;-><init>(Ldev/nino/squareglass/SquareSongMenu;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->fit:Ljava/lang/Runnable;

    .line 28
    new-instance v0, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda1;-><init>(Ldev/nino/squareglass/SquareSongMenu;)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->fitListener:Landroid/view/View$OnLayoutChangeListener;

    .line 32
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Ldev/nino/squareglass/SquareSongMenu;->mapping:Ljava/util/ArrayList;

    .line 33
    new-instance v1, Ldev/nino/squareglass/SquareSongMenu$1;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/SquareSongMenu$1;-><init>(Ldev/nino/squareglass/SquareSongMenu;)V

    iput-object v1, p0, Ldev/nino/squareglass/SquareSongMenu;->observer:Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;

    .line 40
    new-instance v2, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda2;-><init>(Ldev/nino/squareglass/SquareSongMenu;)V

    iput-object v2, p0, Ldev/nino/squareglass/SquareSongMenu;->rebuild:Ljava/lang/Runnable;

    .line 85
    iput-object p2, p0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    iput-object p1, p0, Ldev/nino/squareglass/SquareSongMenu;->list:Landroidx/recyclerview/widget/RecyclerView;

    iput-object p1, p0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    iput-object p3, p0, Ldev/nino/squareglass/SquareSongMenu;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    .line 86
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup;

    invoke-virtual {v2, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v3

    .line 87
    iput-object v2, p0, Ldev/nino/squareglass/SquareSongMenu;->panel:Landroid/view/View;

    .line 88
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    invoke-virtual {v2, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 89
    new-instance v5, Landroid/widget/LinearLayout;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v5, p0, Ldev/nino/squareglass/SquareSongMenu;->layout:Landroid/widget/LinearLayout;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 91
    invoke-virtual {v2, v5, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 92
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v6, -0x1

    const/4 v7, 0x0

    invoke-direct {v3, v6, v7, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v5, p1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v3, 0xc

    if-eqz p4, :cond_0

    .line 94
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p4

    invoke-static {p4, p3}, Ldev/nino/squareglass/SleepTimer;->button(Landroid/content/Context;Ldev/nino/squareglass/LiquidMenuSurface;)Landroid/view/View;

    move-result-object p3

    .line 95
    new-instance p4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x38

    invoke-direct {p0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v4

    invoke-direct {p4, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 96
    invoke-direct {p0, v3}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v4

    const/4 v8, 0x6

    invoke-direct {p0, v8}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v8

    invoke-direct {p0, v3}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v9

    const/4 v10, 0x4

    invoke-direct {p0, v10}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v10

    invoke-virtual {p4, v4, v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v5, p3, p4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 98
    :cond_0
    new-instance p3, Landroid/widget/GridLayout;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p4

    invoke-direct {p3, p4}, Landroid/widget/GridLayout;-><init>(Landroid/content/Context;)V

    iput-object p3, p0, Ldev/nino/squareglass/SquareSongMenu;->quick:Landroid/widget/GridLayout;

    invoke-direct {p0, v3}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result p4

    const/16 v4, 0xa

    invoke-direct {p0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v4

    invoke-direct {p0, v3}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v3

    const/16 v8, 0x10

    invoke-direct {p0, v8}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v8

    invoke-virtual {p3, p4, v4, v3, v8}, Landroid/widget/GridLayout;->setPadding(IIII)V

    .line 99
    new-instance p4, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda3;

    invoke-direct {p4, p0}, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda3;-><init>(Ldev/nino/squareglass/SquareSongMenu;)V

    invoke-virtual {p3, p4}, Landroid/widget/GridLayout;->setOnApplyWindowInsetsListener(Landroid/view/View$OnApplyWindowInsetsListener;)V

    .line 104
    new-instance p4, Ldev/nino/squareglass/SquareSongMenu$2;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {p4, p0, v3}, Ldev/nino/squareglass/SquareSongMenu$2;-><init>(Ldev/nino/squareglass/SquareSongMenu;Landroid/content/Context;)V

    iput-object p4, p0, Ldev/nino/squareglass/SquareSongMenu;->footer:Landroid/widget/ScrollView;

    .line 112
    invoke-virtual {p4, v7}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    invoke-virtual {p4, v7}, Landroid/widget/ScrollView;->setClipToPadding(Z)V

    .line 113
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x2

    invoke-direct {v3, v6, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p4, p3, v3}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 114
    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p3, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, p4, p3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 115
    invoke-virtual {v2, v0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 116
    invoke-virtual {p2, v1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->registerAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;)V

    invoke-direct {p0}, Ldev/nino/squareglass/SquareSongMenu;->rebuild()V

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    return-void
.end method

.method private dp(I)I
    .locals 0

    int-to-float p1, p1

    .line 83
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method private fit()V
    .locals 4

    .line 119
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareSongMenu;->released:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->panel:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 120
    :cond_0
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v1, 0x2

    .line 121
    new-array v1, v1, [I

    iget-object v2, p0, Ldev/nino/squareglass/SquareSongMenu;->layout:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->getLocationOnScreen([I)V

    .line 122
    iget-object v2, p0, Ldev/nino/squareglass/SquareSongMenu;->panel:Landroid/view/View;

    invoke-virtual {v2, v0}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 123
    iget-object v2, p0, Ldev/nino/squareglass/SquareSongMenu;->panel:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    move-result v2

    iget-object v3, p0, Ldev/nino/squareglass/SquareSongMenu;->layout:Landroid/widget/LinearLayout;

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->getTop()I

    move-result v3

    sub-int/2addr v2, v3

    iget-object v3, p0, Ldev/nino/squareglass/SquareSongMenu;->panel:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    sub-int/2addr v2, v3

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v3, 0x1

    aget v1, v1, v3

    sub-int/2addr v0, v1

    invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    .line 124
    iget-object v1, p0, Ldev/nino/squareglass/SquareSongMenu;->layout:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/16 v2, 0x60

    .line 125
    invoke-direct {p0, v2}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v2

    if-lt v0, v2, :cond_1

    iget v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-le v2, v0, :cond_1

    .line 126
    iput v0, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->layout:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_1
    :goto_0
    return-void
.end method

.method static group(Ljava/lang/Object;)I
    .locals 6

    .line 51
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, -0x1

    sparse-switch v0, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "m3.h0"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    goto :goto_0

    :sswitch_1
    const-string v0, "m3.e0"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    goto :goto_0

    :sswitch_2
    const-string v0, "m3.b0"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_2

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    goto :goto_0

    :sswitch_3
    const-string v0, "m3.y"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    goto :goto_0

    :cond_3
    move v5, v1

    goto :goto_0

    :sswitch_4
    const-string v0, "m3.v"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_4

    goto :goto_0

    :cond_4
    move v5, v2

    goto :goto_0

    :sswitch_5
    const-string v0, "m3.s"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_5

    goto :goto_0

    :cond_5
    move v5, v3

    goto :goto_0

    :sswitch_6
    const-string v0, "m3.p"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_6

    goto :goto_0

    :cond_6
    move v5, v4

    :goto_0
    packed-switch v5, :pswitch_data_0

    return v2

    :pswitch_0
    return v4

    :pswitch_1
    return v3

    :pswitch_2
    return v1

    nop

    :sswitch_data_0
    .sparse-switch
        0x3251e8 -> :sswitch_6
        0x3251eb -> :sswitch_5
        0x3251ee -> :sswitch_4
        0x3251f1 -> :sswitch_3
        0x617e996 -> :sswitch_2
        0x617e9f3 -> :sswitch_1
        0x617ea50 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method static install(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$Adapter;Ldev/nino/squareglass/LiquidMenuSurface;Z)Ldev/nino/squareglass/SquareSongMenu;
    .locals 5

    .line 73
    instance-of v0, p1, Landroidx/recyclerview/widget/ListAdapter;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    const/4 v0, 0x0

    move v2, v0

    .line 75
    :goto_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemCount()I

    move-result v3

    if-ge v2, v3, :cond_2

    .line 76
    invoke-static {p1, v2}, Ldev/nino/squareglass/SquareSongMenu;->model(Landroidx/recyclerview/widget/RecyclerView$Adapter;I)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_1

    .line 77
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "m3."

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    const/4 v0, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    const v2, 0x7f0b05b8

    .line 79
    invoke-virtual {p0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    if-nez v0, :cond_3

    .line 80
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemCount()I

    move-result v0

    if-nez v0, :cond_5

    :cond_3
    instance-of v0, p0, Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_5

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Landroid/view/ViewGroup;

    if-nez v0, :cond_4

    goto :goto_2

    .line 81
    :cond_4
    new-instance v0, Ldev/nino/squareglass/SquareSongMenu;

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {v0, p0, p1, p2, p3}, Ldev/nino/squareglass/SquareSongMenu;-><init>(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$Adapter;Ldev/nino/squareglass/LiquidMenuSurface;Z)V

    return-object v0

    :cond_5
    :goto_2
    return-object v1
.end method

.method static kind(Ljava/lang/Object;)I
    .locals 7

    .line 42
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v6, -0x1

    sparse-switch v0, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "m3.o"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    move v6, v1

    goto :goto_0

    :sswitch_1
    const-string v0, "m3.i"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1

    goto :goto_0

    :cond_1
    move v6, v2

    goto :goto_0

    :sswitch_2
    const-string v0, "m3.f"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_2

    goto :goto_0

    :cond_2
    move v6, v3

    goto :goto_0

    :sswitch_3
    const-string v0, "m3.d"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    goto :goto_0

    :cond_3
    move v6, v4

    goto :goto_0

    :sswitch_4
    const-string v0, "m3.a"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_4

    goto :goto_0

    :cond_4
    move v6, v5

    :goto_0
    packed-switch v6, :pswitch_data_0

    return v5

    :pswitch_0
    return v4

    :pswitch_1
    return v3

    :pswitch_2
    return v1

    :pswitch_3
    return v2

    nop

    :sswitch_data_0
    .sparse-switch
        0x3251d9 -> :sswitch_4
        0x3251dc -> :sswitch_3
        0x3251de -> :sswitch_2
        0x3251e1 -> :sswitch_1
        0x3251e7 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_3
    .end packed-switch
.end method

.method private static label(Landroid/view/View;)Ljava/lang/CharSequence;
    .locals 3

    .line 131
    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->length()I

    move-result v1

    if-lez v1, :cond_0

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0

    .line 132
    :cond_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    .line 133
    check-cast p0, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    .line 134
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_2

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Ldev/nino/squareglass/SquareSongMenu;->label(Landroid/view/View;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lez v2, :cond_1

    return-object v1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 136
    :cond_2
    const-string p0, ""

    return-object p0
.end method

.method private synthetic lambda$new$0(Landroid/view/View;IIIIIIII)V
    .locals 0

    .line 29
    iget-object p2, p0, Ldev/nino/squareglass/SquareSongMenu;->fit:Ljava/lang/Runnable;

    invoke-virtual {p1, p2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->fit:Ljava/lang/Runnable;

    invoke-virtual {p1, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic lambda$new$1(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 5

    .line 100
    invoke-static {}, Landroid/view/WindowInsets$Type;->systemBars()I

    move-result v0

    invoke-static {}, Landroid/view/WindowInsets$Type;->displayCutout()I

    move-result v1

    or-int/2addr v0, v1

    invoke-virtual {p2, v0}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object v0

    iget v0, v0, Landroid/graphics/Insets;->bottom:I

    const/16 v1, 0xc

    .line 101
    invoke-direct {p0, v1}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v2

    const/16 v3, 0xa

    invoke-direct {p0, v3}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v3

    invoke-direct {p0, v1}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v1

    const/16 v4, 0x10

    invoke-direct {p0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result p0

    invoke-static {p0, v0}, Ljava/lang/Math;->max(II)I

    move-result p0

    invoke-virtual {p1, v2, v3, v1, p0}, Landroid/view/View;->setPadding(IIII)V

    return-object p2
.end method

.method static synthetic lambda$rebuild$2(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;Landroid/view/View;)V
    .locals 0

    .line 190
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->performClick()Z

    return-void
.end method

.method static synthetic lambda$rebuild$3(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3

    .line 192
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    if-eq p1, v1, :cond_0

    const/4 v2, 0x3

    if-ne p1, v2, :cond_2

    :cond_0
    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    move v1, v0

    .line 195
    :goto_0
    invoke-static {p0, v1}, Ldev/nino/squareglass/LiquidViewMotion;->press(Landroid/view/View;Z)V

    :cond_2
    return v0
.end method

.method static model(Landroidx/recyclerview/widget/RecyclerView$Adapter;I)Ljava/lang/Object;
    .locals 1

    .line 59
    instance-of v0, p0, Landroidx/recyclerview/widget/ListAdapter;

    if-eqz v0, :cond_0

    check-cast p0, Landroidx/recyclerview/widget/ListAdapter;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/ListAdapter;->getCurrentList()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method static perform(Landroidx/recyclerview/widget/RecyclerView$Adapter;Landroid/view/ViewGroup;I)Z
    .locals 4

    const/4 v0, 0x0

    move v1, v0

    .line 62
    :goto_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemCount()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 63
    invoke-static {p0, v1}, Ldev/nino/squareglass/SquareSongMenu;->model(Landroidx/recyclerview/widget/RecyclerView$Adapter;I)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 64
    invoke-static {v2}, Ldev/nino/squareglass/SquareSongMenu;->kind(Ljava/lang/Object;)I

    move-result v3

    if-ne v3, p2, :cond_0

    check-cast v2, Lv40/a;

    invoke-virtual {v2}, Lv40/a;->a()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 65
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemViewType(I)I

    move-result p2

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->createViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    move-result-object p1

    .line 66
    invoke-virtual {p0, p1, v1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->bindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V

    .line 67
    iget-object p0, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->performClick()Z

    move-result p0

    return p0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method private rebuild()V
    .locals 23

    move-object/from16 v0, p0

    .line 139
    iget-boolean v1, v0, Ldev/nino/squareglass/SquareSongMenu;->released:Z

    if-eqz v1, :cond_0

    return-void

    .line 140
    :cond_0
    iget-object v1, v0, Ldev/nino/squareglass/SquareSongMenu;->mapping:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, v0, Ldev/nino/squareglass/SquareSongMenu;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v2, v0, Ldev/nino/squareglass/SquareSongMenu;->quick:Landroid/widget/GridLayout;

    invoke-virtual {v1, v2}, Ldev/nino/squareglass/LiquidMenuSurface;->clearWithin(Landroid/view/ViewGroup;)V

    iget-object v1, v0, Ldev/nino/squareglass/SquareSongMenu;->quick:Landroid/widget/GridLayout;

    invoke-virtual {v1}, Landroid/widget/GridLayout;->removeAllViews()V

    const/4 v1, 0x4

    .line 141
    new-array v2, v1, [I

    const/4 v3, 0x0

    const/4 v4, -0x1

    aput v4, v2, v3

    const/4 v5, 0x1

    aput v4, v2, v5

    const/4 v6, 0x2

    aput v4, v2, v6

    const/4 v7, 0x3

    aput v4, v2, v7

    move v8, v3

    .line 142
    :goto_0
    iget-object v9, v0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v9}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemCount()I

    move-result v9

    if-ge v8, v9, :cond_3

    .line 143
    iget-object v9, v0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-static {v9, v8}, Ldev/nino/squareglass/SquareSongMenu;->model(Landroidx/recyclerview/widget/RecyclerView$Adapter;I)Ljava/lang/Object;

    move-result-object v9

    if-nez v9, :cond_1

    move v9, v3

    goto :goto_1

    :cond_1
    invoke-static {v9}, Ldev/nino/squareglass/SquareSongMenu;->kind(Ljava/lang/Object;)I

    move-result v9

    :goto_1
    if-lez v9, :cond_2

    add-int/lit8 v9, v9, -0x1

    .line 144
    aget v10, v2, v9

    if-gez v10, :cond_2

    aput v8, v2, v9

    :cond_2
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_3
    move v8, v3

    :goto_2
    if-ge v8, v1, :cond_a

    move v9, v3

    move v10, v9

    .line 148
    :goto_3
    iget-object v11, v0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v11}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemCount()I

    move-result v11

    if-ge v9, v11, :cond_9

    .line 149
    iget-object v11, v0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-static {v11, v9}, Ldev/nino/squareglass/SquareSongMenu;->model(Landroidx/recyclerview/widget/RecyclerView$Adapter;I)Ljava/lang/Object;

    move-result-object v11

    move v12, v3

    move v13, v12

    :goto_4
    if-ge v12, v1, :cond_5

    .line 150
    aget v14, v2, v12

    if-ne v9, v14, :cond_4

    move v13, v5

    :cond_4
    add-int/lit8 v12, v12, 0x1

    goto :goto_4

    :cond_5
    if-nez v13, :cond_8

    if-eqz v11, :cond_8

    .line 151
    invoke-static {v11}, Ldev/nino/squareglass/SquareSongMenu;->group(Ljava/lang/Object;)I

    move-result v11

    if-eq v11, v8, :cond_6

    goto :goto_5

    :cond_6
    if-nez v10, :cond_7

    .line 152
    iget-object v10, v0, Ldev/nino/squareglass/SquareSongMenu;->mapping:Ljava/util/ArrayList;

    neg-int v11, v8

    sub-int/2addr v11, v5

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v10, v5

    .line 153
    :cond_7
    iget-object v11, v0, Ldev/nino/squareglass/SquareSongMenu;->mapping:Ljava/util/ArrayList;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    :goto_5
    add-int/lit8 v9, v9, 0x1

    goto :goto_3

    :cond_9
    add-int/lit8 v8, v8, 0x1

    goto :goto_2

    .line 156
    :cond_a
    iget-object v8, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v8}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    invoke-virtual {v8}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v8

    iget v8, v8, Landroid/content/res/Configuration;->fontScale:F

    .line 157
    iget-object v9, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v9}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v9

    iget v9, v9, Landroid/content/res/Configuration;->screenWidthDp:I

    add-int/lit8 v9, v9, -0x24

    int-to-float v9, v9

    const/high16 v10, 0x440c0000    # 560.0f

    mul-float/2addr v10, v8

    cmpl-float v10, v9, v10

    if-ltz v10, :cond_b

    move v9, v1

    goto :goto_6

    :cond_b
    const/high16 v10, 0x43800000    # 256.0f

    mul-float/2addr v10, v8

    cmpl-float v9, v9, v10

    if-ltz v9, :cond_c

    move v9, v6

    goto :goto_6

    :cond_c
    move v9, v5

    :goto_6
    move v10, v3

    move v11, v10

    :goto_7
    if-ge v10, v1, :cond_e

    .line 159
    aget v12, v2, v10

    if-ltz v12, :cond_d

    add-int/lit8 v11, v11, 0x1

    :cond_d
    add-int/lit8 v10, v10, 0x1

    goto :goto_7

    .line 160
    :cond_e
    invoke-static {v9, v11}, Ljava/lang/Math;->min(II)I

    move-result v9

    invoke-static {v5, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    .line 161
    iget-object v10, v0, Ldev/nino/squareglass/SquareSongMenu;->quick:Landroid/widget/GridLayout;

    invoke-virtual {v10, v9}, Landroid/widget/GridLayout;->setColumnCount(I)V

    move v10, v3

    :goto_8
    if-ge v10, v1, :cond_12

    .line 162
    aget v15, v2, v10

    if-gez v15, :cond_f

    move v15, v4

    move/from16 v16, v6

    move/from16 v17, v7

    goto/16 :goto_b

    :cond_f
    move/from16 v16, v6

    .line 164
    iget-object v6, v0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-static {v6, v15}, Ldev/nino/squareglass/SquareSongMenu;->model(Landroidx/recyclerview/widget/RecyclerView$Adapter;I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lv40/a;

    move/from16 v17, v7

    .line 165
    iget-object v7, v0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    iget-object v14, v0, Ldev/nino/squareglass/SquareSongMenu;->layout:Landroid/widget/LinearLayout;

    invoke-virtual {v7, v15}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemViewType(I)I

    move-result v13

    invoke-virtual {v7, v14, v13}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->createViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    move-result-object v7

    .line 166
    iget-object v13, v0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v13, v7, v15}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->bindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V

    .line 167
    new-instance v13, Ldev/nino/squareglass/SquareSongMenu$3;

    iget-object v14, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v14}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v14

    invoke-direct {v13, v0, v14}, Ldev/nino/squareglass/SquareSongMenu$3;-><init>(Ldev/nino/squareglass/SquareSongMenu;Landroid/content/Context;)V

    .line 170
    iget-object v14, v0, Ldev/nino/squareglass/SquareSongMenu;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    const/high16 v15, 0x41b00000    # 22.0f

    invoke-virtual {v14, v13, v15, v5}, Ldev/nino/squareglass/LiquidMenuSurface;->paint(Landroid/widget/FrameLayout;FZ)V

    .line 171
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v14

    invoke-static {v14}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v14

    .line 172
    new-instance v15, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v15}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v15, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v3, 0x16

    invoke-direct {v0, v3}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v15, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 173
    new-instance v3, Landroid/graphics/drawable/RippleDrawable;

    const v20, 0xffffff

    and-int v20, v14, v20

    const/high16 v21, 0x20000000

    or-int v20, v20, v21

    invoke-static/range {v20 .. v20}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v12

    const/4 v4, 0x0

    invoke-direct {v3, v12, v4, v15}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v13, v3}, Landroid/widget/FrameLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 174
    new-instance v3, Landroid/widget/LinearLayout;

    iget-object v4, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v4, 0x11

    .line 175
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v12, 0xa

    invoke-direct {v0, v12}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v15

    const/16 v5, 0xe

    invoke-direct {v0, v5}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v4

    invoke-direct {v0, v12}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v12

    invoke-direct {v0, v5}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v5

    invoke-virtual {v3, v15, v4, v12, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/16 v4, 0x58

    .line 176
    invoke-direct {v0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setMinimumHeight(I)V

    .line 177
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setImportantForAccessibility(I)V

    .line 178
    new-instance v4, Landroid/widget/ImageView;

    iget-object v5, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    iget v5, v6, Lv40/a;->b:I

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 179
    invoke-static {v14}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 180
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x18

    invoke-direct {v0, v12}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v15

    invoke-direct {v0, v12}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v12

    invoke-direct {v5, v15, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 181
    iget-object v4, v7, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    invoke-static {v4}, Ldev/nino/squareglass/SquareSongMenu;->label(Landroid/view/View;)Ljava/lang/CharSequence;

    move-result-object v4

    .line 182
    new-instance v5, Landroid/widget/TextView;

    iget-object v12, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v12

    invoke-direct {v5, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 183
    invoke-virtual {v5, v14}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v12, 0x41500000    # 13.0f

    invoke-virtual {v5, v12}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v12, 0x11

    invoke-virtual {v5, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 184
    iget-object v12, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v12}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    const v14, 0x7f090005

    invoke-virtual {v12, v14}, Landroid/content/res/Resources;->getFont(I)Landroid/graphics/Typeface;

    move-result-object v12

    invoke-virtual {v5, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 185
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v14, -0x2

    const/4 v15, -0x1

    invoke-direct {v12, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v1, 0x8

    invoke-direct {v0, v1}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v1

    iput v1, v12, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 186
    invoke-virtual {v3, v5, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 187
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v15, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v3, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 188
    invoke-virtual {v13, v4}, Landroid/widget/FrameLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v13, v4}, Landroid/widget/FrameLayout;->setTooltipText(Ljava/lang/CharSequence;)V

    const/4 v1, 0x1

    .line 189
    invoke-virtual {v13, v1}, Landroid/widget/FrameLayout;->setFocusable(Z)V

    invoke-virtual {v6}, Lv40/a;->a()Z

    move-result v1

    invoke-virtual {v13, v1}, Landroid/widget/FrameLayout;->setEnabled(Z)V

    invoke-virtual {v6}, Lv40/a;->a()Z

    move-result v1

    if-eqz v1, :cond_10

    const/high16 v1, 0x3f800000    # 1.0f

    goto :goto_9

    :cond_10
    const v1, 0x3ee66666    # 0.45f

    :goto_9
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setAlpha(F)V

    .line 190
    new-instance v1, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda4;

    invoke-direct {v1, v7}, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda4;-><init>(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V

    invoke-virtual {v13, v1}, Landroid/widget/FrameLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 191
    new-instance v1, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda5;

    invoke-direct {v1}, Ldev/nino/squareglass/SquareSongMenu$$ExternalSyntheticLambda5;-><init>()V

    invoke-virtual {v13, v1}, Landroid/widget/FrameLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 198
    new-instance v1, Landroid/widget/GridLayout$LayoutParams;

    invoke-direct {v1}, Landroid/widget/GridLayout$LayoutParams;-><init>()V

    const/4 v3, 0x0

    iput v3, v1, Landroid/widget/GridLayout$LayoutParams;->width:I

    iput v14, v1, Landroid/widget/GridLayout$LayoutParams;->height:I

    .line 199
    iget-object v4, v0, Ldev/nino/squareglass/SquareSongMenu;->quick:Landroid/widget/GridLayout;

    invoke-virtual {v4}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v4

    add-int/lit8 v5, v11, -0x1

    if-ne v4, v5, :cond_11

    .line 200
    rem-int v5, v11, v9

    const/4 v6, 0x1

    if-ne v5, v6, :cond_11

    move v5, v9

    goto :goto_a

    :cond_11
    const/4 v5, 0x1

    .line 201
    :goto_a
    rem-int v6, v4, v9

    sget-object v7, Landroid/widget/GridLayout;->FILL:Landroid/widget/GridLayout$Alignment;

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-static {v6, v5, v7, v12}, Landroid/widget/GridLayout;->spec(IILandroid/widget/GridLayout$Alignment;F)Landroid/widget/GridLayout$Spec;

    move-result-object v5

    iput-object v5, v1, Landroid/widget/GridLayout$LayoutParams;->columnSpec:Landroid/widget/GridLayout$Spec;

    .line 202
    div-int/2addr v4, v9

    sget-object v5, Landroid/widget/GridLayout;->FILL:Landroid/widget/GridLayout$Alignment;

    invoke-static {v4, v5}, Landroid/widget/GridLayout;->spec(ILandroid/widget/GridLayout$Alignment;)Landroid/widget/GridLayout$Spec;

    move-result-object v4

    iput-object v4, v1, Landroid/widget/GridLayout$LayoutParams;->rowSpec:Landroid/widget/GridLayout$Spec;

    const/4 v4, 0x5

    .line 203
    invoke-direct {v0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v5

    invoke-direct {v0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v6

    invoke-direct {v0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v7

    invoke-direct {v0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v4

    invoke-virtual {v1, v5, v6, v7, v4}, Landroid/widget/GridLayout$LayoutParams;->setMargins(IIII)V

    iget-object v4, v0, Ldev/nino/squareglass/SquareSongMenu;->quick:Landroid/widget/GridLayout;

    invoke-virtual {v4, v13, v1}, Landroid/widget/GridLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_b
    add-int/lit8 v10, v10, 0x1

    move v4, v15

    move/from16 v6, v16

    move/from16 v7, v17

    const/4 v1, 0x4

    const/4 v5, 0x1

    goto/16 :goto_8

    :cond_12
    move/from16 v16, v6

    move/from16 v17, v7

    const/16 v1, 0x8

    .line 205
    iget-object v2, v0, Ldev/nino/squareglass/SquareSongMenu;->footer:Landroid/widget/ScrollView;

    iget-object v4, v0, Ldev/nino/squareglass/SquareSongMenu;->quick:Landroid/widget/GridLayout;

    invoke-virtual {v4}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v4

    if-nez v4, :cond_13

    move v3, v1

    :cond_13
    invoke-virtual {v2, v3}, Landroid/widget/ScrollView;->setVisibility(I)V

    .line 209
    iget-object v1, v0, Ldev/nino/squareglass/SquareSongMenu;->quick:Landroid/widget/GridLayout;

    invoke-virtual {v1}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v1

    add-int/2addr v1, v9

    const/16 v22, 0x1

    add-int/lit8 v1, v1, -0x1

    div-int/2addr v1, v9

    .line 210
    iget-object v2, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    iget v2, v2, Landroid/content/res/Configuration;->screenHeightDp:I

    invoke-direct {v0, v2}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v2

    mul-int/lit8 v2, v2, 0x2

    const/16 v18, 0x5

    div-int/lit8 v2, v2, 0x5

    int-to-float v1, v1

    const/4 v3, 0x0

    const/high16 v19, 0x3f800000    # 1.0f

    sub-float v4, v8, v19

    .line 211
    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v3

    const/high16 v4, 0x41a00000    # 20.0f

    mul-float/2addr v3, v4

    const/high16 v4, 0x42c40000    # 98.0f

    add-float/2addr v3, v4

    mul-float/2addr v1, v3

    const/high16 v3, 0x41d00000    # 26.0f

    add-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-direct {v0, v1}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v1

    .line 210
    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    .line 212
    iget-object v2, v0, Ldev/nino/squareglass/SquareSongMenu;->layout:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    .line 213
    iget-object v3, v0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v3

    iget v3, v3, Landroid/content/res/Configuration;->screenHeightDp:I

    invoke-direct {v0, v3}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v3

    mul-int/lit8 v3, v3, 0x2

    div-int/lit8 v3, v3, 0x3

    iget-object v4, v0, Ldev/nino/squareglass/SquareSongMenu;->mapping:Ljava/util/ArrayList;

    .line 214
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    mul-int/lit8 v4, v4, 0x30

    int-to-float v4, v4

    mul-float/2addr v4, v8

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    const/16 v5, 0x90

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-direct {v0, v4}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v4

    add-int/2addr v4, v1

    .line 213
    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v1

    iput v1, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 215
    iget-object v1, v0, Ldev/nino/squareglass/SquareSongMenu;->layout:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0}, Ldev/nino/squareglass/SquareSongMenu;->notifyDataSetChanged()V

    return-void
.end method

.method private schedule()V
    .locals 2

    .line 129
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareSongMenu;->released:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/SquareSongMenu;->rebuild:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->rebuild:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void
.end method


# virtual methods
.method public getItemCount()I
    .locals 0

    .line 221
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->mapping:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    return p0
.end method

.method public getItemViewType(I)I
    .locals 1

    .line 223
    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->mapping:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    if-gez p1, :cond_0

    return p1

    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->getItemViewType(I)I

    move-result p0

    return p0
.end method

.method public onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 3

    .line 236
    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->mapping:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    if-gez p2, :cond_0

    .line 237
    iget-object p0, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    check-cast p0, Landroid/widget/TextView;

    const-string p1, "More options"

    const-string v0, "Manage"

    const-string v1, "Playback"

    const-string v2, "Discover"

    filled-new-array {v1, v2, p1, v0}, [Ljava/lang/String;

    move-result-object p1

    neg-int p2, p2

    add-int/lit8 p2, p2, -0x1

    aget-object p1, p1, p2

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 238
    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    check-cast p1, Ldev/nino/squareglass/SquareSongMenu$NativeHolder;

    iget-object p1, p1, Ldev/nino/squareglass/SquareSongMenu$NativeHolder;->nativeHolder:Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->bindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V

    return-void
.end method

.method public onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    if-gez p2, :cond_1

    .line 227
    new-instance p2, Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {p2, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/high16 p1, 0x41500000    # 13.0f

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 228
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result p1

    if-eqz p1, :cond_0

    const p1, -0x4b473c

    goto :goto_0

    :cond_0
    const p1, -0xa29d93

    :goto_0
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 p1, 0x14

    .line 229
    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v1

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result p1

    const/16 v2, 0x8

    invoke-direct {p0, v2}, Ldev/nino/squareglass/SquareSongMenu;->dp(I)I

    move-result v2

    invoke-virtual {p2, v0, v1, p1, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 230
    new-instance p1, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;

    const/4 v0, -0x1

    const/4 v1, -0x2

    invoke-direct {p1, v0, v1}, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;-><init>(II)V

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, 0x1

    .line 231
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setAccessibilityHeading(Z)V

    new-instance p1, Ldev/nino/squareglass/SquareSongMenu$4;

    invoke-direct {p1, p0, p2}, Ldev/nino/squareglass/SquareSongMenu$4;-><init>(Ldev/nino/squareglass/SquareSongMenu;Landroid/view/View;)V

    return-object p1

    .line 233
    :cond_1
    new-instance v0, Ldev/nino/squareglass/SquareSongMenu$NativeHolder;

    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->createViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    move-result-object p0

    invoke-direct {v0, p0}, Ldev/nino/squareglass/SquareSongMenu$NativeHolder;-><init>(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V

    return-object v0
.end method

.method public onViewRecycled(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V
    .locals 1

    .line 241
    instance-of v0, p1, Ldev/nino/squareglass/SquareSongMenu$NativeHolder;

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    check-cast p1, Ldev/nino/squareglass/SquareSongMenu$NativeHolder;

    iget-object p1, p1, Ldev/nino/squareglass/SquareSongMenu$NativeHolder;->nativeHolder:Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->onViewRecycled(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V

    :cond_0
    return-void
.end method

.method release()V
    .locals 2

    const/4 v0, 0x1

    .line 218
    iput-boolean v0, p0, Ldev/nino/squareglass/SquareSongMenu;->released:Z

    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->listView:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/SquareSongMenu;->rebuild:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->panel:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/SquareSongMenu;->fit:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 219
    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->panel:Landroid/view/View;

    iget-object v1, p0, Ldev/nino/squareglass/SquareSongMenu;->fitListener:Landroid/view/View$OnLayoutChangeListener;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    iget-object v0, p0, Ldev/nino/squareglass/SquareSongMenu;->source:Landroidx/recyclerview/widget/RecyclerView$Adapter;

    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu;->observer:Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->unregisterAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;)V

    return-void
.end method
