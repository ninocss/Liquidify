.class public final Ldev/nino/squareglass/TimeTaste;
.super Ljava/lang/Object;
.source "TimeTaste.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static score([IIJJZ)D
    .locals 11

    const-wide/16 v0, 0x0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/16 v4, 0x18

    if-ge v3, v4, :cond_0

    sub-int v4, v3, p1

    .line 9
    invoke-static {v4}, Ljava/lang/Math;->abs(I)I

    move-result v4

    rsub-int/lit8 v5, v4, 0x18

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 10
    aget v5, p0, v3

    invoke-static {v2, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    int-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->log1p(D)D

    move-result-wide v5

    neg-int v7, v4

    mul-int/2addr v7, v4

    int-to-double v7, v7

    const-wide/high16 v9, 0x4020000000000000L    # 8.0

    div-double/2addr v7, v9

    invoke-static {v7, v8}, Ljava/lang/Math;->exp(D)D

    move-result-wide v7

    mul-double/2addr v5, v7

    add-double/2addr v0, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    const-wide/16 p0, 0x0

    sub-long p2, p4, p2

    .line 12
    invoke-static {p0, p1, p2, p3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p0

    long-to-double p0, p0

    const-wide p2, 0x4194997000000000L    # 8.64E7

    div-double/2addr p0, p2

    if-eqz p6, :cond_1

    .line 13
    invoke-static {p0, p1}, Ljava/lang/Math;->log1p(D)D

    move-result-wide p0

    const-wide p2, 0x3fc3333333333333L    # 0.15

    mul-double/2addr v0, p2

    add-double/2addr p0, v0

    return-wide p0

    :cond_1
    neg-double p2, p0

    const-wide/high16 v2, 0x404e000000000000L    # 60.0

    div-double/2addr p2, v2

    .line 14
    invoke-static {p2, p3}, Ljava/lang/Math;->exp(D)D

    move-result-wide p2

    const-wide v2, 0x3fd3333333333333L    # 0.3

    mul-double/2addr p2, v2

    const-wide v2, 0x3fe6666666666666L    # 0.7

    add-double/2addr p2, v2

    mul-double/2addr v0, p2

    const-wide p2, 0x3f947ae147ae147bL    # 0.02

    cmpg-double p0, p0, p2

    if-gez p0, :cond_2

    const-wide/high16 p0, 0x3fd0000000000000L    # 0.25

    goto :goto_1

    :cond_2
    const-wide/high16 p0, 0x3ff0000000000000L    # 1.0

    :goto_1
    mul-double/2addr v0, p0

    return-wide v0
.end method
