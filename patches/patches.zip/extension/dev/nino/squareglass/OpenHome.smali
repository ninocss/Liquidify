.class final Ldev/nino/squareglass/OpenHome;
.super Ljava/lang/Object;
.source "OpenHome.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/OpenHome$Trace;,
        Ldev/nino/squareglass/OpenHome$Fault;,
        Ldev/nino/squareglass/OpenHome$Failure;,
        Ldev/nino/squareglass/OpenHome$NetworkBinding;,
        Ldev/nino/squareglass/OpenHome$Service;
    }
.end annotation


# static fields
.field static final LIMIT:I = 0x100000

.field static final actionDescriptions:Ldev/nino/squareglass/LinnCache;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldev/nino/squareglass/LinnCache<",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;>;"
        }
    .end annotation
.end field

.field static final attempt:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field static final deadline:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field static final descriptions:Ldev/nino/squareglass/LinnCache;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldev/nino/squareglass/LinnCache<",
            "Ljava/lang/String;",
            "Ldev/nino/squareglass/OpenHome;",
            ">;"
        }
    .end annotation
.end field

.field static volatile network:Ldev/nino/squareglass/OpenHome$NetworkBinding;

.field static volatile trace:Ldev/nino/squareglass/OpenHome$Trace;


# instance fields
.field final location:Ljava/lang/String;

.field final model:Ljava/lang/String;

.field final name:Ljava/lang/String;

.field final services:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ldev/nino/squareglass/OpenHome$Service;",
            ">;"
        }
    .end annotation
.end field

.field private volatile sourceXml:Ljava/lang/String;

.field private volatile sourceXmlAt:J

.field final uuid:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 20
    new-instance v0, Ldev/nino/squareglass/OpenHome$1;

    invoke-direct {v0}, Ldev/nino/squareglass/OpenHome$1;-><init>()V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    .line 21
    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    .line 22
    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    .line 23
    new-instance v0, Ldev/nino/squareglass/LinnCache;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const/16 v1, 0x20

    const-wide v2, 0x45d964b800L

    invoke-direct {v0, v1, v2, v3}, Ldev/nino/squareglass/LinnCache;-><init>(IJ)V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->descriptions:Ldev/nino/squareglass/LinnCache;

    .line 24
    new-instance v0, Ldev/nino/squareglass/LinnCache;

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const/16 v1, 0x80

    invoke-direct {v0, v1, v2, v3}, Ldev/nino/squareglass/LinnCache;-><init>(IJ)V

    sput-object v0, Ldev/nino/squareglass/OpenHome;->actionDescriptions:Ldev/nino/squareglass/LinnCache;

    return-void
.end method

.method constructor <init>(Ljava/lang/String;)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 159
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 59
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    .line 160
    iput-object p1, p0, Ldev/nino/squareglass/OpenHome;->location:Ljava/lang/String;

    const/4 v0, 0x0

    invoke-static {p1, v0, v0}, Ldev/nino/squareglass/OpenHome;->fetch(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object v0

    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object v0

    invoke-interface {v0}, Lorg/w3c/dom/Document;->getDocumentElement()Lorg/w3c/dom/Element;

    move-result-object v0

    .line 161
    const-string v1, "URLBase"

    invoke-static {v0, v1}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    move-object p1, v1

    :goto_0
    invoke-static {p1}, Ldev/nino/squareglass/OpenHome;->local(Ljava/lang/String;)Ljava/net/URL;

    .line 162
    const-string v1, "device"

    const-string v2, "*"

    invoke-interface {v0, v2, v1}, Lorg/w3c/dom/Element;->getElementsByTagNameNS(Ljava/lang/String;Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object v0

    check-cast v0, Lorg/w3c/dom/Element;

    .line 163
    const-string v3, "UDN"

    invoke-static {v0, v3}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    const-string v4, "friendlyName"

    invoke-static {v0, v4}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Ldev/nino/squareglass/OpenHome;->name:Ljava/lang/String;

    const-string v4, "modelName"

    invoke-static {v0, v4}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Ldev/nino/squareglass/OpenHome;->model:Ljava/lang/String;

    .line 164
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_5

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    const/16 v4, 0xa0

    if-gt v3, v4, :cond_5

    const-string v3, "manufacturer"

    invoke-static {v0, v3}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v3, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "linn"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_5

    .line 166
    const-string v3, "service"

    invoke-interface {v0, v2, v3}, Lorg/w3c/dom/Element;->getElementsByTagNameNS(Ljava/lang/String;Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object v0

    .line 167
    :goto_1
    invoke-interface {v0}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result v2

    if-ge v1, v2, :cond_3

    .line 168
    invoke-interface {v0, v1}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object v2

    check-cast v2, Lorg/w3c/dom/Element;

    const-string v3, "serviceType"

    invoke-static {v2, v3}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 169
    const-string v4, "urn:av-openhome-org:service:"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_1

    goto/16 :goto_2

    .line 170
    :cond_1
    const-string v4, ":"

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x3

    aget-object v4, v4, v5

    .line 171
    const-string v9, "Volume"

    const-string v10, "OAuth"

    const-string v5, "Playlist"

    const-string v6, "Product"

    const-string v7, "Time"

    const-string v8, "Info"

    filled-new-array/range {v5 .. v10}, [Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_2

    goto/16 :goto_2

    .line 172
    :cond_2
    new-instance v5, Ldev/nino/squareglass/OpenHome$Service;

    invoke-direct {v5}, Ldev/nino/squareglass/OpenHome$Service;-><init>()V

    iput-object v3, v5, Ldev/nino/squareglass/OpenHome$Service;->type:Ljava/lang/String;

    .line 173
    new-instance v6, Ljava/net/URL;

    new-instance v7, Ljava/net/URL;

    invoke-direct {v7, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const-string v8, "controlURL"

    invoke-static {v2, v8}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v6, v7, v8}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v5, Ldev/nino/squareglass/OpenHome$Service;->control:Ljava/lang/String;

    iget-object v6, v5, Ldev/nino/squareglass/OpenHome$Service;->control:Ljava/lang/String;

    invoke-static {v6}, Ldev/nino/squareglass/OpenHome;->local(Ljava/lang/String;)Ljava/net/URL;

    .line 174
    new-instance v6, Ljava/net/URL;

    new-instance v7, Ljava/net/URL;

    invoke-direct {v7, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const-string v8, "eventSubURL"

    invoke-static {v2, v8}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v6, v7, v8}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v5, Ldev/nino/squareglass/OpenHome$Service;->event:Ljava/lang/String;

    iget-object v6, v5, Ldev/nino/squareglass/OpenHome$Service;->event:Ljava/lang/String;

    invoke-static {v6}, Ldev/nino/squareglass/OpenHome;->local(Ljava/lang/String;)Ljava/net/URL;

    .line 175
    new-instance v6, Ljava/net/URL;

    new-instance v7, Ljava/net/URL;

    invoke-direct {v7, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const-string v8, "SCPDURL"

    invoke-static {v2, v8}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v6, v7, v2}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v5, Ldev/nino/squareglass/OpenHome$Service;->scpd:Ljava/lang/String;

    iget-object v2, v5, Ldev/nino/squareglass/OpenHome$Service;->scpd:Ljava/lang/String;

    invoke-static {v2}, Ldev/nino/squareglass/OpenHome;->local(Ljava/lang/String;)Ljava/net/URL;

    .line 176
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, p0, Ldev/nino/squareglass/OpenHome;->uuid:Ljava/lang/String;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "|"

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v5, Ldev/nino/squareglass/OpenHome$Service;->scpd:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v5, Ldev/nino/squareglass/OpenHome$Service;->cacheKey:Ljava/lang/String;

    .line 177
    iget-object v2, p0, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    invoke-interface {v2, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_1

    .line 179
    :cond_3
    iget-object p1, p0, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    const-string v0, "Playlist"

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    iget-object p0, p0, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    const-string p1, "OAuth"

    invoke-interface {p0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_4

    return-void

    :cond_4
    new-instance p0, Ljava/io/IOException;

    const-string p1, "OpenHome TIDAL services unavailable"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 165
    :cond_5
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Not a Linn renderer"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static cached(Ljava/lang/String;)Ldev/nino/squareglass/OpenHome;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 26
    sget-object v0, Ldev/nino/squareglass/OpenHome;->descriptions:Ldev/nino/squareglass/LinnCache;

    invoke-virtual {v0, p0}, Ldev/nino/squareglass/LinnCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldev/nino/squareglass/OpenHome;

    if-eqz v1, :cond_0

    return-object v1

    .line 28
    :cond_0
    new-instance v1, Ldev/nino/squareglass/OpenHome;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/OpenHome;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0, v1}, Ldev/nino/squareglass/LinnCache;->put(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v1
.end method

.method static decodeIds(Ljava/lang/String;)Ljava/util/List;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 299
    invoke-static {}, Ljava/util/Base64;->getDecoder()Ljava/util/Base64$Decoder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/Base64$Decoder;->decode(Ljava/lang/String;)[B

    move-result-object p0

    .line 300
    array-length v0, p0

    rem-int/lit8 v0, v0, 0x4

    if-nez v0, :cond_1

    .line 301
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    .line 302
    :goto_0
    array-length v2, p0

    if-ge v1, v2, :cond_0

    aget-byte v2, p0, v1

    int-to-long v2, v2

    const-wide/16 v4, 0xff

    and-long/2addr v2, v4

    const/16 v6, 0x18

    shl-long/2addr v2, v6

    add-int/lit8 v6, v1, 0x1

    aget-byte v6, p0, v6

    int-to-long v6, v6

    and-long/2addr v6, v4

    const/16 v8, 0x10

    shl-long/2addr v6, v8

    or-long/2addr v2, v6

    add-int/lit8 v6, v1, 0x2

    aget-byte v6, p0, v6

    int-to-long v6, v6

    and-long/2addr v6, v4

    const/16 v8, 0x8

    shl-long/2addr v6, v8

    or-long/2addr v2, v6

    add-int/lit8 v6, v1, 0x3

    aget-byte v6, p0, v6

    int-to-long v6, v6

    and-long/2addr v4, v6

    or-long/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x4

    goto :goto_0

    :cond_0
    return-object v0

    .line 300
    :cond_1
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Invalid queue IDs"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static discover(I)Ljava/util/Set;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, 0x0

    .line 338
    invoke-static {v0, p0}, Ldev/nino/squareglass/OpenHome;->discover(Ljava/lang/String;I)Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method static discover(Ljava/lang/String;I)Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 341
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 342
    new-instance v1, Ldev/nino/squareglass/LinnDiscovery;

    invoke-direct {v1}, Ldev/nino/squareglass/LinnDiscovery;-><init>()V

    :try_start_0
    new-instance v2, Ldev/nino/squareglass/OpenHome$0;

    invoke-direct {v2, v0}, Ldev/nino/squareglass/OpenHome$0;-><init>(Ljava/util/Set;)V

    invoke-virtual {v1, p0, p1, v2}, Ldev/nino/squareglass/LinnDiscovery;->search(Ljava/lang/String;ILjava/util/function/Consumer;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v1}, Ldev/nino/squareglass/LinnDiscovery;->close()V

    return-object v0

    :catchall_0
    move-exception p0

    :try_start_1
    invoke-virtual {v1}, Ldev/nino/squareglass/LinnDiscovery;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_0

    :catchall_1
    move-exception p1

    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_0
    throw p0
.end method

.method static escape(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 181
    const-string v0, "&"

    const-string v1, "&amp;"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "<"

    const-string v1, "&lt;"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, ">"

    const-string v1, "&gt;"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\""

    const-string v1, "&quot;"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\'"

    const-string v1, "&apos;"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static fetch(Ljava/lang/String;[BLjava/lang/String;)[B
    .locals 20
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v1, p2

    .line 103
    const-string v2, " ms="

    const-string v3, " action="

    const-string v4, "attempt="

    if-nez v1, :cond_0

    const-string v0, "Description"

    goto :goto_0

    :cond_0
    const-string v0, "urn:av-openhome-org:service:"

    const-string v5, ""

    invoke-virtual {v1, v0, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const/16 v5, 0x23

    const/16 v6, 0x2e

    invoke-virtual {v0, v5, v6}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v0

    :goto_0
    move-object v7, v0

    .line 104
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v12

    const/4 v0, 0x0

    move v5, v0

    :goto_1
    const-wide/32 v14, 0xf4240

    .line 106
    :try_start_0
    invoke-static/range {p0 .. p2}, Ldev/nino/squareglass/OpenHome;->fetchOnce(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object v0

    .line 107
    sget-object v6, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v9, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-virtual {v9}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v9

    sub-long/2addr v9, v12

    div-long/2addr v9, v14

    invoke-virtual {v8, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v9, " status=200 retries="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v8}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    move-object v11, v0

    .line 110
    instance-of v0, v11, Ljava/net/SocketTimeoutException;

    if-nez v0, :cond_1

    instance-of v6, v11, Ljava/net/ConnectException;

    if-nez v6, :cond_1

    instance-of v6, v11, Ljava/net/NoRouteToHostException;

    if-nez v6, :cond_1

    instance-of v6, v11, Ljava/io/EOFException;

    if-nez v6, :cond_1

    instance-of v6, v11, Ljava/net/SocketException;

    if-eqz v6, :cond_3

    .line 111
    :cond_1
    invoke-static {v1}, Ldev/nino/squareglass/OpenHome;->readOnly(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_3

    const/4 v6, 0x2

    if-ge v5, v6, :cond_3

    sget-object v6, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v6}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v8

    if-eqz v8, :cond_2

    invoke-virtual {v6}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Long;

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v16

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/32 v18, 0x3b9aca00

    add-long v16, v16, v18

    cmp-long v6, v8, v16

    if-lez v6, :cond_3

    :cond_2
    add-int/lit8 v5, v5, 0x1

    int-to-long v8, v5

    const-wide/16 v10, 0xfa

    mul-long/2addr v8, v10

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V

    goto/16 :goto_1

    .line 112
    :cond_3
    instance-of v5, v11, Ldev/nino/squareglass/OpenHome$Fault;

    if-nez v5, :cond_6

    new-instance v5, Ldev/nino/squareglass/OpenHome$Fault;

    invoke-static {v1}, Ldev/nino/squareglass/OpenHome;->readOnly(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5

    if-eqz v0, :cond_4

    sget-object v0, Ldev/nino/squareglass/OpenHome$Failure;->TIMEOUT:Ldev/nino/squareglass/OpenHome$Failure;

    goto :goto_2

    :cond_4
    sget-object v0, Ldev/nino/squareglass/OpenHome$Failure;->UNREACHABLE:Ldev/nino/squareglass/OpenHome$Failure;

    goto :goto_2

    :cond_5
    sget-object v0, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    :goto_2
    move-object v6, v0

    const-string v9, ""

    const-string v10, ""

    const/4 v8, 0x0

    invoke-direct/range {v5 .. v11}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_3

    :cond_6
    move-object v5, v11

    check-cast v5, Ldev/nino/squareglass/OpenHome$Fault;

    .line 113
    :goto_3
    sget-object v0, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v4, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-virtual {v4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sub-long/2addr v2, v12

    div-long/2addr v2, v14

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, " error="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ldev/nino/squareglass/OpenHome$Fault;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    .line 114
    throw v5
.end method

.method static fetchOnce(Ljava/lang/String;[BLjava/lang/String;)[B
    .locals 16
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    .line 120
    const-string v2, ""

    const-string v3, "content-length"

    invoke-static/range {p0 .. p0}, Ldev/nino/squareglass/OpenHome;->local(Ljava/lang/String;)Ljava/net/URL;

    move-result-object v4

    invoke-virtual {v4}, Ljava/net/URL;->getPort()I

    move-result v5

    if-gez v5, :cond_0

    const/16 v5, 0x50

    goto :goto_0

    :cond_0
    invoke-virtual {v4}, Ljava/net/URL;->getPort()I

    move-result v5

    .line 121
    :goto_0
    invoke-virtual {v4}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v6

    .line 122
    invoke-virtual {v6}, Ljava/net/InetAddress;->isSiteLocalAddress()Z

    move-result v7

    if-eqz v7, :cond_14

    invoke-virtual {v6}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    move-result v7

    if-nez v7, :cond_14

    .line 123
    new-instance v7, Ljava/net/Socket;

    invoke-direct {v7}, Ljava/net/Socket;-><init>()V

    .line 124
    :try_start_0
    sget-object v8, Ldev/nino/squareglass/OpenHome;->network:Ldev/nino/squareglass/OpenHome$NetworkBinding;

    if-eqz v8, :cond_1

    sget-object v8, Ldev/nino/squareglass/OpenHome;->network:Ldev/nino/squareglass/OpenHome$NetworkBinding;

    invoke-interface {v8, v7, v6}, Ldev/nino/squareglass/OpenHome$NetworkBinding;->bind(Ljava/net/Socket;Ljava/net/InetAddress;)V

    :cond_1
    const/4 v8, 0x1

    .line 125
    invoke-virtual {v7, v8}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    new-instance v9, Ljava/net/InetSocketAddress;

    invoke-direct {v9, v6, v5}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    const/16 v6, 0xfa0

    invoke-static {v6}, Ldev/nino/squareglass/OpenHome;->timeout(I)I

    move-result v6

    invoke-virtual {v7, v9, v6}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    const/16 v6, 0x1b58

    invoke-static {v6}, Ldev/nino/squareglass/OpenHome;->timeout(I)I

    move-result v6

    invoke-virtual {v7, v6}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 126
    invoke-virtual {v4}, Ljava/net/URL;->getFile()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_2

    const-string v6, "/"

    .line 127
    :cond_2
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    if-nez v0, :cond_3

    const-string v10, "GET"

    goto :goto_1

    :cond_3
    const-string v10, "POST"

    :goto_1
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, " "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " HTTP/1.1\r\nHOST: "

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ":"

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "\r\nConnection: close\r\n"

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 128
    const-string v5, "\r\n"

    if-eqz v0, :cond_4

    :try_start_1
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "Content-Type: text/xml; charset=\"utf-8\"\r\nSOAPACTION: \""

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "\"\r\nContent-Length: "

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length v4, v0

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 129
    :cond_4
    new-instance v6, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v6}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    sget-object v5, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-virtual {v4, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v4

    invoke-virtual {v6, v4}, Ljava/io/ByteArrayOutputStream;->write([B)V

    if-eqz v0, :cond_5

    .line 130
    invoke-virtual {v6, v0}, Ljava/io/ByteArrayOutputStream;->write([B)V

    :cond_5
    invoke-virtual {v7}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/io/OutputStream;->write([B)V

    .line 131
    new-instance v0, Ljava/io/BufferedInputStream;

    invoke-virtual {v7}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-static {v0}, Ldev/nino/squareglass/LinnEvents;->line(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v4

    .line 132
    const-string v5, "HTTP/1\\.[01] [0-9]{3}.*"

    invoke-virtual {v4, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_13

    const/16 v5, 0x9

    const/16 v6, 0xc

    .line 133
    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v12

    .line 134
    invoke-static {v0}, Ldev/nino/squareglass/LinnEvents;->headers(Ljava/io/InputStream;)Ljava/util/Map;

    move-result-object v4

    new-instance v5, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v5}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 135
    const-string v6, "chunked"

    const-string v9, "transfer-encoding"

    invoke-interface {v4, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v6, v9}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x0

    const-string v10, "Device response too large"

    if-eqz v6, :cond_9

    .line 137
    :goto_2
    :try_start_2
    invoke-static {v0}, Ldev/nino/squareglass/LinnEvents;->line(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v3

    const-string v4, ";"

    const/4 v6, 0x2

    invoke-virtual {v3, v4, v6}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v3

    aget-object v3, v3, v9

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x10

    invoke-static {v3, v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v3

    if-ltz v3, :cond_8

    .line 138
    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v4

    int-to-long v13, v4

    move/from16 p0, v8

    int-to-long v8, v3

    add-long/2addr v13, v8

    const-wide/32 v8, 0x100000

    cmp-long v4, v13, v8

    if-gtz v4, :cond_8

    if-nez v3, :cond_6

    goto :goto_4

    .line 139
    :cond_6
    invoke-static {v0, v5, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/io/InputStream;Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v0}, Ldev/nino/squareglass/LinnEvents;->line(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_7

    const/4 v9, 0x0

    move/from16 v8, p0

    goto :goto_2

    :cond_7
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Invalid HTTP chunk"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 138
    :cond_8
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v10}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_9
    move/from16 p0, v8

    .line 141
    invoke-interface {v4, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v6

    const/high16 v8, 0x100000

    if-eqz v6, :cond_b

    .line 142
    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    if-ltz v3, :cond_a

    if-gt v3, v8, :cond_a

    .line 143
    invoke-static {v0, v5, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/io/InputStream;Ljava/io/ByteArrayOutputStream;I)V

    goto :goto_4

    :cond_a
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v10}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_b
    const/16 v3, 0x2000

    .line 145
    new-array v3, v3, [B

    :goto_3
    invoke-virtual {v0, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v6, -0x1

    if-eq v4, v6, :cond_d

    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v6

    add-int/2addr v6, v4

    if-gt v6, v8, :cond_c

    const/4 v6, 0x0

    invoke-virtual {v5, v3, v6, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_3

    :cond_c
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v10}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 147
    :cond_d
    :goto_4
    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    const/16 v3, 0xc8

    if-eq v12, v3, :cond_12

    .line 149
    const-string v3, "Device action rejected"
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 150
    :try_start_3
    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object v0

    invoke-interface {v0}, Lorg/w3c/dom/Document;->getDocumentElement()Lorg/w3c/dom/Element;

    move-result-object v0

    const-string v4, "errorCode"

    invoke-static {v0, v4}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const-string v5, "[0-9]{1,6}"

    invoke-virtual {v4, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v5
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    if-nez v5, :cond_e

    goto :goto_5

    :cond_e
    move-object v2, v4

    :goto_5
    :try_start_5
    const-string v4, "errorDescription"

    invoke-static {v0, v4}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ldev/nino/squareglass/OpenHome;->safeDescription(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_6

    :catch_0
    move-object v2, v4

    :catch_1
    :goto_6
    move-object v13, v2

    move-object v14, v3

    .line 151
    :try_start_6
    new-instance v9, Ldev/nino/squareglass/OpenHome$Fault;

    const/16 v0, 0x191

    if-eq v12, v0, :cond_10

    const/16 v0, 0x193

    if-ne v12, v0, :cond_f

    goto :goto_7

    :cond_f
    sget-object v0, Ldev/nino/squareglass/OpenHome$Failure;->REJECTED:Ldev/nino/squareglass/OpenHome$Failure;

    goto :goto_8

    :cond_10
    :goto_7
    sget-object v0, Ldev/nino/squareglass/OpenHome$Failure;->AUTH:Ldev/nino/squareglass/OpenHome$Failure;

    :goto_8
    move-object v10, v0

    if-nez v1, :cond_11

    const-string v0, "Description"

    goto :goto_9

    :cond_11
    const/16 v0, 0x23

    invoke-virtual {v1, v0}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    :goto_9
    move-object v11, v0

    const/4 v15, 0x0

    invoke-direct/range {v9 .. v15}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v9
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 154
    :cond_12
    invoke-virtual {v7}, Ljava/net/Socket;->close()V

    return-object v0

    .line 132
    :cond_13
    :try_start_7
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Invalid HTTP status"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    :catchall_0
    move-exception v0

    move-object v1, v0

    .line 123
    :try_start_8
    invoke-virtual {v7}, Ljava/net/Socket;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    goto :goto_a

    :catchall_1
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_a
    throw v1

    .line 122
    :cond_14
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Non-LAN endpoint refused"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static invalidateDescriptions()V
    .locals 1

    .line 30
    sget-object v0, Ldev/nino/squareglass/OpenHome;->descriptions:Ldev/nino/squareglass/LinnCache;

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnCache;->clear()V

    sget-object v0, Ldev/nino/squareglass/OpenHome;->actionDescriptions:Ldev/nino/squareglass/LinnCache;

    invoke-virtual {v0}, Ldev/nino/squareglass/LinnCache;->clear()V

    return-void
.end method

.method static synthetic lambda$discover$1(Ljava/util/Set;Ldev/nino/squareglass/LinnDiscovery$Result;)V
    .locals 0

    .line 342
    iget-object p1, p1, Ldev/nino/squareglass/LinnDiscovery$Result;->location:Ljava/lang/String;

    invoke-interface {p0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method static synthetic lambda$static$0(Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method static local(Ljava/lang/String;)Ljava/net/URL;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 96
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 97
    invoke-virtual {v0}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object p0

    const-string v1, "http"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2

    invoke-virtual {v0}, Ljava/net/URL;->getUserInfo()Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_2

    .line 98
    invoke-virtual {v0}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/net/InetAddress;->getAllByName(Ljava/lang/String;)[Ljava/net/InetAddress;

    move-result-object p0

    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    aget-object v3, p0, v2

    .line 99
    invoke-virtual {v3}, Ljava/net/InetAddress;->isSiteLocalAddress()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    move-result v3

    if-nez v3, :cond_0

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Non-LAN endpoint refused"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    return-object v0

    .line 97
    :cond_2
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Expected LAN HTTP endpoint"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static read(Ljava/io/InputStream;Ljava/io/ByteArrayOutputStream;I)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/16 v0, 0x2000

    .line 157
    new-array v1, v0, [B

    :goto_0
    if-lez p2, :cond_1

    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {p0, v1, v3, v2}, Ljava/io/InputStream;->read([BII)I

    move-result v2

    if-ltz v2, :cond_0

    invoke-virtual {p1, v1, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    sub-int/2addr p2, v2

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/io/EOFException;

    invoke-direct {p0}, Ljava/io/EOFException;-><init>()V

    throw p0

    :cond_1
    return-void
.end method

.method static readOnly(Ljava/lang/String;)Z
    .locals 13

    const/4 v0, 0x1

    if-nez p0, :cond_0

    return v0

    :cond_0
    const/16 v1, 0x23

    .line 54
    invoke-virtual {p0, v1}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v1

    add-int/2addr v1, v0

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    .line 55
    const-string v11, "Repeat"

    const-string v12, "GetServiceStatus"

    const-string v0, "TracksMax"

    const-string v1, "IdArray"

    const-string v2, "ReadList"

    const-string v3, "SourceIndex"

    const-string v4, "SourceXml"

    const-string v5, "TransportState"

    const-string v6, "Id"

    const-string v7, "Time"

    const-string v8, "Volume"

    const-string v9, "Mute"

    const-string v10, "Shuffle"

    filled-new-array/range {v0 .. v12}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method static safeDescription(Ljava/lang/String;)Ljava/lang/String;
    .locals 13

    .line 48
    const-string v11, "Seek failed"

    const-string v12, "Shuffle not currently possible"

    const-string v0, "Action Failed"

    const-string v1, "Invalid Action"

    const-string v2, "Invalid Args"

    const-string v3, "Transition not available"

    const-string v4, "Invalid Id"

    const-string v5, "Buffer full"

    const-string v6, "Not supported"

    const-string v7, "Not authorized"

    const-string v8, "Id not found"

    const-string v9, "Playlist full"

    const-string v10, "Index not found"

    filled-new-array/range {v0 .. v12}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 49
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    return-object v1

    .line 50
    :cond_1
    const-string p0, "Device action rejected"

    return-object p0
.end method

.method static text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 84
    const-string v0, "*"

    invoke-interface {p0, v0, p1}, Lorg/w3c/dom/Element;->getElementsByTagNameNS(Ljava/lang/String;Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object p0

    .line 85
    invoke-interface {p0}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result p1

    if-nez p1, :cond_0

    const-string p0, ""

    return-object p0

    :cond_0
    const/4 p1, 0x0

    invoke-interface {p0, p1}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object p0

    invoke-interface {p0}, Lorg/w3c/dom/Node;->getTextContent()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static tidalUri(ILjava/lang/String;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    if-lez p0, :cond_0

    .line 334
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 335
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "tidal://track?version=2&trackId="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, "&token="

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "UTF-8"

    invoke-static {p1, p0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 334
    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Invalid online TIDAL track"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static timeout(I)I
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/net/SocketTimeoutException;
        }
    .end annotation

    .line 32
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    if-nez v0, :cond_0

    return p0

    .line 33
    :cond_0
    sget-object v1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sub-long/2addr v0, v2

    const-wide/32 v2, 0xf4240

    div-long/2addr v0, v2

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-lez v2, :cond_1

    int-to-long v2, p0

    .line 35
    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int p0, v0

    return p0

    .line 34
    :cond_1
    new-instance p0, Ljava/net/SocketTimeoutException;

    const-string v0, "Linn operation deadline"

    invoke-direct {p0, v0}, Ljava/net/SocketTimeoutException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static xml([B)Lorg/w3c/dom/Document;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 88
    new-instance v0, Ljava/lang/String;

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, p0, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 89
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "<!DOCTYPE"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "<!ENTITY"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 91
    invoke-static {}, Ljavax/xml/parsers/DocumentBuilderFactory;->newInstance()Ljavax/xml/parsers/DocumentBuilderFactory;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljavax/xml/parsers/DocumentBuilderFactory;->setNamespaceAware(Z)V

    const/4 v1, 0x0

    .line 92
    invoke-virtual {v0, v1}, Ljavax/xml/parsers/DocumentBuilderFactory;->setExpandEntityReferences(Z)V

    .line 93
    invoke-virtual {v0}, Ljavax/xml/parsers/DocumentBuilderFactory;->newDocumentBuilder()Ljavax/xml/parsers/DocumentBuilder;

    move-result-object v0

    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-virtual {v0, v1}, Ljavax/xml/parsers/DocumentBuilder;->parse(Ljava/io/InputStream;)Lorg/w3c/dom/Document;

    move-result-object p0

    return-object p0

    .line 90
    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Unsafe device XML"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method varargs call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 183
    iget-object p0, p0, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/OpenHome$Service;

    if-eqz p0, :cond_8

    .line 185
    invoke-virtual {p0}, Ldev/nino/squareglass/OpenHome$Service;->load()V

    .line 186
    iget-object v0, p0, Ldev/nino/squareglass/OpenHome$Service;->inputs:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "."

    if-eqz v0, :cond_7

    .line 187
    iget-object v0, p0, Ldev/nino/squareglass/OpenHome$Service;->inputs:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    .line 188
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    array-length v3, p3

    if-ne v2, v3, :cond_6

    .line 189
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body><u:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 190
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " xmlns:u=\""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Ldev/nino/squareglass/OpenHome$Service;->type:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\">"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move v4, v3

    .line 191
    :goto_0
    array-length v5, p3

    if-ge v4, v5, :cond_0

    const/16 v5, 0x3c

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v5, 0x3e

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    aget-object v6, p3, v4

    invoke-static {v6}, Ldev/nino/squareglass/OpenHome;->escape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "</"

    .line 192
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 193
    :cond_0
    const-string p3, "</u:"

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p3, "></s:Body></s:Envelope>"

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 194
    iget-object p3, p0, Ldev/nino/squareglass/OpenHome$Service;->control:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Ldev/nino/squareglass/OpenHome$Service;->type:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "#"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {p3, v0, v2}, Ldev/nino/squareglass/OpenHome;->fetch(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object p3

    .line 196
    :try_start_0
    invoke-static {p3}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object p3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 197
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "Response"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "*"

    invoke-interface {p3, v2, v0}, Lorg/w3c/dom/Document;->getElementsByTagNameNS(Ljava/lang/String;Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object p3

    .line 198
    invoke-interface {p3}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result v0

    const/4 v2, 0x1

    if-eq v0, v2, :cond_2

    new-instance v5, Ldev/nino/squareglass/OpenHome$Fault;

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p0, p0, Ldev/nino/squareglass/OpenHome$Service;->type:Ljava/lang/String;

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/OpenHome;->readOnly(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_1

    sget-object p0, Ldev/nino/squareglass/OpenHome$Failure;->REJECTED:Ldev/nino/squareglass/OpenHome$Failure;

    goto :goto_1

    :cond_1
    sget-object p0, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    :goto_1
    move-object v6, p0

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const-string v10, "Missing device response"

    const/4 v11, 0x0

    const/16 v8, 0xc8

    const-string v9, ""

    invoke-direct/range {v5 .. v11}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v5

    .line 199
    :cond_2
    new-instance p0, Ljava/util/HashMap;

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    invoke-interface {p3, v3}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object p1

    invoke-interface {p1}, Lorg/w3c/dom/Node;->getChildNodes()Lorg/w3c/dom/NodeList;

    move-result-object p1

    .line 200
    :goto_2
    invoke-interface {p1}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result p2

    if-ge v3, p2, :cond_4

    invoke-interface {p1, v3}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object p2

    instance-of p2, p2, Lorg/w3c/dom/Element;

    if-eqz p2, :cond_3

    invoke-interface {p1, v3}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object p2

    invoke-interface {p2}, Lorg/w3c/dom/Node;->getLocalName()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, v3}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object p3

    invoke-interface {p3}, Lorg/w3c/dom/Node;->getTextContent()Ljava/lang/String;

    move-result-object p3

    invoke-interface {p0, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_4
    return-object p0

    :catch_0
    move-exception v0

    move-object v10, v0

    move-object p3, v4

    .line 196
    new-instance v4, Ldev/nino/squareglass/OpenHome$Fault;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p0, p0, Ldev/nino/squareglass/OpenHome$Service;->type:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/OpenHome;->readOnly(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_5

    sget-object p0, Ldev/nino/squareglass/OpenHome$Failure;->REJECTED:Ldev/nino/squareglass/OpenHome$Failure;

    goto :goto_3

    :cond_5
    sget-object p0, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    :goto_3
    move-object v5, p0

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-string v8, ""

    const-string v9, "Invalid device response"

    const/16 v7, 0xc8

    invoke-direct/range {v4 .. v10}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v4

    .line 188
    :cond_6
    new-instance p0, Ljava/io/IOException;

    const-string p1, "SOAP argument mismatch"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 186
    :cond_7
    new-instance p0, Ljava/io/IOException;

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "Unsupported device action: "

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 184
    :cond_8
    new-instance p0, Ljava/io/IOException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Unsupported device service: "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method checkCapabilities()V
    .locals 23
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object/from16 v0, p0

    .line 206
    const-string v1, "Playlist"

    const-string v2, "Product"

    const-string v3, "Time"

    const-string v4, "Volume"

    const-string v5, "OAuth"

    filled-new-array {v1, v2, v3, v4, v5}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 207
    iget-object v7, v0, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    invoke-interface {v7, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Missing Linn service: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 208
    :cond_1
    const-string v21, "SetRepeat"

    const-string v22, "SetShuffle"

    const-string v6, "Playlist"

    const-string v7, "TracksMax"

    const-string v8, "IdArray"

    const-string v9, "ReadList"

    const-string v10, "Insert"

    const-string v11, "DeleteId"

    const-string v12, "TransportState"

    const-string v13, "Id"

    const-string v14, "Pause"

    const-string v15, "Play"

    const-string v16, "Stop"

    const-string v17, "SeekId"

    const-string v18, "SeekSecondAbsolute"

    const-string v19, "Repeat"

    const-string v20, "Shuffle"

    filled-new-array/range {v6 .. v22}, [Ljava/lang/String;

    move-result-object v1

    const-string v6, "SourceXml"

    const-string v7, "SetSourceIndex"

    const-string v8, "SourceIndex"

    filled-new-array {v2, v8, v6, v7}, [Ljava/lang/String;

    move-result-object v2

    filled-new-array {v3, v3}, [Ljava/lang/String;

    move-result-object v3

    const-string v6, "VolumeIncNoUnmute"

    const-string v7, "VolumeDecNoUnmute"

    const-string v8, "SetVolumeNoUnmute"

    filled-new-array {v4, v4, v8, v6, v7}, [Ljava/lang/String;

    move-result-object v4

    const-string v6, "GetServiceStatus"

    filled-new-array {v5, v6}, [Ljava/lang/String;

    move-result-object v5

    filled-new-array {v1, v2, v3, v4, v5}, [[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    move v3, v2

    :goto_1
    const/4 v4, 0x5

    if-ge v3, v4, :cond_4

    .line 212
    aget-object v4, v1, v3

    iget-object v5, v0, Ldev/nino/squareglass/OpenHome;->services:Ljava/util/Map;

    aget-object v6, v4, v2

    invoke-interface {v5, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ldev/nino/squareglass/OpenHome$Service;

    invoke-virtual {v5}, Ldev/nino/squareglass/OpenHome$Service;->load()V

    const/4 v6, 0x1

    :goto_2
    array-length v7, v4

    if-ge v6, v7, :cond_3

    .line 213
    iget-object v7, v5, Ldev/nino/squareglass/OpenHome$Service;->inputs:Ljava/util/Map;

    aget-object v8, v4, v6

    invoke-interface {v7, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_2
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "Unsupported Linn action: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    aget-object v2, v4, v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v2, v4, v6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_4
    return-void
.end method

.method confirm(JLjava/lang/String;J)V
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 246
    const-string v0, "Playlist"

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v3, p4, p5}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide p4

    add-long/2addr v1, p4

    .line 247
    sget-object p4, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {p4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Ljava/lang/Long;

    if-nez p5, :cond_0

    move-wide v3, v1

    goto :goto_0

    :cond_0
    invoke-virtual {p5}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    :goto_0
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {p4, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 250
    :goto_1
    :try_start_0
    const-string p4, "Id"

    invoke-virtual {p0, v0, p4}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    const-string v3, "TransportState"

    invoke-virtual {p0, v0, v3}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 251
    invoke-static {p1, p2}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p4

    if-eqz p4, :cond_2

    invoke-virtual {p3, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p4, :cond_2

    .line 255
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    if-nez p5, :cond_1

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :cond_1
    invoke-virtual {p0, p5}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    return-void

    :cond_2
    const-wide/16 v3, 0xfa

    .line 252
    :try_start_1
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V

    .line 253
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    cmp-long p4, v3, v1

    if-gez p4, :cond_3

    goto :goto_1

    .line 254
    :cond_3
    new-instance v3, Ldev/nino/squareglass/OpenHome$Fault;

    sget-object v4, Ldev/nino/squareglass/OpenHome$Failure;->TIMEOUT:Ldev/nino/squareglass/OpenHome$Failure;

    const-string v5, "Playback confirmation"

    const-string v7, ""

    const-string v8, "Linn did not confirm the requested playback state"

    const/4 v9, 0x0

    const/4 v6, 0x0

    invoke-direct/range {v3 .. v9}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v0

    move-object p0, v0

    .line 255
    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    if-nez p5, :cond_4

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    goto :goto_2

    :cond_4
    invoke-virtual {p1, p5}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :goto_2
    throw p0
.end method

.method ids()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, 0x0

    .line 296
    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Playlist"

    const-string v2, "IdArray"

    invoke-virtual {p0, v1, v2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object p0

    const-string v0, "Array"

    invoke-interface {p0, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Ldev/nino/squareglass/OpenHome;->decodeIds(Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method insertConfirmed(Ljava/util/List;JLjava/lang/String;Ljava/lang/String;)J
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;J",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")J"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 232
    :try_start_0
    const-string v0, "Playlist"

    const-string v1, "Insert"

    invoke-static {p2, p3}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2, p4, p5}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v0, v1, v2}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    const-string v1, "NewId"

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide p0
    :try_end_0
    .catch Ldev/nino/squareglass/OpenHome$Fault; {:try_start_0 .. :try_end_0} :catch_0

    return-wide p0

    :catch_0
    move-exception v0

    .line 234
    iget-object v1, v0, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v2, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    if-ne v1, v2, :cond_2

    .line 235
    invoke-virtual {p0}, Ldev/nino/squareglass/OpenHome;->ids()Ljava/util/List;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-interface {v2, p1}, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z

    .line 236
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    const/4 v4, 0x1

    if-ne v3, v4, :cond_1

    const/4 v3, 0x0

    .line 237
    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const-wide/16 v8, 0x0

    cmp-long v8, p2, v8

    if-nez v8, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result p1

    add-int/lit8 v3, p1, 0x1

    .line 238
    :goto_0
    invoke-interface {v7, v3, v2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 239
    invoke-static {v2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/OpenHome;->readTracks(Ljava/util/List;)Ljava/util/Map;

    move-result-object p0

    invoke-interface {p0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map;

    .line 240
    invoke-interface {v7, v1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    const-string p1, "Uri"

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    const-string p1, "Metadata"

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p5, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    return-wide v5

    .line 242
    :cond_1
    throw v0

    .line 234
    :cond_2
    throw v0
.end method

.method invalidateSources()V
    .locals 1

    const/4 v0, 0x0

    .line 215
    iput-object v0, p0, Ldev/nino/squareglass/OpenHome;->sourceXml:Ljava/lang/String;

    return-void
.end method

.method playlistIndex()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 222
    invoke-virtual {p0}, Ldev/nino/squareglass/OpenHome;->sources()Ljava/lang/String;

    move-result-object p0

    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object p0

    const-string v0, "Source"

    invoke-interface {p0, v0}, Lorg/w3c/dom/Document;->getElementsByTagName(Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object p0

    const/4 v0, 0x0

    .line 223
    :goto_0
    invoke-interface {p0}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-interface {p0, v0}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object v1

    check-cast v1, Lorg/w3c/dom/Element;

    const-string v2, "Type"

    invoke-static {v1, v2}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "Playlist"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 224
    :cond_1
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Linn Playlist source unavailable"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method playlistSource()Z
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 227
    const-string v0, "Product"

    const-string v1, "SourceIndex"

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 228
    invoke-virtual {p0}, Ldev/nino/squareglass/OpenHome;->sources()Ljava/lang/String;

    move-result-object p0

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    invoke-static {p0}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object p0

    const-string v1, "Source"

    invoke-interface {p0, v1}, Lorg/w3c/dom/Document;->getElementsByTagName(Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object p0

    if-ltz v0, :cond_0

    .line 229
    invoke-interface {p0}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result v1

    if-ge v0, v1, :cond_0

    invoke-interface {p0, v0}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object p0

    check-cast p0, Lorg/w3c/dom/Element;

    const-string v0, "Type"

    invoke-static {p0, v0}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "Playlist"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method preflight()Ljava/lang/String;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 204
    invoke-virtual {p0}, Ldev/nino/squareglass/OpenHome;->checkCapabilities()V

    invoke-virtual {p0}, Ldev/nino/squareglass/OpenHome;->tidalTokenId()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, 0x0

    .line 203
    new-array v0, v0, [Ljava/lang/String;

    invoke-virtual {p0, p1, p2, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object p0

    const-string p1, "Value"

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method readTracks(Ljava/util/List;)Ljava/util/Map;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 306
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v1, 0x0

    move v2, v1

    .line 307
    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_4

    .line 308
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    add-int/lit8 v4, v2, 0x20

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-interface {p1, v2, v3}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v2

    .line 309
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Long;

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-virtual {v3, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 v6, 0x20

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 310
    :cond_0
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/String;

    move-result-object v3

    const-string v5, "Playlist"

    const-string v6, "ReadList"

    invoke-virtual {p0, v5, v6, v3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v3

    const-string v5, "TrackList"

    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    sget-object v5, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v3, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v3

    invoke-static {v3}, Ldev/nino/squareglass/OpenHome;->xml([B)Lorg/w3c/dom/Document;

    move-result-object v3

    invoke-interface {v3}, Lorg/w3c/dom/Document;->getDocumentElement()Lorg/w3c/dom/Element;

    move-result-object v3

    .line 311
    const-string v5, "Entry"

    invoke-interface {v3, v5}, Lorg/w3c/dom/Element;->getElementsByTagName(Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object v3

    move v5, v1

    .line 312
    :goto_2
    invoke-interface {v3}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result v6

    if-ge v5, v6, :cond_2

    .line 313
    invoke-interface {v3, v5}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object v6

    check-cast v6, Lorg/w3c/dom/Element;

    const-string v7, "Id"

    invoke-static {v6, v7}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    .line 314
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface {v2, v9}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface {v0, v9}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1

    .line 315
    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    const-string v10, "Uri"

    invoke-static {v6, v10}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v9, v10, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v10, "Metadata"

    invoke-static {v6, v10}, Ldev/nino/squareglass/OpenHome;->text(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v9, v10, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface {v0, v6, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    .line 314
    :cond_1
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Unexpected device queue entry"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 317
    :cond_2
    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3, v2}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z

    move-result v2

    if-eqz v2, :cond_3

    move v2, v4

    goto/16 :goto_0

    :cond_3
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Device queue changed while reading"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    return-object v0
.end method

.method seekConfirmed(I)V
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 281
    const-string v1, "Time"

    div-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x0

    invoke-static {v2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    .line 282
    sget-object v0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v6, 0x4a817c800L

    add-long/2addr v4, v6

    if-nez v3, :cond_0

    move-wide v6, v4

    goto :goto_0

    .line 283
    :cond_0
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-static {v6, v7, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v6

    :goto_0
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 286
    :goto_1
    :try_start_0
    const-string v0, "Playlist"

    const-string v6, "SeekSecondAbsolute"

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v7

    filled-new-array {v7}, [Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0, v0, v6, v7}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;
    :try_end_0
    .catch Ldev/nino/squareglass/OpenHome$Fault; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    :catchall_0
    move-exception v0

    move-object p0, v0

    goto :goto_4

    :catch_0
    move-exception v0

    .line 287
    :try_start_1
    iget-object v6, v0, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v7, Ldev/nino/squareglass/OpenHome$Failure;->UNCERTAIN:Ldev/nino/squareglass/OpenHome$Failure;

    if-eq v6, v7, :cond_2

    iget-object v6, v0, Ldev/nino/squareglass/OpenHome$Fault;->kind:Ldev/nino/squareglass/OpenHome$Failure;

    sget-object v7, Ldev/nino/squareglass/OpenHome$Failure;->REJECTED:Ldev/nino/squareglass/OpenHome$Failure;

    if-ne v6, v7, :cond_1

    const-string v6, "803"

    iget-object v7, v0, Ldev/nino/squareglass/OpenHome$Fault;->code:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    goto :goto_2

    :cond_1
    throw v0

    .line 288
    :cond_2
    :goto_2
    new-array v0, v2, [Ljava/lang/String;

    invoke-virtual {p0, v1, v1, v0}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    const-string v6, "Seconds"

    invoke-interface {v0, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    sub-int/2addr v0, p1

    .line 289
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x2

    if-gt v0, v6, :cond_4

    .line 293
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    if-nez v3, :cond_3

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    goto :goto_3

    :cond_3
    invoke-virtual {p0, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :goto_3
    return-void

    :cond_4
    const-wide/16 v6, 0x12c

    .line 290
    :try_start_2
    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V

    .line 291
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v6

    cmp-long v0, v6, v4

    if-gez v0, :cond_5

    goto :goto_1

    .line 292
    :cond_5
    new-instance v6, Ldev/nino/squareglass/OpenHome$Fault;

    sget-object v7, Ldev/nino/squareglass/OpenHome$Failure;->TIMEOUT:Ldev/nino/squareglass/OpenHome$Failure;

    const-string v8, "Position confirmation"

    const-string v10, ""

    const-string v11, "Linn did not confirm the playback position"

    const/4 v12, 0x0

    const/4 v9, 0x0

    invoke-direct/range {v6 .. v12}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v6
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 293
    :goto_4
    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    if-nez v3, :cond_6

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    goto :goto_5

    :cond_6
    invoke-virtual {p1, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :goto_5
    throw p0
.end method

.method selectTrack(JIZ)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 259
    const-string v0, "TransportState"

    const-string v1, "Playlist"

    sget-object v2, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide v6, 0x4a817c800L

    add-long/2addr v4, v6

    if-nez v3, :cond_0

    move-wide v6, v4

    goto :goto_0

    .line 260
    :cond_0
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-static {v6, v7, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v6

    :goto_0
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 262
    :try_start_0
    const-string v2, "SeekId"

    invoke-static {p1, p2}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v6

    filled-new-array {v6}, [Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p0, v1, v2, v6}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    .line 263
    const-string v2, ""

    .line 265
    :goto_1
    const-string v6, "Id"

    invoke-virtual {p0, v1, v6}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p0, v1, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 266
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, ":"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 267
    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1

    sget-object v2, Ldev/nino/squareglass/OpenHome;->trace:Ldev/nino/squareglass/OpenHome$Trace;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "attempt="

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v10, Ldev/nino/squareglass/OpenHome;->attempt:Ljava/lang/ThreadLocal;

    invoke-virtual {v10}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, " awaiting_track target="

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v10, " actual="

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, " state="

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-interface {v2, v7}, Ldev/nino/squareglass/OpenHome$Trace;->record(Ljava/lang/String;)V

    move-object v2, v8

    .line 268
    :cond_1
    invoke-static {p1, p2}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7

    if-lez p3, :cond_2

    .line 274
    invoke-virtual {p0, p3}, Ldev/nino/squareglass/OpenHome;->seekConfirmed(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 p3, 0x0

    .line 275
    const-string v2, "Playing"

    if-nez p4, :cond_3

    :try_start_1
    const-string v0, "Pause"

    new-array p3, p3, [Ljava/lang/String;

    invoke-virtual {p0, v1, v0, p3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    goto :goto_2

    .line 276
    :cond_3
    invoke-virtual {p0, v1, v0}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    const-string v0, "Play"

    new-array p3, p3, [Ljava/lang/String;

    invoke-virtual {p0, v1, v0, p3}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    :cond_4
    :goto_2
    if-eqz p4, :cond_5

    goto :goto_3

    .line 277
    :cond_5
    const-string v2, "Paused"

    :goto_3
    move-object v7, v2

    const-wide/16 v8, 0x4e20

    move-object v4, p0

    move-wide v5, p1

    invoke-virtual/range {v4 .. v9}, Ldev/nino/squareglass/OpenHome;->confirm(JLjava/lang/String;J)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 278
    sget-object p0, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    if-nez v3, :cond_6

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->remove()V

    return-void

    :cond_6
    invoke-virtual {p0, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    return-void

    .line 269
    :cond_7
    :try_start_2
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v6

    cmp-long v6, v6, v4

    if-gez v6, :cond_8

    const-wide/16 v6, 0x64

    .line 270
    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V

    goto/16 :goto_1

    .line 269
    :cond_8
    new-instance v4, Ldev/nino/squareglass/OpenHome$Fault;

    sget-object v5, Ldev/nino/squareglass/OpenHome$Failure;->TIMEOUT:Ldev/nino/squareglass/OpenHome$Failure;

    const-string v6, "Track selection"

    const-string v8, ""

    const-string v9, "Linn did not confirm the selected track"

    const/4 v10, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v4 .. v10}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    move-exception v0

    move-object p0, v0

    .line 278
    sget-object p1, Ldev/nino/squareglass/OpenHome;->deadline:Ljava/lang/ThreadLocal;

    if-nez v3, :cond_9

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->remove()V

    goto :goto_4

    :cond_9
    invoke-virtual {p1, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :goto_4
    throw p0
.end method

.method sources()Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 217
    iget-object v0, p0, Ldev/nino/squareglass/OpenHome;->sourceXml:Ljava/lang/String;

    if-eqz v0, :cond_0

    .line 218
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    iget-wide v3, p0, Ldev/nino/squareglass/OpenHome;->sourceXmlAt:J

    sub-long/2addr v1, v3

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const-wide v3, 0x45d964b800L

    cmp-long v1, v1, v3

    if-gez v1, :cond_0

    return-object v0

    .line 219
    :cond_0
    const-string v0, "Product"

    const-string v1, "SourceXml"

    invoke-virtual {p0, v0, v1}, Ldev/nino/squareglass/OpenHome;->read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    iput-wide v1, p0, Ldev/nino/squareglass/OpenHome;->sourceXmlAt:J

    iput-object v0, p0, Ldev/nino/squareglass/OpenHome;->sourceXml:Ljava/lang/String;

    return-object v0
.end method

.method tidalTokenId()Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 322
    new-instance v0, Lorg/json/JSONObject;

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/String;

    const-string v3, "OAuth"

    const-string v4, "GetServiceStatus"

    invoke-virtual {p0, v3, v4, v2}, Ldev/nino/squareglass/OpenHome;->call(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map;

    move-result-object p0

    const-string v2, "ServiceStatusJson"

    invoke-interface {p0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 323
    const-string p0, "services"

    invoke-virtual {v0, p0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    move v0, v1

    .line 324
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v0, v2, :cond_5

    .line 325
    invoke-virtual {p0, v0}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "tidalhifi.com"

    const-string v4, "id"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_3

    .line 326
    :cond_0
    const-string v3, "longLivedTokens"

    const-string v5, "shortLivedTokens"

    filled-new-array {v3, v5}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 327
    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v5

    if-nez v5, :cond_2

    goto :goto_1

    :cond_2
    move v6, v1

    .line 328
    :goto_2
    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v6, v7, :cond_1

    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    const-string v8, "isValid"

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object p0

    invoke-virtual {p0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_4
    :goto_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 331
    :cond_5
    new-instance v2, Ldev/nino/squareglass/OpenHome$Fault;

    sget-object v3, Ldev/nino/squareglass/OpenHome$Failure;->AUTH:Ldev/nino/squareglass/OpenHome$Failure;

    const-string v7, "Sign in to TIDAL for this Majik in the Linn app, then retry"

    const/4 v8, 0x0

    const-string v4, "OAuth.GetServiceStatus"

    const/4 v5, 0x0

    const-string v6, ""

    invoke-direct/range {v2 .. v8}, Ldev/nino/squareglass/OpenHome$Fault;-><init>(Ldev/nino/squareglass/OpenHome$Failure;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2
.end method
