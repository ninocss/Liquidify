.class final Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "NativeIconGlass.kt"

# interfaces
.implements Lam0/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/NativeIconGlass;->attach(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/u;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeIconGlass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeIconGlass.kt\ndev/nino/squareglass/NativeIconGlass$attach$2$1$1\n+ 2 Offset.kt\nandroidx/compose/ui/geometry/OffsetKt\n+ 3 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n*L\n1#1,87:1\n30#2:88\n53#3,3:89\n*S KotlinDebug\n*F\n+ 1 NativeIconGlass.kt\ndev/nino/squareglass/NativeIconGlass$attach$2$1$1\n*L\n50#1:88\n50#1:89,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

# instance fields
.field final synthetic $event:I

.field final synthetic $highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

.field final synthetic $motion:Z

.field final synthetic $paint:Landroidx/compose/ui/platform/ComposeView;

.field label:I


# direct methods
.method constructor <init>(IZLdev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/platform/ComposeView;Lkotlin/coroutines/e;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ",
            "Ldev/nino/squareglass/material/InteractiveHighlight;",
            "Landroidx/compose/ui/platform/ComposeView;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;",
            ">;)V"
        }
    .end annotation

    iput p1, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$event:I

    iput-boolean p2, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$motion:Z

    iput-object p3, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

    iput-object p4, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$paint:Landroidx/compose/ui/platform/ComposeView;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/e;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;

    iget v1, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$event:I

    iget-boolean v2, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$motion:Z

    iget-object v3, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

    iget-object v4, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$paint:Landroidx/compose/ui/platform/ComposeView;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;-><init>(IZLdev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/platform/ComposeView;Lkotlin/coroutines/e;)V

    check-cast v0, Lkotlin/coroutines/e;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/e;

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/u;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/e;)Lkotlin/coroutines/e;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;

    sget-object p1, Lkotlin/u;->a:Lkotlin/u;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    invoke-static {}, Ldev/nino/squareglass/HostCompat;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 49
    iget v0, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->label:I

    if-nez v0, :cond_1

    invoke-static {p1}, Lkotlin/k;->b(Ljava/lang/Object;)V

    .line 50
    iget p1, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$event:I

    if-lez p1, :cond_0

    iget-boolean p1, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$motion:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

    iget-object v0, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$paint:Landroidx/compose/ui/platform/ComposeView;

    const-string v1, "null cannot be cast to non-null type android.view.View"

    invoke-static {v0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v0, v2

    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$paint:Landroidx/compose/ui/platform/ComposeView;

    invoke-static {p0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p0

    int-to-float p0, p0

    div-float/2addr p0, v2

    .line 89
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    int-to-long v0, v0

    .line 90
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    int-to-long v2, p0

    const/16 p0, 0x20

    shl-long/2addr v0, p0

    const-wide v4, 0xffffffffL

    and-long/2addr v2, v4

    or-long/2addr v0, v2

    .line 88
    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Offset;->constructor-impl(J)J

    move-result-wide v0

    .line 50
    invoke-virtual {p1, v0, v1}, Ldev/nino/squareglass/material/InteractiveHighlight;->pulse-k-4lQ0M(J)V

    goto :goto_0

    .line 51
    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$attach$2$1$1;->$highlight:Ldev/nino/squareglass/material/InteractiveHighlight;

    invoke-virtual {p0}, Ldev/nino/squareglass/material/InteractiveHighlight;->reset()V

    .line 52
    :goto_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0

    .line 49
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
