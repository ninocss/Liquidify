.class public final synthetic Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda16;->f$0:Ldev/nino/squareglass/LinnProvider;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$$ExternalSyntheticLambda16;->f$0:Ldev/nino/squareglass/LinnProvider;

    invoke-static {p0}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$R_5M9YtCFkgIqqA-ra_TEZzyRZk(Ldev/nino/squareglass/LinnProvider;)V

    return-void
.end method
