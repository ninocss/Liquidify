.class public final synthetic Ldev/nino/squareglass/LinnNativeVolume$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnNativeVolume;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnNativeVolume;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnNativeVolume$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/LinnNativeVolume;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/LinnNativeVolume$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/LinnNativeVolume;

    invoke-static {p0}, Ldev/nino/squareglass/LinnNativeVolume;->$r8$lambda$YJAtIItxd-GzTnJRKG9J1DVQnfw(Ldev/nino/squareglass/LinnNativeVolume;)V

    return-void
.end method
