.class public final synthetic Ldev/nino/squareglass/NativeTabs$8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/tidal/android/feature/appscaffold/ui/composable/y;

.field public final synthetic f$1:J

.field public final synthetic f$2:I

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$4:J


# direct methods
.method public synthetic constructor <init>(Lcom/tidal/android/feature/appscaffold/ui/composable/y;JILandroidx/compose/runtime/MutableState;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeTabs$8;->f$0:Lcom/tidal/android/feature/appscaffold/ui/composable/y;

    iput-wide p2, p0, Ldev/nino/squareglass/NativeTabs$8;->f$1:J

    iput p4, p0, Ldev/nino/squareglass/NativeTabs$8;->f$2:I

    iput-object p5, p0, Ldev/nino/squareglass/NativeTabs$8;->f$3:Landroidx/compose/runtime/MutableState;

    iput-wide p6, p0, Ldev/nino/squareglass/NativeTabs$8;->f$4:J

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeTabs$8;->f$0:Lcom/tidal/android/feature/appscaffold/ui/composable/y;

    iget-wide v1, p0, Ldev/nino/squareglass/NativeTabs$8;->f$1:J

    iget v3, p0, Ldev/nino/squareglass/NativeTabs$8;->f$2:I

    iget-object v4, p0, Ldev/nino/squareglass/NativeTabs$8;->f$3:Landroidx/compose/runtime/MutableState;

    iget-wide v5, p0, Ldev/nino/squareglass/NativeTabs$8;->f$4:J

    move-object v7, p1

    check-cast v7, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v8, p2

    check-cast v8, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v9

    invoke-static/range {v0 .. v9}, Ldev/nino/squareglass/NativeTabs;->$r8$lambda$MR5e3EF6LsPKiNVa4piJ5jtcdLY(Lcom/tidal/android/feature/appscaffold/ui/composable/y;JILandroidx/compose/runtime/MutableState;JLandroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
