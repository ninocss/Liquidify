.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/graphics/Paint;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/graphics/Paint;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda12;->f$0:Landroidx/compose/ui/graphics/Paint;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda12;->f$0:Landroidx/compose/ui/graphics/Paint;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;

    invoke-static {p0, p1}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$EtQh3UFqAbclxzX6YjfXM_PdV2g(Landroidx/compose/ui/graphics/Paint;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
