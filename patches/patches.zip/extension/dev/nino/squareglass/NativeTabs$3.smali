.class public final synthetic Ldev/nino/squareglass/NativeTabs$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Lam0/a;

.field public final synthetic f$1:Lam0/l;

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Landroidx/compose/ui/Modifier;

.field public final synthetic f$4:I

.field public final synthetic f$5:J

.field public final synthetic f$6:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$7:J


# direct methods
.method public synthetic constructor <init>(Lam0/a;Lam0/l;Ljava/util/List;Landroidx/compose/ui/Modifier;IJLandroidx/compose/runtime/MutableState;J)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeTabs$3;->f$0:Lam0/a;

    iput-object p2, p0, Ldev/nino/squareglass/NativeTabs$3;->f$1:Lam0/l;

    iput-object p3, p0, Ldev/nino/squareglass/NativeTabs$3;->f$2:Ljava/util/List;

    iput-object p4, p0, Ldev/nino/squareglass/NativeTabs$3;->f$3:Landroidx/compose/ui/Modifier;

    iput p5, p0, Ldev/nino/squareglass/NativeTabs$3;->f$4:I

    iput-wide p6, p0, Ldev/nino/squareglass/NativeTabs$3;->f$5:J

    iput-object p8, p0, Ldev/nino/squareglass/NativeTabs$3;->f$6:Landroidx/compose/runtime/MutableState;

    iput-wide p9, p0, Ldev/nino/squareglass/NativeTabs$3;->f$7:J

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeTabs$3;->f$0:Lam0/a;

    iget-object v1, p0, Ldev/nino/squareglass/NativeTabs$3;->f$1:Lam0/l;

    iget-object v2, p0, Ldev/nino/squareglass/NativeTabs$3;->f$2:Ljava/util/List;

    iget-object v3, p0, Ldev/nino/squareglass/NativeTabs$3;->f$3:Landroidx/compose/ui/Modifier;

    iget v4, p0, Ldev/nino/squareglass/NativeTabs$3;->f$4:I

    iget-wide v5, p0, Ldev/nino/squareglass/NativeTabs$3;->f$5:J

    iget-object v7, p0, Ldev/nino/squareglass/NativeTabs$3;->f$6:Landroidx/compose/runtime/MutableState;

    iget-wide v8, p0, Ldev/nino/squareglass/NativeTabs$3;->f$7:J

    move-object v10, p1

    check-cast v10, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v11

    invoke-static/range {v0 .. v11}, Ldev/nino/squareglass/NativeTabs;->Render$lambda$4(Lam0/a;Lam0/l;Ljava/util/List;Landroidx/compose/ui/Modifier;IJLandroidx/compose/runtime/MutableState;JLandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
