.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/graphics/Paint;

.field public final synthetic f$1:Landroidx/compose/ui/graphics/Brush;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/graphics/Paint;Landroidx/compose/ui/graphics/Brush;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$11;->f$0:Landroidx/compose/ui/graphics/Paint;

    iput-object p2, p0, Ldev/nino/squareglass/PlayerArtwork$11;->f$1:Landroidx/compose/ui/graphics/Brush;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PlayerArtwork$11;->f$0:Landroidx/compose/ui/graphics/Paint;

    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$11;->f$1:Landroidx/compose/ui/graphics/Brush;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$k45niXR2dMvUZ43TBK5elQ676Ww(Landroidx/compose/ui/graphics/Paint;Landroidx/compose/ui/graphics/Brush;Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
