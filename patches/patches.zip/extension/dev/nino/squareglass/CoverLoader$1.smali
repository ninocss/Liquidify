.class public final synthetic Ldev/nino/squareglass/CoverLoader$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ljava/util/function/Consumer;

.field public final synthetic f$1:Landroid/graphics/Bitmap;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/Consumer;Landroid/graphics/Bitmap;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/CoverLoader$1;->f$0:Ljava/util/function/Consumer;

    iput-object p2, p0, Ldev/nino/squareglass/CoverLoader$1;->f$1:Landroid/graphics/Bitmap;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/CoverLoader$1;->f$0:Ljava/util/function/Consumer;

    iget-object p0, p0, Ldev/nino/squareglass/CoverLoader$1;->f$1:Landroid/graphics/Bitmap;

    invoke-static {v0, p0}, Ldev/nino/squareglass/CoverLoader;->lambda$load$1(Ljava/util/function/Consumer;Landroid/graphics/Bitmap;)V

    return-void
.end method
