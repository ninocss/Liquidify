.class public final synthetic Ldev/nino/squareglass/LiquidMenuSurface$3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Z


# direct methods
.method public synthetic constructor <init>(Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Ldev/nino/squareglass/LiquidMenuSurface$3;->f$0:Z

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-boolean p0, p0, Ldev/nino/squareglass/LiquidMenuSurface$3;->f$0:Z

    invoke-static {p0}, Ldev/nino/squareglass/LiquidMenuSurface;->$r8$lambda$8KDWgz0TOAv8ur2GLjXW8SAcBhw(Z)Ldev/nino/squareglass/backdrop/shadow/Shadow;

    move-result-object p0

    return-object p0
.end method
