.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:J


# direct methods
.method public synthetic constructor <init>(JJ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Ldev/nino/squareglass/PlayerArtwork$7;->f$0:J

    iput-wide p3, p0, Ldev/nino/squareglass/PlayerArtwork$7;->f$1:J

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 0
    iget-wide v0, p0, Ldev/nino/squareglass/PlayerArtwork$7;->f$0:J

    iget-wide v2, p0, Ldev/nino/squareglass/PlayerArtwork$7;->f$1:J

    check-cast p1, Landroidx/compose/ui/draw/CacheDrawScope;

    invoke-static {v0, v1, v2, v3, p1}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$xwIXK2MP9LWWP_nzv5SW2Eur3m8(JJLandroidx/compose/ui/draw/CacheDrawScope;)Landroidx/compose/ui/draw/DrawResult;

    move-result-object p0

    return-object p0
.end method
