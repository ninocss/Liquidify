.class public final synthetic Ldev/nino/squareglass/DesignEntry$12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/DesignEntry$12;->f$0:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/DesignEntry$12;->f$0:Landroid/content/Context;

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->$r8$lambda$WvOcD5j__Z_CdjzSRk3lwW9zgQc(Landroid/content/Context;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
