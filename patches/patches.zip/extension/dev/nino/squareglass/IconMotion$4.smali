.class public final synthetic Ldev/nino/squareglass/IconMotion$4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Landroidx/compose/runtime/MutableIntState;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableIntState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/IconMotion$4;->f$0:Landroidx/compose/runtime/MutableIntState;

    iput-object p2, p0, Ldev/nino/squareglass/IconMotion$4;->f$1:Landroidx/compose/runtime/MutableIntState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/IconMotion$4;->f$0:Landroidx/compose/runtime/MutableIntState;

    iget-object p0, p0, Ldev/nino/squareglass/IconMotion$4;->f$1:Landroidx/compose/runtime/MutableIntState;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/IconMotion;->$r8$lambda$6dmXf_GYDZGbWFPCaCHRfIYUv9s(Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableIntState;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
