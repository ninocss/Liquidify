.class Ldev/nino/squareglass/PlayerWindow$Snapshot$1;
.super Landroid/view/View;
.source "PlayerWindow.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/PlayerWindow$Snapshot;->view(Landroid/content/Context;Z)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final location:[I

.field final synthetic this$0:Ldev/nino/squareglass/PlayerWindow$Snapshot;

.field final synthetic val$dim:Z


# direct methods
.method constructor <init>(Ldev/nino/squareglass/PlayerWindow$Snapshot;Landroid/content/Context;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .line 53
    iput-boolean p3, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->val$dim:Z

    iput-object p1, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->this$0:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 p1, 0x2

    .line 54
    new-array p1, p1, [I

    iput-object p1, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->location:[I

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 4

    .line 56
    invoke-virtual {p1}, Landroid/graphics/Canvas;->isHardwareAccelerated()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->this$0:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    invoke-static {v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->-$$Nest$fgetnode(Ldev/nino/squareglass/PlayerWindow$Snapshot;)Landroid/graphics/RenderNode;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/RenderNode;->hasDisplayList()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 57
    iget-object v0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->location:[I

    invoke-virtual {p0, v0}, Landroid/view/View;->getLocationOnScreen([I)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 58
    iget-object v0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->this$0:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    iget v0, v0, Ldev/nino/squareglass/PlayerWindow$Snapshot;->x:I

    iget-object v1, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->location:[I

    const/4 v2, 0x0

    aget v1, v1, v2

    sub-int/2addr v0, v1

    int-to-float v0, v0

    iget-object v1, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->this$0:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    iget v1, v1, Ldev/nino/squareglass/PlayerWindow$Snapshot;->y:I

    iget-object v2, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->location:[I

    const/4 v3, 0x1

    aget v2, v2, v3

    sub-int/2addr v1, v2

    int-to-float v1, v1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    iget-object v0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->this$0:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    invoke-static {v0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->-$$Nest$fgetnode(Ldev/nino/squareglass/PlayerWindow$Snapshot;)Landroid/graphics/RenderNode;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->drawRenderNode(Landroid/graphics/RenderNode;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 59
    iget-boolean p0, p0, Ldev/nino/squareglass/PlayerWindow$Snapshot$1;->val$dim:Z

    if-eqz p0, :cond_0

    const/high16 p0, 0x55000000

    invoke-virtual {p1, p0}, Landroid/graphics/Canvas;->drawColor(I)V

    :cond_0
    return-void
.end method
