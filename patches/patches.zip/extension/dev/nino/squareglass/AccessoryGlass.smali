.class public final Ldev/nino/squareglass/AccessoryGlass;
.super Ljava/lang/Object;
.source "AccessoryGlass.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAccessoryGlass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AccessoryGlass.kt\ndev/nino/squareglass/AccessoryGlass\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n*L\n1#1,67:1\n1128#2,6:68\n1128#2,6:74\n1128#2,6:80\n113#3:86\n123#3:87\n113#3:88\n*S KotlinDebug\n*F\n+ 1 AccessoryGlass.kt\ndev/nino/squareglass/AccessoryGlass\n*L\n39#1:68,6\n46#1:74,6\n50#1:80,6\n41#1:86\n44#1:87\n49#1:88\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003JJ\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u00082\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u000c2\u001b\u0008\u0002\u0010\r\u001a\u0015\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u000e\u00a2\u0006\u0002\u0008\u0011H\u0007\u00a2\u0006\u0002\u0010\u0012\u00a8\u0006\u0013"
    }
    d2 = {
        "Ldev/nino/squareglass/AccessoryGlass;",
        "",
        "<init>",
        "()V",
        "surface",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "enabled",
        "",
        "component",
        "",
        "layer",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;ZLjava/lang/String;Lam0/l;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/AccessoryGlass;


# direct methods
.method public static synthetic $r8$lambda$MqMsh_ZI85wVvoWZR_cqRUOgdlA(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/AccessoryGlass;->surface$lambda$1$0(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fH3dRO46yz4Thcuovx-GrfCzGkg(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/AccessoryGlass;->surface$lambda$0$0(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$oT3fg31OUGyVVchbVHpK--oJs2Y()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/AccessoryGlass;->surface$lambda$2$0()Ldev/nino/squareglass/backdrop/highlight/Highlight;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$zsu06tNTeJ4cBtKUQiqtyU0_E3w(ZLjava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/AccessoryGlass;->surface$lambda$3$0(ZLjava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/AccessoryGlass;

    invoke-direct {v0}, Ldev/nino/squareglass/AccessoryGlass;-><init>()V

    sput-object v0, Ldev/nino/squareglass/AccessoryGlass;->INSTANCE:Ldev/nino/squareglass/AccessoryGlass;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final surface$lambda$0$0(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 39
    check-cast p0, Landroidx/compose/ui/graphics/Shape;

    return-object p0
.end method

.method private static final surface$lambda$1$0(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 9

    const-string v0, "$this$drawBackdrop"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    invoke-static {p0}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->vibrancy(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)V

    const/high16 v0, 0x41000000    # 8.0f

    .line 86
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 41
    invoke-interface {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0, v3, v1, v2}, Ldev/nino/squareglass/backdrop/effects/BlurKt;->blur-3YTHUZs$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FIILjava/lang/Object;)V

    .line 42
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 43
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->refraction()F

    move-result v0

    const/high16 v1, 0x41c00000    # 24.0f

    mul-float/2addr v1, v0

    .line 87
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 44
    invoke-interface {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v3

    const/high16 v1, 0x42000000    # 32.0f

    mul-float/2addr v1, v0

    .line 87
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 44
    invoke-interface {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v4

    const/16 v7, 0xc

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p0

    invoke-static/range {v2 .. v8}, Ldev/nino/squareglass/backdrop/effects/LensKt;->lens$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZILjava/lang/Object;)V

    .line 46
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final surface$lambda$2$0()Ldev/nino/squareglass/backdrop/highlight/Highlight;
    .locals 7

    .line 49
    new-instance v0, Ldev/nino/squareglass/backdrop/highlight/Highlight;

    const/high16 v1, 0x3f800000    # 1.0f

    .line 88
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    const/high16 v2, 0x40000000    # 2.0f

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    const/16 v5, 0x8

    const/4 v6, 0x0

    const v3, 0x3f4ccccd    # 0.8f

    const/4 v4, 0x0

    .line 49
    invoke-direct/range {v0 .. v6}, Ldev/nino/squareglass/backdrop/highlight/Highlight;-><init>(FFFLdev/nino/squareglass/backdrop/highlight/HighlightStyle;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private static final surface$lambda$3$0(ZLjava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 15

    move-object/from16 v0, p1

    const-string v1, "$this$drawBackdrop"

    move-object/from16 v2, p4

    invoke-static {v2, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    sget v1, Ldev/nino/squareglass/ProbeDiagnostics;->glassDraws:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Ldev/nino/squareglass/ProbeDiagnostics;->glassDraws:I

    if-eqz p0, :cond_1

    .line 53
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    .line 54
    const-string p0, "nav"

    invoke-static {v0, p0}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const-wide/16 v5, 0x0

    if-eqz p0, :cond_0

    sget-wide v7, Ldev/nino/squareglass/ProbeDiagnostics;->navFirstSampleDrawUptime:J

    cmp-long p0, v7, v5

    if-nez p0, :cond_0

    .line 55
    sput-wide v3, Ldev/nino/squareglass/ProbeDiagnostics;->navFirstSampleDrawUptime:J

    .line 56
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->navFirstSampleTraversal:I

    .line 58
    :cond_0
    const-string p0, "mini"

    invoke-static {v0, p0}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    sget-wide v0, Ldev/nino/squareglass/ProbeDiagnostics;->miniFirstSampleDrawUptime:J

    cmp-long p0, v0, v5

    if-nez p0, :cond_1

    .line 59
    sput-wide v3, Ldev/nino/squareglass/ProbeDiagnostics;->miniFirstSampleDrawUptime:J

    .line 60
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->miniFirstSampleTraversal:I

    :cond_1
    const/16 v13, 0x7e

    const/4 v14, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    move-wide/from16 v3, p2

    .line 63
    invoke-static/range {v2 .. v14}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 64
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final surface(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;ZLjava/lang/String;Lam0/l;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            "Z",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)",
            "Landroidx/compose/ui/Modifier;"
        }
    .end annotation

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v0, p4

    move-object/from16 v3, p6

    move/from16 v4, p7

    const-string v5, "original"

    invoke-static {v1, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "backdrop"

    invoke-static {v2, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "component"

    invoke-static {v0, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const v5, 0x40832cef

    .line 22
    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "C(surface)N(original,backdrop,enabled,component,layer)28@1339L4,38@2191L9,38@2212L293,45@2519L239,49@2796L751:AccessoryGlass.kt#vqphja"

    invoke-static {v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v6, p8, 0x10

    const/4 v7, 0x0

    if-eqz v6, :cond_0

    move-object v8, v7

    goto :goto_0

    :cond_0
    move-object/from16 v8, p5

    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_1

    const/4 v6, -0x1

    const-string v9, "dev.nino.squareglass.AccessoryGlass.surface (AccessoryGlass.kt:21)"

    invoke-static {v5, v4, v6, v9}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 23
    :cond_1
    sget-object v5, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v5}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 26
    instance-of v5, v2, Ldev/nino/squareglass/NativeViewBackdrop;

    if-eqz v5, :cond_2

    move-object v5, v2

    check-cast v5, Ldev/nino/squareglass/NativeViewBackdrop;

    goto :goto_1

    :cond_2
    move-object v5, v7

    :goto_1
    if-eqz v5, :cond_3

    .line 27
    invoke-virtual {v5}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    :cond_3
    const/4 v9, 0x1

    if-eqz v5, :cond_4

    .line 28
    invoke-virtual {v5}, Ldev/nino/squareglass/NativeViewBackdrop;->getHasSample()Z

    move-result v10

    if-ne v10, v9, :cond_4

    move v10, v9

    goto :goto_2

    :cond_4
    const/4 v10, 0x0

    .line 29
    :goto_2
    sget-object v11, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v12, 0x6

    invoke-virtual {v11, v3, v12}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v11

    .line 30
    invoke-static {v7, v9, v7}, Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangleKt;->ContinuousCapsule$default(Ldev/nino/squareglass/material/shapes/Continuity;ILjava/lang/Object;)Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;

    move-result-object v7

    .line 31
    const-string v12, "nav"

    invoke-static {v0, v12}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez p3, :cond_7

    .line 32
    check-cast v7, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v7}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    if-eqz v11, :cond_5

    if-nez v12, :cond_5

    move v6, v9

    goto :goto_3

    :cond_5
    const/4 v6, 0x0

    :goto_3
    invoke-static {v6}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v1

    invoke-static {v1}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 p0, v0

    move-wide/from16 p1, v1

    move/from16 p4, v4

    move-object/from16 p5, v5

    move-object/from16 p3, v6

    invoke-static/range {p0 .. p5}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 65
    :cond_6
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object v0

    :cond_7
    if-eqz v12, :cond_9

    .line 36
    sget-object v11, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v12

    if-eqz v5, :cond_8

    if-nez v10, :cond_8

    const/high16 v5, 0x3f800000    # 1.0f

    goto :goto_4

    :cond_8
    const/high16 v5, 0x3f000000    # 0.5f

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->opacity()F

    move-result v11

    invoke-static {v5, v11}, Ljava/lang/Math;->max(FF)F

    move-result v5

    :goto_4
    move v14, v5

    const/16 v18, 0xe

    const/16 v19, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-static/range {v12 .. v19}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v11

    goto :goto_6

    :cond_9
    if-eqz v5, :cond_a

    if-nez v10, :cond_a

    .line 37
    invoke-static {v11}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v5

    invoke-static {v5}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v11

    goto :goto_6

    :cond_a
    if-eqz v11, :cond_b

    const-wide v12, 0xff33343aL

    .line 38
    invoke-static {v12, v13}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v12

    goto :goto_5

    :cond_b
    sget-object v5, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v12

    :goto_5
    move-wide v14, v12

    invoke-static {v11}, Ldev/nino/squareglass/SquareSettings;->readableOpacity(Z)F

    move-result v16

    const/16 v20, 0xe

    const/16 v21, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    invoke-static/range {v14 .. v21}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v11

    :goto_6
    const v5, 0x2c6c5878

    .line 39
    const-string v13, "CC(remember):AccessoryGlass.kt#9igjgp"

    invoke-static {v3, v5, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 68
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .line 69
    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v5, v14, :cond_c

    .line 39
    new-instance v5, Ldev/nino/squareglass/AccessoryGlass$0;

    invoke-direct {v5, v7}, Ldev/nino/squareglass/AccessoryGlass$0;-><init>(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)V

    .line 71
    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 39
    :cond_c
    check-cast v5, Lam0/a;

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v7, 0x2c6c5c34

    invoke-static {v3, v7, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 68
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .line 69
    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v7, v14, :cond_d

    .line 70
    new-instance v7, Ldev/nino/squareglass/AccessoryGlass$1;

    invoke-direct {v7}, Ldev/nino/squareglass/AccessoryGlass$1;-><init>()V

    .line 71
    invoke-interface {v3, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 39
    :cond_d
    check-cast v7, Lam0/l;

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v14, 0x2c6c825e

    .line 46
    invoke-static {v3, v14, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 74
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .line 75
    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v14, v15, :cond_e

    .line 76
    new-instance v14, Ldev/nino/squareglass/AccessoryGlass$2;

    invoke-direct {v14}, Ldev/nino/squareglass/AccessoryGlass$2;-><init>()V

    .line 77
    invoke-interface {v3, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 46
    :cond_e
    check-cast v14, Lam0/a;

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v15, 0x2c6ca6fe

    .line 50
    invoke-static {v3, v15, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v13

    and-int/lit16 v15, v4, 0x1c00

    xor-int/lit16 v15, v15, 0xc00

    const/16 v6, 0x800

    if-le v15, v6, :cond_f

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_10

    :cond_f
    and-int/lit16 v4, v4, 0xc00

    if-ne v4, v6, :cond_11

    :cond_10
    move v6, v9

    goto :goto_7

    :cond_11
    const/4 v6, 0x0

    :goto_7
    or-int v4, v13, v6

    invoke-interface {v3, v11, v12}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v6

    or-int/2addr v4, v6

    .line 80
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    if-nez v4, :cond_12

    .line 81
    sget-object v4, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v4}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v6, v4, :cond_13

    .line 50
    :cond_12
    new-instance v6, Ldev/nino/squareglass/AccessoryGlass$3;

    invoke-direct {v6, v10, v0, v11, v12}, Ldev/nino/squareglass/AccessoryGlass$3;-><init>(ZLjava/lang/String;J)V

    .line 83
    invoke-interface {v3, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 50
    :cond_13
    move-object v12, v6

    check-cast v12, Lam0/l;

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v18, 0xfbb0

    const/16 v19, 0x0

    const/4 v6, 0x0

    move-object v4, v7

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    move-object v3, v5

    move-object v5, v14

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    .line 39
    invoke-static/range {v1 .. v19}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->drawBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 65
    :cond_14
    invoke-interface/range {p6 .. p6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object v0
.end method
