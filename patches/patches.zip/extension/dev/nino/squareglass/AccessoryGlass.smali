.class public final Ldev/nino/squareglass/AccessoryGlass;
.super Ljava/lang/Object;
.source "AccessoryGlass.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAccessoryGlass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AccessoryGlass.kt\ndev/nino/squareglass/AccessoryGlass\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n*L\n1#1,59:1\n1128#2,6:60\n1128#2,6:66\n113#3:72\n113#3:73\n*S KotlinDebug\n*F\n+ 1 AccessoryGlass.kt\ndev/nino/squareglass/AccessoryGlass\n*L\n38#1:60,6\n42#1:66,6\n40#1:72\n41#1:73\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003JJ\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u00082\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u000c2\u001b\u0008\u0002\u0010\r\u001a\u0015\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u000e\u00a2\u0006\u0002\u0008\u0011H\u0007\u00a2\u0006\u0002\u0010\u0012\u00a8\u0006\u0013"
    }
    d2 = {
        "Ldev/nino/squareglass/AccessoryGlass;",
        "",
        "<init>",
        "()V",
        "surface",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "backdrop",
        "Ldev/nino/squareglass/backdrop/Backdrop;",
        "enabled",
        "",
        "component",
        "",
        "layer",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
        "",
        "Lkotlin/ExtensionFunctionType;",
        "(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;ZLjava/lang/String;Lam0/l;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/AccessoryGlass;


# direct methods
.method public static synthetic $r8$lambda$MqMsh_ZI85wVvoWZR_cqRUOgdlA(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/AccessoryGlass;->surface$lambda$1$0(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fH3dRO46yz4Thcuovx-GrfCzGkg(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/AccessoryGlass;->surface$lambda$0$0(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)Landroidx/compose/ui/graphics/Shape;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tmi1IiUplOChNcKIcqmSQF09Mr0(ZLjava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/AccessoryGlass;->surface$lambda$2$0(ZLjava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/AccessoryGlass;

    invoke-direct {v0}, Ldev/nino/squareglass/AccessoryGlass;-><init>()V

    sput-object v0, Ldev/nino/squareglass/AccessoryGlass;->INSTANCE:Ldev/nino/squareglass/AccessoryGlass;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final surface$lambda$0$0(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)Landroidx/compose/ui/graphics/Shape;
    .locals 0

    .line 38
    check-cast p0, Landroidx/compose/ui/graphics/Shape;

    return-object p0
.end method

.method private static final surface$lambda$1$0(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;
    .locals 9

    const-string v0, "$this$drawBackdrop"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    invoke-static {p0}, Ldev/nino/squareglass/backdrop/effects/ColorFilterKt;->vibrancy(Ldev/nino/squareglass/backdrop/BackdropEffectScope;)V

    const/high16 v0, 0x41000000    # 8.0f

    .line 72
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 40
    invoke-interface {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0, v3, v1, v2}, Ldev/nino/squareglass/backdrop/effects/BlurKt;->blur-3YTHUZs$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FIILjava/lang/Object;)V

    .line 41
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v0

    if-eqz v0, :cond_0

    const/high16 v0, 0x41c00000    # 24.0f

    .line 73
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 41
    invoke-interface {p0, v1}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v3

    .line 73
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 41
    invoke-interface {p0, v0}, Ldev/nino/squareglass/backdrop/BackdropEffectScope;->toPx-0680j_4(F)F

    move-result v4

    const/16 v7, 0xc

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p0

    invoke-static/range {v2 .. v8}, Ldev/nino/squareglass/backdrop/effects/LensKt;->lens$default(Ldev/nino/squareglass/backdrop/BackdropEffectScope;FFZZILjava/lang/Object;)V

    .line 42
    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final surface$lambda$2$0(ZLjava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/u;
    .locals 15

    move-object/from16 v0, p1

    const-string v1, "$this$drawBackdrop"

    move-object/from16 v2, p4

    invoke-static {v2, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    sget v1, Ldev/nino/squareglass/ProbeDiagnostics;->glassDraws:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Ldev/nino/squareglass/ProbeDiagnostics;->glassDraws:I

    if-eqz p0, :cond_1

    .line 45
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    .line 46
    const-string p0, "nav"

    invoke-static {v0, p0}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const-wide/16 v5, 0x0

    if-eqz p0, :cond_0

    sget-wide v7, Ldev/nino/squareglass/ProbeDiagnostics;->navFirstSampleDrawUptime:J

    cmp-long p0, v7, v5

    if-nez p0, :cond_0

    .line 47
    sput-wide v3, Ldev/nino/squareglass/ProbeDiagnostics;->navFirstSampleDrawUptime:J

    .line 48
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->navFirstSampleTraversal:I

    .line 50
    :cond_0
    const-string p0, "mini"

    invoke-static {v0, p0}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    sget-wide v0, Ldev/nino/squareglass/ProbeDiagnostics;->miniFirstSampleDrawUptime:J

    cmp-long p0, v0, v5

    if-nez p0, :cond_1

    .line 51
    sput-wide v3, Ldev/nino/squareglass/ProbeDiagnostics;->miniFirstSampleDrawUptime:J

    .line 52
    sget p0, Ldev/nino/squareglass/ProbeDiagnostics;->nativeDrawTraversals:I

    sput p0, Ldev/nino/squareglass/ProbeDiagnostics;->miniFirstSampleTraversal:I

    :cond_1
    const/16 v13, 0x7e

    const/4 v14, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    move-wide/from16 v3, p2

    .line 55
    invoke-static/range {v2 .. v14}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 56
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final surface(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;ZLjava/lang/String;Lam0/l;Landroidx/compose/runtime/Composer;II)Landroidx/compose/ui/Modifier;
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Ldev/nino/squareglass/backdrop/Backdrop;",
            "Z",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroidx/compose/ui/graphics/GraphicsLayerScope;",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)",
            "Landroidx/compose/ui/Modifier;"
        }
    .end annotation

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v0, p4

    move-object/from16 v3, p6

    move/from16 v4, p7

    const-string v5, "original"

    invoke-static {v1, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "backdrop"

    invoke-static {v2, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "component"

    invoke-static {v0, v5}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const v5, 0x40832cef

    .line 21
    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "C(surface)N(original,backdrop,enabled,component,layer)27@1282L4,37@2134L9,37@2155L169,41@2362L751:AccessoryGlass.kt#vqphja"

    invoke-static {v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v6, p8, 0x10

    const/4 v7, 0x0

    if-eqz v6, :cond_0

    move-object v8, v7

    goto :goto_0

    :cond_0
    move-object/from16 v8, p5

    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_1

    const/4 v6, -0x1

    const-string v9, "dev.nino.squareglass.AccessoryGlass.surface (AccessoryGlass.kt:20)"

    invoke-static {v5, v4, v6, v9}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 22
    :cond_1
    sget-object v5, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v5}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 25
    instance-of v5, v2, Ldev/nino/squareglass/NativeViewBackdrop;

    if-eqz v5, :cond_2

    move-object v5, v2

    check-cast v5, Ldev/nino/squareglass/NativeViewBackdrop;

    goto :goto_1

    :cond_2
    move-object v5, v7

    :goto_1
    if-eqz v5, :cond_3

    .line 26
    invoke-virtual {v5}, Ldev/nino/squareglass/NativeViewBackdrop;->getHandoverVersion()I

    :cond_3
    const/4 v6, 0x0

    const/4 v9, 0x1

    if-eqz v5, :cond_4

    .line 27
    invoke-virtual {v5}, Ldev/nino/squareglass/NativeViewBackdrop;->getHasSample()Z

    move-result v10

    if-ne v10, v9, :cond_4

    move v10, v9

    goto :goto_2

    :cond_4
    move v10, v6

    .line 28
    :goto_2
    sget-object v11, Ldev/nino/squareglass/NativeGlass;->INSTANCE:Ldev/nino/squareglass/NativeGlass;

    const/4 v12, 0x6

    invoke-virtual {v11, v3, v12}, Ldev/nino/squareglass/NativeGlass;->getDark(Landroidx/compose/runtime/Composer;I)Z

    move-result v11

    .line 29
    invoke-static {v7, v9, v7}, Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangleKt;->ContinuousCapsule$default(Ldev/nino/squareglass/material/shapes/Continuity;ILjava/lang/Object;)Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;

    move-result-object v7

    .line 30
    const-string v12, "nav"

    invoke-static {v0, v12}, Ldev/nino/squareglass/HostCompat;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez p3, :cond_7

    .line 31
    check-cast v7, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v7}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    if-eqz v11, :cond_5

    if-nez v12, :cond_5

    move v6, v9

    :cond_5
    invoke-static {v6}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v1

    invoke-static {v1}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 p0, v0

    move-wide/from16 p1, v1

    move/from16 p4, v4

    move-object/from16 p5, v5

    move-object/from16 p3, v6

    invoke-static/range {p0 .. p5}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 57
    :cond_6
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object v0

    :cond_7
    if-eqz v12, :cond_9

    .line 35
    sget-object v11, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v12

    if-eqz v5, :cond_8

    if-nez v10, :cond_8

    const/high16 v5, 0x3f800000    # 1.0f

    goto :goto_3

    :cond_8
    const/high16 v5, 0x3f000000    # 0.5f

    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->opacity()F

    move-result v11

    invoke-static {v5, v11}, Ljava/lang/Math;->max(FF)F

    move-result v5

    :goto_3
    move v14, v5

    const/16 v18, 0xe

    const/16 v19, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-static/range {v12 .. v19}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v11

    goto :goto_5

    :cond_9
    if-eqz v5, :cond_a

    if-nez v10, :cond_a

    .line 36
    invoke-static {v11}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v5

    invoke-static {v5}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v11

    goto :goto_5

    :cond_a
    if-eqz v11, :cond_b

    const-wide v12, 0xff33343aL

    .line 37
    invoke-static {v12, v13}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v12

    goto :goto_4

    :cond_b
    sget-object v5, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v12

    :goto_4
    move-wide v14, v12

    invoke-static {v11}, Ldev/nino/squareglass/SquareSettings;->readableOpacity(Z)F

    move-result v16

    const/16 v20, 0xe

    const/16 v21, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    invoke-static/range {v14 .. v21}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v11

    :goto_5
    const v5, 0x2c6c5878

    .line 38
    const-string v13, "CC(remember):AccessoryGlass.kt#9igjgp"

    invoke-static {v3, v5, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 60
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .line 61
    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v5, v14, :cond_c

    .line 38
    new-instance v5, Ldev/nino/squareglass/AccessoryGlass$0;

    invoke-direct {v5, v7}, Ldev/nino/squareglass/AccessoryGlass$0;-><init>(Ldev/nino/squareglass/material/shapes/ContinuousRoundedRectangle;)V

    .line 63
    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 38
    :cond_c
    check-cast v5, Lam0/a;

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v7, 0x2c6c5bb8

    invoke-static {v3, v7, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 60
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .line 61
    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v7, v14, :cond_d

    .line 62
    new-instance v7, Ldev/nino/squareglass/AccessoryGlass$1;

    invoke-direct {v7}, Ldev/nino/squareglass/AccessoryGlass$1;-><init>()V

    .line 63
    invoke-interface {v3, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 38
    :cond_d
    check-cast v7, Lam0/l;

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v14, 0x2c6c77de

    .line 42
    invoke-static {v3, v14, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v13

    and-int/lit16 v14, v4, 0x1c00

    xor-int/lit16 v14, v14, 0xc00

    const/16 v15, 0x800

    if-le v14, v15, :cond_e

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_f

    :cond_e
    and-int/lit16 v4, v4, 0xc00

    if-ne v4, v15, :cond_10

    :cond_f
    move v6, v9

    :cond_10
    or-int v4, v13, v6

    invoke-interface {v3, v11, v12}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v6

    or-int/2addr v4, v6

    .line 66
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    if-nez v4, :cond_11

    .line 67
    sget-object v4, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v4}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v6, v4, :cond_12

    .line 42
    :cond_11
    new-instance v6, Ldev/nino/squareglass/AccessoryGlass$2;

    invoke-direct {v6, v10, v0, v11, v12}, Ldev/nino/squareglass/AccessoryGlass$2;-><init>(ZLjava/lang/String;J)V

    .line 69
    invoke-interface {v3, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 42
    :cond_12
    move-object v12, v6

    check-cast v12, Lam0/l;

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v18, 0xfbb8

    const/16 v19, 0x0

    move-object v3, v5

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v4, v7

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    .line 38
    invoke-static/range {v1 .. v19}, Ldev/nino/squareglass/backdrop/DrawBackdropModifierKt;->drawBackdrop$default(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/backdrop/Backdrop;Lam0/a;Lam0/l;Lam0/a;Lam0/a;Lam0/a;Lam0/l;Ldev/nino/squareglass/backdrop/backdrops/LayerBackdrop;Lam0/l;Lam0/p;Lam0/l;Lam0/l;FLam0/a;Lam0/a;Lam0/a;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 57
    :cond_13
    invoke-interface/range {p6 .. p6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object v0
.end method
