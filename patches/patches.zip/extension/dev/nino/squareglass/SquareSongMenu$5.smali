.class public final synthetic Ldev/nino/squareglass/SquareSongMenu$5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/SquareSongMenu;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/SquareSongMenu;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareSongMenu$5;->f$0:Ldev/nino/squareglass/SquareSongMenu;

    return-void
.end method


# virtual methods
.method public final onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/SquareSongMenu$5;->f$0:Ldev/nino/squareglass/SquareSongMenu;

    invoke-static/range {p0 .. p9}, Ldev/nino/squareglass/SquareSongMenu;->$r8$lambda$_FlMTZRsj7jE5PVD5W8JQ34smzs(Ldev/nino/squareglass/SquareSongMenu;Landroid/view/View;IIIIIIII)V

    return-void
.end method
