.class final Ldev/nino/squareglass/SquareDetails$CoverFade;
.super Landroid/graphics/drawable/Drawable;
.source "SquareDetails.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareDetails;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "CoverFade"
.end annotation


# instance fields
.field final paint:Landroid/graphics/Paint;

.field final surface:I


# direct methods
.method constructor <init>(I)V
    .locals 2

    .line 441
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 440
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;->paint:Landroid/graphics/Paint;

    .line 441
    iput p1, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;->surface:I

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 1

    .line 449
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    iget-object p0, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, p0}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    return-void
.end method

.method public getOpacity()I
    .locals 0

    const/4 p0, -0x3

    return p0
.end method

.method protected onBoundsChange(Landroid/graphics/Rect;)V
    .locals 12

    .line 443
    iget v0, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;->surface:I

    const v1, 0xffffff

    and-int v3, v0, v1

    .line 444
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;->paint:Landroid/graphics/Paint;

    new-instance v1, Landroid/graphics/LinearGradient;

    iget v2, p1, Landroid/graphics/Rect;->top:I

    int-to-float v8, v2

    iget v2, p1, Landroid/graphics/Rect;->top:I

    add-int/lit8 v2, v2, 0x1

    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    invoke-static {v2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    int-to-float p1, p1

    const/high16 v2, -0x39000000    # -32768.0f

    or-int/2addr v2, v3

    const/high16 v4, 0x3d000000    # 0.03125f

    or-int v5, v3, v4

    const/high16 v4, -0x3e000000    # -32.0f

    or-int v6, v3, v4

    iget v7, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;->surface:I

    move v4, v3

    filled-new-array/range {v2 .. v7}, [I

    move-result-object v9

    const/4 p0, 0x6

    new-array v10, p0, [F

    fill-array-data v10, :array_0

    sget-object v11, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v5, 0x0

    const/4 v7, 0x0

    move-object v4, v1

    move v6, v8

    move v8, p1

    invoke-direct/range {v4 .. v11}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3e4ccccd    # 0.2f
        0x3f0f5c29    # 0.56f
        0x3f3d70a4    # 0.74f
        0x3f666666    # 0.9f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public setAlpha(I)V
    .locals 1

    .line 451
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 1

    .line 452
    iget-object v0, p0, Ldev/nino/squareglass/SquareDetails$CoverFade;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method
