.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Landroidx/compose/runtime/State;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/runtime/State;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$0;->f$0:Landroidx/compose/runtime/State;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/PlayerArtwork$0;->f$0:Landroidx/compose/runtime/State;

    invoke-static {p0}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$28Ara-CWK-qb1Y7xt16TMnI9F94(Landroidx/compose/runtime/State;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
