.class public final Ldev/nino/squareglass/PlaylistSortMenu;
.super Landroid/app/Dialog;
.source "PlaylistSortMenu.java"


# instance fields
.field private chosen:Z

.field private glass:Ldev/nino/squareglass/LiquidMenuSurface;

.field private final options:[Ljava/lang/String;

.field private final owner:Landroidx/fragment/app/DialogFragment;

.field private scroll:Landroid/widget/ScrollView;

.field private final selected:I

.field private shell:Landroid/widget/FrameLayout;


# direct methods
.method public static synthetic $r8$lambda$2divTsf9aAibFx0sGESv_CMft3o(Ldev/nino/squareglass/PlaylistSortMenu;ILandroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ldev/nino/squareglass/PlaylistSortMenu;->lambda$onCreate$0(ILandroid/view/View;)V

    return-void
.end method

.method private constructor <init>(Landroid/app/Activity;Landroidx/fragment/app/DialogFragment;[Ljava/lang/String;I)V
    .locals 0

    .line 31
    invoke-direct {p0, p1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setOwnerActivity(Landroid/app/Activity;)V

    .line 32
    iput-object p2, p0, Ldev/nino/squareglass/PlaylistSortMenu;->owner:Landroidx/fragment/app/DialogFragment;

    iput-object p3, p0, Ldev/nino/squareglass/PlaylistSortMenu;->options:[Ljava/lang/String;

    iput p4, p0, Ldev/nino/squareglass/PlaylistSortMenu;->selected:I

    const/4 p1, 0x1

    .line 33
    invoke-virtual {p0, p1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    return-void
.end method

.method public static create(Landroidx/fragment/app/DialogFragment;Landroid/app/Dialog;[Ljava/lang/String;I)Landroid/app/Dialog;
    .locals 2

    .line 36
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 37
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v1

    if-eqz v1, :cond_2

    const-string v1, "jj.a"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "jj.b"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_0
    instance-of v0, p0, Landroid/content/DialogInterface$OnClickListener;

    if-eqz v0, :cond_2

    .line 38
    invoke-virtual {p0}, Landroidx/fragment/app/DialogFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    if-eqz v0, :cond_2

    if-nez p2, :cond_1

    goto :goto_0

    .line 39
    :cond_1
    new-instance p1, Ldev/nino/squareglass/PlaylistSortMenu;

    invoke-virtual {p0}, Landroidx/fragment/app/DialogFragment;->requireActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    invoke-virtual {p2}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [Ljava/lang/String;

    invoke-direct {p1, v0, p0, p2, p3}, Ldev/nino/squareglass/PlaylistSortMenu;-><init>(Landroid/app/Activity;Landroidx/fragment/app/DialogFragment;[Ljava/lang/String;I)V

    :cond_2
    :goto_0
    return-object p1
.end method

.method private dp(I)I
    .locals 0

    int-to-float p1, p1

    .line 41
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method private synthetic lambda$onCreate$0(ILandroid/view/View;)V
    .locals 0

    .line 57
    iget-boolean p2, p0, Ldev/nino/squareglass/PlaylistSortMenu;->chosen:Z

    if-eqz p2, :cond_0

    return-void

    :cond_0
    const/4 p2, 0x1

    iput-boolean p2, p0, Ldev/nino/squareglass/PlaylistSortMenu;->chosen:Z

    .line 58
    iget-object p2, p0, Ldev/nino/squareglass/PlaylistSortMenu;->owner:Landroidx/fragment/app/DialogFragment;

    check-cast p2, Landroid/content/DialogInterface$OnClickListener;

    invoke-interface {p2, p0, p1}, Landroid/content/DialogInterface$OnClickListener;->onClick(Landroid/content/DialogInterface;I)V

    .line 59
    invoke-virtual {p0}, Ldev/nino/squareglass/PlaylistSortMenu;->dismiss()V

    return-void
.end method


# virtual methods
.method public dismiss()V
    .locals 1

    .line 96
    invoke-super {p0}, Landroid/app/Dialog;->dismiss()V

    iget-object v0, p0, Ldev/nino/squareglass/PlaylistSortMenu;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ldev/nino/squareglass/LiquidMenuSurface;->release()V

    const/4 v0, 0x0

    iput-object v0, p0, Ldev/nino/squareglass/PlaylistSortMenu;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 11

    .line 43
    invoke-super {p0, p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    .line 44
    new-instance p1, Landroid/widget/FrameLayout;

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Ldev/nino/squareglass/PlaylistSortMenu;->shell:Landroid/widget/FrameLayout;

    .line 45
    new-instance p1, Landroid/widget/ScrollView;

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Ldev/nino/squareglass/PlaylistSortMenu;->scroll:Landroid/widget/ScrollView;

    .line 46
    new-instance p1, Landroid/widget/LinearLayout;

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v1, 0x8

    .line 47
    invoke-direct {p0, v1}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v2

    invoke-direct {p0, v1}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v3

    invoke-direct {p0, v1}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v4

    invoke-direct {p0, v1}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v1

    invoke-virtual {p1, v2, v3, v4, v1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 48
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    const/4 v2, 0x0

    move v3, v2

    .line 49
    :goto_0
    iget-object v4, p0, Ldev/nino/squareglass/PlaylistSortMenu;->options:[Ljava/lang/String;

    array-length v4, v4

    const/4 v5, -0x2

    const/4 v6, -0x1

    if-ge v3, v4, :cond_1

    .line 51
    new-instance v4, Landroid/widget/CheckedTextView;

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-direct {v4, v7}, Landroid/widget/CheckedTextView;-><init>(Landroid/content/Context;)V

    iget-object v7, p0, Ldev/nino/squareglass/PlaylistSortMenu;->options:[Ljava/lang/String;

    aget-object v7, v7, v3

    invoke-virtual {v4, v7}, Landroid/widget/CheckedTextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v7, 0x41800000    # 16.0f

    .line 52
    invoke-virtual {v4, v7}, Landroid/widget/CheckedTextView;->setTextSize(F)V

    invoke-virtual {v4, v1}, Landroid/widget/CheckedTextView;->setTextColor(I)V

    const/16 v7, 0x10

    invoke-virtual {v4, v7}, Landroid/widget/CheckedTextView;->setGravity(I)V

    .line 53
    invoke-direct {p0, v7}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v8

    const/16 v9, 0xe

    invoke-direct {p0, v9}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v10

    invoke-direct {p0, v7}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v7

    invoke-direct {p0, v9}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v9

    invoke-virtual {v4, v8, v10, v7, v9}, Landroid/widget/CheckedTextView;->setPaddingRelative(IIII)V

    const/16 v7, 0x34

    invoke-direct {p0, v7}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v7

    invoke-virtual {v4, v7}, Landroid/widget/CheckedTextView;->setMinHeight(I)V

    const v7, 0x1080009

    .line 54
    invoke-virtual {v4, v7}, Landroid/widget/CheckedTextView;->setCheckMarkDrawable(I)V

    .line 55
    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    invoke-virtual {v4, v7}, Landroid/widget/CheckedTextView;->setCheckMarkTintList(Landroid/content/res/ColorStateList;)V

    iget v7, p0, Ldev/nino/squareglass/PlaylistSortMenu;->selected:I

    if-ne v3, v7, :cond_0

    move v7, v0

    goto :goto_1

    :cond_0
    move v7, v2

    :goto_1
    invoke-virtual {v4, v7}, Landroid/widget/CheckedTextView;->setChecked(Z)V

    .line 56
    new-instance v7, Ldev/nino/squareglass/PlaylistSortMenu$0;

    invoke-direct {v7, p0, v3}, Ldev/nino/squareglass/PlaylistSortMenu$0;-><init>(Ldev/nino/squareglass/PlaylistSortMenu;I)V

    invoke-virtual {v4, v7}, Landroid/widget/CheckedTextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 61
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v4, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 63
    :cond_1
    iget-object v0, p0, Ldev/nino/squareglass/PlaylistSortMenu;->scroll:Landroid/widget/ScrollView;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v6, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, v1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 64
    new-instance p1, Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-virtual {p0}, Landroid/app/Dialog;->getOwnerActivity()Landroid/app/Activity;

    move-result-object v0

    const/4 v1, 0x0

    invoke-direct {p1, v0, v1}, Ldev/nino/squareglass/LiquidMenuSurface;-><init>(Landroid/app/Activity;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V

    iput-object p1, p0, Ldev/nino/squareglass/PlaylistSortMenu;->glass:Ldev/nino/squareglass/LiquidMenuSurface;

    iget-object v0, p0, Ldev/nino/squareglass/PlaylistSortMenu;->shell:Landroid/widget/FrameLayout;

    const/high16 v1, 0x41c00000    # 24.0f

    invoke-virtual {p1, v0, v1, v2}, Ldev/nino/squareglass/LiquidMenuSurface;->paint(Landroid/widget/FrameLayout;FZ)V

    .line 65
    iget-object p1, p0, Ldev/nino/squareglass/PlaylistSortMenu;->shell:Landroid/widget/FrameLayout;

    iget-object v0, p0, Ldev/nino/squareglass/PlaylistSortMenu;->scroll:Landroid/widget/ScrollView;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v6, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v0, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p1, p0, Ldev/nino/squareglass/PlaylistSortMenu;->shell:Landroid/widget/FrameLayout;

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 66
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_2

    .line 68
    new-instance p1, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {p1, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {p0, p1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 p1, 0x2

    .line 69
    invoke-virtual {p0, p1}, Landroid/view/Window;->clearFlags(I)V

    const/16 p1, 0x30

    .line 70
    invoke-virtual {p0, p1}, Landroid/view/Window;->setSoftInputMode(I)V

    :cond_2
    return-void
.end method

.method protected onStart()V
    .locals 11

    .line 74
    invoke-super {p0}, Landroid/app/Dialog;->onStart()V

    .line 75
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p0}, Landroid/app/Dialog;->getOwnerActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    const/16 v1, 0x140

    .line 76
    invoke-direct {p0, v1}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v1

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v2

    const/16 v3, 0x18

    invoke-direct {p0, v3}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v4

    sub-int/2addr v2, v4

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/16 v2, 0x230

    .line 77
    invoke-direct {p0, v2}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v2

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v4

    invoke-direct {p0, v3}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v5

    sub-int/2addr v4, v5

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    .line 81
    iget-object v4, p0, Ldev/nino/squareglass/PlaylistSortMenu;->scroll:Landroid/widget/ScrollView;

    const/high16 v5, 0x40000000    # 2.0f

    invoke-static {v1, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    const/high16 v6, -0x80000000

    .line 82
    invoke-static {v2, v6}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    .line 81
    invoke-virtual {v4, v5, v6}, Landroid/widget/ScrollView;->measure(II)V

    .line 83
    iget-object v4, p0, Ldev/nino/squareglass/PlaylistSortMenu;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v4}, Landroid/widget/ScrollView;->getMeasuredHeight()I

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    .line 84
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    if-nez v4, :cond_0

    return-void

    .line 85
    :cond_0
    invoke-virtual {v4, v1, v2}, Landroid/view/Window;->setLayout(II)V

    .line 86
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    const-string v7, "action_sort"

    const-string v8, "id"

    invoke-virtual {v5, v7, v8, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v5

    .line 87
    invoke-virtual {p0}, Landroid/app/Dialog;->getOwnerActivity()Landroid/app/Activity;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v5

    const/4 v6, 0x2

    .line 88
    new-array v6, v6, [I

    iget v7, v0, Landroid/graphics/Rect;->right:I

    invoke-direct {p0, v3}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v3

    sub-int/2addr v7, v3

    const/4 v3, 0x0

    aput v7, v6, v3

    iget v7, v0, Landroid/graphics/Rect;->top:I

    const/16 v8, 0x38

    invoke-direct {p0, v8}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v8

    add-int/2addr v7, v8

    const/4 v8, 0x1

    aput v7, v6, v8

    if-eqz v5, :cond_1

    .line 89
    invoke-virtual {v5, v6}, Landroid/view/View;->getLocationOnScreen([I)V

    aget v7, v6, v8

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result v9

    add-int/2addr v7, v9

    aput v7, v6, v8

    aget v7, v6, v3

    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result v5

    add-int/2addr v7, v5

    aput v7, v6, v3

    .line 90
    :cond_1
    invoke-virtual {v4}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v5

    const/16 v7, 0x33

    iput v7, v5, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 91
    iget v7, v0, Landroid/graphics/Rect;->left:I

    const/16 v9, 0xc

    invoke-direct {p0, v9}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v10

    add-int/2addr v7, v10

    aget v3, v6, v3

    sub-int/2addr v3, v1

    iget v10, v0, Landroid/graphics/Rect;->right:I

    sub-int/2addr v10, v1

    invoke-direct {p0, v9}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v1

    sub-int/2addr v10, v1

    invoke-static {v3, v10}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v5, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 92
    invoke-direct {p0, v9}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v1

    aget v3, v6, v8

    iget v6, v0, Landroid/graphics/Rect;->top:I

    sub-int/2addr v3, v6

    const/16 v6, 0x8

    invoke-direct {p0, v6}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result v6

    add-int/2addr v3, v6

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    sub-int/2addr v0, v2

    invoke-direct {p0, v9}, Ldev/nino/squareglass/PlaylistSortMenu;->dp(I)I

    move-result p0

    sub-int/2addr v0, p0

    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    move-result p0

    invoke-static {v1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    iput p0, v5, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 93
    invoke-virtual {v4, v5}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    return-void
.end method
