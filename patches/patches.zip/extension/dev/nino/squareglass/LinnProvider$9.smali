.class public final synthetic Ldev/nino/squareglass/LinnProvider$9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Function;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lp2/a;

    invoke-static {p1}, Ldev/nino/squareglass/LinnProvider;->lambda$snapshot$1(Lp2/a;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
