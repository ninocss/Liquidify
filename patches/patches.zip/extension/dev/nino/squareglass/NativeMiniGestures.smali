.class public final Ldev/nino/squareglass/NativeMiniGestures;
.super Ljava/lang/Object;
.source "NativeMiniGestures.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeMiniGestures.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeMiniGestures.kt\ndev/nino/squareglass/NativeMiniGestures\n+ 2 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 5 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 6 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,69:1\n75#2:70\n1#3:71\n113#4:72\n113#4:73\n113#4:74\n1128#5,6:75\n1128#5,6:81\n85#6:87\n*S KotlinDebug\n*F\n+ 1 NativeMiniGestures.kt\ndev/nino/squareglass/NativeMiniGestures\n*L\n24#1:70\n25#1:72\n26#1:73\n27#1:74\n31#1:75,6\n36#1:81,6\n23#1:87\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0003\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0008\u0010\u0004\u001a\u00020\u0005H\u0007J#\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\u00072\u000c\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\nH\u0007\u00a2\u0006\u0002\u0010\u000c\u00a8\u0006\r\u00b2\u0006\u0010\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\nX\u008a\u0084\u0002"
    }
    d2 = {
        "Ldev/nino/squareglass/NativeMiniGestures;",
        "",
        "<init>",
        "()V",
        "showSkip",
        "",
        "decorate",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "openPlayer",
        "Lkotlin/Function0;",
        "",
        "(Landroidx/compose/ui/Modifier;Lam0/a;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "extension_debug",
        "open"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/NativeMiniGestures;


# direct methods
.method public static synthetic $r8$lambda$BWOeKSbIaOqDipi7fdcEWiuQjYQ(Landroidx/compose/runtime/State;)Z
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/NativeMiniGestures;->decorate$lambda$4$0$0(Landroidx/compose/runtime/State;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$JbTl6TAc6aP9JCSb9TBpE3Yjj6E()Z
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/NativeMiniGestures;->decorate$lambda$4$0$1()Z

    move-result v0

    return v0
.end method

.method public static synthetic $r8$lambda$NgJdNbQnWuhcmEBUV3QvMFSARR4(Landroidx/compose/runtime/State;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeMiniGestures;->decorate$lambda$4$0(Landroidx/compose/runtime/State;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$zGHX8psWRk5qgub32twkdWoGV6E()Z
    .locals 1

    invoke-static {}, Ldev/nino/squareglass/NativeMiniGestures;->decorate$lambda$4$0$2()Z

    move-result v0

    return v0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/NativeMiniGestures;

    invoke-direct {v0}, Ldev/nino/squareglass/NativeMiniGestures;-><init>()V

    sput-object v0, Ldev/nino/squareglass/NativeMiniGestures;->INSTANCE:Ldev/nino/squareglass/NativeMiniGestures;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$decorate$lambda$0(Landroidx/compose/runtime/State;)Lam0/a;
    .locals 0

    .line 17
    invoke-static {p0}, Ldev/nino/squareglass/NativeMiniGestures;->decorate$lambda$0(Landroidx/compose/runtime/State;)Lam0/a;

    move-result-object p0

    return-object p0
.end method

.method public static final decorate(Landroidx/compose/ui/Modifier;Lam0/a;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)",
            "Landroidx/compose/ui/Modifier;"
        }
    .end annotation

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "openPlayer"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const v0, -0x60da996d

    .line 20
    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "C(decorate)N(original,openPlayer)22@1001L32,23@1067L7,30@1517L311,35@1869L1957:NativeMiniGestures.kt#vqphja"

    invoke-static {p2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, -0x1

    const-string v2, "dev.nino.squareglass.NativeMiniGestures.decorate (NativeMiniGestures.kt:19)"

    invoke-static {v0, p3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 21
    :cond_0
    sget-object v0, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v0}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 22
    const-string v0, "miniGestures"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 67
    :cond_1
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object p0

    :cond_2
    shr-int/lit8 p3, p3, 0x3

    and-int/lit8 p3, p3, 0xe

    .line 23
    invoke-static {p1, p2, p3}, Landroidx/compose/runtime/SnapshotStateKt;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/State;

    move-result-object p1

    .line 24
    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalDensity()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object p3

    check-cast p3, Landroidx/compose/runtime/CompositionLocal;

    const v0, 0x789c5f52

    const-string v2, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    .line 70
    invoke-static {p2, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p2, p3}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object p3

    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 24
    check-cast p3, Landroidx/compose/ui/unit/Density;

    const/16 v0, 0x1c

    int-to-float v0, v0

    .line 72
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 25
    invoke-interface {p3, v0}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    move-result v0

    const/16 v2, 0x30

    int-to-float v2, v2

    .line 73
    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 26
    invoke-interface {p3, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    move-result v2

    const/16 v3, 0x258

    int-to-float v3, v3

    .line 74
    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 27
    invoke-interface {p3, v3}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    move-result p3

    const v3, 0x6b6666aa

    .line 31
    const-string v4, "CC(remember):NativeMiniGestures.kt#9igjgp"

    invoke-static {p2, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    .line 75
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    if-nez v3, :cond_3

    .line 76
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v5, v3, :cond_4

    .line 31
    :cond_3
    new-instance v5, Ldev/nino/squareglass/NativeMiniGestures$$ExternalSyntheticLambda0;

    invoke-direct {v5, p1}, Ldev/nino/squareglass/NativeMiniGestures$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/runtime/State;)V

    .line 78
    invoke-interface {p2, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 31
    :cond_4
    check-cast v5, Lam0/l;

    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v3, 0x0

    const/4 v6, 0x0

    invoke-static {p0, v6, v5, v1, v3}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLam0/l;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    .line 36
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    const v5, 0x6b669918

    invoke-static {p2, v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v4

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v4, v5

    invoke-interface {p2, p3}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v5

    or-int/2addr v4, v5

    invoke-interface {p2, v2}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v5

    or-int/2addr v4, v5

    .line 81
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    if-nez v4, :cond_5

    .line 82
    sget-object v4, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v4}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v5, v4, :cond_6

    .line 36
    :cond_5
    new-instance v4, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;

    invoke-direct {v4, v0, p3, v2, p1}, Ldev/nino/squareglass/NativeMiniGestures$decorate$2$1;-><init>(FFFLandroidx/compose/runtime/State;)V

    move-object v5, v4

    check-cast v5, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 84
    invoke-interface {p2, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 36
    :cond_6
    check-cast v5, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {p0, v1, v3, v5}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 67
    :cond_7
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    return-object p0
.end method

.method private static final decorate$lambda$0(Landroidx/compose/runtime/State;)Lam0/a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "+",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;>;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    .line 87
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lam0/a;

    return-object p0
.end method

.method private static final decorate$lambda$4$0(Landroidx/compose/runtime/State;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/u;
    .locals 3

    const-string v0, "$this$semantics"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x3

    .line 33
    new-array v0, v0, [Landroidx/compose/ui/semantics/CustomAccessibilityAction;

    new-instance v1, Landroidx/compose/ui/semantics/CustomAccessibilityAction;

    .line 32
    new-instance v2, Ldev/nino/squareglass/NativeMiniGestures$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Ldev/nino/squareglass/NativeMiniGestures$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/runtime/State;)V

    .line 33
    const-string p0, "Open player"

    invoke-direct {v1, p0, v2}, Landroidx/compose/ui/semantics/CustomAccessibilityAction;-><init>(Ljava/lang/String;Lam0/a;)V

    const/4 p0, 0x0

    aput-object v1, v0, p0

    .line 34
    new-instance p0, Landroidx/compose/ui/semantics/CustomAccessibilityAction;

    new-instance v1, Ldev/nino/squareglass/NativeMiniGestures$$ExternalSyntheticLambda2;

    invoke-direct {v1}, Ldev/nino/squareglass/NativeMiniGestures$$ExternalSyntheticLambda2;-><init>()V

    const-string v2, "Next track"

    invoke-direct {p0, v2, v1}, Landroidx/compose/ui/semantics/CustomAccessibilityAction;-><init>(Ljava/lang/String;Lam0/a;)V

    const/4 v1, 0x1

    aput-object p0, v0, v1

    .line 35
    new-instance p0, Landroidx/compose/ui/semantics/CustomAccessibilityAction;

    new-instance v1, Ldev/nino/squareglass/NativeMiniGestures$$ExternalSyntheticLambda3;

    invoke-direct {v1}, Ldev/nino/squareglass/NativeMiniGestures$$ExternalSyntheticLambda3;-><init>()V

    const-string v2, "Previous track"

    invoke-direct {p0, v2, v1}, Landroidx/compose/ui/semantics/CustomAccessibilityAction;-><init>(Ljava/lang/String;Lam0/a;)V

    const/4 v1, 0x2

    aput-object p0, v0, v1

    .line 32
    invoke-static {v0}, Ldev/nino/squareglass/HostCompat;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setCustomActions(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/util/List;)V

    .line 36
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final decorate$lambda$4$0$0(Landroidx/compose/runtime/State;)Z
    .locals 0

    .line 33
    invoke-static {p0}, Ldev/nino/squareglass/NativeMiniGestures;->decorate$lambda$0(Landroidx/compose/runtime/State;)Lam0/a;

    move-result-object p0

    invoke-interface {p0}, Lam0/a;->invoke()Ljava/lang/Object;

    const/4 p0, 0x1

    return p0
.end method

.method private static final decorate$lambda$4$0$1()Z
    .locals 1

    const/4 v0, 0x0

    .line 34
    invoke-static {v0}, Ldev/nino/squareglass/NativePlayback;->next(Z)V

    const/4 v0, 0x1

    return v0
.end method

.method private static final decorate$lambda$4$0$2()Z
    .locals 1

    const/4 v0, 0x1

    .line 35
    invoke-static {v0}, Ldev/nino/squareglass/NativePlayback;->next(Z)V

    return v0
.end method

.method public static final showSkip()Z
    .locals 2

    .line 18
    const-string v0, "miniGestures"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result v0

    xor-int/2addr v0, v1

    return v0
.end method
