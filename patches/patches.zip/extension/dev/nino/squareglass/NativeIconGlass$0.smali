.class public final synthetic Ldev/nino/squareglass/NativeIconGlass$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/NativeIconGlass$State;

.field public final synthetic f$1:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/NativeIconGlass$State;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$0;->f$0:Ldev/nino/squareglass/NativeIconGlass$State;

    iput-object p2, p0, Ldev/nino/squareglass/NativeIconGlass$0;->f$1:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeIconGlass$0;->f$0:Ldev/nino/squareglass/NativeIconGlass$State;

    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$0;->f$1:Landroid/view/View;

    check-cast p1, Ljava/lang/Float;

    invoke-static {v0, p0, p1}, Ldev/nino/squareglass/NativeIconGlass;->pulse$lambda$0(Ldev/nino/squareglass/NativeIconGlass$State;Landroid/view/View;Ljava/lang/Float;)V

    return-void
.end method
