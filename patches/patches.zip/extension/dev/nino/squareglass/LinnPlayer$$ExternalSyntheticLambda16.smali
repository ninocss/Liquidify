.class public final synthetic Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:J

.field public final synthetic f$2:Ldev/nino/squareglass/LinnPlayer$Action;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;JLdev/nino/squareglass/LinnPlayer$Action;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda16;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-wide p2, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda16;->f$1:J

    iput-object p4, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda16;->f$2:Ldev/nino/squareglass/LinnPlayer$Action;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda16;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-wide v1, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda16;->f$1:J

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$$ExternalSyntheticLambda16;->f$2:Ldev/nino/squareglass/LinnPlayer$Action;

    invoke-static {v0, v1, v2, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$1RtSk6J5h-Oa-8JZpdhQIbyeIfQ(Ldev/nino/squareglass/LinnPlayer;JLdev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method
