.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:I

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Landroidx/compose/ui/Modifier;

.field public final synthetic f$4:I


# direct methods
.method public synthetic constructor <init>(JILjava/lang/String;Landroidx/compose/ui/Modifier;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$0:J

    iput p3, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$1:I

    iput-object p4, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$2:Ljava/lang/String;

    iput-object p5, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$3:Landroidx/compose/ui/Modifier;

    iput p6, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$4:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 0
    iget-wide v0, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$0:J

    iget v2, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$1:I

    iget-object v3, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$2:Ljava/lang/String;

    iget-object v4, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$3:Landroidx/compose/ui/Modifier;

    iget v5, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda1;->f$4:I

    move-object v6, p1

    check-cast v6, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-static/range {v0 .. v7}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$TxLjNutAPgleV-ZvEXkHl_DHuOQ(JILjava/lang/String;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
