.class public final synthetic Ldev/nino/squareglass/GlassProbe$8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Lam0/p;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Lam0/p;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassProbe$8;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Ldev/nino/squareglass/GlassProbe$8;->f$1:Lam0/p;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/GlassProbe$8;->f$0:Landroid/app/Activity;

    iget-object p0, p0, Ldev/nino/squareglass/GlassProbe$8;->f$1:Lam0/p;

    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {v0, p0, p1, p2}, Ldev/nino/squareglass/GlassProbe;->wrapNative$lambda$0(Landroid/app/Activity;Lam0/p;Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
