.class public final synthetic Ldev/nino/squareglass/LinnPlayer$26;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:Ljava/util/List;

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:I


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;Ljava/util/List;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$26;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer$26;->f$1:Ljava/util/List;

    iput-object p3, p0, Ldev/nino/squareglass/LinnPlayer$26;->f$2:Ljava/util/List;

    iput p4, p0, Ldev/nino/squareglass/LinnPlayer$26;->f$3:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$26;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-object v1, p0, Ldev/nino/squareglass/LinnPlayer$26;->f$1:Ljava/util/List;

    iget-object v2, p0, Ldev/nino/squareglass/LinnPlayer$26;->f$2:Ljava/util/List;

    iget p0, p0, Ldev/nino/squareglass/LinnPlayer$26;->f$3:I

    invoke-static {v0, v1, v2, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$CWaG-cL4jG2FjXJ07bCCcjoxzVA(Ldev/nino/squareglass/LinnPlayer;Ljava/util/List;Ljava/util/List;I)V

    return-void
.end method
