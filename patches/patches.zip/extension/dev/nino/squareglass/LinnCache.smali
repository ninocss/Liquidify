.class final Ldev/nino/squareglass/LinnCache;
.super Ljava/lang/Object;
.source "LinnCache.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LinnCache$Entry;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private final capacity:I

.field private final clock:Ljava/util/function/LongSupplier;

.field private final entries:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TK;",
            "Ldev/nino/squareglass/LinnCache$Entry<",
            "TV;>;>;"
        }
    .end annotation
.end field

.field private final ttl:J


# direct methods
.method constructor <init>(IJ)V
    .locals 1

    .line 17
    new-instance v0, Ldev/nino/squareglass/LinnCache$0;

    invoke-direct {v0}, Ldev/nino/squareglass/LinnCache$0;-><init>()V

    invoke-direct {p0, p1, p2, p3, v0}, Ldev/nino/squareglass/LinnCache;-><init>(IJLjava/util/function/LongSupplier;)V

    return-void
.end method

.method constructor <init>(IJLjava/util/function/LongSupplier;)V
    .locals 4

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    new-instance v0, Ljava/util/LinkedHashMap;

    const/high16 v1, 0x3f400000    # 0.75f

    const/4 v2, 0x1

    const/16 v3, 0x10

    invoke-direct {v0, v3, v1, v2}, Ljava/util/LinkedHashMap;-><init>(IFZ)V

    iput-object v0, p0, Ldev/nino/squareglass/LinnCache;->entries:Ljava/util/Map;

    .line 19
    iput p1, p0, Ldev/nino/squareglass/LinnCache;->capacity:I

    iput-wide p2, p0, Ldev/nino/squareglass/LinnCache;->ttl:J

    iput-object p4, p0, Ldev/nino/squareglass/LinnCache;->clock:Ljava/util/function/LongSupplier;

    return-void
.end method


# virtual methods
.method declared-synchronized clear()V
    .locals 1

    monitor-enter p0

    .line 32
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnCache;->entries:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method declared-synchronized get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)TV;"
        }
    .end annotation

    monitor-enter p0

    .line 22
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnCache;->entries:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ldev/nino/squareglass/LinnCache$Entry;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 23
    monitor-exit p0

    return-object v1

    .line 24
    :cond_0
    :try_start_1
    iget-object v2, p0, Ldev/nino/squareglass/LinnCache;->clock:Ljava/util/function/LongSupplier;

    invoke-interface {v2}, Ljava/util/function/LongSupplier;->getAsLong()J

    move-result-wide v2

    iget-wide v4, v0, Ldev/nino/squareglass/LinnCache$Entry;->created:J

    sub-long/2addr v2, v4

    iget-wide v4, p0, Ldev/nino/squareglass/LinnCache;->ttl:J

    cmp-long v2, v2, v4

    if-ltz v2, :cond_1

    iget-object v0, p0, Ldev/nino/squareglass/LinnCache;->entries:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-object v1

    .line 25
    :cond_1
    :try_start_2
    iget-object p1, v0, Ldev/nino/squareglass/LinnCache$Entry;->value:Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    return-object p1

    :catchall_0
    move-exception p1

    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p1
.end method

.method declared-synchronized put(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)V"
        }
    .end annotation

    monitor-enter p0

    .line 28
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnCache;->entries:Ljava/util/Map;

    new-instance v1, Ldev/nino/squareglass/LinnCache$Entry;

    iget-object v2, p0, Ldev/nino/squareglass/LinnCache;->clock:Ljava/util/function/LongSupplier;

    invoke-interface {v2}, Ljava/util/function/LongSupplier;->getAsLong()J

    move-result-wide v2

    invoke-direct {v1, p2, v2, v3}, Ldev/nino/squareglass/LinnCache$Entry;-><init>(Ljava/lang/Object;J)V

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    :goto_0
    iget-object p1, p0, Ldev/nino/squareglass/LinnCache;->entries:Ljava/util/Map;

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result p1

    iget p2, p0, Ldev/nino/squareglass/LinnCache;->capacity:I

    if-le p1, p2, :cond_0

    iget-object p1, p0, Ldev/nino/squareglass/LinnCache;->entries:Ljava/util/Map;

    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 30
    :cond_0
    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method declared-synchronized remove(Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)V"
        }
    .end annotation

    monitor-enter p0

    .line 31
    :try_start_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnCache;->entries:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method
