.class public final Ldev/nino/squareglass/SearchChrome;
.super Ljava/lang/Object;
.source "SearchChrome.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSearchChrome.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SearchChrome.kt\ndev/nino/squareglass/SearchChrome\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n*L\n1#1,21:1\n113#2:22\n*S KotlinDebug\n*F\n+ 1 SearchChrome.kt\ndev/nino/squareglass/SearchChrome\n*L\n18#1:22\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0008\u00c7\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\r\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0002\u0008\u0007H\u0007\u00a2\u0006\u0002\u0010\u0008J\u0008\u0010\t\u001a\u00020\nH\u0007J\u0008\u0010\u000b\u001a\u00020\u000cH\u0007\u00a8\u0006\r"
    }
    d2 = {
        "Ldev/nino/squareglass/SearchChrome;",
        "",
        "<init>",
        "()V",
        "container",
        "Lkotlin/Function0;",
        "",
        "Landroidx/compose/runtime/Composable;",
        "()Lam0/p;",
        "shape",
        "Landroidx/compose/ui/graphics/Shape;",
        "cursor",
        "Landroidx/compose/ui/graphics/Brush;",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/SearchChrome;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/SearchChrome;

    invoke-direct {v0}, Ldev/nino/squareglass/SearchChrome;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SearchChrome;->INSTANCE:Ldev/nino/squareglass/SearchChrome;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final container()Lam0/p;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    sget-object v0, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;->INSTANCE:Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;

    invoke-virtual {v0}, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;->getLambda$2019281455$extension_debug()Lam0/p;

    move-result-object v0

    return-object v0
.end method

.method public static final cursor()Landroidx/compose/ui/graphics/Brush;
    .locals 4

    .line 19
    new-instance v0, Landroidx/compose/ui/graphics/SolidColor;

    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v1

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2, v3}, Landroidx/compose/ui/graphics/SolidColor;-><init>(JLkotlin/jvm/internal/DefaultConstructorMarker;)V

    check-cast v0, Landroidx/compose/ui/graphics/Brush;

    return-object v0
.end method

.method public static final shape()Landroidx/compose/ui/graphics/Shape;
    .locals 1

    const/high16 v0, 0x41e00000    # 28.0f

    .line 22
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 18
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/Shape;

    return-object v0
.end method
