.class Ldev/nino/squareglass/NativePlayback$1;
.super Ljava/lang/Object;
.source "NativePlayback.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/NativePlayback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 92
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 15

    const-wide/16 v0, 0x1388

    .line 94
    :try_start_0
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgethost()Ljava/lang/ref/WeakReference;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lbi/e;

    if-eqz v2, :cond_2

    .line 95
    invoke-interface {v2}, Lbi/e;->getCurrentItem()Lcom/aspiro/wamp/playqueue/u0;

    move-result-object v3

    if-eqz v3, :cond_2

    .line 96
    invoke-interface {v2}, Lbi/e;->getCurrentItem()Lcom/aspiro/wamp/playqueue/u0;

    move-result-object v3

    invoke-interface {v3}, Lcom/aspiro/wamp/playqueue/u0;->getMediaItem()Lcom/aspiro/wamp/model/MediaItem;

    move-result-object v3

    invoke-interface {v2}, Lbi/e;->getCurrentMediaPosition()I

    move-result v2

    .line 97
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    if-eqz v3, :cond_0

    .line 98
    invoke-virtual {v3}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v6

    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetlastId()I

    move-result v7

    if-eq v6, v7, :cond_0

    invoke-virtual {v3}, Lcom/aspiro/wamp/model/MediaItem;->getId()I

    move-result v6

    invoke-static {v6}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfputlastId(I)V

    const/4 v6, 0x0

    invoke-static {v6}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfputlistened(I)V

    invoke-static {v6}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfputcountedCurrent(Z)V

    invoke-static {v2}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfputlastPosition(I)V

    .line 99
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetlastPosition()I

    move-result v6

    sub-int v6, v2, v6

    .line 100
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetlastTick()J

    move-result-wide v7

    sub-long v7, v4, v7

    .line 101
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetplaying()Z

    move-result v9

    if-eqz v9, :cond_1

    const-string v9, "learnTime"

    const/4 v10, 0x1

    invoke-static {v9, v10}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result v9

    if-eqz v9, :cond_1

    if-lez v6, :cond_1

    int-to-long v11, v6

    const-wide/16 v13, 0x5dc

    add-long/2addr v13, v7

    cmp-long v9, v11, v13

    if-gtz v9, :cond_1

    const-wide/16 v11, 0x2710

    cmp-long v9, v7, v11

    if-gtz v9, :cond_1

    .line 102
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetlistened()I

    move-result v9

    long-to-int v7, v7

    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v6

    add-int/2addr v9, v6

    invoke-static {v9}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfputlistened(I)V

    .line 103
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetlistened()I

    move-result v6

    const/16 v7, 0x7530

    if-lt v6, v7, :cond_1

    instance-of v6, v3, Lcom/aspiro/wamp/model/Track;

    if-eqz v6, :cond_1

    move-object v6, v3

    check-cast v6, Lcom/aspiro/wamp/model/Track;

    invoke-virtual {v6}, Lcom/aspiro/wamp/model/Track;->isUpload()Z

    move-result v6

    if-nez v6, :cond_1

    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetcountedCurrent()Z

    move-result v6

    if-nez v6, :cond_1

    invoke-static {v10}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfputcountedCurrent(Z)V

    check-cast v3, Lcom/aspiro/wamp/model/Track;

    invoke-static {v3}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$smrecord(Lcom/aspiro/wamp/model/Track;)V

    .line 105
    :cond_1
    invoke-static {v2}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfputlastPosition(I)V

    invoke-static {v4, v5}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfputlastTick(J)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 108
    :cond_2
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v2

    invoke-virtual {v2, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :catchall_0
    move-exception v2

    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v3

    invoke-virtual {v3, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    throw v2

    :catch_0
    invoke-static {}, Ldev/nino/squareglass/NativePlayback;->-$$Nest$sfgetmain()Landroid/os/Handler;

    move-result-object v2

    invoke-virtual {v2, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
