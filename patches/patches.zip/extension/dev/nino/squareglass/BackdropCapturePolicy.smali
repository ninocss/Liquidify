.class public final Ldev/nino/squareglass/BackdropCapturePolicy;
.super Ljava/lang/Object;
.source "BackdropCapturePolicy.java"


# instance fields
.field private stableFrames:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    .line 5
    iput v0, p0, Ldev/nino/squareglass/BackdropCapturePolicy;->stableFrames:I

    return-void
.end method


# virtual methods
.method public allowCapture(Z)Z
    .locals 2

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    .line 11
    invoke-virtual {p0}, Ldev/nino/squareglass/BackdropCapturePolicy;->transition()V

    return v0

    .line 14
    :cond_0
    iget p1, p0, Ldev/nino/squareglass/BackdropCapturePolicy;->stableFrames:I

    const/4 v1, 0x1

    if-lez p1, :cond_1

    sub-int/2addr p1, v1

    .line 15
    iput p1, p0, Ldev/nino/squareglass/BackdropCapturePolicy;->stableFrames:I

    return v0

    :cond_1
    return v1
.end method

.method public transition()V
    .locals 1

    const/4 v0, 0x2

    .line 7
    iput v0, p0, Ldev/nino/squareglass/BackdropCapturePolicy;->stableFrames:I

    return-void
.end method
