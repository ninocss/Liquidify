.class public final Ldev/nino/squareglass/SquareSettings;
.super Ljava/lang/Object;
.source "SquareSettings.java"


# static fields
.field private static final listener:Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;

.field private static preferences:Landroid/content/SharedPreferences;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 16
    new-instance v0, Ldev/nino/squareglass/SquareSettings$0;

    invoke-direct {v0}, Ldev/nino/squareglass/SquareSettings$0;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquareSettings;->listener:Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static blur()F
    .locals 4

    .line 27
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const/16 v0, 0x10

    goto :goto_0

    :cond_0
    const/16 v0, 0x8

    :goto_0
    const/4 v1, 0x0

    const/16 v2, 0x18

    const-string v3, "blur"

    invoke-static {v3, v0, v1, v2}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v0

    int-to-float v0, v0

    return v0
.end method

.method public static flag(Ljava/lang/String;Z)Z
    .locals 1

    .line 22
    sget-object v0, Ldev/nino/squareglass/SquareSettings;->preferences:Landroid/content/SharedPreferences;

    if-nez v0, :cond_0

    return p1

    :cond_0
    invoke-interface {v0, p0, p1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method public static glass(Ljava/lang/String;)Z
    .locals 2

    .line 39
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    invoke-static {p0, v0}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result p0

    if-eqz p0, :cond_0

    return v0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public static initialTheme()I
    .locals 1

    const/4 v0, __RL_SQUARE_THEME_MODE__

    return v0
.end method

.method public static initialize(Landroid/content/Context;)V
    .locals 2

    .line 11
    sget-object v0, Ldev/nino/squareglass/SquareSettings;->preferences:Landroid/content/SharedPreferences;

    if-nez v0, :cond_0

    .line 12
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string v0, "squareglass_design_v1"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    sput-object p0, Ldev/nino/squareglass/SquareSettings;->preferences:Landroid/content/SharedPreferences;

    .line 13
    sget-object v0, Ldev/nino/squareglass/SquareSettings;->listener:Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences;->registerOnSharedPreferenceChangeListener(Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;)V

    :cond_0
    return-void
.end method

.method public static integer(Ljava/lang/String;III)I
    .locals 1

    .line 19
    sget-object v0, Ldev/nino/squareglass/SquareSettings;->preferences:Landroid/content/SharedPreferences;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {v0, p0, p1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p1

    :goto_0
    invoke-static {p3, p1}, Ljava/lang/Math;->min(II)I

    move-result p0

    invoke-static {p2, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method static synthetic lambda$static$0(Landroid/content/SharedPreferences;Ljava/lang/String;)V
    .locals 0

    .line 17
    invoke-static {}, Ldev/nino/squareglass/DesignState;->changed()V

    return-void
.end method

.method public static managerReady()I
    .locals 1

    const/4 v0, __RL_SQUARE_MANAGER_READY__

    return v0
.end method

.method public static motion()Z
    .locals 2

    .line 37
    const-string v0, "reduceMotion"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ldev/nino/squareglass/SquareSettings;->flag(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    return v1
.end method

.method public static opacity()F
    .locals 4

    .line 28
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const/16 v0, 0x41

    goto :goto_0

    :cond_0
    const/16 v0, 0x32

    :goto_0
    const/16 v1, 0x14

    const/16 v2, 0x5a

    const-string v3, "opacity"

    invoke-static {v3, v0, v1, v2}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr v0, v1

    return v0
.end method

.method public static preset()I
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x2

    .line 26
    const-string v2, "preset"

    invoke-static {v2, v0, v0, v1}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v0

    return v0
.end method

.method public static preset(I)V
    .locals 2

    .line 33
    sget-object v0, Ldev/nino/squareglass/SquareSettings;->preferences:Landroid/content/SharedPreferences;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "preset"

    invoke-interface {v0, v1, p0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "blur"

    .line 34
    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "opacity"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "lens"

    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    return-void
.end method

.method public static put(Ljava/lang/String;I)V
    .locals 1

    .line 24
    sget-object v0, Ldev/nino/squareglass/SquareSettings;->preferences:Landroid/content/SharedPreferences;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    return-void
.end method

.method public static put(Ljava/lang/String;Z)V
    .locals 1

    .line 25
    sget-object v0, Ldev/nino/squareglass/SquareSettings;->preferences:Landroid/content/SharedPreferences;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p0, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    return-void
.end method

.method public static readableOpacity(Z)F
    .locals 1

    .line 29
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->opacity()F

    move-result v0

    if-eqz p0, :cond_0

    const p0, 0x3f47ae14    # 0.78f

    goto :goto_0

    :cond_0
    const p0, 0x3f23d70a    # 0.64f

    :goto_0
    invoke-static {v0, p0}, Ljava/lang/Math;->max(FF)F

    move-result p0

    return p0
.end method

.method public static refraction()F
    .locals 4

    .line 31
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->preset()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    const/16 v0, 0x28

    :goto_0
    const/16 v1, 0x64

    const-string v3, "lens"

    invoke-static {v3, v0, v2, v1}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr v0, v1

    return v0
.end method

.method public static reset()V
    .locals 1

    .line 30
    sget-object v0, Ldev/nino/squareglass/SquareSettings;->preferences:Landroid/content/SharedPreferences;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    return-void
.end method

.method public static themeEnabled()I
    .locals 1

    const/4 v0, __RL_SQUARE_THEME_ENABLED__

    return v0
.end method

.method public static themeMode()I
    .locals 4

    .line 9
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->initialTheme()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v3, "theme"

    invoke-static {v3, v0, v1, v2}, Ldev/nino/squareglass/SquareSettings;->integer(Ljava/lang/String;III)I

    move-result v0

    return v0
.end method
