.class public final synthetic Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Lkotlinx/coroutines/CoroutineScope;

.field public final synthetic f$1:Lam0/l;

.field public final synthetic f$2:Z

.field public final synthetic f$3:Lcom/aspiro/wamp/mycollectionscreen/presentation/u;


# direct methods
.method public synthetic constructor <init>(Lkotlinx/coroutines/CoroutineScope;Lam0/l;ZLcom/aspiro/wamp/mycollectionscreen/presentation/u;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;->f$0:Lkotlinx/coroutines/CoroutineScope;

    iput-object p2, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;->f$1:Lam0/l;

    iput-boolean p3, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;->f$2:Z

    iput-object p4, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;->f$3:Lcom/aspiro/wamp/mycollectionscreen/presentation/u;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;->f$0:Lkotlinx/coroutines/CoroutineScope;

    iget-object v1, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;->f$1:Lam0/l;

    iget-boolean v2, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;->f$2:Z

    iget-object p0, p0, Ldev/nino/squareglass/SquareLibrary$$ExternalSyntheticLambda0;->f$3:Lcom/aspiro/wamp/mycollectionscreen/presentation/u;

    invoke-static {v0, v1, v2, p0}, Ldev/nino/squareglass/SquareLibrary;->$r8$lambda$Fe7Ln53nETeU0h-oLG1Vqi4BivE(Lkotlinx/coroutines/CoroutineScope;Lam0/l;ZLcom/aspiro/wamp/mycollectionscreen/presentation/u;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
