.class public final synthetic Ldev/nino/squareglass/LiquidViewMotion$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LiquidViewMotion$$ExternalSyntheticLambda1;->f$0:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/LiquidViewMotion$$ExternalSyntheticLambda1;->f$0:Landroid/view/View;

    check-cast p1, Ljava/lang/Float;

    invoke-static {p0, p1}, Ldev/nino/squareglass/LiquidViewMotion;->$r8$lambda$nA6t1B3w4LErRG7UfnF0rxWN6bI(Landroid/view/View;Ljava/lang/Float;)V

    return-void
.end method
