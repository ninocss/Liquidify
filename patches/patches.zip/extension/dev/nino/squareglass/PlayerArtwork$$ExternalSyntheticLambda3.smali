.class public final synthetic Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

.field public final synthetic f$1:Landroid/view/View;

.field public final synthetic f$2:F

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/PlayerArtwork$Frame;Landroid/view/View;FLandroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;->f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

    iput-object p2, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;->f$1:Landroid/view/View;

    iput p3, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;->f$2:F

    iput-object p4, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;->f$3:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;->f$0:Ldev/nino/squareglass/PlayerArtwork$Frame;

    iget-object v1, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;->f$1:Landroid/view/View;

    iget v2, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;->f$2:F

    iget-object v3, p0, Ldev/nino/squareglass/PlayerArtwork$$ExternalSyntheticLambda3;->f$3:Landroidx/compose/runtime/MutableState;

    move-object v4, p1

    check-cast v4, Landroidx/compose/ui/layout/MeasureScope;

    move-object v5, p2

    check-cast v5, Landroidx/compose/ui/layout/Measurable;

    move-object v6, p3

    check-cast v6, Landroidx/compose/ui/unit/Constraints;

    invoke-static/range {v0 .. v6}, Ldev/nino/squareglass/PlayerArtwork;->$r8$lambda$DWQM-MkcQaYRTSf-Gwkur_tfduE(Ldev/nino/squareglass/PlayerArtwork$Frame;Landroid/view/View;FLandroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/MeasureScope;Landroidx/compose/ui/layout/Measurable;Landroidx/compose/ui/unit/Constraints;)Landroidx/compose/ui/layout/MeasureResult;

    move-result-object p0

    return-object p0
.end method
