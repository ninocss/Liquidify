.class public final synthetic Ldev/nino/squareglass/GlassMotion$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/InteractiveHighlight;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/InteractiveHighlight;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassMotion$6;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/GlassMotion$6;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    check-cast p2, Lam0/l;

    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/GlassMotion;->$r8$lambda$VE1bnizU_udWyID96Uv10vy1C2s(Ldev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/ui/graphics/drawscope/DrawScope;Lam0/l;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
