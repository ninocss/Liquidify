.class public final synthetic Ldev/nino/squareglass/NativeTabs$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Lam0/l;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lam0/l;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeTabs$6;->f$0:Lam0/l;

    iput p2, p0, Ldev/nino/squareglass/NativeTabs$6;->f$1:I

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/NativeTabs$6;->f$0:Lam0/l;

    iget p0, p0, Ldev/nino/squareglass/NativeTabs$6;->f$1:I

    invoke-static {v0, p0}, Ldev/nino/squareglass/NativeTabs;->$r8$lambda$cAQoFlunMZbXrWi6uiLohGXQo7I(Lam0/l;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
