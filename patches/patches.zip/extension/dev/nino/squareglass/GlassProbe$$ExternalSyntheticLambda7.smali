.class public final synthetic Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda7;->f$0:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda7;->f$0:Landroid/app/Activity;

    invoke-static {p0}, Ldev/nino/squareglass/GlassProbe;->$r8$lambda$kGRV_meWq2_hPE56v0JVliqxANw(Landroid/app/Activity;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
