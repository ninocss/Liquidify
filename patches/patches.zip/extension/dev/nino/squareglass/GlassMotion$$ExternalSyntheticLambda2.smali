.class public final synthetic Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/material/InteractiveHighlight;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/material/InteractiveHighlight;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda2;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/GlassMotion$$ExternalSyntheticLambda2;->f$0:Ldev/nino/squareglass/material/InteractiveHighlight;

    check-cast p1, Ldev/nino/squareglass/backdrop/BackdropEffectScope;

    invoke-static {p0, p1}, Ldev/nino/squareglass/GlassMotion;->$r8$lambda$edjisbuDzrIgZkv6ynG7FCFijvY(Ldev/nino/squareglass/material/InteractiveHighlight;Ldev/nino/squareglass/backdrop/BackdropEffectScope;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
