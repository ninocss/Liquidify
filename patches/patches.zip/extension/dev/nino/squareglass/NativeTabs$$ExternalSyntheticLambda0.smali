.class public final synthetic Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Ljava/util/List;

.field public final synthetic f$2:Lam0/l;

.field public final synthetic f$3:Landroidx/compose/ui/Modifier;

.field public final synthetic f$4:I


# direct methods
.method public synthetic constructor <init>(ILjava/util/List;Lam0/l;Landroidx/compose/ui/Modifier;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$0:I

    iput-object p2, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$1:Ljava/util/List;

    iput-object p3, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$2:Lam0/l;

    iput-object p4, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$3:Landroidx/compose/ui/Modifier;

    iput p5, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$4:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    iget v0, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$0:I

    iget-object v1, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$1:Ljava/util/List;

    iget-object v2, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$2:Lam0/l;

    iget-object v3, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$3:Landroidx/compose/ui/Modifier;

    iget v4, p0, Ldev/nino/squareglass/NativeTabs$$ExternalSyntheticLambda0;->f$4:I

    move-object v5, p1

    check-cast v5, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-static/range {v0 .. v6}, Ldev/nino/squareglass/NativeTabs;->$r8$lambda$zHREun_1hLPxpALfFjayWFYcQ4E(ILjava/util/List;Lam0/l;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
