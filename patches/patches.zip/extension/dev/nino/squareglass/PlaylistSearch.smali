.class public final Ldev/nino/squareglass/PlaylistSearch;
.super Ljava/lang/Object;
.source "PlaylistSearch.java"


# direct methods
.method static bridge synthetic -$$Nest$smpaint(Landroidx/appcompat/widget/SearchView;)V
    .locals 0

    invoke-static {p0}, Ldev/nino/squareglass/PlaylistSearch;->paint(Landroidx/appcompat/widget/SearchView;)V

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static paint(Landroidx/appcompat/widget/SearchView;)V
    .locals 4

    .line 21
    invoke-static {p0}, Ldev/nino/squareglass/SquareExplore;->search(Landroid/view/View;)V

    .line 23
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/high16 v1, 0x41400000    # 12.0f

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v1, 0x0

    .line 24
    invoke-virtual {p0, v0, v1, v0, v1}, Landroid/view/View;->setPaddingRelative(IIII)V

    .line 25
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "search_src_text"

    const-string v3, "id"

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 26
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroid/widget/TextView;

    if-eqz p0, :cond_0

    const/high16 v0, 0x41800000    # 16.0f

    .line 27
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setSingleLine(Z)V

    :cond_0
    return-void
.end method

.method public static style(Landroidx/appcompat/widget/SearchView;)V
    .locals 1

    .line 11
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeEnabled()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 12
    :cond_0
    const-string v0, "Search this playlist"

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/SearchView;->setQueryHint(Ljava/lang/CharSequence;)V

    const v0, 0x7fffffff

    .line 13
    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/SearchView;->setMaxWidth(I)V

    .line 14
    new-instance v0, Ldev/nino/squareglass/PlaylistSearch$1;

    invoke-direct {v0, p0}, Ldev/nino/squareglass/PlaylistSearch$1;-><init>(Landroidx/appcompat/widget/SearchView;)V

    invoke-virtual {p0, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 18
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {p0}, Ldev/nino/squareglass/PlaylistSearch;->paint(Landroidx/appcompat/widget/SearchView;)V

    :cond_1
    :goto_0
    return-void
.end method
