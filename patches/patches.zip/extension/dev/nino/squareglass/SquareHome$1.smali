.class public final synthetic Ldev/nino/squareglass/SquareHome$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Landroidx/compose/runtime/State;


# direct methods
.method public synthetic constructor <init>(ZLandroidx/compose/runtime/State;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Ldev/nino/squareglass/SquareHome$1;->f$0:Z

    iput-object p2, p0, Ldev/nino/squareglass/SquareHome$1;->f$1:Landroidx/compose/runtime/State;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 0
    iget-boolean v0, p0, Ldev/nino/squareglass/SquareHome$1;->f$0:Z

    iget-object p0, p0, Ldev/nino/squareglass/SquareHome$1;->f$1:Landroidx/compose/runtime/State;

    invoke-static {v0, p0}, Ldev/nino/squareglass/SquareHome;->$r8$lambda$_nrbNGoJjqv8GtA6Q5cgcbvhEcg(ZLandroidx/compose/runtime/State;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
