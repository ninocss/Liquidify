.class public final Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;
.super Ljava/lang/Object;
.source "SearchChrome.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;

.field private static lambda$2019281455:Lam0/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$sQi803Sv9DQatOr3C_yuE4MGPDU(Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;->lambda_2019281455$lambda$0(Landroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;

    invoke-direct {v0}, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;-><init>()V

    sput-object v0, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;->INSTANCE:Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;

    .line 14
    new-instance v0, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt$$ExternalSyntheticLambda0;-><init>()V

    const v1, 0x785bca2f

    const/4 v2, 0x0

    invoke-static {v1, v2, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lam0/p;

    sput-object v0, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;->lambda$2019281455:Lam0/p;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final lambda_2019281455$lambda$0(Landroidx/compose/runtime/Composer;I)Lkotlin/u;
    .locals 10

    const-string v0, "C15@689L50:SearchChrome.kt#vqphja"

    invoke-static {p0, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_0

    move v0, v3

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    and-int/lit8 v1, p1, 0x1

    invoke-interface {p0, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, -0x1

    const-string v1, "dev.nino.squareglass.ComposableSingletons$SearchChromeKt.lambda$2019281455.<anonymous> (SearchChrome.kt:14)"

    const v4, 0x785bca2f

    invoke-static {v4, p1, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 15
    :cond_1
    sget-object p1, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {p1}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 16
    sget-object v4, Ldev/nino/squareglass/GlassPanels;->INSTANCE:Ldev/nino/squareglass/GlassPanels;

    sget-object p1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast p1, Landroidx/compose/ui/Modifier;

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p1, v0, v3, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/high16 v6, 0x41e00000    # 28.0f

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Ldev/nino/squareglass/GlassPanels;->panel$default(Ldev/nino/squareglass/GlassPanels;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object p1

    invoke-static {p1, p0, v2}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1

    .line 14
    :cond_2
    invoke-interface {p0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 17
    :cond_3
    :goto_1
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method


# virtual methods
.method public final getLambda$2019281455$extension_debug()Lam0/p;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/u;",
            ">;"
        }
    .end annotation

    sget-object p0, Ldev/nino/squareglass/ComposableSingletons$SearchChromeKt;->lambda$2019281455:Lam0/p;

    return-object p0
.end method
