.class public final Ldev/nino/squareglass/IconMotion;
.super Ljava/lang/Object;
.source "IconMotion.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/IconMotion$Entry;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nIconMotion.kt\nKotlin\n*S Kotlin\n*F\n+ 1 IconMotion.kt\ndev/nino/squareglass/IconMotion\n+ 2 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 3 Effects.kt\nandroidx/compose/runtime/EffectsKt\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 5 Effects.kt\nandroidx/compose/runtime/EffectsKt$rememberCoroutineScope$1\n+ 6 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope\n+ 7 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n+ 8 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,151:1\n75#2:152\n75#2:153\n599#3:154\n596#3,6:155\n1128#4,3:161\n1131#4,3:165\n1128#4,6:168\n1128#4,6:174\n1128#4,6:180\n1128#4,6:186\n1128#4,6:192\n1128#4,6:198\n1128#4,6:204\n1128#4,6:210\n1128#4,6:216\n1128#4,6:222\n1128#4,6:228\n1128#4,6:234\n1128#4,6:240\n597#5:164\n66#6,5:246\n78#7:251\n111#7,2:252\n78#7:263\n111#7,2:264\n85#8:254\n117#8,2:255\n85#8:257\n117#8,2:258\n85#8:260\n117#8,2:261\n*S KotlinDebug\n*F\n+ 1 IconMotion.kt\ndev/nino/squareglass/IconMotion\n*L\n84#1:152\n85#1:153\n86#1:154\n86#1:155,6\n86#1:161,3\n86#1:165,3\n87#1:168,6\n88#1:174,6\n89#1:180,6\n90#1:186,6\n91#1:192,6\n92#1:198,6\n94#1:204,6\n97#1:210,6\n111#1:216,6\n114#1:222,6\n124#1:228,6\n129#1:234,6\n130#1:240,6\n86#1:164\n109#1:246,5\n88#1:251\n88#1:252,2\n92#1:263\n92#1:264,2\n89#1:254\n89#1:255,2\n90#1:257\n90#1:258,2\n91#1:260\n91#1:261,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000o\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0012\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002*\u0001\u0010\u0008\u00c7\u0002\u0018\u00002\u00020\u0001:\u00011B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0007J\u0010\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u0018\u0010\u0019\u001a\u00020\u00012\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dH\u0007J\u0010\u0010\u001e\u001a\u00020\u00132\u0006\u0010\u001f\u001a\u00020\u0001H\u0007J\u000e\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020!J\u0015\u0010#\u001a\u00020!2\u0006\u0010\"\u001a\u00020!H\u0007\u00a2\u0006\u0002\u0010$J\u001d\u0010%\u001a\u00020!2\u0006\u0010\"\u001a\u00020!2\u0006\u0010&\u001a\u00020\rH\u0007\u00a2\u0006\u0002\u0010\'J\u001d\u0010(\u001a\u00020!2\u0006\u0010\"\u001a\u00020!2\u0006\u0010)\u001a\u00020\u0018H\u0007\u00a2\u0006\u0002\u0010*J%\u0010+\u001a\u00020!2\u0006\u0010\"\u001a\u00020!2\u0006\u0010,\u001a\u00020\r2\u0006\u0010-\u001a\u00020\rH\u0007\u00a2\u0006\u0002\u0010.J/\u0010/\u001a\u00020!2\u0006\u0010\"\u001a\u00020!2\u0006\u0010,\u001a\u00020\r2\u0006\u0010-\u001a\u00020\r2\u0008\u0010)\u001a\u0004\u0018\u00010\u0018H\u0003\u00a2\u0006\u0002\u00100R\u001e\u0010\u0004\u001a\u0012\u0012\u0004\u0012\u00020\u00060\u0005j\u0008\u0012\u0004\u0012\u00020\u0006`\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u00020\u0010X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u0011\u00a8\u00062\u00b2\u0006\n\u0010\u0014\u001a\u00020\rX\u008a\u008e\u0002\u00b2\u0006\n\u00103\u001a\u000204X\u008a\u008e\u0002\u00b2\u0006\n\u00105\u001a\u000206X\u008a\u008e\u0002\u00b2\u0006\u000c\u00107\u001a\u0004\u0018\u00010\u0018X\u008a\u008e\u0002\u00b2\u0006\n\u00108\u001a\u00020\rX\u008a\u008e\u0002"
    }
    d2 = {
        "Ldev/nino/squareglass/IconMotion;",
        "",
        "<init>",
        "()V",
        "entries",
        "Ljava/util/ArrayList;",
        "Ldev/nino/squareglass/IconMotion$Entry;",
        "Lkotlin/collections/ArrayList;",
        "handler",
        "Landroid/os/Handler;",
        "policy",
        "Ldev/nino/squareglass/MotionPolicy;",
        "cursor",
        "",
        "idleStyle",
        "tick",
        "dev/nino/squareglass/IconMotion$tick$1",
        "Ldev/nino/squareglass/IconMotion$tick$1;",
        "touch",
        "",
        "event",
        "Landroid/view/MotionEvent;",
        "interacted",
        "down",
        "",
        "registerNative",
        "view",
        "Landroid/view/View;",
        "fire",
        "Ljava/util/function/IntConsumer;",
        "unregisterNative",
        "token",
        "watch",
        "Landroidx/compose/ui/Modifier;",
        "original",
        "settings",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "settingsResource",
        "resource",
        "(Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "favorite",
        "liked",
        "(Landroidx/compose/ui/Modifier;ZLandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "icon",
        "key",
        "pulse",
        "(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "decorate",
        "(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;",
        "Entry",
        "extension_debug",
        "bounds",
        "Landroidx/compose/ui/geometry/Rect;",
        "lastTap",
        "",
        "previousLike",
        "previousPulse"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/IconMotion;

.field private static cursor:I

.field private static final entries:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ldev/nino/squareglass/IconMotion$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private static final handler:Landroid/os/Handler;

.field private static idleStyle:I

.field private static final policy:Ldev/nino/squareglass/MotionPolicy;

.field private static final tick:Ldev/nino/squareglass/IconMotion$tick$1;


# direct methods
.method public static synthetic $r8$lambda$4A1PF7ivn5pgfhmEYT-tNfirh0w(Landroidx/compose/runtime/State;Landroid/view/View;Landroidx/lifecycle/Lifecycle;Landroidx/compose/runtime/State;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$17$0(Landroidx/compose/runtime/State;Landroid/view/View;Landroidx/lifecycle/Lifecycle;Landroidx/compose/runtime/State;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$BiTUnFfZZ0yI2PEntuMBygiB6YQ(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/LayoutCoordinates;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$21$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/LayoutCoordinates;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$OGfaHqE4BfYVoK0DEXXzvKGwp_Y(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)Z
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$17$0$0(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$gebVyEYJr9MIBIh0xwyPMHIFfIo(Landroidx/compose/runtime/MutableIntState;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$16$0(Landroidx/compose/runtime/MutableIntState;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$huk5O6hz55kQXhgv8lCZnrq8dCU(Landroidx/compose/runtime/State;I)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$17$0$1(Landroidx/compose/runtime/State;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Ldev/nino/squareglass/IconMotion;

    invoke-direct {v0}, Ldev/nino/squareglass/IconMotion;-><init>()V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    .line 27
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    .line 28
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    .line 29
    new-instance v0, Ldev/nino/squareglass/MotionPolicy;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    invoke-direct {v0, v1, v2}, Ldev/nino/squareglass/MotionPolicy;-><init>(J)V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->policy:Ldev/nino/squareglass/MotionPolicy;

    .line 32
    new-instance v0, Ldev/nino/squareglass/IconMotion$tick$1;

    invoke-direct {v0}, Ldev/nino/squareglass/IconMotion$tick$1;-><init>()V

    sput-object v0, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    const/16 v0, 0x8

    sput v0, Ldev/nino/squareglass/IconMotion;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$decorate$lambda$11(Landroidx/compose/runtime/MutableState;)Ljava/lang/Boolean;
    .locals 0

    .line 25
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$11(Landroidx/compose/runtime/MutableState;)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$decorate$lambda$12(Landroidx/compose/runtime/MutableState;Ljava/lang/Boolean;)V
    .locals 0

    .line 25
    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$12(Landroidx/compose/runtime/MutableState;Ljava/lang/Boolean;)V

    return-void
.end method

.method public static final synthetic access$decorate$lambda$14(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 25
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$14(Landroidx/compose/runtime/MutableIntState;)I

    move-result p0

    return p0
.end method

.method public static final synthetic access$decorate$lambda$15(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0

    .line 25
    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$15(Landroidx/compose/runtime/MutableIntState;I)V

    return-void
.end method

.method public static final synthetic access$decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 25
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I

    move-result p0

    return p0
.end method

.method public static final synthetic access$decorate$lambda$5(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/geometry/Rect;
    .locals 0

    .line 25
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$5(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/geometry/Rect;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$decorate$lambda$8(Landroidx/compose/runtime/MutableState;)J
    .locals 2

    .line 25
    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$8(Landroidx/compose/runtime/MutableState;)J

    move-result-wide v0

    return-wide v0
.end method

.method public static final synthetic access$decorate$lambda$9(Landroidx/compose/runtime/MutableState;J)V
    .locals 0

    .line 25
    invoke-static {p0, p1, p2}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$9(Landroidx/compose/runtime/MutableState;J)V

    return-void
.end method

.method public static final synthetic access$getCursor$p()I
    .locals 1

    .line 25
    sget v0, Ldev/nino/squareglass/IconMotion;->cursor:I

    return v0
.end method

.method public static final synthetic access$getEntries$p()Ljava/util/ArrayList;
    .locals 1

    .line 25
    sget-object v0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static final synthetic access$getHandler$p()Landroid/os/Handler;
    .locals 1

    .line 25
    sget-object v0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    return-object v0
.end method

.method public static final synthetic access$getIdleStyle$p()I
    .locals 1

    .line 25
    sget v0, Ldev/nino/squareglass/IconMotion;->idleStyle:I

    return v0
.end method

.method public static final synthetic access$getPolicy$p()Ldev/nino/squareglass/MotionPolicy;
    .locals 1

    .line 25
    sget-object v0, Ldev/nino/squareglass/IconMotion;->policy:Ldev/nino/squareglass/MotionPolicy;

    return-object v0
.end method

.method public static final synthetic access$getTick$p()Ldev/nino/squareglass/IconMotion$tick$1;
    .locals 1

    .line 25
    sget-object v0, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    return-object v0
.end method

.method public static final synthetic access$interacted(Ldev/nino/squareglass/IconMotion;Z)V
    .locals 0

    .line 25
    invoke-direct {p0, p1}, Ldev/nino/squareglass/IconMotion;->interacted(Z)V

    return-void
.end method

.method public static final synthetic access$setCursor$p(I)V
    .locals 0

    .line 25
    sput p0, Ldev/nino/squareglass/IconMotion;->cursor:I

    return-void
.end method

.method public static final synthetic access$setIdleStyle$p(I)V
    .locals 0

    .line 25
    sput p0, Ldev/nino/squareglass/IconMotion;->idleStyle:I

    return-void
.end method

.method private final decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 20

    move/from16 v0, p3

    move-object/from16 v1, p4

    move-object/from16 v6, p5

    move/from16 v8, p6

    const-string v2, "C(decorate)N(original,key,pulse,liked)83@3907L7,84@3957L7,85@3993L24,86@4040L45,87@4107L31,88@4161L36,89@4221L34,90@4284L32,91@4346L35,93@4457L39,94@4520L26,95@4572L28,96@4646L800,96@4609L837,110@5477L78,110@5455L100,113@5586L330,113@5564L352,123@5954L143,123@5925L172,128@6217L28,129@6277L925:IconMotion.kt#vqphja"

    const v3, 0x2c0a9bc9

    .line 82
    invoke-static {v6, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, -0x1

    const-string v4, "dev.nino.squareglass.IconMotion.decorate (IconMotion.kt:81)"

    invoke-static {v3, v8, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 83
    :cond_0
    sget-object v2, Ldev/nino/squareglass/DesignState;->INSTANCE:Ldev/nino/squareglass/DesignState;

    invoke-virtual {v2}, Ldev/nino/squareglass/DesignState;->getRevision()I

    .line 84
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalView()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v2

    check-cast v2, Landroidx/compose/runtime/CompositionLocal;

    const v3, 0x789c5f52

    .line 152
    const-string v4, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 84
    check-cast v2, Landroid/view/View;

    .line 85
    invoke-static {}, Landroidx/lifecycle/compose/LocalLifecycleOwnerKt;->getLocalLifecycleOwner()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v5

    check-cast v5, Landroidx/compose/runtime/CompositionLocal;

    .line 153
    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    check-cast v3, Landroidx/lifecycle/LifecycleOwner;

    .line 85
    invoke-interface {v3}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    move-result-object v3

    const v4, 0x2e20b340

    .line 86
    const-string v5, "CC(rememberCoroutineScope)N(getContext)600@27430L68:Effects.kt#9igjgp"

    .line 154
    invoke-static {v6, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v4, 0x28c0fdc4

    .line 159
    const-string v5, "CC(remember):Effects.kt#9igjgp"

    .line 160
    invoke-static {v6, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 161
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 162
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_1

    .line 164
    sget-object v4, Lkotlin/coroutines/EmptyCoroutineContext;->INSTANCE:Lkotlin/coroutines/EmptyCoroutineContext;

    .line 160
    check-cast v4, Lkotlin/coroutines/h;

    invoke-static {v4, v6}, Landroidx/compose/runtime/EffectsKt;->createCompositionCoroutineScope(Lkotlin/coroutines/h;Landroidx/compose/runtime/Composer;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v4

    .line 165
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 160
    :cond_1
    check-cast v4, Lkotlinx/coroutines/CoroutineScope;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 154
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v5, 0x53d2ef76

    .line 87
    const-string v9, "CC(remember):IconMotion.kt#9igjgp"

    invoke-static {v6, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    .line 168
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-nez v5, :cond_2

    .line 169
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v7, v5, :cond_3

    .line 87
    :cond_2
    new-instance v7, Ldev/nino/squareglass/material/InteractiveHighlight;

    invoke-direct {v7, v4, v11, v10, v11}, Ldev/nino/squareglass/material/InteractiveHighlight;-><init>(Lkotlinx/coroutines/CoroutineScope;Lam0/p;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 171
    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 87
    :cond_3
    move-object v14, v7

    check-cast v14, Ldev/nino/squareglass/material/InteractiveHighlight;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d2f7c8

    .line 88
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 174
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 175
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    const/4 v12, 0x0

    if-ne v4, v5, :cond_4

    .line 88
    invoke-static {v12}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v4

    .line 177
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 88
    :cond_4
    move-object v15, v4

    check-cast v15, Landroidx/compose/runtime/MutableIntState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d2fe8d

    .line 89
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 180
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 181
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_5

    .line 89
    sget-object v4, Landroidx/compose/ui/geometry/Rect;->Companion:Landroidx/compose/ui/geometry/Rect$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/geometry/Rect$Companion;->getZero()Landroidx/compose/ui/geometry/Rect;

    move-result-object v4

    invoke-static {v4, v11, v10, v11}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 183
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 89
    :cond_5
    move-object/from16 v16, v4

    check-cast v16, Landroidx/compose/runtime/MutableState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d3060b

    .line 90
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 186
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 187
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_6

    const-wide/16 v4, -0x4e20

    .line 90
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-static {v4, v11, v10, v11}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 189
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 90
    :cond_6
    move-object v13, v4

    check-cast v13, Landroidx/compose/runtime/MutableState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d30de9

    .line 91
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 192
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 193
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_7

    .line 91
    invoke-static {v1, v11, v10, v11}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 195
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 91
    :cond_7
    move-object v10, v4

    check-cast v10, Landroidx/compose/runtime/MutableState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v4, 0x53d315ac

    .line 92
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 198
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .line 199
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_8

    .line 92
    invoke-static {v0}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v4

    .line 201
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 92
    :cond_8
    check-cast v4, Landroidx/compose/runtime/MutableIntState;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object/from16 v17, v13

    .line 93
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v13

    const v5, 0x53d32390

    .line 94
    invoke-static {v6, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 204
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .line 205
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_9

    .line 94
    new-instance v5, Ldev/nino/squareglass/IconMotion$4;

    invoke-direct {v5, v15}, Ldev/nino/squareglass/IconMotion$4;-><init>(Landroidx/compose/runtime/MutableIntState;)V

    .line 207
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 94
    :cond_9
    check-cast v5, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v7, 0x6

    .line 95
    invoke-static {v5, v6, v7}, Landroidx/compose/runtime/SnapshotStateKt;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/State;

    move-result-object v7

    .line 96
    invoke-static/range {v16 .. v16}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$5(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/geometry/Rect;

    move-result-object v11

    invoke-static {v11, v6, v12}, Landroidx/compose/runtime/SnapshotStateKt;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/State;

    move-result-object v11

    move-object/from16 v18, v4

    .line 97
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const v12, 0x53d33e29

    invoke-static {v6, v12, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v12

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v19

    or-int v12, v12, v19

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v19

    or-int v12, v12, v19

    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v19

    or-int v12, v12, v19

    move-object/from16 v19, v4

    .line 210
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    if-nez v12, :cond_a

    .line 211
    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v4, v12, :cond_b

    .line 97
    :cond_a
    new-instance v4, Ldev/nino/squareglass/IconMotion$5;

    invoke-direct {v4, v11, v2, v3, v7}, Ldev/nino/squareglass/IconMotion$5;-><init>(Landroidx/compose/runtime/State;Landroid/view/View;Landroidx/lifecycle/Lifecycle;Landroidx/compose/runtime/State;)V

    .line 213
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 97
    :cond_b
    check-cast v4, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    shl-int/lit8 v7, v8, 0x3

    and-int/lit16 v7, v7, 0x380

    move-object v12, v5

    move-object/from16 v11, v18

    move-object v5, v4

    move-object/from16 v4, v19

    invoke-static/range {v2 .. v7}, Landroidx/compose/runtime/EffectsKt;->DisposableEffect(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lam0/l;Landroidx/compose/runtime/Composer;I)V

    .line 111
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const v3, 0x53d3a337

    invoke-static {v6, v3, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v3, v8, 0x380

    xor-int/lit16 v3, v3, 0x180

    const/4 v4, 0x1

    const/16 v5, 0x100

    if-le v3, v5, :cond_c

    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v3

    if-nez v3, :cond_d

    :cond_c
    and-int/lit16 v3, v8, 0x180

    if-ne v3, v5, :cond_e

    :cond_d
    move v3, v4

    goto :goto_0

    :cond_e
    const/4 v3, 0x0

    .line 216
    :goto_0
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    if-nez v3, :cond_f

    .line 217
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v5, v3, :cond_10

    .line 111
    :cond_f
    new-instance v3, Ldev/nino/squareglass/IconMotion$decorate$2$1;

    const/4 v5, 0x0

    invoke-direct {v3, v0, v12, v11, v5}, Ldev/nino/squareglass/IconMotion$decorate$2$1;-><init>(ILam0/l;Landroidx/compose/runtime/MutableIntState;Lkotlin/coroutines/e;)V

    move-object v5, v3

    check-cast v5, Lam0/p;

    .line 219
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 111
    :cond_10
    check-cast v5, Lam0/p;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    shr-int/lit8 v0, v8, 0x6

    and-int/lit8 v0, v0, 0xe

    invoke-static {v2, v5, v6, v0}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lam0/p;Landroidx/compose/runtime/Composer;I)V

    const v0, 0x53d3b1d3

    .line 114
    invoke-static {v6, v0, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v0, v8, 0x1c00

    xor-int/lit16 v0, v0, 0xc00

    const/16 v2, 0x800

    if-le v0, v2, :cond_11

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_13

    :cond_11
    and-int/lit16 v0, v8, 0xc00

    if-ne v0, v2, :cond_12

    goto :goto_1

    :cond_12
    const/4 v4, 0x0

    .line 222
    :cond_13
    :goto_1
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    if-nez v4, :cond_15

    .line 223
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v0, v2, :cond_14

    goto :goto_2

    :cond_14
    move-object/from16 v4, v17

    goto :goto_3

    .line 114
    :cond_15
    :goto_2
    new-instance v0, Ldev/nino/squareglass/IconMotion$decorate$3$1;

    const/4 v5, 0x0

    move-object v3, v10

    move-object v2, v12

    move-object/from16 v4, v17

    invoke-direct/range {v0 .. v5}, Ldev/nino/squareglass/IconMotion$decorate$3$1;-><init>(Ljava/lang/Boolean;Lam0/l;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V

    check-cast v0, Lam0/p;

    .line 225
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 114
    :goto_3
    check-cast v0, Lam0/p;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    shr-int/lit8 v2, v8, 0x9

    and-int/lit8 v2, v2, 0xe

    invoke-static {v1, v0, v6, v2}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lam0/p;Landroidx/compose/runtime/Composer;I)V

    .line 124
    invoke-static {v15}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const v2, 0x53d3df18

    invoke-static {v6, v2, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v13}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v2

    invoke-interface {v6, v14}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .line 228
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    if-nez v2, :cond_17

    .line 229
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v3, v2, :cond_16

    goto :goto_4

    :cond_16
    move-object v5, v3

    move-object/from16 v3, v16

    const/4 v2, 0x0

    goto :goto_5

    .line 124
    :cond_17
    :goto_4
    new-instance v12, Ldev/nino/squareglass/IconMotion$decorate$4$1;

    const/16 v17, 0x0

    const/4 v2, 0x0

    invoke-direct/range {v12 .. v17}, Ldev/nino/squareglass/IconMotion$decorate$4$1;-><init>(ZLdev/nino/squareglass/material/InteractiveHighlight;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/e;)V

    move-object/from16 v3, v16

    move-object v5, v12

    check-cast v5, Lam0/p;

    .line 231
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 124
    :goto_5
    check-cast v5, Lam0/p;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v1, v5, v6, v2}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Lam0/p;Landroidx/compose/runtime/Composer;I)V

    .line 128
    sget-object v0, Ldev/nino/squareglass/GlassMotion;->INSTANCE:Ldev/nino/squareglass/GlassMotion;

    move-object/from16 v1, p1

    invoke-virtual {v0, v1, v14}, Ldev/nino/squareglass/GlassMotion;->glyph(Landroidx/compose/ui/Modifier;Ldev/nino/squareglass/material/InteractiveHighlight;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-virtual {v14}, Ldev/nino/squareglass/material/InteractiveHighlight;->getGestureModifier()Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-interface {v0, v1}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const v1, 0x53d3ff85

    .line 129
    invoke-static {v6, v1, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 234
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .line 235
    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_18

    .line 129
    new-instance v1, Ldev/nino/squareglass/IconMotion$6;

    invoke-direct {v1, v3}, Ldev/nino/squareglass/IconMotion$6;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 237
    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 129
    :cond_18
    check-cast v1, Lam0/l;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v1}, Landroidx/compose/ui/layout/OnGloballyPositionedModifierKt;->onGloballyPositioned(Landroidx/compose/ui/Modifier;Lam0/l;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 130
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const v2, 0x53d40a86

    invoke-static {v6, v2, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 240
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .line 241
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v2, v3, :cond_19

    .line 130
    new-instance v2, Ldev/nino/squareglass/IconMotion$decorate$6$1;

    invoke-direct {v2, v4}, Ldev/nino/squareglass/IconMotion$decorate$6$1;-><init>(Landroidx/compose/runtime/MutableState;)V

    check-cast v2, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 243
    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 130
    :cond_19
    check-cast v2, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v1, v2}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 82
    :cond_1a
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object v0
.end method

.method private static final decorate$lambda$11(Landroidx/compose/runtime/MutableState;)Ljava/lang/Boolean;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Boolean;"
        }
    .end annotation

    .line 91
    check-cast p0, Landroidx/compose/runtime/State;

    .line 260
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    return-object p0
.end method

.method private static final decorate$lambda$12(Landroidx/compose/runtime/MutableState;Ljava/lang/Boolean;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Ljava/lang/Boolean;",
            ")V"
        }
    .end annotation

    .line 261
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final decorate$lambda$14(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 92
    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 263
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method private static final decorate$lambda$15(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0

    .line 264
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method private static final decorate$lambda$16$0(Landroidx/compose/runtime/MutableIntState;I)Lkotlin/u;
    .locals 0

    .line 94
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {p0}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I

    move-result p1

    add-int/lit8 p1, p1, 0x1

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$3(Landroidx/compose/runtime/MutableIntState;I)V

    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final decorate$lambda$17$0(Landroidx/compose/runtime/State;Landroid/view/View;Landroidx/lifecycle/Lifecycle;Landroidx/compose/runtime/State;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .locals 2

    const-string v0, "$this$DisposableEffect"

    invoke-static {p4, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p4, 0x2

    .line 98
    new-array p4, p4, [I

    .line 99
    new-instance v0, Ldev/nino/squareglass/IconMotion$Entry;

    new-instance v1, Ldev/nino/squareglass/IconMotion$2;

    invoke-direct {v1, p0, p1, p4, p2}, Ldev/nino/squareglass/IconMotion$2;-><init>(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)V

    new-instance p0, Ldev/nino/squareglass/IconMotion$3;

    invoke-direct {p0, p3}, Ldev/nino/squareglass/IconMotion$3;-><init>(Landroidx/compose/runtime/State;)V

    invoke-direct {v0, v1, p0}, Ldev/nino/squareglass/IconMotion$Entry;-><init>(Lam0/a;Lam0/l;)V

    .line 107
    sget-object p0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz p1, :cond_0

    .line 108
    sget-object p0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    sget-object p1, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    check-cast p1, Ljava/lang/Runnable;

    const-wide/16 p2, 0x1f4

    invoke-virtual {p0, p1, p2, p3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 246
    :cond_0
    new-instance p0, Ldev/nino/squareglass/IconMotion$decorate$lambda$17$0$$inlined$onDispose$1;

    invoke-direct {p0, v0}, Ldev/nino/squareglass/IconMotion$decorate$lambda$17$0$$inlined$onDispose$1;-><init>(Ldev/nino/squareglass/IconMotion$Entry;)V

    check-cast p0, Landroidx/compose/runtime/DisposableEffectResult;

    return-object p0
.end method

.method private static final decorate$lambda$17$0$0(Landroidx/compose/runtime/State;Landroid/view/View;[ILandroidx/lifecycle/Lifecycle;)Z
    .locals 11

    .line 100
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/geometry/Rect;

    .line 101
    invoke-virtual {p1, p2}, Landroid/view/View;->getLocationInWindow([I)V

    .line 102
    invoke-virtual {p1}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-static {}, Landroid/view/WindowInsets$Type;->ime()I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/view/WindowInsets;->isVisible(I)Z

    move-result v0

    if-ne v0, v1, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    .line 103
    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->isShown()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-virtual {p1}, Landroid/view/View;->hasWindowFocus()Z

    move-result v3

    if-eqz v3, :cond_1

    if-nez v0, :cond_1

    .line 104
    invoke-virtual {p3}, Landroidx/lifecycle/Lifecycle;->getCurrentState()Landroidx/lifecycle/Lifecycle$State;

    move-result-object p3

    sget-object v0, Landroidx/lifecycle/Lifecycle$State;->RESUMED:Landroidx/lifecycle/Lifecycle$State;

    invoke-virtual {p3, v0}, Landroidx/lifecycle/Lifecycle$State;->isAtLeast(Landroidx/lifecycle/Lifecycle$State;)Z

    move-result p3

    if-eqz p3, :cond_1

    .line 105
    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getLeft()F

    move-result v3

    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getTop()F

    move-result v4

    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getRight()F

    move-result v5

    invoke-virtual {p0}, Landroidx/compose/ui/geometry/Rect;->getBottom()F

    move-result v6

    aget p0, p2, v2

    int-to-float v7, p0

    aget p0, p2, v1

    int-to-float v8, p0

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p0

    int-to-float v9, p0

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p0

    int-to-float v10, p0

    invoke-static/range {v3 .. v10}, Ldev/nino/squareglass/MotionPolicy;->visible(FFFFFFFF)Z

    move-result p0

    if-eqz p0, :cond_1

    return v1

    :cond_1
    return v2
.end method

.method private static final decorate$lambda$17$0$1(Landroidx/compose/runtime/State;I)Lkotlin/u;
    .locals 0

    .line 106
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lam0/l;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, p1}, Lam0/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final decorate$lambda$2(Landroidx/compose/runtime/MutableIntState;)I
    .locals 0

    .line 88
    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 251
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method private static final decorate$lambda$21$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/layout/LayoutCoordinates;)Lkotlin/u;
    .locals 1

    const-string v0, "it"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 129
    invoke-static {p1}, Landroidx/compose/ui/layout/LayoutCoordinatesKt;->boundsInWindow(Landroidx/compose/ui/layout/LayoutCoordinates;)Landroidx/compose/ui/geometry/Rect;

    move-result-object p1

    invoke-static {p0, p1}, Ldev/nino/squareglass/IconMotion;->decorate$lambda$6(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/geometry/Rect;)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method private static final decorate$lambda$3(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0

    .line 252
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method private static final decorate$lambda$5(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/geometry/Rect;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Landroidx/compose/ui/geometry/Rect;",
            ">;)",
            "Landroidx/compose/ui/geometry/Rect;"
        }
    .end annotation

    .line 89
    check-cast p0, Landroidx/compose/runtime/State;

    .line 254
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/compose/ui/geometry/Rect;

    return-object p0
.end method

.method private static final decorate$lambda$6(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/geometry/Rect;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Landroidx/compose/ui/geometry/Rect;",
            ">;",
            "Landroidx/compose/ui/geometry/Rect;",
            ")V"
        }
    .end annotation

    .line 255
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private static final decorate$lambda$8(Landroidx/compose/runtime/MutableState;)J
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;)J"
        }
    .end annotation

    .line 90
    check-cast p0, Landroidx/compose/runtime/State;

    .line 257
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    return-wide v0
.end method

.method private static final decorate$lambda$9(Landroidx/compose/runtime/MutableState;J)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Long;",
            ">;J)V"
        }
    .end annotation

    .line 90
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    .line 258
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static final favorite(Landroidx/compose/ui/Modifier;ZLandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 10

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(favorite)N(original,liked)78@3605L28:IconMotion.kt#vqphja"

    const v1, -0x2e6fcbec

    .line 79
    invoke-static {p2, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.IconMotion.favorite (IconMotion.kt:78)"

    invoke-static {v1, p3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    sget-object v3, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    and-int/lit8 p1, p3, 0xe

    or-int/lit16 p1, p1, 0x1b0

    shl-int/lit8 p3, p3, 0x6

    and-int/lit16 v0, p3, 0x1c00

    or-int/2addr p1, v0

    const v0, 0xe000

    and-int/2addr p3, v0

    or-int v9, p1, p3

    const/4 v5, 0x7

    const/4 v6, 0x0

    move-object v4, p0

    move-object v8, p2

    invoke-direct/range {v3 .. v9}, Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method private final interacted(Z)V
    .locals 2

    .line 53
    sget-object p0, Ldev/nino/squareglass/IconMotion;->policy:Ldev/nino/squareglass/MotionPolicy;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1, p1}, Ldev/nino/squareglass/MotionPolicy;->touch(JZ)V

    return-void
.end method

.method public static final registerNative(Landroid/view/View;Ljava/util/function/IntConsumer;)Ljava/lang/Object;
    .locals 3

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fire"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    new-instance v0, Ldev/nino/squareglass/IconMotion$Entry;

    new-instance v1, Ldev/nino/squareglass/IconMotion$0;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/IconMotion$0;-><init>(Landroid/view/View;)V

    new-instance p0, Ldev/nino/squareglass/IconMotion$1;

    invoke-direct {p0, p1}, Ldev/nino/squareglass/IconMotion$1;-><init>(Ljava/util/function/IntConsumer;)V

    invoke-direct {v0, v1, p0}, Ldev/nino/squareglass/IconMotion$Entry;-><init>(Lam0/a;Lam0/l;)V

    .line 60
    sget-object p0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz p1, :cond_0

    .line 61
    sget-object p0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    sget-object p1, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    check-cast p1, Ljava/lang/Runnable;

    const-wide/16 v1, 0x1f4

    invoke-virtual {p0, p1, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-object v0
.end method

.method static final registerNative$lambda$0(Landroid/view/View;)Z
    .locals 2

    .line 56
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 57
    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->hasWindowFocus()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0, v0}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 58
    invoke-virtual {p0}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object p0

    const/4 v0, 0x1

    if-eqz p0, :cond_0

    invoke-static {}, Landroid/view/WindowInsets$Type;->ime()I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/WindowInsets;->isVisible(I)Z

    move-result p0

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    return v0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return p0
.end method

.method static final registerNative$lambda$1(Ljava/util/function/IntConsumer;I)Lkotlin/u;
    .locals 0

    .line 59
    invoke-interface {p0, p1}, Ljava/util/function/IntConsumer;->accept(I)V

    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final settings(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 10

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(settings)N(original)75@3331L27:IconMotion.kt#vqphja"

    const v1, -0x29fba5af

    .line 76
    invoke-static {p1, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.IconMotion.settings (IconMotion.kt:75)"

    invoke-static {v1, p2, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    sget-object v3, Ldev/nino/squareglass/IconMotion;->INSTANCE:Ldev/nino/squareglass/IconMotion;

    and-int/lit8 v0, p2, 0xe

    or-int/lit16 v0, v0, 0xdb0

    shl-int/lit8 p2, p2, 0x9

    const v1, 0xe000

    and-int/2addr p2, v1

    or-int v9, v0, p2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v4, p0

    move-object v8, p1

    invoke-direct/range {v3 .. v9}, Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method public static final settingsResource(Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 3

    const-string v0, "original"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(settingsResource)N(original,resource):IconMotion.kt#vqphja"

    const v1, -0x51ec8cba

    .line 78
    invoke-static {p2, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.IconMotion.settingsResource (IconMotion.kt:77)"

    invoke-static {v1, p3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    const v0, 0x7f08048e

    if-ne p1, v0, :cond_1

    const p1, 0x7703c638

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string p1, "77@3485L18"

    invoke-static {p2, p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 p1, p3, 0xe

    shr-int/lit8 p3, p3, 0x3

    and-int/lit8 p3, p3, 0x70

    or-int/2addr p1, p3

    invoke-static {p0, p2, p1}, Ldev/nino/squareglass/IconMotion;->settings(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    goto :goto_0

    :cond_1
    const p1, 0x7703c92e

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_0
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_2
    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method public static final touch(Landroid/view/MotionEvent;)V
    .locals 5

    const-string v0, "event"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 50
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p0

    .line 51
    sget-object v0, Ldev/nino/squareglass/IconMotion;->policy:Ldev/nino/squareglass/MotionPolicy;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    const/4 v3, 0x1

    if-eq p0, v3, :cond_0

    const/4 v4, 0x3

    if-eq p0, v4, :cond_0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    :goto_0
    invoke-virtual {v0, v1, v2, v3}, Ldev/nino/squareglass/MotionPolicy;->touch(JZ)V

    return-void
.end method

.method public static final unregisterNative(Ljava/lang/Object;)V
    .locals 1

    const-string v0, "token"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    sget-object v0, Ldev/nino/squareglass/IconMotion;->entries:Ljava/util/ArrayList;

    check-cast p0, Ldev/nino/squareglass/IconMotion$Entry;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_0

    sget-object p0, Ldev/nino/squareglass/IconMotion;->handler:Landroid/os/Handler;

    sget-object v0, Ldev/nino/squareglass/IconMotion;->tick:Ldev/nino/squareglass/IconMotion$tick$1;

    check-cast v0, Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public final icon(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;
    .locals 8

    const-string v0, "original"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C(icon)N(original,key,pulse)79@3711L33:IconMotion.kt#vqphja"

    const v1, -0x30ec217f

    .line 80
    invoke-static {p4, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v2, "dev.nino.squareglass.IconMotion.icon (IconMotion.kt:79)"

    invoke-static {v1, p5, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_0
    and-int/lit8 v0, p5, 0xe

    or-int/lit16 v0, v0, 0xc00

    and-int/lit8 v1, p5, 0x70

    or-int/2addr v0, v1

    and-int/lit16 v1, p5, 0x380

    or-int/2addr v0, v1

    shl-int/lit8 p5, p5, 0x3

    const v1, 0xe000

    and-int/2addr p5, v1

    or-int v7, v0, p5

    const/4 v5, 0x0

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    move-object v6, p4

    invoke-direct/range {v1 .. v7}, Ldev/nino/squareglass/IconMotion;->decorate(Landroidx/compose/ui/Modifier;IILjava/lang/Boolean;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;

    move-result-object p0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    return-object p0
.end method

.method public final watch(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;
    .locals 1

    const-string p0, "original"

    invoke-static {p1, p0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 67
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    sget-object v0, Ldev/nino/squareglass/IconMotion$watch$1;->INSTANCE:Ldev/nino/squareglass/IconMotion$watch$1;

    check-cast v0, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    invoke-static {p1, p0, v0}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Landroidx/compose/ui/Modifier;

    move-result-object p0

    return-object p0
.end method
