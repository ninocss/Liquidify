.class final Ldev/nino/squareglass/SquareExplore$Binding;
.super Ljava/lang/Object;
.source "SquareExplore.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;
.implements Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareExplore;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Binding"
.end annotation


# instance fields
.field final lists:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/recyclerview/widget/RecyclerView;",
            ">;"
        }
    .end annotation
.end field

.field final root:Landroid/view/View;


# direct methods
.method public static synthetic $r8$lambda$As3g_LihEb-QUqlcteanAIsVXlQ(Ldev/nino/squareglass/SquareExplore$Binding;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Ldev/nino/squareglass/SquareExplore$Binding;->lambda$onChildViewAttachedToWindow$0(Landroid/view/View;)V

    return-void
.end method

.method constructor <init>(Landroid/view/View;)V
    .locals 1

    .line 63
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 62
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/SquareExplore$Binding;->lists:Ljava/util/ArrayList;

    .line 63
    iput-object p1, p0, Ldev/nino/squareglass/SquareExplore$Binding;->root:Landroid/view/View;

    return-void
.end method

.method private synthetic lambda$onChildViewAttachedToWindow$0(Landroid/view/View;)V
    .locals 1

    .line 83
    invoke-virtual {p1}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/SquareExplore$Binding;->paint(Landroid/view/View;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public onChildViewAttachedToWindow(Landroid/view/View;)V
    .locals 1

    .line 83
    new-instance v0, Ldev/nino/squareglass/SquareExplore$Binding$0;

    invoke-direct {v0, p0, p1}, Ldev/nino/squareglass/SquareExplore$Binding$0;-><init>(Ldev/nino/squareglass/SquareExplore$Binding;Landroid/view/View;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onChildViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    .line 85
    iget-object p1, p0, Ldev/nino/squareglass/SquareExplore$Binding;->root:Landroid/view/View;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/SquareExplore$Binding;->paint(Landroid/view/View;)V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    .line 87
    iget-object p1, p0, Ldev/nino/squareglass/SquareExplore$Binding;->lists:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->removeOnChildAttachStateChangeListener(Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;)V

    goto :goto_0

    .line 88
    :cond_0
    iget-object p0, p0, Ldev/nino/squareglass/SquareExplore$Binding;->lists:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method paint(Landroid/view/View;)V
    .locals 5

    .line 65
    instance-of v0, p1, Landroid/widget/TextView;

    if-eqz v0, :cond_1

    .line 66
    move-object v0, p1

    check-cast v0, Landroid/widget/TextView;

    .line 67
    invoke-virtual {v0}, Landroid/widget/TextView;->getCurrentTextColor()I

    move-result v1

    .line 68
    invoke-static {v1}, Landroid/graphics/Color;->red(I)I

    move-result v2

    invoke-static {v1}, Landroid/graphics/Color;->green(I)I

    move-result v3

    invoke-static {v1}, Landroid/graphics/Color;->blue(I)I

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 69
    invoke-static {v1}, Landroid/graphics/Color;->red(I)I

    move-result v3

    invoke-static {v1}, Landroid/graphics/Color;->green(I)I

    move-result v4

    invoke-static {v1}, Landroid/graphics/Color;->blue(I)I

    move-result v1

    invoke-static {v4, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    sub-int v1, v2, v1

    const/16 v3, 0x19

    if-ge v1, v3, :cond_1

    const/16 v1, 0xdc

    if-ge v2, v1, :cond_0

    const/16 v1, 0x32

    if-gt v2, v1, :cond_1

    .line 71
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v1

    invoke-static {v1}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 73
    :cond_1
    instance-of v0, p1, Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_2

    iget-object v0, p0, Ldev/nino/squareglass/SquareExplore$Binding;->lists:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 74
    move-object v0, p1

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 75
    iget-object v1, p0, Ldev/nino/squareglass/SquareExplore$Binding;->lists:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 76
    invoke-virtual {v0, p0}, Landroidx/recyclerview/widget/RecyclerView;->addOnChildAttachStateChangeListener(Landroidx/recyclerview/widget/RecyclerView$OnChildAttachStateChangeListener;)V

    .line 78
    :cond_2
    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_3

    .line 79
    check-cast p1, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    .line 80
    :goto_0
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_3

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Ldev/nino/squareglass/SquareExplore$Binding;->paint(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method
