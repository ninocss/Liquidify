.class public final synthetic Ldev/nino/squareglass/LinnPlayer$24;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$24;->f$0:Ldev/nino/squareglass/LinnPlayer;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$24;->f$0:Ldev/nino/squareglass/LinnPlayer;

    check-cast p1, Ldev/nino/squareglass/LinnEvent;

    invoke-virtual {p0, p1}, Ldev/nino/squareglass/LinnPlayer;->eventReceived(Ldev/nino/squareglass/LinnEvent;)V

    return-void
.end method
