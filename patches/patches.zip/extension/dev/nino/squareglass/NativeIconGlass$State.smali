.class final Ldev/nino/squareglass/NativeIconGlass$State;
.super Ljava/lang/Object;
.source "NativeIconGlass.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/NativeIconGlass;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "State"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0006\n\u0002\u0010\u0007\n\u0002\u0008\u0013\n\u0002\u0010\t\n\u0002\u0008\u0005\u0008\u0002\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\"\u0004\u0008\u0008\u0010\u0005R\u001a\u0010\t\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000b\u0010\u000c\"\u0004\u0008\r\u0010\u000eR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\u0001X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011\"\u0004\u0008\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0015\u0010\u000c\"\u0004\u0008\u0016\u0010\u000eR\u001a\u0010\u0017\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0018\u0010\u000c\"\u0004\u0008\u0019\u0010\u000eR\u001a\u0010\u001a\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001b\u0010\u0007\"\u0004\u0008\u001c\u0010\u0005R\u001a\u0010\u001d\u001a\u00020\u001eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001f\u0010 \"\u0004\u0008!\u0010\"\u00a8\u0006#"
    }
    d2 = {
        "Ldev/nino/squareglass/NativeIconGlass$State;",
        "",
        "selected",
        "",
        "<init>",
        "(Z)V",
        "getSelected",
        "()Z",
        "setSelected",
        "progress",
        "",
        "getProgress",
        "()F",
        "setProgress",
        "(F)V",
        "token",
        "getToken",
        "()Ljava/lang/Object;",
        "setToken",
        "(Ljava/lang/Object;)V",
        "x",
        "getX",
        "setX",
        "y",
        "getY",
        "setY",
        "moved",
        "getMoved",
        "setMoved",
        "tap",
        "",
        "getTap",
        "()J",
        "setTap",
        "(J)V",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private moved:Z

.field private progress:F

.field private selected:Z

.field private tap:J

.field private token:Ljava/lang/Object;

.field private x:F

.field private y:F


# direct methods
.method public constructor <init>(Z)V
    .locals 2

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->selected:Z

    const/high16 p1, 0x3f800000    # 1.0f

    .line 17
    iput p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->progress:F

    const-wide/16 v0, -0x4e20

    .line 22
    iput-wide v0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->tap:J

    return-void
.end method


# virtual methods
.method public final getMoved()Z
    .locals 0

    .line 21
    iget-boolean p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->moved:Z

    return p0
.end method

.method public final getProgress()F
    .locals 0

    .line 17
    iget p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->progress:F

    return p0
.end method

.method public final getSelected()Z
    .locals 0

    .line 16
    iget-boolean p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->selected:Z

    return p0
.end method

.method public final getTap()J
    .locals 2

    .line 22
    iget-wide v0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->tap:J

    return-wide v0
.end method

.method public final getToken()Ljava/lang/Object;
    .locals 0

    .line 18
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->token:Ljava/lang/Object;

    return-object p0
.end method

.method public final getX()F
    .locals 0

    .line 19
    iget p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->x:F

    return p0
.end method

.method public final getY()F
    .locals 0

    .line 20
    iget p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->y:F

    return p0
.end method

.method public final setMoved(Z)V
    .locals 0

    .line 21
    iput-boolean p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->moved:Z

    return-void
.end method

.method public final setProgress(F)V
    .locals 0

    .line 17
    iput p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->progress:F

    return-void
.end method

.method public final setSelected(Z)V
    .locals 0

    .line 16
    iput-boolean p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->selected:Z

    return-void
.end method

.method public final setTap(J)V
    .locals 0

    .line 22
    iput-wide p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->tap:J

    return-void
.end method

.method public final setToken(Ljava/lang/Object;)V
    .locals 0

    .line 18
    iput-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->token:Ljava/lang/Object;

    return-void
.end method

.method public final setX(F)V
    .locals 0

    .line 19
    iput p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->x:F

    return-void
.end method

.method public final setY(F)V
    .locals 0

    .line 20
    iput p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->y:F

    return-void
.end method
