.class final Ldev/nino/squareglass/NativeIconGlass$State;
.super Ljava/lang/Object;
.source "NativeIconGlass.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/NativeIconGlass;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "State"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nNativeIconGlass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NativeIconGlass.kt\ndev/nino/squareglass/NativeIconGlass$State\n+ 2 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n*L\n1#1,87:1\n78#2:88\n111#2,2:89\n*S KotlinDebug\n*F\n+ 1 NativeIconGlass.kt\ndev/nino/squareglass/NativeIconGlass$State\n*L\n24#1:88\n24#1:89,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\t\n\u0002\u0010\u0008\n\u0002\u0008\r\n\u0002\u0010\u0007\n\u0002\u0008\u000b\n\u0002\u0010\t\n\u0002\u0008\u0005\u0008\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\n\u0010\u000b\"\u0004\u0008\u000c\u0010\rR+\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u0015\u0010\u0016\u001a\u0004\u0008\u0011\u0010\u0012\"\u0004\u0008\u0013\u0010\u0014R\u001c\u0010\u0017\u001a\u0004\u0018\u00010\u0001X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0018\u0010\u0019\"\u0004\u0008\u001a\u0010\u001bR\u001a\u0010\u001c\u001a\u00020\u001dX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001e\u0010\u001f\"\u0004\u0008 \u0010!R\u001a\u0010\"\u001a\u00020\u001dX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008#\u0010\u001f\"\u0004\u0008$\u0010!R\u001a\u0010%\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008&\u0010\u000b\"\u0004\u0008\'\u0010\rR\u001a\u0010(\u001a\u00020)X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008*\u0010+\"\u0004\u0008,\u0010-\u00a8\u0006."
    }
    d2 = {
        "Ldev/nino/squareglass/NativeIconGlass$State;",
        "",
        "paint",
        "Landroidx/compose/ui/platform/ComposeView;",
        "selected",
        "",
        "<init>",
        "(Landroidx/compose/ui/platform/ComposeView;Z)V",
        "getPaint",
        "()Landroidx/compose/ui/platform/ComposeView;",
        "getSelected",
        "()Z",
        "setSelected",
        "(Z)V",
        "<set-?>",
        "",
        "event",
        "getEvent",
        "()I",
        "setEvent",
        "(I)V",
        "event$delegate",
        "Landroidx/compose/runtime/MutableIntState;",
        "token",
        "getToken",
        "()Ljava/lang/Object;",
        "setToken",
        "(Ljava/lang/Object;)V",
        "x",
        "",
        "getX",
        "()F",
        "setX",
        "(F)V",
        "y",
        "getY",
        "setY",
        "moved",
        "getMoved",
        "setMoved",
        "tap",
        "",
        "getTap",
        "()J",
        "setTap",
        "(J)V",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final event$delegate:Landroidx/compose/runtime/MutableIntState;

.field private moved:Z

.field private final paint:Landroidx/compose/ui/platform/ComposeView;

.field private selected:Z

.field private tap:J

.field private token:Ljava/lang/Object;

.field private x:F

.field private y:F


# direct methods
.method public constructor <init>(Landroidx/compose/ui/platform/ComposeView;Z)V
    .locals 1

    const-string v0, "paint"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->paint:Landroidx/compose/ui/platform/ComposeView;

    .line 23
    iput-boolean p2, p0, Ldev/nino/squareglass/NativeIconGlass$State;->selected:Z

    const/4 p1, 0x0

    .line 24
    invoke-static {p1}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object p1

    iput-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->event$delegate:Landroidx/compose/runtime/MutableIntState;

    const-wide/16 p1, -0x4e20

    .line 29
    iput-wide p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->tap:J

    return-void
.end method


# virtual methods
.method public final getEvent()I
    .locals 0

    .line 24
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->event$delegate:Landroidx/compose/runtime/MutableIntState;

    check-cast p0, Landroidx/compose/runtime/IntState;

    .line 88
    invoke-interface {p0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result p0

    return p0
.end method

.method public final getMoved()Z
    .locals 0

    .line 28
    iget-boolean p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->moved:Z

    return p0
.end method

.method public final getPaint()Landroidx/compose/ui/platform/ComposeView;
    .locals 0

    .line 22
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->paint:Landroidx/compose/ui/platform/ComposeView;

    return-object p0
.end method

.method public final getSelected()Z
    .locals 0

    .line 23
    iget-boolean p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->selected:Z

    return p0
.end method

.method public final getTap()J
    .locals 2

    .line 29
    iget-wide v0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->tap:J

    return-wide v0
.end method

.method public final getToken()Ljava/lang/Object;
    .locals 0

    .line 25
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->token:Ljava/lang/Object;

    return-object p0
.end method

.method public final getX()F
    .locals 0

    .line 26
    iget p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->x:F

    return p0
.end method

.method public final getY()F
    .locals 0

    .line 27
    iget p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->y:F

    return p0
.end method

.method public final setEvent(I)V
    .locals 0

    .line 24
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$State;->event$delegate:Landroidx/compose/runtime/MutableIntState;

    .line 89
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    return-void
.end method

.method public final setMoved(Z)V
    .locals 0

    .line 28
    iput-boolean p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->moved:Z

    return-void
.end method

.method public final setSelected(Z)V
    .locals 0

    .line 23
    iput-boolean p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->selected:Z

    return-void
.end method

.method public final setTap(J)V
    .locals 0

    .line 29
    iput-wide p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->tap:J

    return-void
.end method

.method public final setToken(Ljava/lang/Object;)V
    .locals 0

    .line 25
    iput-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->token:Ljava/lang/Object;

    return-void
.end method

.method public final setX(F)V
    .locals 0

    .line 26
    iput p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->x:F

    return-void
.end method

.method public final setY(F)V
    .locals 0

    .line 27
    iput p1, p0, Ldev/nino/squareglass/NativeIconGlass$State;->y:F

    return-void
.end method
