.class public final synthetic Ldev/nino/squareglass/PageCoordinator-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
