.class public final synthetic Ldev/nino/squareglass/LinnProvider$23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;

.field public final synthetic f$1:I

.field public final synthetic f$2:Lcom/aspiro/wamp/player/k0;

.field public final synthetic f$3:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$4:Ldev/nino/squareglass/LinnProvider$Device;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$23;->f$0:Ldev/nino/squareglass/LinnProvider;

    iput p2, p0, Ldev/nino/squareglass/LinnProvider$23;->f$1:I

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider$23;->f$2:Lcom/aspiro/wamp/player/k0;

    iput-object p4, p0, Ldev/nino/squareglass/LinnProvider$23;->f$3:Ldev/nino/squareglass/LinnPlayer;

    iput-object p5, p0, Ldev/nino/squareglass/LinnProvider$23;->f$4:Ldev/nino/squareglass/LinnProvider$Device;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$23;->f$0:Ldev/nino/squareglass/LinnProvider;

    iget v1, p0, Ldev/nino/squareglass/LinnProvider$23;->f$1:I

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider$23;->f$2:Lcom/aspiro/wamp/player/k0;

    iget-object v3, p0, Ldev/nino/squareglass/LinnProvider$23;->f$3:Ldev/nino/squareglass/LinnPlayer;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$23;->f$4:Ldev/nino/squareglass/LinnProvider$Device;

    invoke-static {v0, v1, v2, v3, p0}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$hIRLDwbtUAia8O8ExHPVTEozh5U(Ldev/nino/squareglass/LinnProvider;ILcom/aspiro/wamp/player/k0;Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnProvider$Device;)V

    return-void
.end method
