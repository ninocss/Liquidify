.class public final synthetic Ldev/nino/squareglass/NativeIconGlass$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/IntConsumer;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/NativeIconGlass$State;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/NativeIconGlass$State;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/NativeIconGlass$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/NativeIconGlass$State;

    return-void
.end method


# virtual methods
.method public final accept(I)V
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/NativeIconGlass$$ExternalSyntheticLambda0;->f$0:Ldev/nino/squareglass/NativeIconGlass$State;

    invoke-static {p0, p1}, Ldev/nino/squareglass/NativeIconGlass;->$r8$lambda$RizWUs0HSPXiKQyV9pVZqNB458w(Ldev/nino/squareglass/NativeIconGlass$State;I)V

    return-void
.end method
