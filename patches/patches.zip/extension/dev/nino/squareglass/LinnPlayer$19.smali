.class public final synthetic Ldev/nino/squareglass/LinnPlayer$19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnPlayer;

.field public final synthetic f$1:Ldev/nino/squareglass/LinnPlayer$Action;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer$Action;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnPlayer$19;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iput-object p2, p0, Ldev/nino/squareglass/LinnPlayer$19;->f$1:Ldev/nino/squareglass/LinnPlayer$Action;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer$19;->f$0:Ldev/nino/squareglass/LinnPlayer;

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer$19;->f$1:Ldev/nino/squareglass/LinnPlayer$Action;

    invoke-static {v0, p0}, Ldev/nino/squareglass/LinnPlayer;->$r8$lambda$k_IUIeTL_UJHZSkK8TWBSYa7lQg(Ldev/nino/squareglass/LinnPlayer;Ldev/nino/squareglass/LinnPlayer$Action;)V

    return-void
.end method
