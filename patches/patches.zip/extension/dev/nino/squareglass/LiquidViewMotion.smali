.class public final Ldev/nino/squareglass/LiquidViewMotion;
.super Ljava/lang/Object;
.source "LiquidViewMotion.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldev/nino/squareglass/LiquidViewMotion$Binding;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLiquidViewMotion.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LiquidViewMotion.kt\ndev/nino/squareglass/LiquidViewMotion\n+ 2 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,56:1\n410#2,3:57\n413#2,4:61\n1#3:60\n*S KotlinDebug\n*F\n+ 1 LiquidViewMotion.kt\ndev/nino/squareglass/LiquidViewMotion\n*L\n32#1:57,3\n32#1:61,4\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0008\u00c7\u0002\u0018\u00002\u00020\u0001:\u0001\u001aB\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\u000cH\u0007JN\u0010\r\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u00122\u000c\u0010\u0013\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u00142\u000e\u0010\u0015\u001a\n\u0018\u00010\u0016j\u0004\u0018\u0001`\u0017H\u0007J\u0018\u0010\u0018\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\u0012H\u0007R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001b"
    }
    d2 = {
        "Ldev/nino/squareglass/LiquidViewMotion;",
        "",
        "<init>",
        "()V",
        "bindings",
        "Ljava/util/WeakHashMap;",
        "Landroid/view/View;",
        "Ldev/nino/squareglass/LiquidViewMotion$Binding;",
        "cancel",
        "",
        "view",
        "key",
        "",
        "animate",
        "from",
        "",
        "target",
        "settle",
        "",
        "update",
        "Ljava/util/function/Consumer;",
        "finished",
        "Ljava/lang/Runnable;",
        "Lkotlinx/coroutines/Runnable;",
        "press",
        "pressed",
        "Binding",
        "extension_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Ldev/nino/squareglass/LiquidViewMotion;

.field private static final bindings:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ldev/nino/squareglass/LiquidViewMotion$Binding;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$V9QweJl28gSy7QpVcjQ4pjwHvkk(Ldev/nino/squareglass/LiquidViewMotion$Binding;Ljava/lang/String;Lkotlinx/coroutines/Job;Ljava/lang/Throwable;)Lkotlin/u;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ldev/nino/squareglass/LiquidViewMotion;->animate$lambda$1(Ldev/nino/squareglass/LiquidViewMotion$Binding;Ljava/lang/String;Lkotlinx/coroutines/Job;Ljava/lang/Throwable;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$nA6t1B3w4LErRG7UfnF0rxWN6bI(Landroid/view/View;Ljava/lang/Float;)V
    .locals 0

    invoke-static {p0, p1}, Ldev/nino/squareglass/LiquidViewMotion;->press$lambda$0(Landroid/view/View;Ljava/lang/Float;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ldev/nino/squareglass/LiquidViewMotion;

    invoke-direct {v0}, Ldev/nino/squareglass/LiquidViewMotion;-><init>()V

    sput-object v0, Ldev/nino/squareglass/LiquidViewMotion;->INSTANCE:Ldev/nino/squareglass/LiquidViewMotion;

    .line 24
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/LiquidViewMotion;->bindings:Ljava/util/WeakHashMap;

    const/16 v0, 0x8

    sput v0, Ldev/nino/squareglass/LiquidViewMotion;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$getBindings$p()Ljava/util/WeakHashMap;
    .locals 1

    .line 12
    sget-object v0, Ldev/nino/squareglass/LiquidViewMotion;->bindings:Ljava/util/WeakHashMap;

    return-object v0
.end method

.method public static final animate(Landroid/view/View;Ljava/lang/String;FFZLjava/util/function/Consumer;Ljava/lang/Runnable;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Ljava/lang/String;",
            "FFZ",
            "Ljava/util/function/Consumer<",
            "Ljava/lang/Float;",
            ">;",
            "Ljava/lang/Runnable;",
            ")V"
        }
    .end annotation

    move-object v5, p5

    const-string v1, "view"

    invoke-static {p0, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "key"

    invoke-static {p1, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "update"

    invoke-static {p5, v1}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    invoke-static/range {p0 .. p1}, Ldev/nino/squareglass/LiquidViewMotion;->cancel(Landroid/view/View;Ljava/lang/String;)V

    .line 31
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-static {p3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-interface {p5, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    if-eqz p6, :cond_0

    invoke-interface/range {p6 .. p6}, Ljava/lang/Runnable;->run()V

    :cond_0
    return-void

    .line 32
    :cond_1
    sget-object v1, Ldev/nino/squareglass/LiquidViewMotion;->bindings:Ljava/util/WeakHashMap;

    check-cast v1, Ljava/util/Map;

    .line 57
    invoke-interface {v1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_2

    .line 32
    new-instance v2, Ldev/nino/squareglass/LiquidViewMotion$Binding;

    invoke-direct {v2}, Ldev/nino/squareglass/LiquidViewMotion$Binding;-><init>()V

    move-object v3, v2

    check-cast v3, Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {p0, v3}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 61
    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    :cond_2
    move-object v0, v2

    check-cast v0, Ldev/nino/squareglass/LiquidViewMotion$Binding;

    .line 33
    invoke-virtual {v0}, Ldev/nino/squareglass/LiquidViewMotion$Binding;->getScope()Lkotlinx/coroutines/CoroutineScope;

    move-result-object v8

    sget-object v9, Lkotlinx/coroutines/CoroutineStart;->LAZY:Lkotlinx/coroutines/CoroutineStart;

    new-instance v1, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;

    const/4 v7, 0x0

    move v2, p2

    move v3, p3

    move v4, p4

    move-object/from16 v6, p6

    invoke-direct/range {v1 .. v7}, Ldev/nino/squareglass/LiquidViewMotion$animate$job$1;-><init>(FFZLjava/util/function/Consumer;Ljava/lang/Runnable;Lkotlin/coroutines/e;)V

    move-object v7, v5

    move-object v4, v1

    check-cast v4, Lam0/p;

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x0

    move-object v1, v8

    move-object v3, v9

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/h;Lkotlinx/coroutines/CoroutineStart;Lam0/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    move-result-object v1

    .line 41
    invoke-virtual {v0}, Ldev/nino/squareglass/LiquidViewMotion$Binding;->getJobs()Ljava/util/HashMap;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    invoke-interface {v2, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    new-instance v2, Ldev/nino/squareglass/LiquidViewMotion$$ExternalSyntheticLambda0;

    invoke-direct {v2, v0, p1, v1}, Ldev/nino/squareglass/LiquidViewMotion$$ExternalSyntheticLambda0;-><init>(Ldev/nino/squareglass/LiquidViewMotion$Binding;Ljava/lang/String;Lkotlinx/coroutines/Job;)V

    invoke-interface {v1, v2}, Lkotlinx/coroutines/Job;->invokeOnCompletion(Lam0/l;)Lkotlinx/coroutines/DisposableHandle;

    .line 43
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-interface {p5, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    .line 44
    invoke-interface {v1}, Lkotlinx/coroutines/Job;->start()Z

    return-void
.end method

.method private static final animate$lambda$1(Ldev/nino/squareglass/LiquidViewMotion$Binding;Ljava/lang/String;Lkotlinx/coroutines/Job;Ljava/lang/Throwable;)Lkotlin/u;
    .locals 0

    .line 42
    invoke-virtual {p0}, Ldev/nino/squareglass/LiquidViewMotion$Binding;->getJobs()Ljava/util/HashMap;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    if-ne p3, p2, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/LiquidViewMotion$Binding;->getJobs()Ljava/util/HashMap;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    sget-object p0, Lkotlin/u;->a:Lkotlin/u;

    return-object p0
.end method

.method public static final cancel(Landroid/view/View;Ljava/lang/String;)V
    .locals 1

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    sget-object v0, Ldev/nino/squareglass/LiquidViewMotion;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldev/nino/squareglass/LiquidViewMotion$Binding;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/LiquidViewMotion$Binding;->getJobs()Ljava/util/HashMap;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lkotlinx/coroutines/Job;

    if-eqz p0, :cond_0

    const/4 p1, 0x1

    const/4 v0, 0x0

    invoke-static {p0, v0, p1, v0}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    :cond_0
    return-void
.end method

.method public static final press(Landroid/view/View;Z)V
    .locals 7

    const-string v0, "view"

    invoke-static {p0, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p1, :cond_0

    .line 48
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->motion()Z

    move-result p1

    if-eqz p1, :cond_0

    const p1, 0x3f7851ec    # 0.97f

    goto :goto_0

    :cond_0
    const/high16 p1, 0x3f800000    # 1.0f

    :goto_0
    move v3, p1

    .line 49
    invoke-virtual {p0}, Landroid/view/View;->getScaleX()F

    move-result v2

    new-instance v5, Ldev/nino/squareglass/LiquidViewMotion$$ExternalSyntheticLambda1;

    invoke-direct {v5, p0}, Ldev/nino/squareglass/LiquidViewMotion$$ExternalSyntheticLambda1;-><init>(Landroid/view/View;)V

    const/4 v6, 0x0

    const-string v1, "press"

    const/4 v4, 0x0

    move-object v0, p0

    invoke-static/range {v0 .. v6}, Ldev/nino/squareglass/LiquidViewMotion;->animate(Landroid/view/View;Ljava/lang/String;FFZLjava/util/function/Consumer;Ljava/lang/Runnable;)V

    return-void
.end method

.method private static final press$lambda$0(Landroid/view/View;Ljava/lang/Float;)V
    .locals 2

    const-string v0, "scale"

    invoke-static {p1, v0}, Ldev/nino/squareglass/HostCompat;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 50
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    .line 52
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float p1, v0, p1

    const/high16 v1, 0x3f000000    # 0.5f

    mul-float/2addr p1, v1

    add-float/2addr p1, v0

    invoke-virtual {p0, p1}, Landroid/view/View;->setScaleY(F)V

    return-void
.end method
