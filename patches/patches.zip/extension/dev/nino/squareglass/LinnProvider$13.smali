.class public final synthetic Ldev/nino/squareglass/LinnProvider$13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ldev/nino/squareglass/LinnProvider;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Landroid/content/SharedPreferences;

.field public final synthetic f$3:Lcom/aspiro/wamp/player/k0;


# direct methods
.method public synthetic constructor <init>(Ldev/nino/squareglass/LinnProvider;Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/LinnProvider$13;->f$0:Ldev/nino/squareglass/LinnProvider;

    iput-object p2, p0, Ldev/nino/squareglass/LinnProvider$13;->f$1:Ljava/lang/String;

    iput-object p3, p0, Ldev/nino/squareglass/LinnProvider$13;->f$2:Landroid/content/SharedPreferences;

    iput-object p4, p0, Ldev/nino/squareglass/LinnProvider$13;->f$3:Lcom/aspiro/wamp/player/k0;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/LinnProvider$13;->f$0:Ldev/nino/squareglass/LinnProvider;

    iget-object v1, p0, Ldev/nino/squareglass/LinnProvider$13;->f$1:Ljava/lang/String;

    iget-object v2, p0, Ldev/nino/squareglass/LinnProvider$13;->f$2:Landroid/content/SharedPreferences;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider$13;->f$3:Lcom/aspiro/wamp/player/k0;

    invoke-static {v0, v1, v2, p0}, Ldev/nino/squareglass/LinnProvider;->$r8$lambda$v3WZyxs8NtaATzewWuwa7bNw200(Ldev/nino/squareglass/LinnProvider;Ljava/lang/String;Landroid/content/SharedPreferences;Lcom/aspiro/wamp/player/k0;)V

    return-void
.end method
