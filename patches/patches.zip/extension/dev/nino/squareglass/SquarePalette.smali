.class public final Ldev/nino/squareglass/SquarePalette;
.super Ljava/lang/Object;
.source "SquarePalette.java"


# static fields
.field private static final darkColors:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lf20/a;",
            ">;"
        }
    .end annotation
.end field

.field private static final lightColors:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lf20/a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 13
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquarePalette;->lightColors:Ljava/util/Map;

    .line 14
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Ldev/nino/squareglass/SquarePalette;->darkColors:Ljava/util/Map;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static alpha(II)I
    .locals 1

    const v0, 0xffffff

    and-int/2addr p0, v0

    shl-int/lit8 p1, p1, 0x18

    or-int/2addr p0, p1

    return p0
.end method

.method public static base(Z)I
    .locals 0

    if-eqz p0, :cond_0

    const p0, -0xf2f1ef

    return p0

    :cond_0
    const p0, -0xe0d0a

    return p0
.end method

.method public static ink(Z)I
    .locals 0

    if-eqz p0, :cond_0

    const p0, -0x80706

    return p0

    :cond_0
    const p0, -0xeae9e6

    return p0
.end method

.method public static inkColor()J
    .locals 2

    .line 25
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide v0

    return-wide v0
.end method

.method public static isDark()Z
    .locals 4

    .line 17
    invoke-static {}, Ldev/nino/squareglass/SquareSettings;->themeMode()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    if-ne v0, v3, :cond_0

    return v1

    :cond_0
    return v2

    .line 19
    :cond_1
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->uiMode:I

    and-int/lit8 v0, v0, 0x30

    const/16 v3, 0x20

    if-ne v0, v3, :cond_2

    return v1

    :cond_2
    return v2
.end method

.method public static market(Lf20/a;Ljava/lang/String;)Lf20/a;
    .locals 6

    .line 65
    sget-boolean v0, Ldev/nino/squareglass/ProbeDiagnostics;->enabled:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    sget v0, Ldev/nino/squareglass/ProbeDiagnostics;->marketPaletteCalls:I

    add-int/2addr v0, v1

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->marketPaletteCalls:I

    .line 66
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    .line 68
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, -0x1

    sparse-switch v2, :sswitch_data_0

    :goto_0
    move v1, v3

    goto/16 :goto_1

    :sswitch_0
    const-string v1, "emphasisText"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    const/16 v1, 0x16

    goto/16 :goto_1

    :sswitch_1
    const-string v1, "emphasisFill"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    const/16 v1, 0x15

    goto/16 :goto_1

    :sswitch_2
    const-string v1, "surface30"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    goto :goto_0

    :cond_3
    const/16 v1, 0x14

    goto/16 :goto_1

    :sswitch_3
    const-string v1, "surface20"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    goto :goto_0

    :cond_4
    const/16 v1, 0x13

    goto/16 :goto_1

    :sswitch_4
    const-string v1, "surface10"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    goto :goto_0

    :cond_5
    const/16 v1, 0x12

    goto/16 :goto_1

    :sswitch_5
    const-string v1, "textInverse"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    goto :goto_0

    :cond_6
    const/16 v1, 0x11

    goto/16 :goto_1

    :sswitch_6
    const-string v1, "emphasis40"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7

    goto :goto_0

    :cond_7
    const/16 v1, 0x10

    goto/16 :goto_1

    :sswitch_7
    const-string v1, "emphasis30"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8

    goto :goto_0

    :cond_8
    const/16 v1, 0xf

    goto/16 :goto_1

    :sswitch_8
    const-string v1, "emphasis20"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    goto :goto_0

    :cond_9
    const/16 v1, 0xe

    goto/16 :goto_1

    :sswitch_9
    const-string v1, "emphasis10"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    goto/16 :goto_0

    :cond_a
    const/16 v1, 0xd

    goto/16 :goto_1

    :sswitch_a
    const-string v1, "surfaceInverse"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    goto/16 :goto_0

    :cond_b
    const/16 v1, 0xc

    goto/16 :goto_1

    :sswitch_b
    const-string v1, "text30"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    goto/16 :goto_0

    :cond_c
    const/16 v1, 0xb

    goto/16 :goto_1

    :sswitch_c
    const-string v1, "text20"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d

    goto/16 :goto_0

    :cond_d
    const/16 v1, 0xa

    goto/16 :goto_1

    :sswitch_d
    const-string v1, "text10"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    goto/16 :goto_0

    :cond_e
    const/16 v1, 0x9

    goto/16 :goto_1

    :sswitch_e
    const-string v1, "fillInverse"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f

    goto/16 :goto_0

    :cond_f
    const/16 v1, 0x8

    goto :goto_1

    :sswitch_f
    const-string v1, "fill50"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    goto/16 :goto_0

    :cond_10
    const/4 v1, 0x7

    goto :goto_1

    :sswitch_10
    const-string v1, "fill40"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11

    goto/16 :goto_0

    :cond_11
    const/4 v1, 0x6

    goto :goto_1

    :sswitch_11
    const-string v1, "fill30"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12

    goto/16 :goto_0

    :cond_12
    const/4 v1, 0x5

    goto :goto_1

    :sswitch_12
    const-string v1, "fill20"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13

    goto/16 :goto_0

    :cond_13
    const/4 v1, 0x4

    goto :goto_1

    :sswitch_13
    const-string v1, "fill10"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_14

    goto/16 :goto_0

    :cond_14
    const/4 v1, 0x3

    goto :goto_1

    :sswitch_14
    const-string v1, "divider20"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_15

    goto/16 :goto_0

    :cond_15
    const/4 v1, 0x2

    goto :goto_1

    :sswitch_15
    const-string v2, "divider10"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_17

    goto/16 :goto_0

    :sswitch_16
    const-string v1, "surface5"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_16

    goto/16 :goto_0

    :cond_16
    const/4 v1, 0x0

    :cond_17
    :goto_1
    const/16 v2, 0x1a

    const/16 v3, 0x66

    const/16 v4, 0xb3

    const/16 v5, 0x33

    packed-switch v1, :pswitch_data_0

    return-object p0

    .line 82
    :pswitch_0
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    goto/16 :goto_2

    :pswitch_1
    if-eqz v0, :cond_18

    const v1, -0xcfcbc1

    goto/16 :goto_2

    :cond_18
    const v1, -0x1f1d15

    goto/16 :goto_2

    :pswitch_2
    if-eqz v0, :cond_19

    const v1, -0xdddad2

    goto/16 :goto_2

    :cond_19
    const v1, -0x161510

    goto/16 :goto_2

    .line 73
    :pswitch_3
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result v1

    goto/16 :goto_2

    .line 86
    :pswitch_4
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v4}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto/16 :goto_2

    .line 85
    :pswitch_5
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v3}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 84
    :pswitch_6
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v5}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 83
    :pswitch_7
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v2}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 71
    :pswitch_8
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->tertiary(Z)I

    move-result v1

    goto :goto_2

    .line 70
    :pswitch_9
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->secondary(Z)I

    move-result v1

    goto :goto_2

    .line 79
    :pswitch_a
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v2}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 78
    :pswitch_b
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v5}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 77
    :pswitch_c
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v3}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 76
    :pswitch_d
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v4}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 69
    :pswitch_e
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    goto :goto_2

    .line 81
    :pswitch_f
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    invoke-static {v1, v5}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 80
    :pswitch_10
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result v1

    const/16 v2, 0x1f

    invoke-static {v1, v2}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result v1

    goto :goto_2

    .line 72
    :pswitch_11
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result v1

    :goto_2
    if-eqz v0, :cond_1a

    .line 89
    sget-object v0, Ldev/nino/squareglass/SquarePalette;->darkColors:Ljava/util/Map;

    goto :goto_3

    :cond_1a
    sget-object v0, Ldev/nino/squareglass/SquarePalette;->lightColors:Ljava/util/Map;

    .line 90
    :goto_3
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lf20/a;

    if-nez v2, :cond_1b

    .line 91
    new-instance v2, Lf20/a;

    invoke-direct {v2, v1}, Lf20/a;-><init>(I)V

    invoke-interface {v0, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    :cond_1b
    invoke-virtual {p0}, Lf20/a;->k()I

    move-result p0

    invoke-virtual {v2}, Lf20/a;->k()I

    move-result v0

    invoke-static {p1, p0, v0}, Ldev/nino/squareglass/ProbeDiagnostics;->palette(Ljava/lang/String;II)V

    return-object v2

    :sswitch_data_0
    .sparse-switch
        -0x604c56d8 -> :sswitch_16
        -0x5eec4908 -> :sswitch_15
        -0x5eec48e9 -> :sswitch_14
        -0x4bf7591e -> :sswitch_13
        -0x4bf758ff -> :sswitch_12
        -0x4bf758e0 -> :sswitch_11
        -0x4bf758c1 -> :sswitch_10
        -0x4bf758a2 -> :sswitch_f
        -0x42d92bd3 -> :sswitch_e
        -0x34464bf4 -> :sswitch_d
        -0x34464bd5 -> :sswitch_c
        -0x34464bb6 -> :sswitch_b
        -0xd15a63d -> :sswitch_a
        0x1e34ac9b -> :sswitch_9
        0x1e34acba -> :sswitch_8
        0x1e34acd9 -> :sswitch_7
        0x1e34acf8 -> :sswitch_6
        0x42c17143 -> :sswitch_5
        0x56c17b8c -> :sswitch_4
        0x56c17bab -> :sswitch_3
        0x56c17bca -> :sswitch_2
        0x63c6611f -> :sswitch_1
        0x63ccb0c9 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_11
        :pswitch_e
        :pswitch_9
        :pswitch_8
        :pswitch_e
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_11
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public static secondary(Z)I
    .locals 0

    if-eqz p0, :cond_0

    const p0, -0x4b473c

    return p0

    :cond_0
    const p0, -0xa29d93

    return p0
.end method

.method public static surface(Z)I
    .locals 0

    if-eqz p0, :cond_0

    const p0, -0xe6e4de

    return p0

    :cond_0
    const/4 p0, -0x1

    return p0
.end method

.method private static tertiary(Z)I
    .locals 0

    if-eqz p0, :cond_0

    const p0, -0x656054

    return p0

    :cond_0
    const p0, -0x9f9a91

    return p0
.end method

.method public static wave(JLjava/lang/String;)J
    .locals 5

    .line 33
    sget-boolean v0, Ldev/nino/squareglass/ProbeDiagnostics;->enabled:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    sget v0, Ldev/nino/squareglass/ProbeDiagnostics;->wavePaletteCalls:I

    add-int/2addr v0, v1

    sput v0, Ldev/nino/squareglass/ProbeDiagnostics;->wavePaletteCalls:I

    .line 34
    :cond_0
    invoke-static {}, Ldev/nino/squareglass/SquarePalette;->isDark()Z

    move-result v0

    const/16 v2, 0x20

    ushr-long v2, p0, v2

    long-to-int v2, v2

    .line 37
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v3

    const/4 v4, -0x1

    sparse-switch v3, :sswitch_data_0

    :goto_0
    move v1, v4

    goto/16 :goto_1

    :sswitch_0
    const-string v1, "solidBaseBrighter"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    const/16 v1, 0xd

    goto/16 :goto_1

    :sswitch_1
    const-string v1, "solidAccentFill"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    const/16 v1, 0xc

    goto/16 :goto_1

    :sswitch_2
    const-string v1, "solidAccentDark"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    goto :goto_0

    :cond_3
    const/16 v1, 0xb

    goto/16 :goto_1

    :sswitch_3
    const-string v1, "solidBaseBright"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    goto :goto_0

    :cond_4
    const/16 v1, 0xa

    goto/16 :goto_1

    :sswitch_4
    const-string v1, "solidAccentDarker"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    goto :goto_0

    :cond_5
    const/16 v1, 0x9

    goto/16 :goto_1

    :sswitch_5
    const-string v1, "solidAccentBright"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    goto :goto_0

    :cond_6
    const/16 v1, 0x8

    goto :goto_1

    :sswitch_6
    const-string v1, "solidBaseBrightest"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7

    goto :goto_0

    :cond_7
    const/4 v1, 0x7

    goto :goto_1

    :sswitch_7
    const-string v1, "solidContrastDarkest"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8

    goto :goto_0

    :cond_8
    const/4 v1, 0x6

    goto :goto_1

    :sswitch_8
    const-string v1, "solidBaseFill"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    goto :goto_0

    :cond_9
    const/4 v1, 0x5

    goto :goto_1

    :sswitch_9
    const-string v1, "solidAccentBrighter"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    goto :goto_0

    :cond_a
    const/4 v1, 0x4

    goto :goto_1

    :sswitch_a
    const-string v1, "solidContrastDarker"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    goto/16 :goto_0

    :cond_b
    const/4 v1, 0x3

    goto :goto_1

    :sswitch_b
    const-string v1, "solidContrastFill"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    goto/16 :goto_0

    :cond_c
    const/4 v1, 0x2

    goto :goto_1

    :sswitch_c
    const-string v3, "solidContrastDark"

    invoke-virtual {p2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_e

    goto/16 :goto_0

    :sswitch_d
    const-string v1, "solidAccentDarkest"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d

    goto/16 :goto_0

    :cond_d
    const/4 v1, 0x0

    :cond_e
    :goto_1
    packed-switch v1, :pswitch_data_0

    .line 55
    const-string v1, "opacityBaseFill"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result p0

    ushr-int/lit8 p1, v2, 0x18

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result p0

    goto/16 :goto_2

    .line 56
    :cond_f
    const-string v1, "opacityBaseBright"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_10

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result p0

    ushr-int/lit8 p1, v2, 0x18

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result p0

    goto/16 :goto_2

    .line 57
    :cond_10
    const-string v1, "opacityContrastFill"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_11

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p0

    ushr-int/lit8 p1, v2, 0x18

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result p0

    goto/16 :goto_2

    .line 58
    :cond_11
    const-string v1, "opacityAccent"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_12

    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p0

    ushr-int/lit8 p1, v2, 0x18

    invoke-static {p0, p1}, Ldev/nino/squareglass/SquarePalette;->alpha(II)I

    move-result p0

    goto/16 :goto_2

    :cond_12
    return-wide p0

    :pswitch_0
    if-eqz v0, :cond_13

    const p0, -0xdddad2

    goto/16 :goto_2

    :cond_13
    const p0, -0x161510

    goto/16 :goto_2

    .line 48
    :pswitch_1
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p0

    goto/16 :goto_2

    :pswitch_2
    if-eqz v0, :cond_14

    const p0, -0x4b473c

    goto :goto_2

    :cond_14
    const p0, -0xcac6bf

    goto :goto_2

    .line 39
    :pswitch_3
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->surface(Z)I

    move-result p0

    goto :goto_2

    :pswitch_4
    if-eqz v0, :cond_15

    const p0, -0x7d786a

    goto :goto_2

    :cond_15
    const p0, -0xdbd8d2

    goto :goto_2

    :pswitch_5
    if-eqz v0, :cond_16

    const p0, -0x2a2721

    goto :goto_2

    :cond_16
    const p0, -0xbab6af

    goto :goto_2

    :pswitch_6
    if-eqz v0, :cond_17

    const p0, -0xcfcbc1

    goto :goto_2

    :cond_17
    const p0, -0x1f1d15

    goto :goto_2

    .line 47
    :pswitch_7
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->tertiary(Z)I

    move-result p0

    goto :goto_2

    .line 38
    :pswitch_8
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->base(Z)I

    move-result p0

    goto :goto_2

    :pswitch_9
    if-eqz v0, :cond_18

    const p0, -0x171510

    goto :goto_2

    :cond_18
    const p0, -0x9d978d

    goto :goto_2

    .line 44
    :pswitch_a
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->tertiary(Z)I

    move-result p0

    goto :goto_2

    .line 42
    :pswitch_b
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->ink(Z)I

    move-result p0

    goto :goto_2

    .line 43
    :pswitch_c
    invoke-static {v0}, Ldev/nino/squareglass/SquarePalette;->secondary(Z)I

    move-result p0

    goto :goto_2

    :pswitch_d
    if-eqz v0, :cond_19

    const p0, -0xa29d93

    goto :goto_2

    :cond_19
    const p0, -0xe6e4de

    .line 61
    :goto_2
    invoke-static {p0}, Landroidx/compose/ui/graphics/ColorKt;->Color(I)J

    move-result-wide p0

    return-wide p0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x7aac5ec5 -> :sswitch_d
        -0x6c3f881d -> :sswitch_c
        -0x6c3e8210 -> :sswitch_b
        -0x5a7de830 -> :sswitch_a
        -0x36ea8064 -> :sswitch_9
        0x570cfbf -> :sswitch_8
        0xac0e2c3 -> :sswitch_7
        0x1633eb90 -> :sswitch_6
        0x546362af -> :sswitch_5
        0x56e1aa58 -> :sswitch_4
        0x6625ea36 -> :sswitch_3
        0x67730c6b -> :sswitch_2
        0x67741278 -> :sswitch_1
        0x74544163 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
