.class public final synthetic Ldev/nino/squareglass/PageGlass$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/p;


# instance fields
.field public final synthetic f$0:F

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(FZ)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Ldev/nino/squareglass/PageGlass$$ExternalSyntheticLambda3;->f$0:F

    iput-boolean p2, p0, Ldev/nino/squareglass/PageGlass$$ExternalSyntheticLambda3;->f$1:Z

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget v0, p0, Ldev/nino/squareglass/PageGlass$$ExternalSyntheticLambda3;->f$0:F

    iget-boolean p0, p0, Ldev/nino/squareglass/PageGlass$$ExternalSyntheticLambda3;->f$1:Z

    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {v0, p0, p1, p2}, Ldev/nino/squareglass/PageGlass;->$r8$lambda$nrx0WLjZwXi4bbkP2pvB1SPxEwQ(FZLandroidx/compose/runtime/Composer;I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
