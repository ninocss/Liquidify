.class Ldev/nino/squareglass/SleepTimer$7;
.super Ljava/lang/Object;
.source "SleepTimer.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/SleepTimer;->showInDialog(Landroid/app/Dialog;Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$glass:Ldev/nino/squareglass/LiquidMenuSurface;

.field final synthetic val$snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;


# direct methods
.method constructor <init>(Ldev/nino/squareglass/LiquidMenuSurface;Ldev/nino/squareglass/PlayerWindow$Snapshot;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 170
    iput-object p1, p0, Ldev/nino/squareglass/SleepTimer$7;->val$glass:Ldev/nino/squareglass/LiquidMenuSurface;

    iput-object p2, p0, Ldev/nino/squareglass/SleepTimer$7;->val$snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    .line 172
    iget-object p1, p0, Ldev/nino/squareglass/SleepTimer$7;->val$glass:Ldev/nino/squareglass/LiquidMenuSurface;

    invoke-virtual {p1}, Ldev/nino/squareglass/LiquidMenuSurface;->release()V

    iget-object p0, p0, Ldev/nino/squareglass/SleepTimer$7;->val$snapshot:Ldev/nino/squareglass/PlayerWindow$Snapshot;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ldev/nino/squareglass/PlayerWindow$Snapshot;->release()V

    :cond_0
    return-void
.end method
