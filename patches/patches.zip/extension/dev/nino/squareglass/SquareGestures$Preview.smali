.class final Ldev/nino/squareglass/SquareGestures$Preview;
.super Landroid/graphics/drawable/Drawable;
.source "SquareGestures.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldev/nino/squareglass/SquareGestures;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Preview"
.end annotation


# instance fields
.field action:I

.field final density:F

.field final icon:Landroid/graphics/Path;

.field final paint:Landroid/graphics/Paint;

.field progress:F

.field final textScale:F

.field travel:F


# direct methods
.method constructor <init>(Landroid/view/View;)V
    .locals 2

    .line 145
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 141
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    .line 142
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    .line 146
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    iput v0, p0, Ldev/nino/squareglass/SquareGestures$Preview;->density:F

    .line 147
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    iget p1, p1, Landroid/util/DisplayMetrics;->scaledDensity:F

    iput p1, p0, Ldev/nino/squareglass/SquareGestures$Preview;->textScale:F

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 26

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 155
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v7

    .line 156
    iget v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->travel:F

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    const/high16 v8, 0x3f800000    # 1.0f

    cmpg-float v3, v2, v8

    if-gez v3, :cond_0

    return-void

    .line 157
    :cond_0
    iget v3, v0, Ldev/nino/squareglass/SquareGestures$Preview;->travel:F

    const/4 v9, 0x0

    cmpl-float v3, v3, v9

    if-lez v3, :cond_1

    iget v3, v7, Landroid/graphics/Rect;->left:I

    int-to-float v3, v3

    goto :goto_0

    :cond_1
    iget v3, v7, Landroid/graphics/Rect;->right:I

    int-to-float v3, v3

    sub-float/2addr v3, v2

    .line 158
    :goto_0
    iget v4, v0, Ldev/nino/squareglass/SquareGestures$Preview;->travel:F

    cmpl-float v4, v4, v9

    if-lez v4, :cond_2

    iget v4, v7, Landroid/graphics/Rect;->left:I

    int-to-float v4, v4

    add-float/2addr v4, v2

    goto :goto_1

    :cond_2
    iget v2, v7, Landroid/graphics/Rect;->right:I

    int-to-float v4, v2

    .line 159
    :goto_1
    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    iget v2, v7, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    iget v5, v7, Landroid/graphics/Rect;->bottom:I

    int-to-float v5, v5

    invoke-virtual {v1, v3, v2, v4, v5}, Landroid/graphics/Canvas;->clipRect(FFFF)Z

    .line 160
    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 161
    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    iget v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->action:I

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-ne v5, v11, :cond_3

    const v5, -0x7fab27

    goto :goto_2

    :cond_3
    if-ne v5, v10, :cond_4

    const v5, -0x3793f5

    goto :goto_2

    :cond_4
    const v5, -0x30caa8

    :goto_2
    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 162
    iget v2, v7, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    iget v5, v7, Landroid/graphics/Rect;->bottom:I

    int-to-float v5, v5

    iget-object v6, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    move/from16 v25, v3

    move v3, v2

    move/from16 v2, v25

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    add-float v3, v2, v4

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v3, v2

    .line 163
    invoke-virtual {v7}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v4

    .line 164
    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    const/high16 v5, 0x40e00000    # 7.0f

    iget v6, v0, Ldev/nino/squareglass/SquareGestures$Preview;->density:F

    mul-float/2addr v6, v5

    sub-float v5, v4, v6

    invoke-virtual {v1, v3, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 165
    iget v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->density:F

    iget v6, v0, Ldev/nino/squareglass/SquareGestures$Preview;->progress:F

    invoke-static {v8, v6}, Ljava/lang/Math;->min(FF)F

    move-result v6

    const v7, 0x3df5c28f    # 0.12f

    mul-float/2addr v6, v7

    const v7, 0x3f6147ae    # 0.88f

    add-float/2addr v6, v7

    mul-float/2addr v5, v6

    invoke-virtual {v1, v5, v5}, Landroid/graphics/Canvas;->scale(FF)V

    .line 166
    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    const/4 v6, -0x1

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 167
    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    invoke-virtual {v2}, Landroid/graphics/Path;->reset()V

    .line 168
    iget v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->action:I

    .line 171
    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/4 v6, 0x3

    if-ne v2, v6, :cond_5

    const/high16 v2, 0x41100000    # 9.0f

    .line 169
    invoke-virtual {v5, v9, v2}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v11, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/16 v16, 0x0

    const/high16 v17, -0x3f200000    # -7.0f

    const/high16 v12, -0x3e780000    # -17.0f

    const/high16 v13, -0x40800000    # -1.0f

    const/high16 v14, -0x3f000000    # -8.0f

    const/high16 v15, -0x3ea00000    # -14.0f

    invoke-virtual/range {v11 .. v17}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/16 v23, 0x0

    const/high16 v24, 0x41100000    # 9.0f

    const/high16 v19, 0x41000000    # 8.0f

    const/high16 v20, -0x3ea00000    # -14.0f

    const/high16 v21, 0x41880000    # 17.0f

    const/high16 v22, -0x40800000    # -1.0f

    move-object/from16 v18, v2

    invoke-virtual/range {v18 .. v24}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    goto :goto_3

    :cond_5
    const/high16 v2, -0x3ed00000    # -11.0f

    const/high16 v6, -0x3f000000    # -8.0f

    .line 171
    invoke-virtual {v5, v2, v6}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/high16 v7, 0x41000000    # 8.0f

    invoke-virtual {v5, v7, v6}, Landroid/graphics/Path;->lineTo(FF)V

    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/high16 v6, -0x40800000    # -1.0f

    invoke-virtual {v5, v2, v6}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/high16 v8, 0x40400000    # 3.0f

    invoke-virtual {v5, v8, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 172
    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-virtual {v5, v2, v6}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/high16 v5, -0x3f800000    # -4.0f

    invoke-virtual {v2, v5, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 173
    iget v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->action:I

    .line 174
    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/high16 v6, 0x41500000    # 13.0f

    if-ne v2, v11, :cond_6

    const/high16 v2, 0x40800000    # 4.0f

    .line 173
    invoke-virtual {v5, v2, v8}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    const/high16 v8, 0x41400000    # 12.0f

    invoke-virtual {v5, v8, v7}, Landroid/graphics/Path;->lineTo(FF)V

    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    invoke-virtual {v5, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    invoke-virtual {v2}, Landroid/graphics/Path;->close()V

    goto :goto_3

    .line 174
    :cond_6
    invoke-virtual {v5, v7, v8}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    invoke-virtual {v2, v7, v6}, Landroid/graphics/Path;->lineTo(FF)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    invoke-virtual {v2, v8, v7}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    invoke-virtual {v2, v6, v7}, Landroid/graphics/Path;->lineTo(FF)V

    .line 176
    :goto_3
    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->icon:Landroid/graphics/Path;

    iget-object v5, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v5}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    .line 177
    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    iget-object v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    const/high16 v5, 0x41300000    # 11.0f

    iget v6, v0, Ldev/nino/squareglass/SquareGestures$Preview;->textScale:F

    mul-float/2addr v6, v5

    invoke-virtual {v2, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 178
    iget v2, v0, Ldev/nino/squareglass/SquareGestures$Preview;->action:I

    if-ne v2, v10, :cond_7

    const-string v2, "Play last"

    goto :goto_4

    :cond_7
    invoke-static {v2}, Ldev/nino/squareglass/SquareGestures;->label(I)Ljava/lang/String;

    move-result-object v2

    :goto_4
    const/high16 v5, 0x41b00000    # 22.0f

    iget v6, v0, Ldev/nino/squareglass/SquareGestures$Preview;->density:F

    mul-float/2addr v6, v5

    add-float/2addr v4, v6

    iget-object v0, v0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method public getOpacity()I
    .locals 0

    const/4 p0, -0x3

    return p0
.end method

.method public setAlpha(I)V
    .locals 0

    .line 180
    iget-object p0, p0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 0

    .line 181
    iget-object p0, p0, Ldev/nino/squareglass/SquareGestures$Preview;->paint:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    return-void
.end method

.method update(Landroid/view/View;IF)V
    .locals 1

    .line 150
    iput p2, p0, Ldev/nino/squareglass/SquareGestures$Preview;->action:I

    iput p3, p0, Ldev/nino/squareglass/SquareGestures$Preview;->progress:F

    invoke-virtual {p1}, Landroid/view/View;->getTranslationX()F

    move-result p2

    iput p2, p0, Ldev/nino/squareglass/SquareGestures$Preview;->travel:F

    .line 151
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p3

    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    move-result p1

    invoke-virtual {p0, p2, p3, v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 152
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method
