.class final Ldev/nino/squareglass/LinnNativeVolume;
.super Ljava/lang/Object;
.source "LinnNativeVolume.java"

# interfaces
.implements Lfq/f;


# instance fields
.field listening:Z

.field final maximum:Lrx/subjects/PublishSubject;

.field final provider:Ldev/nino/squareglass/LinnProvider;

.field final updates:Lrx/subjects/PublishSubject;


# direct methods
.method public static synthetic $r8$lambda$YJAtIItxd-GzTnJRKG9J1DVQnfw(Ldev/nino/squareglass/LinnNativeVolume;)V
    .locals 0

    invoke-direct {p0}, Ldev/nino/squareglass/LinnNativeVolume;->lambda$startListening$0()V

    return-void
.end method

.method constructor <init>(Ldev/nino/squareglass/LinnProvider;)V
    .locals 1

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    invoke-static {}, Lrx/subjects/PublishSubject;->a()Lrx/subjects/PublishSubject;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->maximum:Lrx/subjects/PublishSubject;

    .line 7
    invoke-static {}, Lrx/subjects/PublishSubject;->a()Lrx/subjects/PublishSubject;

    move-result-object v0

    iput-object v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->updates:Lrx/subjects/PublishSubject;

    .line 9
    iput-object p1, p0, Ldev/nino/squareglass/LinnNativeVolume;->provider:Ldev/nino/squareglass/LinnProvider;

    return-void
.end method

.method private synthetic lambda$startListening$0()V
    .locals 2

    .line 13
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->listening:Z

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->maximum:Lrx/subjects/PublishSubject;

    const/16 v1, 0x64

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Lrx/subjects/PublishSubject;->onNext(Ljava/lang/Object;)V

    .line 14
    iget-object v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz v0, :cond_1

    iget-object v1, v0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    if-eqz v1, :cond_1

    iget-object p0, p0, Ldev/nino/squareglass/LinnNativeVolume;->updates:Lrx/subjects/PublishSubject;

    iget-object v0, v0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    invoke-virtual {v0}, Landroidx/media/VolumeProviderCompat;->getCurrentVolume()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p0, v0}, Lrx/subjects/PublishSubject;->onNext(Ljava/lang/Object;)V

    :cond_1
    :goto_0
    return-void
.end method


# virtual methods
.method changed(I)V
    .locals 1

    .line 18
    iget-boolean v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->listening:Z

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnNativeVolume;->updates:Lrx/subjects/PublishSubject;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0, p1}, Lrx/subjects/PublishSubject;->onNext(Ljava/lang/Object;)V

    :cond_0
    return-void
.end method

.method public getMaxVolumeSubject()Lrx/subjects/f;
    .locals 0

    .line 10
    iget-object p0, p0, Ldev/nino/squareglass/LinnNativeVolume;->maximum:Lrx/subjects/PublishSubject;

    return-object p0
.end method

.method public getUpdateVolumeSubject()Lrx/subjects/f;
    .locals 0

    .line 11
    iget-object p0, p0, Ldev/nino/squareglass/LinnNativeVolume;->updates:Lrx/subjects/PublishSubject;

    return-object p0
.end method

.method public startListening()V
    .locals 2

    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->listening:Z

    iget-object v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object v0, v0, Ldev/nino/squareglass/LinnProvider;->main:Landroid/os/Handler;

    new-instance v1, Ldev/nino/squareglass/LinnNativeVolume$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Ldev/nino/squareglass/LinnNativeVolume$$ExternalSyntheticLambda0;-><init>(Ldev/nino/squareglass/LinnNativeVolume;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public stopListening()V
    .locals 1

    const/4 v0, 0x0

    .line 16
    iput-boolean v0, p0, Ldev/nino/squareglass/LinnNativeVolume;->listening:Z

    return-void
.end method

.method public updateVolume(I)V
    .locals 1

    .line 17
    iget-object p0, p0, Ldev/nino/squareglass/LinnNativeVolume;->provider:Ldev/nino/squareglass/LinnProvider;

    iget-object p0, p0, Ldev/nino/squareglass/LinnProvider;->player:Ldev/nino/squareglass/LinnPlayer;

    if-eqz p0, :cond_0

    iget-object v0, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    if-eqz v0, :cond_0

    iget-object p0, p0, Ldev/nino/squareglass/LinnPlayer;->volume:Landroidx/media/VolumeProviderCompat;

    invoke-virtual {p0, p1}, Landroidx/media/VolumeProviderCompat;->onSetVolumeTo(I)V

    :cond_0
    return-void
.end method
