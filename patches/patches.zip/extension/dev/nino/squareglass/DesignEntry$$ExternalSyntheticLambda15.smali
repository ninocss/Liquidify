.class public final synthetic Ldev/nino/squareglass/DesignEntry$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/l;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-static {p0}, Ldev/nino/squareglass/DesignEntry;->$r8$lambda$jBYzxjK_1-qhmzO1QfrRzpW5j7o(I)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
