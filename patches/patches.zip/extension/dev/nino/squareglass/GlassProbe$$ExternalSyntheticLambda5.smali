.class public final synthetic Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lam0/a;


# instance fields
.field public final synthetic f$0:Lam0/a;


# direct methods
.method public synthetic constructor <init>(Lam0/a;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda5;->f$0:Lam0/a;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Ldev/nino/squareglass/GlassProbe$$ExternalSyntheticLambda5;->f$0:Lam0/a;

    invoke-static {p0}, Ldev/nino/squareglass/GlassProbe;->$r8$lambda$Hna9nCja0-wfbhepC_99fi39BE8(Lam0/a;)Lkotlin/u;

    move-result-object p0

    return-object p0
.end method
