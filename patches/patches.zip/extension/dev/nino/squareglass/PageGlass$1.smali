.class public final synthetic Ldev/nino/squareglass/PageGlass$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# instance fields
.field public final synthetic f$0:Landroid/view/View;

.field public final synthetic f$1:Landroidx/compose/ui/platform/ComposeView;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;Landroidx/compose/ui/platform/ComposeView;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/nino/squareglass/PageGlass$1;->f$0:Landroid/view/View;

    iput-object p2, p0, Ldev/nino/squareglass/PageGlass$1;->f$1:Landroidx/compose/ui/platform/ComposeView;

    return-void
.end method


# virtual methods
.method public final onPreDraw()Z
    .locals 1

    .line 0
    iget-object v0, p0, Ldev/nino/squareglass/PageGlass$1;->f$0:Landroid/view/View;

    iget-object p0, p0, Ldev/nino/squareglass/PageGlass$1;->f$1:Landroidx/compose/ui/platform/ComposeView;

    invoke-static {v0, p0}, Ldev/nino/squareglass/PageGlass;->install$lambda$0(Landroid/view/View;Landroidx/compose/ui/platform/ComposeView;)Z

    move-result p0

    return p0
.end method
