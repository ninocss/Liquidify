.class Ldev/nino/squareglass/ProbeDiagnostics$2;
.super Ljava/lang/Object;
.source "ProbeDiagnostics.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/nino/squareglass/ProbeDiagnostics;->install(Landroid/app/Activity;Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$activity:Landroid/app/Activity;

.field final synthetic val$lifetime:Landroid/view/View;

.field final synthetic val$receiver:Landroid/content/BroadcastReceiver;


# direct methods
.method constructor <init>(Landroid/app/Activity;Landroid/content/BroadcastReceiver;Landroid/view/View;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 91
    iput-object p1, p0, Ldev/nino/squareglass/ProbeDiagnostics$2;->val$activity:Landroid/app/Activity;

    iput-object p2, p0, Ldev/nino/squareglass/ProbeDiagnostics$2;->val$receiver:Landroid/content/BroadcastReceiver;

    iput-object p3, p0, Ldev/nino/squareglass/ProbeDiagnostics$2;->val$lifetime:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 1

    .line 94
    iget-object p1, p0, Ldev/nino/squareglass/ProbeDiagnostics$2;->val$activity:Landroid/app/Activity;

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Landroid/view/Window;->clearFlags(I)V

    .line 95
    iget-object p1, p0, Ldev/nino/squareglass/ProbeDiagnostics$2;->val$activity:Landroid/app/Activity;

    iget-object v0, p0, Ldev/nino/squareglass/ProbeDiagnostics$2;->val$receiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p1, v0}, Landroid/app/Activity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 96
    iget-object p1, p0, Ldev/nino/squareglass/ProbeDiagnostics$2;->val$lifetime:Landroid/view/View;

    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    return-void
.end method
